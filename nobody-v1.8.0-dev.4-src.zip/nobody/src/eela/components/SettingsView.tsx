// ── NOBODY EELA · Settings ───────────────────────────────────────────────────
// One calm paper card of rows. The Interface row is the home of UI switching
// (Classic / Cinema / EELA) — switching plays the shell's intro veil.

import { PanelBottom, FolderOpen, Keyboard } from "lucide-react";
import { useDesktopRows, rowKeys } from "../../shared/desktop/useDesktopRows";
import { HotkeyList } from "../../shared/desktop/HotkeyList";
import { Languages, Moon, Wand2, Type, Music4, BarChart3, Layers, Gauge, Disc3, Blend, AudioWaveform, SlidersHorizontal, Volume2, ShieldCheck, VolumeX, Radio } from "lucide-react";
import { openScrobbleSheet } from "../../shared/scrobble/sheetStore";
import { useScrobbleSummary } from "../../shared/scrobble/ScrobbleSheet";
import { useSettings } from "../../cinema/store/settings";
import { useT } from "../../cinema/lib/useT";
import { LANGS } from "../../cinema/i18n";
import { switchUiMode, useUiMode } from "../../uiMode";
import { usePerfLite } from "../../perfMode";
import type { EelaLyricsStyle, EqStyle, Lang, ThemeMode } from "../../cinema/types";
import type { DictKey } from "../../cinema/i18n";
import { useSoundFx, fmtDb, RG_MODES } from "../../cinema/lib/useSoundFx";
import { EQ_MAX_DB, EQ_MIN_DB, PREAMP_MAX_DB, PREAMP_MIN_DB, fmtFreq } from "../../shared/audioFx";

// V1.4.0: the RU option. The shared LANGS array gains "ru" when the i18n
// round lands; until then a local "RU" pill is appended so the picker already
// offers it (de-duped, so either merge order renders exactly one RU).
const LANG_OPTS: { id: Lang; label: string }[] = (() => {
  const base = LANGS.map((l) => ({ id: l.id, label: l.label }));
  if (!base.some((l) => (l.id as string) === "ru")) base.push({ id: "ru" as unknown as Lang, label: "RU" });
  return base;
})();

export function SettingsView() {
  const t = useT();
  const s = useSettings();
  const uiMode = useUiMode();
  const [perfLite, setPerfLite] = usePerfLite();
  const deskRows = useDesktopRows();

  const themes: { id: ThemeMode; label: string }[] = [
    { id: "dark", label: t("stDark") },
    { id: "light", label: t("stLight") },
    { id: "contrast", label: t("stContrast") },
  ];

  const lyricStyles: { id: EelaLyricsStyle; label: string }[] = [
    { id: "calm", label: t("eCalm") },
    { id: "karaoke", label: t("stKaraoke") },
    { id: "minimal", label: t("stMinimal") },
  ];

  const eqStyles: { id: EqStyle; label: string }[] = [
    { id: "bars", label: t("stEqBars") },
    { id: "dots", label: t("stEqDots") },
    { id: "ring", label: t("stEqRing") },
    { id: "random", label: t("stEqRandom") },
  ];

  const faces: { id: "classic" | "cinema" | "eela" | "alok"; label: string; sub: string }[] = [
    { id: "classic", label: t("uiClassic"), sub: t("uiClassicSub") },
    { id: "cinema", label: t("uiCinema"), sub: t("uiCinemaSub") },
    { id: "eela", label: t("uiEela"), sub: t("uiEelaSub") },
    { id: "alok", label: t("uiAlok"), sub: t("uiAlokSub") },
  ];

  const xfPct = Math.round(((s.crossfade ?? 0) / 12) * 100);
  const sizePct = Math.round(((s.lyricsSize - 0.8) / (1.5 - 0.8)) * 100);

  return (
    <div className="ne-scroll h-full pb-[120px]">
      <div className="mx-auto max-w-[860px] px-5 pt-[86px] sm:px-8">
        <div className="ne-eyebrow mb-1.5">NOBODY</div>
        <h1 className="ne-display ne-h1">{t("navSettings")}</h1>

        <div className="ne-card mt-5 divide-y" style={{ borderColor: "var(--line2)" }}>
          {/* language */}
          <Row icon={Languages} label={t("stLanguage")}>
            <div className="ne-seg" role="group" aria-label={t("stLanguage")}>
              {LANG_OPTS.map((l) => (
                <button key={l.id} className="ne-seg-btn" data-on={s.lang === l.id} onClick={() => s.set("lang", l.id as Lang)}>
                  {l.label}
                </button>
              ))}
            </div>
          </Row>

          {/* theme — EELA's own (paper-light by default, independent of cinema) */}
          <Row icon={Moon} label={t("stTheme")}>
            <div className="ne-seg" role="group" aria-label={t("stTheme")}>
              {themes.map((th) => (
                <button key={th.id} className="ne-seg-btn" data-on={(s.eelaTheme ?? "light") === th.id} onClick={() => s.set("eelaTheme", th.id)}>
                  {th.label}
                </button>
              ))}
            </div>
          </Row>

          {/* ── interface switcher (the UI home) ── */}
          <Row icon={Layers} label={t("stInterface")} sub={t("stInterfaceSub")}>
            <div className="flex flex-wrap justify-end gap-2">
              {faces.map((f) => {
                const active = uiMode === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => switchUiMode(f.id)}
                    disabled={active}
                    className="ne-btn flex-col !items-start !gap-0.5 !rounded-[14px] !px-4 !py-2.5"
                    style={
                      active
                        ? { background: "var(--accent)", borderColor: "transparent", color: "var(--on-accent)" }
                        : undefined
                    }
                    aria-pressed={active}
                    title={f.sub}
                  >
                    <span className="text-[12.5px] font-semibold">{f.label}</span>
                    <span className="text-[10px] opacity-70">{active ? "✓ " : ""}{f.sub}</span>
                  </button>
                );
              })}
            </div>
          </Row>

          {/* accent from cover */}
          <Row icon={Wand2} label={t("stAccent")} sub={t("stAccentSub")}>
            <span
              role="switch"
              aria-checked={s.accentFromCover}
              tabIndex={0}
              className="ne-switch"
              data-on={s.accentFromCover}
              onClick={() => s.set("accentFromCover", !s.accentFromCover)}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") s.set("accentFromCover", !s.accentFromCover); }}
            />
          </Row>

          {/* gapless (V1.6.0 · P3) */}
          <Row icon={Disc3} label={t("stGapless")} sub={t("stGaplessSub")}>
            <span
              role="switch"
              aria-checked={s.gapless !== false}
              aria-label={t("stGapless")}
              tabIndex={0}
              className="ne-switch"
              data-on={s.gapless !== false}
              onClick={() => s.set("gapless", s.gapless === false)}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); s.set("gapless", s.gapless === false); } }}
            />
          </Row>

          {/* crossfade (V1.6.0 · P3) */}
          <Row icon={Blend} label={t("stCrossfade")} sub={t("stCrossfadeSub")}>
            <div className="flex w-[240px] max-w-full items-center gap-3">
              <input
                type="range"
                min={0}
                max={12}
                step={1}
                value={s.crossfade ?? 0}
                onChange={(e) => s.set("crossfade", parseInt(e.target.value, 10) || 0)}
                className="ne-range flex-1"
                style={{ ["--ne-val" as any]: `${xfPct}%` }}
                aria-label={t("stCrossfade")}
              />
              <span className="tnum w-14 text-end text-[11px] text-[var(--mut)]">
                {(s.crossfade ?? 0) > 0 ? `${s.crossfade} ${t("stSeconds")}` : t("stCrossfadeOff")}
              </span>
            </div>
          </Row>

          {/* performance mode (V1.5.5 · P2) */}
          <Row icon={Gauge} label={t("stPerfLite")} sub={t("stPerfLiteSub")}>
            <span
              role="switch"
              aria-checked={perfLite}
              aria-label={t("stPerfLite")}
              tabIndex={0}
              className="ne-switch"
              data-on={perfLite}
              onClick={() => setPerfLite(!perfLite)}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setPerfLite(!perfLite); } }}
            />
          </Row>

          {/* 1.8.0 (P5): tray + "Open with" + global shortcuts (desktop shell only) */}
          {deskRows.map((r) => {
            const k = rowKeys(r);
            return (
              <div key={r.id} data-desk-row={r.id} data-disabled={r.disabled || undefined} style={r.disabled ? { opacity: 0.6 } : undefined}>
                <Row icon={r.id === "tray" ? PanelBottom : r.id === "hotkeys" ? Keyboard : FolderOpen} label={t(k.label)} sub={t(k.sub)}>
                  <span
                    role="switch"
                    aria-checked={r.on}
                    aria-disabled={r.disabled || undefined}
                    aria-label={t(k.label)}
                    tabIndex={0}
                    className="ne-switch"
                    data-on={r.on}
                    onClick={r.toggle}
                    onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); r.toggle(); } }}
                  />
                </Row>
                {r.id === "hotkeys" && <HotkeyList face="eela" />}
              </div>
            );
          })}

          {/* scrobbling (1.7.0) */}
          <ScrobbleRow />

          {/* lyrics size */}
          <Row icon={Type} label={t("stLyricsSize")}>
            <div className="flex w-[240px] max-w-full items-center gap-3">
              <input
                type="range"
                min={0.8}
                max={1.5}
                step={0.05}
                value={s.lyricsSize}
                onChange={(e) => s.set("lyricsSize", parseFloat(e.target.value))}
                className="ne-range flex-1"
                style={{ ["--ne-val" as any]: `${sizePct}%` }}
                aria-label={t("stLyricsSize")}
              />
              <span className="tnum w-7 text-end text-[11px] text-[var(--mut)]">{Math.round(s.lyricsSize * 18)}</span>
            </div>
          </Row>

          {/* lyrics style */}
          <Row icon={Music4} label={t("stLyricsStyle")}>
            <div className="ne-seg" role="group" aria-label={t("stLyricsStyle")}>
              {lyricStyles.map((st) => (
                <button
                  key={st.id}
                  className="ne-seg-btn"
                  data-on={(s.eelaLyricsStyle ?? "karaoke") === st.id}
                  onClick={() => s.set("eelaLyricsStyle", st.id)}
                >
                  {st.label}
                </button>
              ))}
            </div>
          </Row>

          {/* equalizer style */}
          <Row icon={BarChart3} label={t("stEq")} last>
            <div className="ne-seg" role="group" aria-label={t("stEq")}>
              {eqStyles.map((eq) => (
                <button key={eq.id} className="ne-seg-btn" data-on={s.eqStyle === eq.id} onClick={() => s.set("eqStyle", eq.id)}>
                  {eq.label}
                </button>
              ))}
            </div>
          </Row>
        </div>

        {/* ── Sound (V1.6.2 · P3): EQ 6/10 + preamp + presets, ReplayGain ── */}
        <SoundCard />

        <div className="mt-8 flex items-center justify-between border-t pt-4 text-[10.5px] text-[var(--faint)]" style={{ borderColor: "var(--line)" }}>
          <span>{t("stVersion")}</span>
          <span className="ne-display italic">NOBODY · {t("credit")}</span>
        </div>
      </div>
    </div>
  );
}

function Row({ icon: Icon, label, sub, children, last }: { icon: any; label: string; sub?: string; children: React.ReactNode; last?: boolean }) {
  return (
    <div
      className="flex flex-wrap items-center justify-between gap-x-6 gap-y-3 px-5 py-4.5 sm:px-6"
      style={last ? undefined : { borderBottom: "1px solid var(--line2)" }}
    >
      <div className="flex min-w-0 items-center gap-3.5">
        <span
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full"
          style={{ background: "color-mix(in srgb, var(--accent) 12%, transparent)", color: "var(--accent-ink)" }}
        >
          <Icon size={14} />
        </span>
        <div className="min-w-0">
          <div className="text-[13px] font-semibold leading-tight">{label}</div>
          {sub && <div className="mt-0.5 max-w-[380px] text-[11px] leading-snug text-[var(--mut)]">{sub}</div>}
        </div>
      </div>
      <div className="flex shrink-0 items-center justify-end">{children}</div>
    </div>
  );
}

// ── Sound card (V1.6.2 · P3) ─────────────────────────────────────────────────
// EELA has no FX sheet, so the shared sound controls live here. Same hook as
// Cinema / ALOK (useSoundFx), so a change in any face shows up everywhere.
const pctOf = (v: number, lo: number, hi: number) => `${Math.round(((v - lo) / (hi - lo)) * 100)}%`;

function DbRange({ value, min, max, onChange, label, disabled }: {
  value: number; min: number; max: number; onChange: (v: number) => void; label: string; disabled?: boolean;
}) {
  return (
    <div className="flex w-[240px] max-w-full items-center gap-3">
      <input
        type="range"
        min={min}
        max={max}
        step={0.5}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
        onDoubleClick={() => onChange(0)}
        className="ne-range flex-1"
        style={{ ["--ne-val" as any]: pctOf(value, min, max) }}
        aria-label={label}
      />
      <span className="tnum w-14 text-end text-[11px] text-[var(--mut)]">{fmtDb(value)} dB</span>
    </div>
  );
}

function SoundCard() {
  const t = useT();
  const fx = useSoundFx();
  const rgOff = fx.rg.mode === "off";
  const eqDim = fx.eqOn ? undefined : { opacity: 0.45 };
  const rgDim = rgOff ? { opacity: 0.45, pointerEvents: "none" as const } : undefined;

  return (
    <>
      <div className="ne-eyebrow mb-2 mt-8">{t("stSound")}</div>
      <div className="ne-card" style={{ borderColor: "var(--line2)" }}>
        {/* equalizer on/off + band layout */}
        <Row icon={AudioWaveform} label={t("stEqualizer")} sub={t("stEqualizerSub")}>
          <div className="flex items-center gap-3">
            <div className="ne-seg" role="group" aria-label={t("fxBands")}>
              {([6, 10] as const).map((b) => (
                <button key={b} className="ne-seg-btn" data-on={fx.bands === b} aria-pressed={fx.bands === b} onClick={() => fx.setBands(b)}>
                  {t(b === 6 ? "fxBands6" : "fxBands10")}
                </button>
              ))}
            </div>
            <span
              role="switch"
              aria-checked={fx.eqOn}
              aria-label={t("stEqualizer")}
              tabIndex={0}
              className="ne-switch"
              data-on={fx.eqOn}
              onClick={fx.toggleEq}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fx.toggleEq(); } }}
            />
          </div>
        </Row>

        {/* band sliders */}
        <div className="px-5 py-4 transition-opacity sm:px-6" style={{ borderBottom: "1px solid var(--line2)", ...eqDim }}>
          <div className="flex items-end justify-between gap-1 rounded-2xl px-2 py-3" style={{ background: "color-mix(in srgb, var(--accent) 5%, transparent)" }}>
            {fx.freqs.map((f, i) => (
              <div key={`${fx.bands}-${f}`} className="flex min-w-0 flex-1 flex-col items-center gap-1.5">
                <span className="tnum text-[9.5px] text-[var(--faint)]">{fmtDb(fx.gains[i] ?? 0)}</span>
                <input
                  type="range"
                  min={EQ_MIN_DB}
                  max={EQ_MAX_DB}
                  step={0.5}
                  value={fx.gains[i] ?? 0}
                  onChange={(e) => fx.setGain(i, Number(e.target.value))}
                  onDoubleClick={() => fx.setGain(i, 0)}
                  className="ne-vert"
                  disabled={!fx.eqOn}
                  aria-label={`${f} Hz`}
                />
                <span className="tnum text-[9.5px] text-[var(--mut)]">{fmtFreq(f)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* preset */}
        <Row icon={SlidersHorizontal} label={t("stEqPreset")} sub={fx.eqOn && !fx.activePreset ? t("fxPresetCustom") : undefined}>
          <div className="flex max-w-[460px] flex-wrap justify-end gap-1.5" style={eqDim}>
            {fx.presets.map((id) => (
              <button key={id} className="ne-chip" data-on={fx.activePreset === id} disabled={!fx.eqOn} onClick={() => fx.applyPreset(id)}>
                {t(`fxPreset_${id}` as DictKey)}
              </button>
            ))}
            {fx.eqOn && (fx.activePreset !== "flat" || Math.abs(fx.preamp) > 0.01) && (
              <button className="ne-chip" onClick={fx.resetEq}>{t("fxReset")}</button>
            )}
          </div>
        </Row>

        {/* preamp */}
        <Row icon={Gauge} label={t("fxPreamp")} sub={t("fxPreampSub")}>
          <div style={eqDim}>
            <DbRange value={fx.preamp} min={PREAMP_MIN_DB} max={PREAMP_MAX_DB} onChange={fx.setPreamp} label={t("fxPreamp")} disabled={!fx.eqOn} />
          </div>
        </Row>

        {/* ReplayGain mode */}
        <Row icon={Volume2} label={t("fxRg")} sub={t("fxRgSub")}>
          <div className="ne-seg" role="group" aria-label={t("fxRg")}>
            {RG_MODES.map((m) => (
              <button key={m} className="ne-seg-btn" data-on={fx.rg.mode === m} aria-pressed={fx.rg.mode === m} onClick={() => fx.setRg({ mode: m })}>
                {t(m === "off" ? "fxRgOff" : m === "track" ? "fxRgTrack" : "fxRgAlbum")}
              </button>
            ))}
          </div>
        </Row>

        <div className="transition-opacity" style={rgDim} aria-disabled={rgOff}>
          <Row icon={Blend} label={t("fxRgPreamp")}>
            <DbRange value={fx.rg.preamp} min={-12} max={12} onChange={(v) => fx.setRg({ preamp: v })} label={t("fxRgPreamp")} disabled={rgOff} />
          </Row>
          <Row icon={VolumeX} label={t("fxRgFallback")}>
            <DbRange value={fx.rg.fallback} min={-12} max={0} onChange={(v) => fx.setRg({ fallback: v })} label={t("fxRgFallback")} disabled={rgOff} />
          </Row>
          <Row
            icon={ShieldCheck}
            label={t("fxRgClip")}
            sub={fx.rgNow.hasTrack ? `${t("fxRgNow")}: ${fmtDb(fx.rgNow.db)} dB${fx.rgNow.tagged ? "" : ` · ${t("fxRgNoTag")}`}` : undefined}
          >
            <span
              role="switch"
              aria-checked={fx.rg.preventClip}
              aria-label={t("fxRgClip")}
              tabIndex={rgOff ? -1 : 0}
              className="ne-switch"
              data-on={fx.rg.preventClip}
              onClick={() => fx.setRg({ preventClip: !fx.rg.preventClip })}
              onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fx.setRg({ preventClip: !fx.rg.preventClip }); } }}
            />
          </Row>
        </div>
        <div className="px-5 py-3.5 text-[11px] leading-snug text-[var(--faint)] sm:px-6">{t("fxRgHint")}</div>
      </div>
    </>
  );
}

/* 1.7.0: Last.fm / ListenBrainz status + entry */
function ScrobbleRow() {
  const t = useT();
  const sum = useScrobbleSummary();
  return (
    <Row icon={Radio} label={t("scOpen")} sub={sum.on ? sum.text : t("scSettingsSub")}>
      <button className="ne-chip" onClick={() => openScrobbleSheet("eela")} data-scrobble-open data-warn={sum.warn || undefined}>
        {t("scManage")}
      </button>
    </Row>
  );
}
