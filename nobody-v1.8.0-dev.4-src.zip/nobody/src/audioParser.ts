// Native zero-dependency audio metadata, cover-art AND embedded-lyrics extractor.
// PHASE-4: fully replaces the ~1MB `music-metadata` bundle. Everything below
// parses from at most the first 3MB of the file (+ an optional small tail
// slice for formats that keep their metadata/duration at the end of file).
//
// Supported containers:
//   MP3 (ID3v2.3/v2.4 tags + MPEG frame header + Xing/Info duration)
//   FLAC (STREAMINFO + VORBIS_COMMENT + PICTURE blocks)
//   MP4/M4A (moov→mvhd duration + udta→meta→ilst tags/covr/©lyr)
//   OGG / Opus (id headers + VorbisComment + last-page granule duration)
//   WAV (fmt/data chunks + LIST/INFO tags + embedded id3 chunk)
//   AIFF (COMM chunk + embedded id3 chunk)

import { applyReplayGainTag, normalizeGenre, ID3_GENRES, type ReplayGainInfo } from "./shared/replayGain";

export interface ParsedAudioMeta {
  title?: string;
  /** V1.6.1 (P3): normalised genre ("Rock; Pop" for multi-value tags). */
  genre?: string;
  /** V1.6.1 (P3): ReplayGain / R128 loudness tags. */
  replayGain?: ReplayGainInfo;
  artist?: string;
  album?: string;
  year?: string;
  cover?: string;
  /** Raw embedded lyric text – may already contain [mm:ss.xx] LRC timestamps. */
  lyrics?: string;
  /* ---- PHASE-4 technical info (previously provided by music-metadata) ---- */
  /** Seconds. Only set when the value is trustworthy (exact header value or
   *  a real-size based estimate); otherwise the caller probes the player. */
  duration?: number;
  container?: string;
  codec?: string;
  /** bits per second */
  bitrate?: number;
  sampleRate?: number;
  channels?: number;
  bitDepth?: number;
}

export type ParseAudioOptions = {
  /** Bytes from the physical END of the file. Desktop imports pass a small
   *  tail File; browser imports pass the full File itself. Used to reach an
   *  MP4 `moov` atom written at EOF and the last OggS page (duration). */
  tail?: File | Uint8Array;
  /** Real on-disk size — desktop head-Files only report the 3MB head size. */
  realSize?: number;
  /** 1.7.0 (P4): random access into the PHYSICAL file for boxes/tags that
   *  lie outside head + tail (a big MP4 `moov` straddling the 3 MB head, an
   *  ID3 tag holding a 5 MB cover). Desktop passes a bounded readSlice;
   *  a complete browser File gets one automatically. Must return exactly
   *  `length` bytes or throw. */
  readRange?: (start: number, length: number) => Promise<Uint8Array>;
};

/** 1.7.0 (P4): largest out-of-head region the parser will fetch (a moov with
 *  a 12 MB cover + sample tables, or a whole ID3 tag). */
const MAX_RANGE_READ = 24 * 1024 * 1024;

/** Head bytes (offset 0) + optional tail bytes (at realSize - tail.length)
 *  + optional random access. */
type ByteSource = {
  head: Uint8Array;
  tail?: Uint8Array;
  tailStart: number;
  size: number;
  read?: (start: number, length: number) => Promise<Uint8Array>;
};

async function readBytes(src: ByteSource, start: number, length: number): Promise<Uint8Array | undefined> {
  if (start < 0 || length < 0 || start + length > src.size) return undefined;
  const end = start + length;
  if (end <= src.head.length) return src.head.subarray(start, end);
  const t = src.tail;
  if (t && start >= src.tailStart && end <= src.tailStart + t.length) {
    return t.subarray(start - src.tailStart, end - src.tailStart);
  }
  if (src.read && length <= MAX_RANGE_READ) {
    try {
      const b = await src.read(start, length);
      if (b && b.byteLength === length) return b;
    } catch {
      /* fall through */
    }
  }
  return undefined;
}

/** V1.6.1 (P3): fold a loudness tag into meta.replayGain. */
function rgTag(meta: ParsedAudioMeta, key: string, value: string): boolean {
  const rg = meta.replayGain ?? {};
  const hit = applyReplayGainTag(rg, key, value);
  if (hit && (rg.trackGain !== undefined || rg.albumGain !== undefined || rg.trackPeak !== undefined || rg.albumPeak !== undefined)) {
    meta.replayGain = rg;
  }
  return hit;
}

/** 3 MB captures even large embedded covers + full lyric frames. */
const HEAD_BYTES = 1024 * 1024 * 3;

export async function parseAudioFileMetadata(file: File, options: ParseAudioOptions = {}): Promise<ParsedAudioMeta> {
  try {
    const buffer = await file.slice(0, HEAD_BYTES).arrayBuffer();
    if (buffer.byteLength < 12) return {};
    const view = new DataView(buffer);
    const u8 = new Uint8Array(buffer);

    const realSize = options.realSize ?? file.size;
    // A File that IS the whole physical file (browser import) can be sliced
    // directly; desktop head-Files rely on options.readRange.
    const complete = file.size >= realSize;
    const src: ByteSource = {
      head: u8,
      tailStart: 0,
      size: Math.max(realSize, u8.length),
      read:
        options.readRange ??
        (complete ? async (start, length) => new Uint8Array(await file.slice(start, start + length).arrayBuffer()) : undefined),
    };

    // ---- FLAC -------------------------------------------------------------
    /* NOTE: the FLAC stream marker is "fLaC" — CAPITAL C (0x43). The old
       parser compared against 0x63 (lowercase 'c') so the native FLAC path
       NEVER matched; it only worked because music-metadata did all the work.
       Caught by the synthetic-container test suite. */
    if (u8[0] === 0x66 && u8[1] === 0x4c && u8[2] === 0x61 && u8[3] === 0x43) {
      return parseFLAC(buffer, view);
    }

    // ---- OGG / Opus ---------------------------------------------------------
    if (u8[0] === 0x4f && u8[1] === 0x67 && u8[2] === 0x67 && u8[3] === 0x53) {
      const tail = await readTailBytes(options.tail, 256 * 1024);
      return parseOgg(buffer, tail, realSize);
    }

    // ---- MP4 / M4A (ftyp brand box at offset 4) -----------------------------
    if (
      u8[4] === 0x66 && u8[5] === 0x74 && u8[6] === 0x79 && u8[7] === 0x70
    ) {
      const tail = await readTailBytes(options.tail, 1024 * 1024);
      if (tail && tail.length) {
        src.tail = tail;
        src.tailStart = Math.max(0, src.size - tail.length);
      }
      return await parseMP4(src);
    }

    // ---- WAV (RIFF) ---------------------------------------------------------
    if (u8[0] === 0x52 && u8[1] === 0x49 && u8[2] === 0x46 && u8[3] === 0x46) {
      return parseWav(buffer, view);
    }

    // ---- AIFF (FORM) --------------------------------------------------------
    if (u8[0] === 0x46 && u8[1] === 0x4f && u8[2] === 0x52 && u8[3] === 0x4d) {
      return parseAiff(buffer, view);
    }

    // ---- ID3v2 leading tag (MP3 / WAV-AIFF exports that start with ID3) -----
    if (u8[0] === 0x49 && u8[1] === 0x44 && u8[2] === 0x33) {
      const tagEnd = id3TagEnd(view);
      // 1.7.0 (P4): a tag bigger than the head (a large cover written by the
      // tag editor) is fetched whole, so frames after the picture survive.
      let tagBuf = buffer;
      if (tagEnd > u8.length && tagEnd <= realSize) {
        const whole = await readBytes(src, 0, tagEnd);
        if (whole) tagBuf = whole.buffer.slice(whole.byteOffset, whole.byteOffset + whole.byteLength) as ArrayBuffer;
      }
      const meta = parseID3v2(tagBuf, new DataView(tagBuf), 0);
      // Whatever starts with ID3 and is not RIFF/FORM (checked above) is an
      // MPEG audio stream — read the first frame header for technicals.
      if (tagEnd + 4 <= u8.length) {
        await parseMpegStream(u8, 0, tagEnd, meta, src);
      } else {
        const probe = await readBytes(src, tagEnd, Math.min(65536, src.size - tagEnd));
        if (probe) await parseMpegStream(probe, tagEnd, 0, meta, src);
      }
      return meta;
    }

    // ---- Raw MPEG stream without ID3 ----------------------------------------
    const meta: ParsedAudioMeta = {};
    await parseMpegStream(u8, 0, 0, meta, src);
    if (meta.container) return meta;
  } catch {
    // Silent fallback
  }
  return {};
}

/* ========================================================================== */
/* shared helpers                                                              */
/* ========================================================================== */

/** Last `maxBytes` of the physical file. Small files re-serve their own
 *  (already complete) head bytes, bounded by maxBytes. */
async function readTailBytes(source: File | Uint8Array | undefined, maxBytes: number): Promise<Uint8Array | undefined> {
  try {
    if (!source) return undefined;
    if (source instanceof Uint8Array) {
      return source.byteLength > maxBytes ? source.subarray(source.byteLength - maxBytes) : source;
    }
    const size = source.size;
    if (!Number.isFinite(size) || size <= 0) return undefined;
    const start = Math.max(0, size - maxBytes);
    return new Uint8Array(await source.slice(start, size).arrayBuffer());
  } catch {
    return undefined;
  }
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  const CHUNK = 0x8000; // 32768 — safe for every JS engine's stack
  for (let start = 0; start < bytes.length; start += CHUNK) {
    const chunk = bytes.subarray(start, start + CHUNK);
    binary += String.fromCharCode.apply(null, chunk as unknown as number[]);
  }
  return window.btoa(binary);
}

function base64ToBytes(b64: string): Uint8Array {
  const clean = b64.includes("base64,") ? b64.slice(b64.indexOf("base64,") + 7) : b64;
  const binary = window.atob(clean);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

function decodeText(bytes: Uint8Array, encoding: number): string {
  // 0 = ISO-8859-1, 1 = UTF-16 (BOM), 2 = UTF-16BE, 3 = UTF-8
  const decoder =
    encoding === 1
      ? new TextDecoder("utf-16")
      : encoding === 2
        ? new TextDecoder("utf-16be")
        : encoding === 3
          ? new TextDecoder("utf-8")
          : new TextDecoder("latin1");
  return decoder.decode(bytes).replace(/\0/g, "").trim();
}

/** Like decodeText but keeps NUL separators (multi-value v2.4 frames). */
function rawText(bytes: Uint8Array, encoding: number): string {
  const decoder =
    encoding === 1
      ? new TextDecoder("utf-16")
      : encoding === 2
        ? new TextDecoder("utf-16be")
        : encoding === 3
          ? new TextDecoder("utf-8")
          : new TextDecoder("latin1");
  return decoder.decode(bytes).replace(/^\0+|\0+$/g, "");
}

function skipNullTerminated(view: DataView, pos: number, end: number, wide: boolean): number {
  if (wide) {
    while (pos + 1 < end && !(view.getUint8(pos) === 0 && view.getUint8(pos + 1) === 0)) pos += 2;
    return pos + 2;
  }
  while (pos < end && view.getUint8(pos) !== 0) pos++;
  return pos + 1;
}

function formatLrcTime(ms: number): string {
  const totalSeconds = ms / 1000;
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds - m * 60;
  return `[${String(m).padStart(2, "0")}:${s.toFixed(2).padStart(5, "0")}]`;
}

/* ========================================================================== */
/* ID3v2 (MP3 / WAV / AIFF)                                                    */
/* ========================================================================== */

/** Total leading ID3v2 tag length (header + body [+ footer]). */
function id3TagEnd(view: DataView): number {
  const size =
    ((view.getUint8(6) & 0x7f) << 21) |
    ((view.getUint8(7) & 0x7f) << 14) |
    ((view.getUint8(8) & 0x7f) << 7) |
    (view.getUint8(9) & 0x7f);
  const flags = view.getUint8(5);
  return 10 + size + (flags & 0x10 ? 10 : 0);
}

/** V1.5.3 (P1): reverse ID3 unsynchronisation (every `FF 00` → `FF`). */
function deUnsync(src: Uint8Array): Uint8Array {
  const out = new Uint8Array(src.length);
  let j = 0;
  for (let i = 0; i < src.length; i++) {
    const b = src[i];
    out[j++] = b;
    if (b === 0xff && i + 1 < src.length && src[i + 1] === 0x00) i++;
  }
  return out.subarray(0, j);
}

function parseID3v2(buffer: ArrayBuffer, view: DataView, base: number): ParsedAudioMeta {
  const meta: ParsedAudioMeta = {};
  const version = view.getUint8(base + 3);
  const headerFlags = view.getUint8(base + 5);
  const tagSize =
    ((view.getUint8(base + 6) & 0x7f) << 21) |
    ((view.getUint8(base + 7) & 0x7f) << 14) |
    ((view.getUint8(base + 8) & 0x7f) << 7) |
    (view.getUint8(base + 9) & 0x7f);

  // V1.5.3 (P1): v2.3 whole-tag unsynchronisation — undo it on a private copy
  // and re-enter with the flag cleared, so frame sizes/APIC bytes line up.
  // (v2.4 unsynchronises per frame and keeps frame sizes post-transform.)
  if (version === 3 && headerFlags & 0x80) {
    const bodyEnd = Math.min(buffer.byteLength, base + 10 + tagSize);
    const body = deUnsync(new Uint8Array(buffer, base + 10, Math.max(0, bodyEnd - base - 10)));
    const copy = new Uint8Array(10 + body.length);
    copy.set(new Uint8Array(buffer, base, 10), 0);
    copy.set(body, 10);
    copy[5] = headerFlags & ~0x80;
    // keep the syncsafe size consistent with the shortened body
    const n = body.length;
    copy[6] = (n >> 21) & 0x7f; copy[7] = (n >> 14) & 0x7f; copy[8] = (n >> 7) & 0x7f; copy[9] = n & 0x7f;
    return parseID3v2(copy.buffer, new DataView(copy.buffer), 0);
  }

  let offset = base + 10;
  const maxOffset = Math.min(buffer.byteLength, base + 10 + tagSize);

  // V1.5.3 (P1): skip the extended header (v2.3: 4-byte BE size excluding
  // itself; v2.4: syncsafe size including itself). It used to be walked as
  // if it were a frame, so tags carrying one lost every field.
  if (headerFlags & 0x40 && offset + 4 <= maxOffset) {
    if (version === 3) {
      offset += 4 + view.getUint32(offset);
    } else if (version === 4) {
      offset +=
        ((view.getUint8(offset) & 0x7f) << 21) |
        ((view.getUint8(offset + 1) & 0x7f) << 14) |
        ((view.getUint8(offset + 2) & 0x7f) << 7) |
        (view.getUint8(offset + 3) & 0x7f);
    }
  }

  while (offset + 10 < maxOffset) {
    if (version < 3) break;

    const frameID = String.fromCharCode(
      view.getUint8(offset),
      view.getUint8(offset + 1),
      view.getUint8(offset + 2),
      view.getUint8(offset + 3),
    );

    if (!frameID.match(/^[A-Z0-9]{4}$/)) break;

    const frameSize =
      version === 4
        ? ((view.getUint8(offset + 4) & 0x7f) << 21) |
          ((view.getUint8(offset + 5) & 0x7f) << 14) |
          ((view.getUint8(offset + 6) & 0x7f) << 7) |
          (view.getUint8(offset + 7) & 0x7f)
        : view.getUint32(offset + 4);

    if (frameSize <= 0 || offset + 10 + frameSize > maxOffset) break;

    const frameStart = offset + 10;
    const frameEnd = frameStart + frameSize;

    if (frameID === "APIC") {
      try {
        const encoding = view.getUint8(frameStart);
        let pos = frameStart + 1;
        let mime = "";
        while (pos < frameEnd && view.getUint8(pos) !== 0) {
          mime += String.fromCharCode(view.getUint8(pos));
          pos++;
        }
        pos++; // null
        pos++; // picture type
        pos = skipNullTerminated(view, pos, frameEnd, encoding === 1 || encoding === 2);

        if (pos < frameEnd) {
          const imgData = new Uint8Array(buffer, pos, frameEnd - pos);
          meta.cover = `data:${mime || "image/jpeg"};base64,${bytesToBase64(imgData)}`;
        }
      } catch {
        /* ignore */
      }
    } else if (frameID === "USLT") {
      // Unsynchronised lyrics — very often contains full LRC text with timestamps.
      try {
        const encoding = view.getUint8(frameStart);
        let pos = frameStart + 1 + 3; // skip language code
        pos = skipNullTerminated(view, pos, frameEnd, encoding === 1 || encoding === 2); // descriptor
        if (pos < frameEnd) {
          const text = decodeText(new Uint8Array(buffer, pos, frameEnd - pos), encoding);
          if (text && (!meta.lyrics || text.length > meta.lyrics.length)) meta.lyrics = text;
        }
      } catch {
        /* ignore */
      }
    } else if (frameID === "SYLT") {
      // Synchronised lyrics — convert to LRC format so the existing parser can sync them.
      try {
        const encoding = view.getUint8(frameStart);
        const wide = encoding === 1 || encoding === 2;
        let pos = frameStart + 1 + 3; // language
        const timeFormat = view.getUint8(pos); // 1 = MPEG frames, 2 = milliseconds
        pos += 1;
        pos += 1; // content type
        pos = skipNullTerminated(view, pos, frameEnd, wide); // descriptor

        const lines: string[] = [];
        while (pos < frameEnd - 4) {
          const textStart = pos;
          pos = skipNullTerminated(view, pos, frameEnd, wide);
          const textEnd = wide ? pos - 2 : pos - 1;
          if (textEnd <= textStart || pos + 4 > frameEnd) break;
          const text = decodeText(new Uint8Array(buffer, textStart, textEnd - textStart), encoding);
          const stamp = view.getUint32(pos);
          pos += 4;
          if (timeFormat === 2 && text) {
            lines.push(`${formatLrcTime(stamp)}${text.replace(/^\n+/, "")}`);
          }
        }
        if (lines.length > 1) {
          const lrc = lines.join("\n");
          if (!meta.lyrics || lrc.length > meta.lyrics.length) meta.lyrics = lrc;
        }
      } catch {
        /* ignore */
      }
    } else if (frameID === "TCON") {
      // V1.6.1 (P3): genre — v2.4 separates multiple values with NUL, so
      // decode raw (decodeText strips NULs) and normalise "(17)" refs
      try {
        const encoding = view.getUint8(frameStart);
        const raw = rawText(new Uint8Array(buffer, frameStart + 1, frameSize - 1), encoding);
        meta.genre ||= normalizeGenre(raw);
      } catch {
        /* ignore */
      }
    } else if (frameID === "TXXX") {
      // V1.6.1 (P3): user text frames — REPLAYGAIN_* live here in MP3s
      try {
        const encoding = view.getUint8(frameStart);
        const wide = encoding === 1 || encoding === 2;
        const descEnd = skipNullTerminated(view, frameStart + 1, frameEnd, wide);
        const desc = decodeText(new Uint8Array(buffer, frameStart + 1, Math.max(0, descEnd - frameStart - 1 - (wide ? 2 : 1))), encoding);
        if (descEnd < frameEnd && /^(REPLAYGAIN_|R128_)/i.test(desc)) {
          rgTag(meta, desc, decodeText(new Uint8Array(buffer, descEnd, frameEnd - descEnd), encoding));
        }
      } catch {
        /* ignore */
      }
    } else if (
      frameID === "TIT2" ||
      frameID === "TPE1" ||
      frameID === "TPE2" ||
      frameID === "TALB" ||
      frameID === "TYER" ||
      frameID === "TDRC"
    ) {
      try {
        const encoding = view.getUint8(frameStart);
        const text = decodeText(new Uint8Array(buffer, frameStart + 1, frameSize - 1), encoding);
        if (text) {
          if (frameID === "TIT2") meta.title = text;
          else if (frameID === "TPE1") meta.artist = text;
          else if (frameID === "TPE2") meta.artist ||= text;
          else if (frameID === "TALB") meta.album = text;
          else meta.year = text.slice(0, 4);
        }
      } catch {
        /* ignore */
      }
    }

    offset += 10 + frameSize;
  }

  return meta;
}

/* ========================================================================== */
/* MPEG audio frame header + Xing/Info (MP3/MP2 technicals + duration)         */
/* ========================================================================== */

const MPEG_SAMPLE_RATES: Record<number, number[]> = {
  3: [44100, 48000, 32000], // MPEG 1
  2: [22050, 24000, 16000], // MPEG 2
  0: [11025, 12000, 8000], // MPEG 2.5
};

const MPEG_BITRATES: Record<string, number[]> = {
  // `${versionBits}-${layerBits}` -> kbps table (index 0 and 15 are invalid)
  // versionBits: 3 = MPEG1, 2 = MPEG2, 0 = MPEG2.5. layerBits: 3 = Layer I,
  // 2 = Layer II, 1 = Layer III.
  "3-3": [0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448], // MPEG1  L1
  "3-2": [0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384], // MPEG1  L2
  "3-1": [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320], // MPEG1  L3
  "2-3": [0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256], // MPEG2  L1
  "2-2": [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160], // MPEG2  L2
  "2-1": [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160], // MPEG2  L3
  "0-3": [0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256], // MPEG2.5 L1
  "0-2": [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160], // MPEG2.5 L2
  "0-1": [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160], // MPEG2.5 L3
};

/** Scans `u8` (which starts at physical offset `base`) from `from` for the
 *  first MPEG audio frame. Duration: Xing/Info or VBRI frame count (exact),
 *  else CBR estimate over the AUDIO bytes only.
 *  1.7.0 (P4): the CBR estimate used the whole file size, so the ID3 tag
 *  (and its padding / cover) was counted as audio: a 6 s file read 11.7 s
 *  after a 2 MB cover was added. It now spans first frame → end of audio
 *  (minus a trailing ID3v1 / APEv2 tag when the end is reachable). */
async function parseMpegStream(u8: Uint8Array, base: number, from: number, meta: ParsedAudioMeta, src: ByteSource): Promise<void> {
  const view = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  const searchEnd = Math.min(u8.length - 4, from + 65536);
  for (let i = Math.max(0, from); i < searchEnd; i++) {
    if (u8[i] !== 0xff || (u8[i + 1] & 0xe0) !== 0xe0) continue;
    const versionBits = (u8[i + 1] >> 3) & 3; // 0=2.5, 2=2, 3=1
    const layerBits = (u8[i + 1] >> 1) & 3; // 1=III, 2=II, 3=I
    const bitrateIdx = (u8[i + 2] >> 4) & 15;
    const srIdx = (u8[i + 2] >> 2) & 3;
    const mode = (u8[i + 3] >> 6) & 3; // 3 = mono

    if (versionBits === 1 || layerBits === 0 || bitrateIdx === 0 || bitrateIdx === 15 || srIdx === 3) continue;

    const rates = MPEG_SAMPLE_RATES[versionBits];
    const bitrateTable = MPEG_BITRATES[`${versionBits}-${layerBits}`];
    if (!rates || !bitrateTable) continue;

    const sampleRate = rates[srIdx];
    const kbps = bitrateTable[bitrateIdx];
    if (!sampleRate || !kbps) continue;

    meta.container = "MPEG";
    meta.codec = layerBits === 1 ? "MP3" : layerBits === 2 ? "MP2" : "MP1";
    meta.sampleRate = sampleRate;
    meta.channels = mode === 3 ? 1 : 2;
    meta.bitrate = kbps * 1000;

    const samplesPerFrame = layerBits === 3 ? 384 : layerBits === 2 || versionBits === 3 ? 1152 : 576; // L1 / L2, L3 v1 / L3 v2,2.5

    // Xing/Info frame → exact duration without scanning the whole file.
    try {
      const sideInfo = versionBits === 3 ? (mode === 3 ? 17 : 32) : mode === 3 ? 9 : 17;
      const xingPos = i + 4 + sideInfo;
      if (xingPos + 16 <= u8.length) {
        const word = String.fromCharCode(u8[xingPos], u8[xingPos + 1], u8[xingPos + 2], u8[xingPos + 3]);
        if (word === "Xing" || word === "Info") {
          const flags = view.getUint32(xingPos + 4);
          if (flags & 1) {
            const frames = view.getUint32(xingPos + 8);
            if (frames > 0) meta.duration = (frames * samplesPerFrame) / sampleRate;
          }
        }
      }
      // 1.7.0 (P4): Fraunhofer VBRI header (always 32 bytes after the frame header).
      const vbriPos = i + 36;
      if (!meta.duration && vbriPos + 18 <= u8.length) {
        const word = String.fromCharCode(u8[vbriPos], u8[vbriPos + 1], u8[vbriPos + 2], u8[vbriPos + 3]);
        if (word === "VBRI") {
          const frames = view.getUint32(vbriPos + 14);
          if (frames > 0) meta.duration = (frames * samplesPerFrame) / sampleRate;
        }
      }
    } catch {
      /* ignore */
    }

    // Fallback: CBR estimate over the audio bytes (first frame → audio end).
    if (!meta.duration && src.size > 0) {
      const audioStart = base + i;
      let audioEnd = src.size;
      const trailer = await readBytes(src, Math.max(0, src.size - 160), Math.min(160, src.size));
      if (trailer && trailer.length >= 128) {
        const t = trailer.length - 128;
        if (trailer[t] === 0x54 && trailer[t + 1] === 0x41 && trailer[t + 2] === 0x47) audioEnd -= 128; // "TAG" (ID3v1)
        // APEv2 footer ("APETAGEX") right before the ID3v1 or at EOF
        const apeAt = (audioEnd - (src.size - trailer.length)) - 32;
        if (apeAt >= 0 && String.fromCharCode(...trailer.subarray(apeAt, apeAt + 8)) === "APETAGEX") {
          const tv = new DataView(trailer.buffer, trailer.byteOffset + apeAt);
          const apeSize = tv.getUint32(12, true); // items + footer
          const hasHeader = (tv.getUint32(20, true) & 0x80000000) !== 0;
          if (apeSize > 0 && apeSize < audioEnd - audioStart) audioEnd -= apeSize + (hasHeader ? 32 : 0);
        }
      }
      const audioBytes = audioEnd - audioStart;
      if (audioBytes > 0) meta.duration = (audioBytes * 8) / meta.bitrate;
    }
    return;
  }
}

/* ========================================================================== */
/* shared Vorbis comment fields (FLAC + OGG)                                   */
/* ========================================================================== */

/** Parses "KEY=value" Vorbis comment fields. `pos` must point at the vendor
 *  length; `end` bounds the comment block. */
function parseVorbisFields(bytes: Uint8Array, pos: number, end: number, meta: ParsedAudioMeta): void {
  if (pos + 8 > end || end > bytes.byteLength) return;
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const vendorLen = view.getUint32(pos, true);
  pos += 4 + vendorLen;
  if (pos + 4 > end) return;
  const count = view.getUint32(pos, true);
  pos += 4;
  const utf8 = new TextDecoder("utf-8");

  for (let i = 0; i < count && pos + 4 <= end; i++) {
    const fieldLen = view.getUint32(pos, true);
    pos += 4;
    if (fieldLen > end - pos) break;
    const field = utf8.decode(bytes.subarray(pos, pos + fieldLen));
    pos += fieldLen;

    const eq = field.indexOf("=");
    if (eq < 0) continue;
    const key = field.slice(0, eq).toUpperCase();
    const value = field.slice(eq + 1).trim();
    if (!value) continue;

    if (key === "TITLE") meta.title ||= value;
    else if (key === "ARTIST") meta.artist ||= value;
    else if (key === "ALBUM") meta.album ||= value;
    else if (key === "DATE" || key === "YEAR") meta.year ||= value.slice(0, 4);
    else if (key === "GENRE") {
      // V1.6.1 (P3): repeated GENRE= fields are all kept
      meta.genre = normalizeGenre(meta.genre ? `${meta.genre};${value}` : value);
    } else if (rgTag(meta, key, value)) {
      /* V1.6.1 (P3): REPLAYGAIN_* / R128_* consumed */
    } else if (
      key === "LYRICS" ||
      key === "UNSYNCEDLYRICS" ||
      key === "UNSYNCED LYRICS" ||
      key === "SYNCEDLYRICS"
    ) {
      if (!meta.lyrics || value.length > meta.lyrics.length) meta.lyrics = value;
    } else if (key === "METADATA_BLOCK_PICTURE" && !meta.cover) {
      try {
        meta.cover = parseFlacPicture(base64ToBytes(value));
      } catch {
        /* ignore */
      }
    }
  }
}

/** Parses a FLAC PICTURE block payload (also used for OGG
 *  METADATA_BLOCK_PICTURE after base64 decoding). */
function parseFlacPicture(data: Uint8Array): string | undefined {
  if (data.byteLength < 32) return undefined;
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  let pos = 0;
  pos += 4; // picture type
  const mimeLen = view.getUint32(pos);
  pos += 4;
  let mime = "";
  for (let i = 0; i < mimeLen && pos + i < data.byteLength; i++) mime += String.fromCharCode(data[pos + i]);
  pos += mimeLen;
  const descLen = view.getUint32(pos);
  pos += 4 + descLen;
  pos += 16; // width, height, depth, colors
  if (pos + 4 > data.byteLength) return undefined;
  const dataLen = view.getUint32(pos);
  pos += 4;
  if (dataLen <= 0 || pos + dataLen > data.byteLength) return undefined;
  return `data:${mime || "image/jpeg"};base64,${bytesToBase64(data.subarray(pos, pos + dataLen))}`;
}

/* ========================================================================== */
/* FLAC                                                                        */
/* ========================================================================== */

function parseFLAC(buffer: ArrayBuffer, view: DataView): ParsedAudioMeta {
  const meta: ParsedAudioMeta = { container: "FLAC", codec: "FLAC" };
  let offset = 4; // skip "fLaC"
  const maxOffset = buffer.byteLength;

  while (offset + 4 < maxOffset) {
    const header = view.getUint8(offset);
    const isLast = (header & 0x80) !== 0;
    const blockType = header & 0x7f;
    const blockSize =
      (view.getUint8(offset + 1) << 16) | (view.getUint8(offset + 2) << 8) | view.getUint8(offset + 3);

    offset += 4;
    if (offset + blockSize > maxOffset) break;

    if (blockType === 0) {
      // STREAMINFO — always the first block. Gives exact duration + technicals.
      try {
        const b = (i: number) => view.getUint8(offset + i);
        const sampleRate = (b(10) << 12) | (b(11) << 4) | (b(12) >> 4);
        const channels = ((b(12) >> 1) & 0x07) + 1;
        const bitDepth = (((b(12) & 0x01) << 4) | (b(13) >> 4)) + 1;
        const totalSamples =
          (b(13) & 0x0f) * 4294967296 + b(14) * 16777216 + (b(15) << 16 | b(16) << 8 | b(17));
        if (sampleRate > 0) {
          meta.sampleRate = sampleRate;
          meta.channels = channels;
          meta.bitDepth = bitDepth;
          if (totalSamples > 0) meta.duration = totalSamples / sampleRate;
        }
      } catch {
        /* ignore */
      }
    } else if (blockType === 4) {
      // VORBIS_COMMENT — little-endian lengths, "KEY=value" fields.
      try {
        parseVorbisFields(new Uint8Array(buffer, offset, blockSize), 0, blockSize, meta);
      } catch {
        /* ignore */
      }
    } else if (blockType === 6) {
      // PICTURE
      try {
        meta.cover ||= parseFlacPicture(new Uint8Array(buffer, offset, blockSize));
      } catch {
        /* ignore */
      }
    }

    if (isLast) break;
    offset += blockSize;
  }

  return meta;
}

/* ========================================================================== */
/* MP4 / M4A                                                                   */
/* ========================================================================== */

/** Walks ISO-BMFF boxes within [start, end). Calls `visit(type, bodyStart,
 *  bodyEnd)` for each direct child. Bounds-checked; never throws on corrupt
 *  input (a broken size just ends the walk). */
function walkBoxes(
  view: DataView,
  start: number,
  end: number,
  visit: (type: string, bodyStart: number, bodyEnd: number, truncated: boolean) => void,
): void {
  let pos = start;
  const limit = Math.min(end, view.byteLength);
  while (pos + 8 <= limit) {
    let size = view.getUint32(pos);
    let headerSize = 8;
    if (size === 1) {
      if (pos + 16 > limit) break;
      const hi = view.getUint32(pos + 8);
      const lo = view.getUint32(pos + 12);
      size = hi * 4294967296 + lo;
      headerSize = 16;
    } else if (size === 0) {
      size = limit - pos; // box extends to the end of the buffer
    }
    if (size < headerSize) break;
    const type = String.fromCharCode(
      view.getUint8(pos + 4),
      view.getUint8(pos + 5),
      view.getUint8(pos + 6),
      view.getUint8(pos + 7),
    );
    visit(type, pos + headerSize, Math.min(limit, pos + size), pos + size > limit);
    pos += size;
  }
}

const MP4_TEXT_FIELDS: Record<string, "title" | "artist" | "album" | "year" | "lyrics" | "genre"> = {
  "\u00A9gen": "genre",
  "\u00A9nam": "title",
  "\u00A9ART": "artist",
  aART: "artist",
  "\u00A9alb": "album",
  "\u00A9day": "year",
  "\u00A9lyr": "lyrics",
};

function parseIlst(view: DataView, start: number, end: number, meta: ParsedAudioMeta): void {
  walkBoxes(view, start, end, (itemType, itemBody, itemEnd, itemCut) => {
    // 1.7.0 (P4): an item cut off by the read window is garbage (a truncated
    // cover used to be stored as a broken JPEG).
    if (itemCut) return;
    // V1.6.1 (P3): iTunes freeform atoms ("----" → mean / name / data):
    // ReplayGain lives in ----:com.apple.iTunes:replaygain_track_gain etc.
    if (itemType === "----") {
      let name = "";
      let value = "";
      walkBoxes(view, itemBody, itemEnd, (t, b, e) => {
        if (t === "name" && b + 4 <= e) {
          name = new TextDecoder("utf-8").decode(new Uint8Array(view.buffer, view.byteOffset + b + 4, e - b - 4));
        } else if (t === "data" && b + 8 <= e) {
          value = new TextDecoder("utf-8").decode(new Uint8Array(view.buffer, view.byteOffset + b + 8, e - b - 8));
        }
      });
      if (name && value) rgTag(meta, name.replace(/\0/g, ""), value.replace(/\0/g, ""));
      return;
    }
    walkBoxes(view, itemBody, itemEnd, (childType, childBody, childEnd, childCut) => {
      if (childCut || childType !== "data" || childBody + 8 > childEnd) return;
      const kind = view.getUint32(childBody) & 0xffffff; // version(8) + flags(24)
      const bytes = new Uint8Array(view.buffer, view.byteOffset + childBody + 8, childEnd - childBody - 8);

      if (itemType === "covr") {
        if (!meta.cover) {
          const mime = kind === 14 ? "image/png" : "image/jpeg";
          meta.cover = `data:${mime};base64,${bytesToBase64(bytes)}`;
        }
        return;
      }

      // V1.6.1 (P3): "gnre" = uint16 ID3v1 genre index + 1
      if (itemType === "gnre") {
        if (bytes.byteLength >= 2 && !meta.genre) {
          const idx = ((bytes[0] << 8) | bytes[1]) - 1;
          if (ID3_GENRES[idx]) meta.genre = ID3_GENRES[idx];
        }
        return;
      }
      const field = MP4_TEXT_FIELDS[itemType];
      if (!field) return;
      const value = new TextDecoder("utf-8").decode(bytes).replace(/\0/g, "").trim();
      if (!value) return;
      if (field === "genre") {
        meta.genre ||= normalizeGenre(value);
      } else if (field === "year") {
        meta.year ||= value.slice(0, 4);
      } else if (field === "lyrics") {
        if (!meta.lyrics || value.length > meta.lyrics.length) meta.lyrics = value;
      } else if (field === "artist") {
        meta.artist ||= value;
      } else {
        meta[field] ||= value;
      }
    });
  });
}

/** `meta` boxes carry 4 version/flag bytes before their child boxes. */
function parseMetaBox(view: DataView, start: number, end: number, meta: ParsedAudioMeta): void {
  // 1.7.0 (P4): QuickTime writes `meta` as a plain box (no version/flags):
  // then a child box type ("hdlr"/"ilst"/"free") sits at +4.
  let first = start + 4;
  if (start + 8 <= end) {
    const t = String.fromCharCode(view.getUint8(start + 4), view.getUint8(start + 5), view.getUint8(start + 6), view.getUint8(start + 7));
    if (t === "hdlr" || t === "ilst" || t === "free" || t === "keys") first = start;
  }
  walkBoxes(view, first, end, (type, bodyStart, bodyEnd) => {
    if (type === "ilst") parseIlst(view, bodyStart, bodyEnd, meta);
  });
}

function parseMvhd(view: DataView, bodyStart: number, meta: ParsedAudioMeta): void {
  try {
    const version = view.getUint8(bodyStart);
    let timescale = 0;
    let duration = 0;
    if (version === 1 && bodyStart + 32 <= view.byteLength) {
      timescale = view.getUint32(bodyStart + 20);
      // V1.5.3 (P1): 64-bit big-endian — HIGH word first (+24), LOW word (+28).
      duration = view.getUint32(bodyStart + 24) * 4294967296 + view.getUint32(bodyStart + 28);
    } else if (bodyStart + 20 <= view.byteLength) {
      timescale = view.getUint32(bodyStart + 12);
      duration = view.getUint32(bodyStart + 16);
    }
    if (timescale > 0 && duration > 0) meta.duration = duration / timescale;
  } catch {
    /* ignore */
  }
}

const MP4_CODECS: Record<string, string> = {
  mp4a: "AAC",
  alac: "ALAC",
  "ac-3": "AC-3",
  "ec-3": "E-AC-3",
  Opus: "Opus",
  fLaC: "FLAC",
  samr: "AMR",
  sqcp: "QCELP",
};

/** Walks a moov BODY [start, end): mvhd, meta / udta→meta, trak→…→stsd. */
function parseMoovBody(view: DataView, start: number, end: number, meta: ParsedAudioMeta): void {
  walkBoxes(view, start, end, (childType, cbs, cbe) => {
    if (childType === "mvhd") parseMvhd(view, cbs, meta);
    else if (childType === "meta") parseMetaBox(view, cbs, cbe, meta);
    else if (childType === "udta") {
      walkBoxes(view, cbs, cbe, (t, s, e) => {
        if (t === "meta") parseMetaBox(view, s, e, meta);
      });
    } else if (childType === "trak") {
      // trak → mdia → minf → stbl → stsd (codec sample entry)
      walkBoxes(view, cbs, cbe, (t2, s2, e2) => {
        if (t2 !== "mdia") return;
        walkBoxes(view, s2, e2, (t3, s3, e3) => {
          if (t3 !== "minf") return;
          walkBoxes(view, s3, e3, (t4, s4, e4) => {
            if (t4 !== "stbl") return;
            walkBoxes(view, s4, e4, (t5, s5, e5) => {
              // stsd = version/flags(4) + entry_count(4), then the first
              // sample entry: size(4) + FORMAT(4).
              // 1.7.0 (P4): the format was read at +8 (the entry SIZE), so
              // every M4A reported a codec like "\0\0\0Z".
              if (t5 !== "stsd" || s5 + 16 > e5 || meta.codec) return;
              const codec = String.fromCharCode(
                view.getUint8(s5 + 12),
                view.getUint8(s5 + 13),
                view.getUint8(s5 + 14),
                view.getUint8(s5 + 15),
              ).trim();
              if (!codec) return;
              meta.codec = MP4_CODECS[codec] || codec;
            });
          });
        });
      });
    }
  });
}

/** 1.7.0 (P4): MP4 by exact top-level box chain instead of "whatever moov
 *  fits in the 3 MB head, else grep the 1 MB tail for 'moov'".
 *  The old reader lost every tag when moov STARTED inside the head but its
 *  udta/ilst lay past 3 MB (ALAC/lossless files with moov at EOF, any file
 *  whose cover pushed ilst over the edge): mvhd was found, so the tail retry
 *  never ran, and a half-read cover was stored as a broken image. It also
 *  gave up on a moov bigger than the tail (large cover at EOF). */
async function parseMP4(src: ByteSource): Promise<ParsedAudioMeta> {
  const meta: ParsedAudioMeta = { container: "MP4" };
  const head = src.head;
  if (head.length >= 12) {
    const brand = String.fromCharCode(head[8], head[9], head[10], head[11]);
    if (brand.startsWith("M4A") || brand.startsWith("M4B")) meta.container = "M4A";
  }

  // 1. top-level chain → moov offset/size (headers only, 16 bytes each)
  let moovStart = -1;
  let moovSize = 0;
  let moovHs = 8;
  let pos = 0;
  for (let guard = 0; guard < 10000 && pos + 8 <= src.size; guard++) {
    const h = await readBytes(src, pos, Math.min(16, src.size - pos));
    if (!h || h.length < 8) break;
    const hv = new DataView(h.buffer, h.byteOffset, h.byteLength);
    let size = hv.getUint32(0);
    let hs = 8;
    if (size === 1) {
      if (h.length < 16) break;
      size = hv.getUint32(8) * 4294967296 + hv.getUint32(12);
      hs = 16;
    } else if (size === 0) {
      size = src.size - pos;
    }
    if (size < hs) break;
    const type = String.fromCharCode(h[4], h[5], h[6], h[7]);
    if (type === "moov") {
      moovStart = pos;
      moovSize = Math.min(size, src.size - pos);
      moovHs = hs;
      break;
    }
    pos += size;
  }

  // 2. chain broken (header in an unreadable gap): legacy scan of the tail
  //    for a plausible moov — but keep looking past false positives.
  if (moovStart < 0 && src.tail && src.tail.length > 8) {
    const t = src.tail;
    const tv = new DataView(t.buffer, t.byteOffset, t.byteLength);
    for (let i = 4; i + 4 <= t.length; i++) {
      if (t[i] !== 0x6d || t[i + 1] !== 0x6f || t[i + 2] !== 0x6f || t[i + 3] !== 0x76) continue; // "moov"
      const size = tv.getUint32(i - 4);
      const s0 = i - 4;
      if (size < 16 || s0 + size > t.length) continue;
      const first = String.fromCharCode(t[i + 8], t[i + 9], t[i + 10], t[i + 11]);
      if (first !== "mvhd" && first !== "trak" && first !== "udta" && first !== "meta" && first !== "iods") continue;
      moovStart = src.tailStart + s0;
      moovSize = size;
      moovHs = 8;
      break;
    }
  }
  if (moovStart < 0) return meta;

  // 3. moov bytes: whole when reachable, else the longest readable prefix
  //    (head, or head + an adjoining tail). Truncated items are skipped.
  let moov = await readBytes(src, moovStart, moovSize);
  if (!moov) {
    if (moovStart < head.length) {
      let part = head.subarray(moovStart);
      const t = src.tail;
      if (t && src.tailStart <= head.length && src.tailStart + t.length > head.length) {
        const extra = t.subarray(head.length - src.tailStart, Math.min(t.length, moovStart + moovSize - src.tailStart));
        const joined = new Uint8Array(part.length + extra.length);
        joined.set(part, 0);
        joined.set(extra, part.length);
        part = joined;
      }
      moov = part;
    } else if (src.tail && moovStart >= src.tailStart) {
      moov = src.tail.subarray(moovStart - src.tailStart);
    }
  }
  if (!moov || moov.length < moovHs) return meta;
  const mv = new DataView(moov.buffer, moov.byteOffset, moov.byteLength);
  try {
    parseMoovBody(mv, moovHs, Math.min(moov.length, moovSize), meta);
  } catch {
    /* keep what was read */
  }
  return meta;
}

/* ========================================================================== */
/* OGG / Opus                                                                  */
/* ========================================================================== */

function parseOgg(buffer: ArrayBuffer, tail: Uint8Array | undefined, realSize: number): ParsedAudioMeta {
  const meta: ParsedAudioMeta = { container: "OGG" };
  const u8 = new Uint8Array(buffer);

  // Gather the payload of the first pages (id header + comment header live here).
  let cursor = 0;
  const payload: number[] = [];
  for (let page = 0; page < 32 && cursor + 27 <= u8.length; page++) {
    if (!(u8[cursor] === 0x4f && u8[cursor + 1] === 0x67 && u8[cursor + 2] === 0x67 && u8[cursor + 3] === 0x53)) break;
    const segments = u8[cursor + 26];
    let pageSize = 27 + segments;
    for (let s = 0; s < segments; s++) pageSize += u8[cursor + 27 + s];
    if (cursor + pageSize > u8.length) break;
    for (let s = 0; s < segments; s++) {
      const segLen = u8[cursor + 27 + s];
      const segStart = cursor + 27 + segments + payloadPageOffset(u8, cursor, s);
      for (let i = 0; i < segLen; i++) payload.push(u8[segStart + i]);
    }
    cursor += pageSize;
  }

  const p = new Uint8Array(payload);
  const has = (offset: number, word: string) => {
    for (let i = 0; i < word.length; i++) if (p[offset + i] !== word.charCodeAt(i)) return false;
    return true;
  };

  let sampleRate = 0;
  let preSkip = 0;
  let isOpus = false;

  if (p.length >= 30 && has(0, "\x01vorbis")) {
    // identification header: version(4) channels(1) rate(4) ...
    meta.channels = p[11];
    sampleRate = p[12] | (p[13] << 8) | (p[14] << 16) | (p[15] << 24);
    const nominal = p[20] | (p[21] << 8) | (p[22] << 16) | (p[23] << 24);
    meta.sampleRate = sampleRate;
    meta.codec = "Vorbis";
    if (nominal > 0) meta.bitrate = nominal;
  } else if (p.length >= 19 && has(0, "OpusHead")) {
    isOpus = true;
    meta.channels = p[9];
    preSkip = p[10] | (p[11] << 8);
    const inputRate = p[12] | (p[13] << 8) | (p[14] << 16) | (p[15] << 24);
    meta.sampleRate = inputRate || 48000;
    meta.codec = "Opus";
  }

  // comment header (vorbis: 0x03"vorbis" — opus: "OpusTags")
  for (let i = 1; i < p.length - 8; i++) {
    if (has(i, "\x03vorbis")) {
      parseVorbisFields(p, i + 7, p.length, meta);
      break;
    }
    if (has(i, "OpusTags")) {
      parseVorbisFields(p, i + 8, p.length, meta);
      break;
    }
  }

  // duration: granule position of the LAST page. Only trust bytes that are
  // known to reach the physical end of the file (the tail slice, or the head
  // itself when it contains the whole file — never a truncated head).
  const headIsWhole = realSize <= buffer.byteLength;
  const endBytes = tail && tail.byteLength > 64 ? tail : headIsWhole ? u8 : undefined;
  if (endBytes) {
    for (let i = endBytes.byteLength - 4; i >= 0; i--) {
      if (endBytes[i] === 0x4f && endBytes[i + 1] === 0x67 && endBytes[i + 2] === 0x67 && endBytes[i + 3] === 0x53) {
        const endView = new DataView(endBytes.buffer, endBytes.byteOffset, endBytes.byteLength);
        if (i + 14 <= endBytes.byteLength) {
          const lo = endView.getUint32(i + 6, true);
          const hi = endView.getUint32(i + 10, true);
          const granule = hi * 4294967296 + lo;
          if (isOpus) {
            meta.duration = Math.max(0, (granule - preSkip) / 48000);
          } else if (sampleRate > 0) {
            meta.duration = granule / sampleRate;
          }
        }
        break;
      }
    }
  }

  return meta;
}

/** Byte offset of segment `s` inside the page that starts at `pageStart`. */
function payloadPageOffset(u8: Uint8Array, pageStart: number, s: number): number {
  let offset = 0;
  for (let i = 0; i < s; i++) offset += u8[pageStart + 27 + i];
  return offset;
}

/* ========================================================================== */
/* WAV (RIFF)                                                                  */
/* ========================================================================== */

function parseWav(buffer: ArrayBuffer, view: DataView): ParsedAudioMeta {
  const meta: ParsedAudioMeta = { container: "WAV" };
  const u8 = new Uint8Array(buffer);
  let pos = 12; // skip RIFF + size + "WAVE"

  while (pos + 8 <= buffer.byteLength) {
    const id = String.fromCharCode(u8[pos], u8[pos + 1], u8[pos + 2], u8[pos + 3]);
    const size = view.getUint32(pos + 4, true);
    const body = pos + 8;
    if (size === 0 || body + size > buffer.byteLength) {
      if (size === 0) {
        pos = body;
        continue;
      }
      break;
    }

    if (id === "fmt " && size >= 16) {
      const audioFormat = view.getUint16(body, true);
      meta.channels = view.getUint16(body + 2, true) || undefined;
      meta.sampleRate = view.getUint32(body + 4, true) || undefined;
      const byteRate = view.getUint32(body + 8, true);
      meta.bitDepth = view.getUint16(body + 14, true) || undefined;
      meta.bitrate = byteRate ? byteRate * 8 : undefined;
      meta.codec =
        audioFormat === 3 ? "PCM Float" : audioFormat === 6 ? "ALAW" : audioFormat === 7 ? "ULAW" : "PCM";
    } else if (id === "data") {
      const byteRate = meta.bitrate ? meta.bitrate / 8 : 0;
      if (byteRate > 0) meta.duration = size / byteRate;
    } else if (id === "LIST" && size > 4) {
      // LIST/INFO metadata chunks (INAM/IART/IPRD/ICRD)
      try {
        const formType = String.fromCharCode(u8[body], u8[body + 1], u8[body + 2], u8[body + 3]);
        if (formType === "INFO") {
          let sub = body + 4;
          const end = body + size;
          while (sub + 8 <= end) {
            const subId = String.fromCharCode(u8[sub], u8[sub + 1], u8[sub + 2], u8[sub + 3]);
            const subSize = view.getUint32(sub + 4, true);
            const subBody = sub + 8;
            if (subBody + subSize > end) break;
            const value = new TextDecoder("latin1")
              .decode(u8.subarray(subBody, subBody + subSize))
              .replace(/\0/g, "")
              .trim();
            if (value) {
              if (subId === "INAM") meta.title ||= value;
              else if (subId === "IART") meta.artist ||= value;
              else if (subId === "IPRD") meta.album ||= value;
              else if (subId === "ICRD") meta.year ||= value.slice(0, 4);
              else if (subId === "IGNR") meta.genre ||= normalizeGenre(value);
            }
            sub = subBody + subSize + (subSize % 2);
          }
        }
      } catch {
        /* ignore */
      }
    } else if (id === "id3 " || id === "ID3 ") {
      try {
        const id3 = parseID3v2(buffer, view, body);
        meta.title ||= id3.title;
        meta.artist ||= id3.artist;
        meta.album ||= id3.album;
        meta.year ||= id3.year;
        meta.cover ||= id3.cover;
        meta.lyrics ||= id3.lyrics;
        meta.genre ||= id3.genre;
        meta.replayGain ||= id3.replayGain;
      } catch {
        /* ignore */
      }
    }

    pos = body + size + (size % 2); // chunks are word-aligned
  }

  return meta;
}

/* ========================================================================== */
/* AIFF / AIFC                                                                 */
/* ========================================================================== */

/** 80-bit IEEE 754 extended float (big endian) used in AIFF COMM chunks. */
function readIbm80(view: DataView, pos: number): number {
  const exponent = ((view.getUint8(pos) & 0x7f) << 8) | view.getUint8(pos + 1);
  const hi = view.getUint32(pos + 2);
  const lo = view.getUint32(pos + 6);
  const mantissa = hi * 4294967296 + lo;
  if (exponent === 0 && mantissa === 0) return 0;
  return mantissa * 2 ** (exponent - 16383 - 63);
}

function parseAiff(buffer: ArrayBuffer, view: DataView): ParsedAudioMeta {
  const meta: ParsedAudioMeta = { container: "AIFF", codec: "PCM" };
  const u8 = new Uint8Array(buffer);
  let pos = 12; // skip FORM + size + AIFF/AIFC

  while (pos + 8 <= buffer.byteLength) {
    const id = String.fromCharCode(u8[pos], u8[pos + 1], u8[pos + 2], u8[pos + 3]);
    const size = view.getUint32(pos + 4);
    const body = pos + 8;
    if (size === 0 || body + size > buffer.byteLength) break;

    if (id === "COMM" && size >= 18) {
      meta.channels = view.getUint16(body) || undefined;
      const frames = view.getUint32(body + 2);
      meta.bitDepth = view.getUint16(body + 6) || undefined;
      const rate = readIbm80(view, body + 8);
      meta.sampleRate = Math.round(rate) || undefined;
      if (rate > 0 && frames > 0) {
        meta.duration = frames / rate;
        if (meta.sampleRate && meta.bitDepth) meta.bitrate = rate * (meta.channels || 2) * meta.bitDepth;
      }
    } else if (id === "id3 " || id === "ID3 ") {
      try {
        const id3 = parseID3v2(buffer, view, body);
        meta.title ||= id3.title;
        meta.artist ||= id3.artist;
        meta.album ||= id3.album;
        meta.year ||= id3.year;
        meta.cover ||= id3.cover;
        meta.lyrics ||= id3.lyrics;
        meta.genre ||= id3.genre;
        meta.replayGain ||= id3.replayGain;
      } catch {
        /* ignore */
      }
    }

    pos = body + size + (size % 2);
  }

  return meta;
}
