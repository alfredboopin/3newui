// ── NOBODY · shared virtual list (V1.5.4 · Phase 2) ──────────────────────────
// Face-neutral windowing for every track-bearing list (EELA library, ALOK
// panels, Classic library + queue, Download Centers). Design constraints:
//   • The list lives INSIDE an existing scroll box (the faces already own
//     their scroll containers, headers and sections above the rows), so the
//     nearest scrollable ancestor is detected and used as the scroll element;
//     content above the list is handled through tanstack's scrollMargin.
//   • Rows stay in normal document flow (top/bottom spacers instead of
//     absolute positioning) so each face's existing row CSS, hover states
//     and grid layouts keep working untouched.
//   • Short lists (<= threshold) render plainly — zero behaviour change for
//     the common small-library case.
// Row heights are measured (ResizeObserver via measureElement), so variable
// rows are fine; `estimateSize` only drives the initial scrollbar size.

import { Fragment, useCallback, useLayoutEffect, useRef, useState } from "react";
import type { ReactNode } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";

export interface VirtualListProps<T> {
  items: readonly T[];
  getKey: (item: T, index: number) => string | number;
  renderItem: (item: T, index: number) => ReactNode;
  /** Estimated row height in px (first paint / scrollbar size). */
  estimateSize: number | ((index: number) => number);
  /** Flex/grid `gap` between rows of the parent, if any (px). */
  gap?: number;
  overscan?: number;
  /** Lists up to this length render without windowing. */
  threshold?: number;
  /** Explicit scroll element; default = nearest scrollable ancestor. */
  scrollElement?: HTMLElement | null;
  /** Wrapper class for each measured row (rarely needed). */
  rowClassName?: string;
}

function isScrollable(el: HTMLElement): boolean {
  const s = getComputedStyle(el);
  return /(auto|scroll|overlay)/.test(s.overflowY);
}

function findScrollParent(from: HTMLElement | null): HTMLElement | null {
  let el = from?.parentElement ?? null;
  while (el && el !== document.body && el !== document.documentElement) {
    if (isScrollable(el)) return el;
    el = el.parentElement;
  }
  return null;
}

export function VirtualList<T>({
  items,
  getKey,
  renderItem,
  estimateSize,
  gap = 0,
  overscan = 8,
  threshold = 60,
  scrollElement,
  rowClassName,
}: VirtualListProps<T>) {
  const anchorRef = useRef<HTMLDivElement>(null);
  const [scrollEl, setScrollEl] = useState<HTMLElement | null>(scrollElement ?? null);
  const [margin, setMargin] = useState(0);
  const windowed = items.length > threshold;

  // resolve the scroll element once the anchor is in the DOM
  useLayoutEffect(() => {
    if (!windowed) return;
    const el = scrollElement ?? findScrollParent(anchorRef.current);
    setScrollEl((prev) => (prev === el ? prev : el));
  }, [windowed, scrollElement]);

  // keep scrollMargin (distance from the scroll content top to our first
  // row) in sync with whatever lives above the list
  const measureMargin = useCallback(() => {
    const a = anchorRef.current;
    if (!a || !scrollEl) return;
    const m = a.getBoundingClientRect().top - scrollEl.getBoundingClientRect().top + scrollEl.scrollTop;
    const r = Math.max(0, Math.round(m));
    setMargin((prev) => (Math.abs(prev - r) < 1 ? prev : r));
  }, [scrollEl]);

  useLayoutEffect(() => {
    if (!windowed || !scrollEl) return;
    measureMargin();
    if (typeof ResizeObserver === "undefined") return;
    // any ancestor between the anchor and the scroll box resizing means
    // content above us may have changed height
    const ro = new ResizeObserver(() => measureMargin());
    ro.observe(scrollEl);
    let el = anchorRef.current?.parentElement ?? null;
    while (el && el !== scrollEl) {
      ro.observe(el);
      const prev = el.previousElementSibling;
      if (prev) ro.observe(prev);
      el = el.parentElement;
    }
    const sib = anchorRef.current?.previousElementSibling;
    if (sib) ro.observe(sib);
    return () => ro.disconnect();
  }, [windowed, scrollEl, measureMargin, items.length]);

  const active = windowed && !!scrollEl;
  const est = typeof estimateSize === "number" ? () => estimateSize : estimateSize;
  const virtualizer = useVirtualizer<HTMLElement, HTMLDivElement>({
    count: active ? items.length : 0,
    getScrollElement: () => scrollEl,
    estimateSize: est,
    overscan,
    gap,
    scrollMargin: margin,
    getItemKey: (i) => getKey(items[i], i),
  });

  if (!active) {
    return (
      <>
        <div ref={anchorRef} aria-hidden style={{ display: windowed ? "block" : "none", height: 0 }} />
        {items.map((item, i) => (
          <Fragment key={getKey(item, i)}>{renderItem(item, i)}</Fragment>
        ))}
      </>
    );
  }

  const vItems = virtualizer.getVirtualItems();
  const total = virtualizer.getTotalSize();
  const first = vItems[0];
  const last = vItems[vItems.length - 1];
  const top = first ? Math.max(0, first.start - margin) : 0;
  const bottom = last ? Math.max(0, total - (last.end - margin)) : 0;

  return (
    <>
      <div ref={anchorRef} aria-hidden style={{ height: top, flexShrink: 0 }} />
      {vItems.map((vi) => (
        <div key={vi.key} data-index={vi.index} ref={virtualizer.measureElement} className={rowClassName}>
          {renderItem(items[vi.index], vi.index)}
        </div>
      ))}
      <div aria-hidden style={{ height: bottom, flexShrink: 0 }} />
    </>
  );
}
