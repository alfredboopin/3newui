// ── NOBODY · pointer drag-reorder for list rows (V1.6.4, Phase 3) ────────────
// Face-neutral: works on any list whose rows carry `data-qi={index}` and a
// dedicated grip handle. Pointer events (mouse, pen AND touch, pointer
// capture on the grip) instead of HTML5 DnD, which is flaky in Electron and
// dead on touch. Virtualisation-safe: the drop slot is computed only from the
// rows that are mounted, by index, never by counting DOM children.
//
// Keyboard: the grip is focusable; ↑/↓ (or Alt+↑/↓ anywhere on a row) moves
// the item one slot and keeps focus on its grip. Esc cancels a pointer drag.

import { useCallback, useEffect, useRef, useState } from "react";
import type React from "react";

export interface DragState { from: number; to: number }

export interface RowRect { index: number; top: number; bottom: number }

/** Final index the dragged item lands at for pointer y (rows in any order). */
export function computeDropIndex(rows: RowRect[], from: number, y: number, count: number): number {
  const others = rows.filter((r) => r.index !== from).sort((a, b) => a.index - b.index);
  if (!others.length) return from;
  let to: number | null = null;
  for (const r of others) {
    if (y < (r.top + r.bottom) / 2) { to = r.index > from ? r.index - 1 : r.index; break; }
  }
  if (to === null) {
    const last = others[others.length - 1].index;
    to = last > from ? last : last + 1;
  }
  return Math.max(0, Math.min(count - 1, to));
}

const EDGE_PX = 40;
const MAX_SCROLL_PX = 16;

interface Opts {
  count: number;
  onMove: (from: number, to: number) => void;
  /** the scrolling list box (auto-scroll + row lookup) */
  scrollRef: React.RefObject<HTMLElement | null>;
}

export function useDragReorder({ count, onMove, scrollRef }: Opts) {
  const [drag, setDrag] = useState<DragState | null>(null);
  const live = useRef<{ from: number; to: number; y: number; raf: number; cleanup: () => void } | null>(null);
  const onMoveRef = useRef(onMove);
  onMoveRef.current = onMove;
  const countRef = useRef(count);
  countRef.current = count;

  const measure = useCallback((from: number, y: number) => {
    const box = scrollRef.current;
    if (!box) return from;
    const rows: RowRect[] = [];
    box.querySelectorAll<HTMLElement>("[data-qi]").forEach((el) => {
      const index = Number(el.dataset.qi);
      if (!Number.isFinite(index)) return;
      const r = el.getBoundingClientRect();
      rows.push({ index, top: r.top, bottom: r.bottom });
    });
    return computeDropIndex(rows, from, y, countRef.current);
  }, [scrollRef]);

  const focusGrip = useCallback((index: number) => {
    requestAnimationFrame(() => {
      const g = scrollRef.current?.querySelector<HTMLElement>(`[data-qi="${index}"] [data-grip]`);
      g?.focus({ preventScroll: false });
    });
  }, [scrollRef]);

  const end = useCallback((commit: boolean) => {
    const s = live.current;
    if (!s) return;
    live.current = null;
    cancelAnimationFrame(s.raf);
    s.cleanup();
    document.documentElement.classList.remove("nb-dragging");
    setDrag(null);
    if (commit && s.to !== s.from) onMoveRef.current(s.from, s.to);
  }, []);

  // unmount mid-drag (sheet closed) → just cancel
  useEffect(() => () => end(false), [end]);

  const startPointer = useCallback((e: React.PointerEvent, index: number) => {
    if (e.button !== 0 || countRef.current < 2) return;
    e.preventDefault();
    e.stopPropagation();
    end(false);
    const grip = e.currentTarget as HTMLElement;
    try { grip.setPointerCapture(e.pointerId); } catch { /* ignore */ }
    const pid = e.pointerId;

    const onPtrMove = (ev: PointerEvent) => {
      if (ev.pointerId !== pid || !live.current) return;
      live.current.y = ev.clientY;
      const to = measure(live.current.from, ev.clientY);
      if (to !== live.current.to) { live.current.to = to; setDrag({ from: live.current.from, to }); }
    };
    const onUp = (ev: PointerEvent) => { if (ev.pointerId === pid) end(true); };
    const onCancel = (ev: PointerEvent) => { if (ev.pointerId === pid) end(false); };
    const onKey = (ev: KeyboardEvent) => { if (ev.key === "Escape") { ev.preventDefault(); ev.stopPropagation(); end(false); } };
    window.addEventListener("pointermove", onPtrMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onCancel);
    window.addEventListener("keydown", onKey, true);
    const onBlur = () => end(false);
    window.addEventListener("blur", onBlur);

    // edge auto-scroll while the pointer rests near the top/bottom of the box
    const tick = () => {
      const s = live.current;
      const box = scrollRef.current;
      if (!s) return;
      if (box) {
        const r = box.getBoundingClientRect();
        let dy = 0;
        if (s.y < r.top + EDGE_PX) dy = -Math.ceil(((r.top + EDGE_PX - s.y) / EDGE_PX) * MAX_SCROLL_PX);
        else if (s.y > r.bottom - EDGE_PX) dy = Math.ceil(((s.y - (r.bottom - EDGE_PX)) / EDGE_PX) * MAX_SCROLL_PX);
        if (dy) {
          const before = box.scrollTop;
          box.scrollTop = before + Math.max(-MAX_SCROLL_PX, Math.min(MAX_SCROLL_PX, dy));
          if (box.scrollTop !== before) {
            const to = measure(s.from, s.y);
            if (to !== s.to) { s.to = to; setDrag({ from: s.from, to }); }
          }
        }
      }
      s.raf = requestAnimationFrame(tick);
    };

    live.current = {
      from: index, to: index, y: e.clientY, raf: 0,
      cleanup: () => {
        window.removeEventListener("pointermove", onPtrMove);
        window.removeEventListener("pointerup", onUp);
        window.removeEventListener("pointercancel", onCancel);
        window.removeEventListener("keydown", onKey, true);
        window.removeEventListener("blur", onBlur);
        try { grip.releasePointerCapture(pid); } catch { /* ignore */ }
      },
    };
    live.current.raf = requestAnimationFrame(tick);
    document.documentElement.classList.add("nb-dragging");
    setDrag({ from: index, to: index });
  }, [end, measure, scrollRef]);

  const keyMove = useCallback((e: React.KeyboardEvent, index: number, needAlt: boolean) => {
    if (e.key !== "ArrowUp" && e.key !== "ArrowDown") return false;
    if (needAlt && !e.altKey) return false;
    const to = index + (e.key === "ArrowUp" ? -1 : 1);
    e.preventDefault();
    e.stopPropagation();
    if (to < 0 || to >= countRef.current) return true;
    onMoveRef.current(index, to);
    focusGrip(to);
    return true;
  }, [focusGrip]);

  /** spread on the grip element */
  const gripProps = (index: number, label: string) => ({
    "data-grip": "",
    role: "button" as const,
    tabIndex: 0,
    title: label,
    "aria-label": label,
    onPointerDown: (e: React.PointerEvent) => startPointer(e, index),
    onClick: (e: React.MouseEvent) => e.stopPropagation(),
    onKeyDown: (e: React.KeyboardEvent) => { keyMove(e, index, false); },
  });

  /** spread on the row element (merge your own onKeyDown via `rowKeyDown`) */
  const rowProps = (index: number) => {
    const d = drag;
    let drop: "before" | "after" | undefined;
    if (d && d.to !== d.from && index === d.to) drop = d.to > d.from ? "after" : "before";
    return {
      "data-qi": index,
      "data-drag-src": d && d.from === index ? "" : undefined,
      "data-drop": drop,
    };
  };

  /** Alt+↑/↓ on a focused row; returns true when the key was handled */
  const rowKeyDown = (e: React.KeyboardEvent, index: number) => keyMove(e, index, true);

  return { drag, gripProps, rowProps, rowKeyDown };
}
