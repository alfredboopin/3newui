// ── NOBODY · keyboard helpers for the .nte-* sheets (1.7.0) ─────────────────
// Tab trap + RTL-aware roving arrows, shared by the scrobbling and duplicate
// sheets (same behaviour as the stats sheet).

import { useEffect } from "react";
import type { KeyboardEvent as ReactKeyboardEvent, RefObject } from "react";

const FOCUSABLE = 'button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])';

/** keeps Tab / Shift+Tab inside `root` */
export function trapTab(e: ReactKeyboardEvent, root: HTMLElement | null) {
  if (e.key !== "Tab" || !root) return;
  const nodes = Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE)).filter((n) => n.offsetParent !== null || n === document.activeElement);
  if (!nodes.length) return;
  const first = nodes[0];
  const last = nodes[nodes.length - 1];
  const active = document.activeElement;
  if (e.shiftKey && (active === first || active === root || !root.contains(active))) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && (active === last || !root.contains(active))) { e.preventDefault(); first.focus(); }
}

/** ←/→/Home/End over a radio-like row. Returns true when handled. */
export function rovingArrows<T extends string>(
  e: ReactKeyboardEvent, list: readonly T[], cur: T, set: (v: T) => void,
  root: HTMLElement | null, attr: string, rtl: boolean,
): boolean {
  let step = 0;
  if (e.key === "ArrowRight") step = rtl ? -1 : 1;
  else if (e.key === "ArrowLeft") step = rtl ? 1 : -1;
  else if (e.key === "Home") step = -list.length;
  else if (e.key === "End") step = list.length;
  if (!step) return false;
  e.preventDefault();
  const i = Math.max(0, Math.min(list.length - 1, list.indexOf(cur) + step));
  set(list[i]);
  requestAnimationFrame(() => root?.querySelector<HTMLElement>(`[${attr}="${list[i]}"]`)?.focus());
  return true;
}

/** opens an https page in the system browser (Electron) or a new tab (web) */
export async function openExternalUrl(url: string): Promise<boolean> {
  try {
    const api = typeof window !== "undefined" ? window.electronAPI : undefined;
    if (api?.openExternal) return !!(await api.openExternal(url));
    // noopener makes window.open return null even when the tab opened
    window.open(url, "_blank", "noopener,noreferrer");
    return true;
  } catch { return false; }
}

/** Callback ref for the safe button of an inline confirm: focus it once it is
 *  in the document. Replaces `autoFocus`, which did not move the focus when the
 *  confirm replaced the (focused) button that opened it, so Esc / Tab then
 *  started from <body> instead of the sheet. */
export const focusOnMount = (el: HTMLElement | null) => {
  if (!el) return;
  // Callback refs run in the commit phase, after the old (focused) button has
  // been removed and this one inserted, so focusing right away works and closes
  // the gap where an early Esc / Tab still went to <body> (a rAF can land
  // 100+ ms later on a busy frame). The rAF stays as a fallback for a node
  // that is not in the document yet (portal / detached subtree).
  if (el.isConnected) { el.focus(); if (document.activeElement === el) return; }
  requestAnimationFrame(() => { if (el.isConnected && document.activeElement !== el) el.focus(); });
};

/** When the focused control inside a sheet disappears (a group hidden by
 *  "Not duplicates", "Show hidden" once nothing is hidden, a row removed…),
 *  the browser drops the focus on <body>, outside the sheet's key handler:
 *  Esc / Tab then did nothing. This puts the focus back on the dialog itself
 *  (tabIndex -1) so the keys keep working. Real moves (Tab, clicks on another
 *  control, a confirm's focusOnMount) are left alone. */
export function useFocusRescue(ref: RefObject<HTMLElement | null>) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let t = 0;
    const onOut = (e: FocusEvent) => {
      if (e.relatedTarget) return;
      window.clearTimeout(t);
      t = window.setTimeout(() => {
        const a = document.activeElement;
        if (el.isConnected && (!a || a === document.body)) el.focus({ preventScroll: true });
      }, 0);
    };
    el.addEventListener("focusout", onOut);
    return () => { window.clearTimeout(t); el.removeEventListener("focusout", onOut); };
  }, [ref]);
}
