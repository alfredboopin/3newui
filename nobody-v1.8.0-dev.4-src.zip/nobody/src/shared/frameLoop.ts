// ── NOBODY · shared, visibility-aware frame scheduler (V1.5.4 · Phase 2) ─────
// Every face used to run its own self-rescheduling requestAnimationFrame
// loops (visualizers, sliders, clocks, lyric followers …). Each one had its
// own — or no — hidden-window check, and the Electron window keeps rendering
// while minimized when background throttling is off. This module owns ONE
// rAF loop for the whole document:
//   • it stops completely while `document.hidden` (minimized / occluded
//     window) and restarts on `visibilitychange`;
//   • a subscriber can be bound to an element — it only runs while that
//     element is rendered and on screen (IntersectionObserver: covers
//     `display:none` panes behind another face, closed sheets, off-screen);
//   • a subscriber can be throttled (`minIntervalMs`), and "decorative"
//     subscribers drop to ~30 fps in Performance mode;
//   • a subscriber can park itself (return `false`) and be woken later —
//     no frames are spent on e.g. a fully-decayed paused visualizer;
//   • when nobody is active the loop is not scheduled at all.

import { useEffect, useRef } from "react";
import { isPerfLite, onPerfModeChange } from "../perfMode";

/** Return `false` to park the subscription until `wake()` is called. */
export type FrameCallback = (now: number, dt: number) => void | boolean;

export interface FrameOptions {
  /** Only run while this element is rendered + intersecting the viewport. */
  element?: Element | null;
  /** Minimum time between two calls (ms). */
  minIntervalMs?: number;
  /** Purely visual work — throttled to ~30 fps in Performance mode. */
  decorative?: boolean;
}

export interface FrameHandle {
  /** Remove the subscription for good. */
  stop: () => void;
  /** Resume a parked subscription (no-op when already running). */
  wake: () => void;
}

interface Sub {
  fn: FrameCallback;
  el: Element | null;
  minInterval: number;
  decorative: boolean;
  onScreen: boolean;
  parked: boolean;
  last: number;
}

const LITE_INTERVAL = 1000 / 30 - 1;

const subs = new Set<Sub>();
let raf = 0;
let lite = false;
let listening = false;

// one IntersectionObserver for every element-bound subscription
let io: IntersectionObserver | null = null;
const byEl = new Map<Element, Set<Sub>>();

function observer(): IntersectionObserver | null {
  if (io || typeof IntersectionObserver === "undefined") return io;
  io = new IntersectionObserver((entries) => {
    let woke = false;
    for (const e of entries) {
      const set = byEl.get(e.target);
      if (!set) continue;
      for (const s of set) {
        const was = s.onScreen;
        s.onScreen = e.isIntersecting;
        if (!was && s.onScreen) { s.last = 0; woke = true; }
      }
    }
    if (woke) schedule();
  });
  return io;
}

function runnable(s: Sub): boolean {
  return !s.parked && s.onScreen;
}

function anyRunnable(): boolean {
  for (const s of subs) if (runnable(s)) return true;
  return false;
}

function schedule() {
  if (raf || typeof window === "undefined") return;
  if (document.hidden || !anyRunnable()) return;
  raf = requestAnimationFrame(loop);
}

function loop(now: number) {
  raf = 0;
  if (document.hidden) return; // visibilitychange restarts us
  for (const s of subs) {
    if (!runnable(s)) continue;
    const interval = Math.max(s.minInterval, lite && s.decorative ? LITE_INTERVAL : 0);
    if (interval && s.last && now - s.last < interval) continue;
    const dt = s.last ? now - s.last : 16.7;
    s.last = now;
    try {
      if (s.fn(now, dt) === false) s.parked = true;
    } catch (err) {
      // one broken consumer must never stall every other animation
      console.error("[frameLoop]", err);
    }
  }
  schedule();
}

function ensureListeners() {
  if (listening || typeof document === "undefined") return;
  listening = true;
  lite = isPerfLite();
  onPerfModeChange((on) => { lite = on; });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      if (raf) { cancelAnimationFrame(raf); raf = 0; }
      return;
    }
    // back on screen: reset deltas so nothing "jumps" by the hidden duration
    for (const s of subs) s.last = 0;
    schedule();
  });
}

/** Subscribe a per-frame callback to the shared loop. */
export function subscribeFrame(fn: FrameCallback, opts: FrameOptions = {}): FrameHandle {
  ensureListeners();
  const sub: Sub = {
    fn,
    el: opts.element ?? null,
    minInterval: Math.max(0, opts.minIntervalMs ?? 0),
    decorative: !!opts.decorative,
    onScreen: true,
    parked: false,
    last: 0,
  };
  subs.add(sub);
  if (sub.el) {
    const obs = observer();
    if (obs) {
      let set = byEl.get(sub.el);
      if (!set) { set = new Set(); byEl.set(sub.el, set); obs.observe(sub.el); }
      set.add(sub);
    }
  }
  schedule();
  return {
    stop: () => {
      subs.delete(sub);
      if (sub.el) {
        const set = byEl.get(sub.el);
        if (set) {
          set.delete(sub);
          if (!set.size) { byEl.delete(sub.el); io?.unobserve(sub.el); }
        }
      }
      if (!subs.size && raf) { cancelAnimationFrame(raf); raf = 0; }
    },
    wake: () => {
      if (!sub.parked || !subs.has(sub)) return;
      sub.parked = false;
      sub.last = 0;
      schedule();
    },
  };
}

/**
 * React binding. The latest `fn` is always called (kept in a ref), so the
 * subscription is only rebuilt when `enabled` / the element / the options
 * change — never on every render.
 */
export function useFrame(
  fn: FrameCallback,
  opts: FrameOptions & { enabled?: boolean; elementRef?: React.RefObject<Element | null> } = {}
): void {
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const { enabled = true, elementRef, minIntervalMs, decorative } = opts;
  useEffect(() => {
    if (!enabled) return;
    const h = subscribeFrame((now, dt) => fnRef.current(now, dt), {
      element: elementRef?.current ?? opts.element ?? null,
      minIntervalMs,
      decorative,
    });
    return h.stop;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, elementRef, opts.element, minIntervalMs, decorative]);
}
