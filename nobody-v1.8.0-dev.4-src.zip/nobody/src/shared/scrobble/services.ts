// ── NOBODY · scrobbling service clients (1.7.0, Phase 4 · part 8) ───────────
// Pure clients for Last.fm (API 2.0, signed calls) and ListenBrainz (API 1).
// The transport is injected (desktopFetch in the app: Electron main-process
// proxy with a host allow-list; plain fetch in tests / the web build).
//
// Every call resolves to a SendResult instead of throwing, classified so the
// scrobbler knows what to do with the queue:
//   ok        → drop the sent items (per-item `ignored` are dropped too)
//   retry     → keep everything, try again later (offline, 5xx, rate limit)
//   auth      → keep everything, the user must reconnect (bad session/token)
//   reject    → the batch itself is bad → drop it (or bisect it)
//   config    → the API key / secret is wrong (Last.fm 10/13/26)

import { md5 } from "./md5";

export type ServiceId = "lastfm" | "listenbrainz";
export const SERVICES: ServiceId[] = ["lastfm", "listenbrainz"];

export interface HttpResponseLike { status: number; text(): Promise<string>; headers?: { get(name: string): string | null } }
export type Fetcher = (url: string, init: { method: string; headers?: Record<string, string>; body?: string; timeoutMs?: number }) => Promise<HttpResponseLike>;

/** one listen to send (scrobble) or announce (now playing) */
export interface ScrobbleItem {
  /** dedupe key: `${trackId}@${startMs}` */
  k: string;
  /** listen start, epoch SECONDS */
  ts: number;
  artist: string;
  track: string;
  album?: string;
  /** seconds */
  dur?: number;
}

export type SendKind = "ok" | "retry" | "auth" | "reject" | "config";
export interface SendResult {
  kind: SendKind;
  /** keys the service accepted / ignored (ok only) */
  accepted?: string[];
  ignored?: { k: string; why: string }[];
  /** ms to wait before the next try (rate limit headers) */
  retryAfterMs?: number;
  message?: string;
  status?: number;
}

export const APP_NAME = "NOBODY";

// ───────────────────────────── Last.fm ─────────────────────────────

export const LASTFM_API = "https://ws.audioscrobbler.com/2.0/";
export const LASTFM_AUTH = "https://www.last.fm/api/auth/";
/** Last.fm rejects scrobbles older than 14 days (ignored code 3) */
export const LASTFM_MAX_AGE_S = 14 * 24 * 3600;
export const LASTFM_BATCH = 50;

export interface LastfmKeys { apiKey: string; secret: string }

/** api_sig: params sorted by name (format/callback excluded), name+value
 *  concatenated, secret appended, md5 of the UTF-8 bytes. */
export function lastfmSign(params: Record<string, string>, secret: string): string {
  const names = Object.keys(params).filter((n) => n !== "format" && n !== "callback").sort();
  let s = "";
  for (const n of names) s += n + params[n];
  return md5(s + secret);
}

export function formEncode(params: Record<string, string>): string {
  return Object.keys(params).map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`).join("&");
}

/** Last.fm error code → what to do */
export function lastfmErrorKind(code: number): SendKind {
  switch (code) {
    case 9: // invalid session key
    case 4: // authentication failed
    case 14: // token not authorised (yet)
    case 15: // token expired
      return "auth";
    case 10: // invalid API key
    case 13: // invalid method signature
    case 26: // API key suspended
      return "config";
    case 8: // operation failed
    case 11: // service offline
    case 16: // temporary error
    case 29: // rate limit
      return "retry";
    default:
      return "reject";
  }
}

async function readJson(res: HttpResponseLike): Promise<any> {
  try { return JSON.parse(await res.text()); } catch { return null; }
}

/** transport failure / HTTP status → result (null = parse the body) */
function statusKind(status: number): SendKind | null {
  if (!status) return "retry";
  if (status === 429 || status >= 500) return "retry";
  return null;
}

export class LastfmClient {
  constructor(private keys: LastfmKeys, private fetcher: Fetcher) {}

  get configured() { return !!this.keys.apiKey && !!this.keys.secret; }

  private async call(method: string, params: Record<string, string>, opts: { post?: boolean; sign?: boolean } = {}): Promise<{ kind: SendKind; data?: any; message?: string; status?: number; code?: number }> {
    const p: Record<string, string> = { ...params, method, api_key: this.keys.apiKey };
    if (opts.sign !== false) p.api_sig = lastfmSign(p, this.keys.secret);
    p.format = "json";
    let res: HttpResponseLike;
    try {
      res = opts.post
        ? await this.fetcher(LASTFM_API, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded; charset=utf-8" }, body: formEncode(p), timeoutMs: 15000 })
        : await this.fetcher(`${LASTFM_API}?${formEncode(p)}`, { method: "GET", timeoutMs: 15000 });
    } catch (e) {
      return { kind: "retry", message: String((e as Error)?.message || e) };
    }
    const data = await readJson(res);
    if (data && typeof data.error === "number") {
      return { kind: lastfmErrorKind(data.error), message: String(data.message || `Last.fm error ${data.error}`), status: res.status, code: data.error };
    }
    const sk = statusKind(res.status);
    if (sk) return { kind: sk, status: res.status, message: `HTTP ${res.status}` };
    if (res.status >= 400 || !data) return { kind: "reject", status: res.status, message: `HTTP ${res.status}` };
    return { kind: "ok", data, status: res.status };
  }

  /** step 1 of the desktop auth flow */
  async getToken(): Promise<{ token?: string; kind: SendKind; message?: string }> {
    const r = await this.call("auth.getToken", {});
    const token = r.data?.token;
    return r.kind === "ok" && typeof token === "string" ? { token, kind: "ok" } : { kind: r.kind === "ok" ? "reject" : r.kind, message: r.message };
  }

  authUrl(token: string) {
    return `${LASTFM_AUTH}?api_key=${encodeURIComponent(this.keys.apiKey)}&token=${encodeURIComponent(token)}`;
  }

  /** step 2: after the user allowed access in the browser. `pending` while
   *  they haven't yet (error 14), `expired` after an hour (15). */
  async getSession(token: string): Promise<{ kind: SendKind | "pending" | "expired"; name?: string; key?: string; message?: string }> {
    const r = await this.call("auth.getSession", { token });
    if (r.kind === "ok") {
      const s = r.data?.session;
      if (s && typeof s.key === "string") return { kind: "ok", name: String(s.name || ""), key: s.key };
      return { kind: "reject", message: "no session" };
    }
    if (r.code === 14) return { kind: "pending" };
    if (r.code === 15) return { kind: "expired" };
    return { kind: r.kind, message: r.message };
  }

  async nowPlaying(sk: string, it: Omit<ScrobbleItem, "k" | "ts">): Promise<SendResult> {
    const p: Record<string, string> = { artist: it.artist, track: it.track, sk };
    if (it.album) p.album = it.album;
    if (it.dur && it.dur > 0) p.duration = String(Math.round(it.dur));
    const r = await this.call("track.updateNowPlaying", p, { post: true });
    return { kind: r.kind, message: r.message, status: r.status };
  }

  async scrobble(sk: string, items: ScrobbleItem[]): Promise<SendResult> {
    const batch = items.slice(0, LASTFM_BATCH);
    const p: Record<string, string> = { sk };
    batch.forEach((it, i) => {
      p[`artist[${i}]`] = it.artist;
      p[`track[${i}]`] = it.track;
      p[`timestamp[${i}]`] = String(Math.floor(it.ts));
      if (it.album) p[`album[${i}]`] = it.album;
      if (it.dur && it.dur > 0) p[`duration[${i}]`] = String(Math.round(it.dur));
      p[`chosenByUser[${i}]`] = "1";
    });
    const r = await this.call("track.scrobble", p, { post: true });
    if (r.kind !== "ok") return { kind: r.kind, message: r.message, status: r.status };
    // per-item verdicts: scrobbles.scrobble is an object for one, array for many
    const raw = r.data?.scrobbles?.scrobble;
    const list: any[] = Array.isArray(raw) ? raw : raw ? [raw] : [];
    const accepted: string[] = [];
    const ignored: { k: string; why: string }[] = [];
    batch.forEach((it, i) => {
      const v = list[i];
      const code = Number(v?.ignoredMessage?.code ?? 0);
      if (code) ignored.push({ k: it.k, why: lastfmIgnoredReason(code) });
      else accepted.push(it.k);
    });
    return { kind: "ok", accepted, ignored };
  }
}

export function lastfmIgnoredReason(code: number): string {
  return ({ 1: "artist", 2: "track", 3: "too-old", 4: "too-new", 5: "daily-limit" } as Record<number, string>)[code] || "ignored";
}

// ─────────────────────────── ListenBrainz ───────────────────────────

export const LB_API = "https://api.listenbrainz.org";
export const LB_BATCH = 100;

export interface ClientInfo { version: string }

export function lbTrackMetadata(it: Omit<ScrobbleItem, "k" | "ts">, client: ClientInfo) {
  const additional_info: Record<string, string | number> = {
    media_player: APP_NAME,
    media_player_version: client.version,
    submission_client: APP_NAME,
    submission_client_version: client.version,
  };
  if (it.dur && it.dur > 0) additional_info.duration_ms = Math.round(it.dur * 1000);
  const md: Record<string, unknown> = { artist_name: it.artist, track_name: it.track, additional_info };
  if (it.album) md.release_name = it.album;
  return md;
}

export function lbPayload(type: "single" | "import" | "playing_now", items: (ScrobbleItem | Omit<ScrobbleItem, "k" | "ts">)[], client: ClientInfo) {
  return {
    listen_type: type,
    payload: items.map((it) => {
      const row: Record<string, unknown> = { track_metadata: lbTrackMetadata(it, client) };
      if (type !== "playing_now" && "ts" in it) row.listened_at = Math.floor(it.ts);
      return row;
    }),
  };
}

function retryAfter(res: HttpResponseLike): number | undefined {
  const v = res.headers?.get("x-ratelimit-reset-in") ?? res.headers?.get("retry-after");
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? Math.min(3600, n) * 1000 + 250 : undefined;
}

export class ListenBrainzClient {
  constructor(private fetcher: Fetcher, private client: ClientInfo, private base = LB_API) {}

  private async post(token: string, body: unknown): Promise<SendResult> {
    let res: HttpResponseLike;
    try {
      res = await this.fetcher(`${this.base}/1/submit-listens`, {
        method: "POST",
        headers: { Authorization: `Token ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify(body),
        timeoutMs: 20000,
      });
    } catch (e) {
      return { kind: "retry", message: String((e as Error)?.message || e) };
    }
    if (res.status === 401 || res.status === 403) return { kind: "auth", status: res.status, message: "invalid token" };
    const sk = statusKind(res.status);
    if (sk) return { kind: sk, status: res.status, retryAfterMs: retryAfter(res), message: `HTTP ${res.status}` };
    if (res.status >= 400) {
      const d = await readJson(res);
      return { kind: "reject", status: res.status, message: String(d?.error || `HTTP ${res.status}`) };
    }
    return { kind: "ok", status: res.status };
  }

  /** → user name when the token is valid */
  async validate(token: string): Promise<{ kind: SendKind; name?: string; message?: string }> {
    let res: HttpResponseLike;
    try {
      res = await this.fetcher(`${this.base}/1/validate-token`, { method: "GET", headers: { Authorization: `Token ${token}` }, timeoutMs: 15000 });
    } catch (e) {
      return { kind: "retry", message: String((e as Error)?.message || e) };
    }
    const sk = statusKind(res.status);
    if (sk) return { kind: sk, message: `HTTP ${res.status}` };
    const d = await readJson(res);
    if (d?.valid === true && d.user_name) return { kind: "ok", name: String(d.user_name) };
    return { kind: "auth", message: String(d?.message || "invalid token") };
  }

  nowPlaying(token: string, it: Omit<ScrobbleItem, "k" | "ts">) {
    return this.post(token, lbPayload("playing_now", [it], this.client));
  }

  async scrobble(token: string, items: ScrobbleItem[]): Promise<SendResult> {
    const batch = items.slice(0, LB_BATCH);
    const r = await this.post(token, lbPayload(batch.length === 1 ? "single" : "import", batch, this.client));
    return r.kind === "ok" ? { ...r, accepted: batch.map((x) => x.k), ignored: [] } : r;
  }
}
