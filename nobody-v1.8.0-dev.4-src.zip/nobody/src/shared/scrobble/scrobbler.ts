// ── NOBODY · scrobbler (1.7.0, Phase 4 · part 8) ────────────────────────────
// Sends finished listens to Last.fm and/or ListenBrainz.
//
// Source: the listen tracker's closed listens (`full` = song > 30 s heard
// ≥ 50 % or ≥ 4 min, the Last.fm rule), from every player (engine faces AND
// Classic), whether or not "Keep listening history" is on. "Now playing" is
// announced once a song has really played 5 s.
//
// Offline-first: every listen goes into a per-service queue in localStorage
// (cap 10k each) BEFORE any network call, then the queue is flushed in
// batches (Last.fm 50, ListenBrainz 100). Failures are classified:
//   retry  (offline / 5xx / rate limit) → exponential backoff 30 s … 30 min,
//          plus an immediate try when the OS reports `online`
//   auth   (session revoked / token wrong) → queue kept, "reconnect" shown
//   reject (bad batch) → re-sent one by one, a single bad item is dropped
// A listen is enqueued once (`trackId@start` ring), so a listen recovered
// after a crash or an unload can never be scrobbled twice.
//
// Secrets (Last.fm session key, ListenBrainz token, own Last.fm secret) go
// through `SecretStore`: Electron safeStorage (OS keychain / DPAPI) on the
// desktop, localStorage in the web build.

import {
  LASTFM_MAX_AGE_S, LastfmClient, ListenBrainzClient, SERVICES,
  type Fetcher, type ScrobbleItem, type SendResult, type ServiceId,
} from "./services";
import type { PlayRecord } from "../stats/listenLog";
import type { ListenMeta } from "../stats/listenTracker";

export const STATE_KEY = "nobody-scrobble-v1";
export const QUEUE_KEY = "nobody-scrobble-queue-v1";
export const SEEN_KEY = "nobody-scrobble-seen-v1";
export const QUEUE_CAP = 10_000;
const SEEN_CAP = 600;
export const BACKOFF_MIN_MS = 30_000;
export const BACKOFF_MAX_MS = 30 * 60_000;
const FLUSH_DELAY_MS = 1500;
const PLACEHOLDERS = new Set(["unknown artist", "unknown album", "unknown", "<unknown>", "various artists?"]);

export interface ServiceState {
  enabled: boolean;
  /** account name shown in the UI (empty = not connected) */
  user: string;
  nowPlaying: boolean;
  sent: number;
  ignored: number;
  lastOkAt: number;
  /** "auth" | "config" | "offline" | message */
  lastError: string | null;
  needsAuth: boolean;
}
export interface ScrobbleState {
  lastfm: ServiceState;
  listenbrainz: ServiceState;
  /** user-provided Last.fm API key (the secret lives in the SecretStore) */
  lastfmApiKey: string;
  /** listens skipped because the song had no artist / title */
  noTags: number;
}

export interface SecretStore {
  get(name: string): Promise<string | null>;
  set(name: string, value: string): Promise<void>;
  del(name: string): Promise<void>;
}
type KV = Pick<Storage, "getItem" | "setItem" | "removeItem">;

export interface ScrobblerDeps {
  fetcher: Fetcher;
  secrets: SecretStore;
  storage: KV | null;
  version: string;
  /** built-in Last.fm app keys (empty → the user supplies their own) */
  builtinLastfm: { apiKey: string; secret: string };
  now?: () => number;
  setTimer?: (fn: () => void, ms: number) => unknown;
  clearTimer?: (h: unknown) => void;
  /** library tags for a listen whose snapshot has placeholders */
  resolve?: (id: string) => { title: string; artist: string; album: string } | null;
}

const SECRET = { lastfm: "scrobble.lastfm.session", listenbrainz: "scrobble.listenbrainz.token", lastfmSecret: "scrobble.lastfm.secret" } as const;

const freshService = (): ServiceState => ({ enabled: true, user: "", nowPlaying: true, sent: 0, ignored: 0, lastOkAt: 0, lastError: null, needsAuth: false });
const freshState = (): ScrobbleState => ({ lastfm: freshService(), listenbrainz: freshService(), lastfmApiKey: "", noTags: 0 });

export const cleanName = (v: string | undefined | null) => {
  const s = String(v ?? "").replace(/\s+/g, " ").trim();
  return PLACEHOLDERS.has(s.toLowerCase()) ? "" : s;
};

/** a closed listen → a queue item (null = not scrobblable) */
export function itemFromListen(rec: PlayRecord, resolve?: ScrobblerDeps["resolve"]): ScrobbleItem | "notags" | null {
  if (!rec || !rec.full) return null;
  let artist = cleanName(rec.artist);
  let track = cleanName(rec.title);
  let album = cleanName(rec.album);
  if ((!artist || !track) && resolve) {
    const m = resolve(rec.id);
    if (m) { artist = artist || cleanName(m.artist); track = track || cleanName(m.title); album = album || cleanName(m.album); }
  }
  if (!artist || !track) return "notags";
  return {
    k: `${rec.id}@${rec.at}`,
    ts: Math.floor(rec.at / 1000),
    artist: artist.slice(0, 1024),
    track: track.slice(0, 1024),
    album: album ? album.slice(0, 1024) : undefined,
    dur: rec.dur > 0 ? Math.round(rec.dur) : undefined,
  };
}

interface Runtime { busy: boolean; fails: number; nextAt: number; timer: unknown; oneByOne: number }

export class Scrobbler {
  state: ScrobbleState = freshState();
  queue: Record<ServiceId, ScrobbleItem[]> = { lastfm: [], listenbrainz: [] };
  private seen: string[] = [];
  private secretsCache: Partial<Record<keyof typeof SECRET, string>> = {};
  private rt: Record<ServiceId, Runtime> = {
    lastfm: { busy: false, fails: 0, nextAt: 0, timer: null, oneByOne: 0 },
    listenbrainz: { busy: false, fails: 0, nextAt: 0, timer: null, oneByOne: 0 },
  };
  private listeners = new Set<() => void>();
  private ready: Promise<void>;
  private now: () => number;
  private setTimer: (fn: () => void, ms: number) => unknown;
  private clearTimer: (h: unknown) => void;
  private lb: ListenBrainzClient;
  /** pending Last.fm browser authorisation */
  private authRun = 0;
  rev = 0;

  constructor(private deps: ScrobblerDeps) {
    this.now = deps.now ?? (() => Date.now());
    this.setTimer = deps.setTimer ?? ((fn, ms) => setTimeout(fn, ms));
    this.clearTimer = deps.clearTimer ?? ((h) => clearTimeout(h as ReturnType<typeof setTimeout>));
    this.lb = new ListenBrainzClient(deps.fetcher, { version: deps.version });
    this.load();
    this.ready = this.loadSecrets();
  }

  // ── persistence ──
  private load() {
    const st = this.deps.storage;
    if (!st) return;
    try {
      const raw = st.getItem(STATE_KEY);
      if (raw) {
        const o = JSON.parse(raw);
        const base = freshState();
        for (const s of SERVICES) base[s] = { ...base[s], ...(o?.[s] || {}) };
        base.lastfmApiKey = typeof o?.lastfmApiKey === "string" ? o.lastfmApiKey : "";
        base.noTags = Number(o?.noTags) || 0;
        this.state = base;
      }
    } catch { /* corrupt → fresh */ }
    try {
      const q = JSON.parse(st.getItem(QUEUE_KEY) || "null");
      for (const s of SERVICES) if (Array.isArray(q?.[s])) this.queue[s] = q[s].filter(validItem).slice(-QUEUE_CAP);
    } catch { /* corrupt */ }
    try {
      const seen = JSON.parse(st.getItem(SEEN_KEY) || "null");
      if (Array.isArray(seen)) this.seen = seen.filter((x) => typeof x === "string").slice(-SEEN_CAP);
    } catch { /* corrupt */ }
  }
  private saveState() { try { this.deps.storage?.setItem(STATE_KEY, JSON.stringify(this.state)); } catch { /* quota */ } }
  private saveQueue() { try { this.deps.storage?.setItem(QUEUE_KEY, JSON.stringify(this.queue)); } catch { /* quota */ } }
  private saveSeen() { try { this.deps.storage?.setItem(SEEN_KEY, JSON.stringify(this.seen)); } catch { /* quota */ } }
  private async loadSecrets() {
    for (const k of Object.keys(SECRET) as (keyof typeof SECRET)[]) {
      try { const v = await this.deps.secrets.get(SECRET[k]); if (v) this.secretsCache[k] = v; } catch { /* unavailable */ }
    }
  }
  whenReady() { return this.ready; }

  private emit() {
    this.rev++;
    for (const l of [...this.listeners]) { try { l(); } catch { /* listener bug */ } }
  }
  subscribe(fn: () => void): () => void { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; }

  // ── Last.fm keys ──
  lastfmKeys(): { apiKey: string; secret: string; own: boolean } {
    const own = !!this.state.lastfmApiKey && !!this.secretsCache.lastfmSecret;
    if (own) return { apiKey: this.state.lastfmApiKey, secret: this.secretsCache.lastfmSecret!, own: true };
    return { ...this.deps.builtinLastfm, own: false };
  }
  get hasBuiltinLastfm() { return !!this.deps.builtinLastfm.apiKey && !!this.deps.builtinLastfm.secret; }
  lastfmReady() { const k = this.lastfmKeys(); return !!k.apiKey && !!k.secret; }
  private lastfm() { return new LastfmClient(this.lastfmKeys(), this.deps.fetcher); }

  async setLastfmKeys(apiKey: string, secret: string) {
    apiKey = apiKey.trim(); secret = secret.trim();
    if (!/^[0-9a-f]{32}$/i.test(apiKey) || !/^[0-9a-f]{32}$/i.test(secret)) return false;
    this.state.lastfmApiKey = apiKey;
    this.secretsCache.lastfmSecret = secret;
    await this.deps.secrets.set(SECRET.lastfmSecret, secret).catch(() => {});
    this.saveState();
    this.emit();
    return true;
  }
  async clearLastfmKeys() {
    this.state.lastfmApiKey = "";
    delete this.secretsCache.lastfmSecret;
    await this.deps.secrets.del(SECRET.lastfmSecret).catch(() => {});
    this.saveState();
    this.emit();
  }

  // ── status ──
  connected(s: ServiceId) { return !!this.secretsCache[s] && !!this.state[s].user; }
  active(s: ServiceId) { return this.connected(s) && this.state[s].enabled && !this.state[s].needsAuth; }
  pending(s: ServiceId) { return this.queue[s].length; }
  retryAt(s: ServiceId) { return this.rt[s].nextAt; }
  busy(s: ServiceId) { return this.rt[s].busy; }

  setPref(s: ServiceId, patch: Partial<Pick<ServiceState, "enabled" | "nowPlaying">>) {
    this.state[s] = { ...this.state[s], ...patch };
    this.saveState();
    this.emit();
    if (patch.enabled) this.schedule(s, 0);
  }

  // ── connect / disconnect ──
  async connectListenBrainz(token: string): Promise<{ ok: boolean; why?: "auth" | "offline" | "error"; name?: string }> {
    token = token.trim();
    if (!/^[A-Za-z0-9-]{8,128}$/.test(token)) return { ok: false, why: "auth" };
    const r = await this.lb.validate(token);
    if (r.kind !== "ok" || !r.name) return { ok: false, why: r.kind === "retry" ? "offline" : r.kind === "auth" ? "auth" : "error" };
    await this.deps.secrets.set(SECRET.listenbrainz, token).catch(() => {});
    this.secretsCache.listenbrainz = token;
    this.state.listenbrainz = { ...this.state.listenbrainz, user: r.name, needsAuth: false, lastError: null, enabled: true };
    this.saveState();
    this.emit();
    this.schedule("listenbrainz", 0);
    return { ok: true, name: r.name };
  }

  /** Last.fm desktop auth: token → browser page → poll the session.
   *  `open` shows the URL (openExternal). Resolves when connected / failed. */
  async connectLastfm(open: (url: string) => void | Promise<unknown>, opts: { pollMs?: number; timeoutMs?: number } = {}): Promise<{ ok: boolean; why?: "config" | "offline" | "expired" | "cancelled" | "error"; name?: string }> {
    if (!this.lastfmReady()) return { ok: false, why: "config" };
    const run = ++this.authRun;
    const client = this.lastfm();
    const t = await client.getToken();
    if (run !== this.authRun) return { ok: false, why: "cancelled" };
    if (!t.token) return { ok: false, why: t.kind === "config" ? "config" : t.kind === "retry" ? "offline" : "error" };
    try { await open(client.authUrl(t.token)); } catch { /* the user can still use the copied link */ }
    this.lastAuthUrl = client.authUrl(t.token);
    this.emit();
    const pollMs = opts.pollMs ?? 3000;
    const deadline = this.now() + (opts.timeoutMs ?? 10 * 60_000);
    while (this.now() < deadline) {
      await new Promise((r) => this.setTimer(() => r(null), pollMs));
      if (run !== this.authRun) return { ok: false, why: "cancelled" };
      const s = await client.getSession(t.token);
      if (run !== this.authRun) return { ok: false, why: "cancelled" };
      if (s.kind === "pending" || s.kind === "retry") continue;
      this.lastAuthUrl = null;
      if (s.kind === "ok" && s.key) {
        await this.deps.secrets.set(SECRET.lastfm, s.key).catch(() => {});
        this.secretsCache.lastfm = s.key;
        this.state.lastfm = { ...this.state.lastfm, user: s.name || "Last.fm", needsAuth: false, lastError: null, enabled: true };
        this.saveState();
        this.emit();
        this.schedule("lastfm", 0);
        return { ok: true, name: s.name };
      }
      this.emit();
      return { ok: false, why: s.kind === "expired" ? "expired" : s.kind === "config" ? "config" : "error" };
    }
    this.lastAuthUrl = null;
    this.emit();
    return { ok: false, why: "expired" };
  }
  /** the browser page of a running Last.fm authorisation (copy-link fallback) */
  lastAuthUrl: string | null = null;
  get authorizing() { return this.lastAuthUrl !== null; }
  cancelLastfmAuth() { this.authRun++; this.lastAuthUrl = null; this.emit(); }

  async disconnect(s: ServiceId) {
    if (s === "lastfm") this.cancelLastfmAuth();
    delete this.secretsCache[s];
    await this.deps.secrets.del(SECRET[s]).catch(() => {});
    this.state[s] = { ...freshService(), nowPlaying: this.state[s].nowPlaying };
    this.queue[s] = [];
    const r = this.rt[s];
    if (r.timer) this.clearTimer(r.timer);
    this.rt[s] = { busy: false, fails: 0, nextAt: 0, timer: null, oneByOne: 0 };
    this.saveState();
    this.saveQueue();
    this.emit();
  }

  clearQueue(s: ServiceId) {
    this.queue[s] = [];
    this.saveQueue();
    this.emit();
  }

  // ── listens in ──
  /** listenTracker.onClosed */
  onListenClosed(rec: PlayRecord) {
    const it = itemFromListen(rec, this.deps.resolve);
    if (!it) return;
    const targets = SERVICES.filter((s) => this.connected(s) && this.state[s].enabled);
    if (!targets.length) return;
    if (it === "notags") { this.state.noTags++; this.saveState(); this.emit(); return; }
    if (this.seen.includes(it.k)) return;
    this.seen.push(it.k);
    if (this.seen.length > SEEN_CAP) this.seen.splice(0, this.seen.length - SEEN_CAP);
    this.saveSeen();
    for (const s of targets) {
      const q = this.queue[s];
      q.push(it);
      if (q.length > QUEUE_CAP) q.splice(0, q.length - QUEUE_CAP);
    }
    this.saveQueue();
    this.emit();
    for (const s of targets) this.schedule(s, FLUSH_DELAY_MS);
  }

  /** listenTracker.onGenuine: the song really plays → "now playing" */
  onNowPlaying(id: string, meta: ListenMeta | null) {
    let artist = cleanName(meta?.artist), track = cleanName(meta?.title), album = cleanName(meta?.album);
    if ((!artist || !track) && this.deps.resolve) {
      const m = this.deps.resolve(id);
      if (m) { artist = artist || cleanName(m.artist); track = track || cleanName(m.title); album = album || cleanName(m.album); }
    }
    if (!artist || !track) return;
    const it = { artist, track, album: album || undefined, dur: meta?.duration && meta.duration > 0 ? meta.duration : undefined };
    for (const s of SERVICES) {
      if (!this.active(s) || !this.state[s].nowPlaying) continue;
      const p = s === "lastfm" ? this.lastfm().nowPlaying(this.secretsCache.lastfm!, it) : this.lb.nowPlaying(this.secretsCache.listenbrainz!, it);
      void p.then((r) => { if (r.kind === "auth") this.markAuth(s, r); }, () => {});
    }
  }

  // ── flushing ──
  private schedule(s: ServiceId, ms: number) {
    const r = this.rt[s];
    if (r.timer) this.clearTimer(r.timer);
    r.timer = this.setTimer(() => { r.timer = null; void this.flush(s); }, Math.max(0, ms));
  }

  /** the OS is back online / the user pressed "Send now" */
  retryNow(s?: ServiceId) {
    for (const x of s ? [s] : SERVICES) {
      this.rt[x].fails = 0;
      this.rt[x].nextAt = 0;
      if (this.queue[x].length) this.schedule(x, 0);
    }
    this.emit();
  }

  private markAuth(s: ServiceId, r: SendResult) {
    this.state[s] = { ...this.state[s], needsAuth: true, lastError: "auth" };
    void r;
    this.saveState();
    this.emit();
  }

  async flush(s: ServiceId): Promise<void> {
    await this.ready;
    const r = this.rt[s];
    if (r.busy || !this.active(s)) return;
    r.busy = true;
    this.emit();
    try {
      for (let guard = 0; guard < 400 && this.queue[s].length && this.active(s); guard++) {
        if (s === "lastfm") {
          // Last.fm ignores scrobbles older than 14 days: don't send them
          const min = Math.floor(this.now() / 1000) - LASTFM_MAX_AGE_S + 60;
          const old = this.queue.lastfm.filter((x) => x.ts < min);
          if (old.length) {
            this.queue.lastfm = this.queue.lastfm.filter((x) => x.ts >= min);
            this.state.lastfm.ignored += old.length;
            this.saveQueue();
            this.saveState();
            if (!this.queue.lastfm.length) break;
          }
        }
        const size = r.oneByOne > 0 ? 1 : s === "lastfm" ? 50 : 100;
        const batch = this.queue[s].slice(0, size);
        const res = s === "lastfm"
          ? await this.lastfm().scrobble(this.secretsCache.lastfm!, batch)
          : await this.lb.scrobble(this.secretsCache.listenbrainz!, batch);
        if (!this.connected(s)) return; // disconnected meanwhile
        if (res.kind === "ok") {
          const done = new Set([...(res.accepted ?? []), ...(res.ignored ?? []).map((x) => x.k)]);
          this.queue[s] = this.queue[s].filter((x) => !done.has(x.k));
          this.state[s] = { ...this.state[s], sent: this.state[s].sent + (res.accepted?.length ?? 0), ignored: this.state[s].ignored + (res.ignored?.length ?? 0), lastOkAt: this.now(), lastError: null };
          r.fails = 0;
          r.nextAt = 0;
          if (r.oneByOne > 0) r.oneByOne--;
          this.saveQueue();
          this.saveState();
          this.emit();
          continue;
        }
        if (res.kind === "reject") {
          if (batch.length > 1) { r.oneByOne = batch.length; continue; }
          // one bad item: drop it
          this.queue[s] = this.queue[s].filter((x) => x.k !== batch[0].k);
          this.state[s] = { ...this.state[s], ignored: this.state[s].ignored + 1 };
          if (r.oneByOne > 0) r.oneByOne--;
          this.saveQueue();
          this.saveState();
          this.emit();
          continue;
        }
        if (res.kind === "auth") { this.markAuth(s, res); return; }
        if (res.kind === "config") {
          this.state[s] = { ...this.state[s], lastError: "config" };
          this.saveState();
          return;
        }
        // retry: exponential backoff (or what the server asked for)
        r.fails++;
        const wait = res.retryAfterMs ?? Math.min(BACKOFF_MAX_MS, BACKOFF_MIN_MS * 2 ** (r.fails - 1));
        r.nextAt = this.now() + wait;
        this.state[s] = { ...this.state[s], lastError: "offline" };
        this.saveState();
        this.schedule(s, wait);
        return;
      }
    } finally {
      r.busy = false;
      this.emit();
    }
  }

  /** boot: send what was left from the last session */
  async start() {
    await this.ready;
    for (const s of SERVICES) if (this.queue[s].length && this.active(s)) this.schedule(s, 4000);
  }
}

function validItem(x: unknown): x is ScrobbleItem {
  const it = x as ScrobbleItem;
  return !!it && typeof it.k === "string" && Number.isFinite(it.ts) && typeof it.artist === "string" && !!it.artist && typeof it.track === "string" && !!it.track;
}
