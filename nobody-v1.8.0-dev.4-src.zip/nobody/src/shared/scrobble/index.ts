// ── NOBODY · scrobbling bootstrap (1.7.0) ────────────────────────────────────
// The app-wide Scrobbler: desktopFetch transport (Electron main-process proxy,
// allow-listed hosts), OS-encrypted secrets on the desktop, library fallback
// for listens that were logged with placeholder tags.

import { useSyncExternalStore } from "react";
import { desktopFetch } from "../../desktopHttp";
import { useLibrary } from "../../cinema/store/library";
import { APP_VERSION } from "../../version";
import { listenTracker } from "../stats/listenTracker";
import { Scrobbler, type SecretStore } from "./scrobbler";
import type { Fetcher } from "./services";

const env = ((import.meta as unknown as { env?: Record<string, string | undefined> }).env) || {};
/** Build-time Last.fm application keys (.env: VITE_LASTFM_API_KEY / VITE_LASTFM_SECRET).
 *  Empty → the Scrobbling sheet asks for the user's own API account. */
export const BUILTIN_LASTFM = { apiKey: env.VITE_LASTFM_API_KEY || "", secret: env.VITE_LASTFM_SECRET || "" };

const WEB_SECRETS = "nobody-scrobble-secrets-v1";
function webSecrets(): SecretStore {
  const read = (): Record<string, string> => { try { return JSON.parse(localStorage.getItem(WEB_SECRETS) || "{}") || {}; } catch { return {}; } };
  const write = (o: Record<string, string>) => { try { localStorage.setItem(WEB_SECRETS, JSON.stringify(o)); } catch { /* quota */ } };
  return {
    get: async (n) => read()[n] ?? null,
    set: async (n, v) => { const o = read(); o[n] = v; write(o); },
    del: async (n) => { const o = read(); delete o[n]; write(o); },
  };
}

/** Electron: main-process safeStorage (DPAPI on Windows). Falls back to
 *  the web store on an older preload without the secret IPC. */
function makeSecrets(): SecretStore {
  const api = typeof window !== "undefined" ? window.electronAPI : undefined;
  if (api?.secretGet && api.secretSet && api.secretDelete) {
    return {
      get: async (n) => { try { return (await api.secretGet!(n)) ?? null; } catch { return null; } },
      set: async (n, v) => { await api.secretSet!(n, v); },
      del: async (n) => { await api.secretDelete!(n); },
    };
  }
  return webSecrets();
}

const fetcher: Fetcher = async (url, init) => desktopFetch(url, { method: init.method, headers: init.headers, body: init.body, timeoutMs: init.timeoutMs });

let instance: Scrobbler | null = null;
export function getScrobbler(): Scrobbler {
  if (!instance) {
    instance = new Scrobbler({
      fetcher,
      secrets: makeSecrets(),
      storage: typeof localStorage !== "undefined" ? localStorage : null,
      version: APP_VERSION,
      builtinLastfm: BUILTIN_LASTFM,
      resolve: (id) => {
        const t = useLibrary.getState().tracks[id];
        return t ? { title: t.title, artist: t.artist, album: t.album } : null;
      },
    });
  }
  return instance;
}

let installed = false;
/** called from installListeningHistory(), BEFORE the tracker recovers a
 *  listen left open by a crash (so that one is scrobbled too) */
export function installScrobbling() {
  if (installed) return;
  installed = true;
  const s = getScrobbler();
  listenTracker.onClosed((rec) => s.onListenClosed(rec));
  listenTracker.onGenuine((id, _src, meta) => s.onNowPlaying(id, meta));
  if (typeof window !== "undefined") window.addEventListener("online", () => s.retryNow());
  void s.start();
}

/** React: re-render on every scrobbler change */
export function useScrobbler(): Scrobbler {
  const s = getScrobbler();
  useSyncExternalStore((cb) => s.subscribe(cb), () => s.rev);
  return s;
}
