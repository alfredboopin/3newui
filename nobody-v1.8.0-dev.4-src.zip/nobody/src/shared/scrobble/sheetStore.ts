// ── NOBODY · scrobbling sheet open state (1.7.0) ────────────────────────────
// Same pattern as the stats sheet: one sheet per face, mounted inside that
// face's root; `face` pins which one shows.

import { create } from "zustand";
import { getUiMode } from "../../uiMode";
import type { TagEditorFace } from "../tagEditor/store";

export type ScrobbleFace = TagEditorFace;

interface ScrobbleSheetState {
  face: ScrobbleFace | null;
  open: (face?: ScrobbleFace) => void;
  close: () => void;
}

export const useScrobbleSheet = create<ScrobbleSheetState>((set) => ({
  face: null,
  open: (face) => {
    const mode = face ?? getUiMode();
    if (mode === "classic") return;
    set({ face: mode });
  },
  close: () => set({ face: null }),
}));

export const openScrobbleSheet = (face?: ScrobbleFace) => useScrobbleSheet.getState().open(face);
