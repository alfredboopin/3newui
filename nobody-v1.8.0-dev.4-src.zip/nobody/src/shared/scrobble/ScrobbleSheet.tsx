// ── NOBODY · scrobbling sheet (1.7.0, Phase 4 · part 8b) ────────────────────
// Last.fm + ListenBrainz accounts on the shared .nte-* shell, mounted inside
// each face root (Cinema / EELA / ALOK). Everything goes through the app-wide
// Scrobbler (index.ts): connect / disconnect, per-service switches, pending
// queue, "Send now". Secrets never come back to the renderer UI: the sheet
// only ever shows account names.
//
// Keyboard: Esc closes (or backs out of a confirm), Tab stays inside, keys
// never reach the face (no transport shortcuts while typing a token).

import { useEffect, useRef, useState } from "react";
import type { KeyboardEvent as ReactKeyboardEvent, ReactNode } from "react";
import { AlertTriangle, CheckCircle2, Copy, ExternalLink, KeyRound, Loader2, Radio, RefreshCw, Send, X } from "lucide-react";
import { useSettings } from "../../cinema/store/settings";
import { uiApi } from "../../cinema/store/ui";
import { useT } from "../../cinema/lib/useT";
import { openExternalUrl, trapTab, focusOnMount, useFocusRescue } from "../sheetKeys";
import { useScrobbler } from "./index";
import type { Scrobbler } from "./scrobbler";
import type { ServiceId } from "./services";
import { useScrobbleSheet, type ScrobbleFace } from "./sheetStore";
import "../tagEditor/tagEditor.css";
import "./scrobbleSheet.css";

const LOCALE: Record<string, string> = { en: "en-US", fa: "fa-IR", tr: "tr-TR", ru: "ru-RU" };
export const LASTFM_CREATE_API = "https://www.last.fm/api/account/create";
export const LB_TOKEN_PAGE = "https://listenbrainz.org/settings/";
const NAME: Record<ServiceId, string> = { lastfm: "Last.fm", listenbrainz: "ListenBrainz" };

export function ScrobbleSheet({ face }: { face: ScrobbleFace }) {
  const open = useScrobbleSheet((s) => s.face === face);
  if (!open) return null;
  return <ScrobbleBody face={face} />;
}

/** one-line status for Settings rows: "Last.fm · name", "Off", … */
export function useScrobbleSummary(): { text: string; on: boolean; warn: boolean } {
  const s = useScrobbler();
  const t = useT();
  const parts: string[] = [];
  let warn = false;
  for (const id of ["lastfm", "listenbrainz"] as ServiceId[]) {
    if (!s.connected(id)) continue;
    const st = s.state[id];
    if (st.needsAuth) warn = true;
    parts.push(st.needsAuth ? `${NAME[id]} · ${t("scReconnectShort")}` : !st.enabled ? `${NAME[id]} · ${t("scPausedShort")}` : `${NAME[id]} · ${st.user}`);
  }
  return { text: parts.length ? parts.join("  ·  ") : t("scOffShort"), on: parts.length > 0, warn };
}

type Msg = { kind: "error" | "info"; text: string } | null;

function ScrobbleBody({ face }: { face: ScrobbleFace }) {
  const t = useT();
  const lang = useSettings((s) => s.lang);
  const close = useScrobbleSheet((s) => s.close);
  const s = useScrobbler();
  const dialogRef = useRef<HTMLDivElement>(null);
  useFocusRescue(dialogRef);
  const opener = useRef<Element | null>(typeof document !== "undefined" ? document.activeElement : null);
  const [ask, setAsk] = useState<ServiceId | null>(null);
  const rtl = lang === "fa";
  const locale = LOCALE[lang] || "en-US";

  useEffect(() => {
    // opened from another sheet (stats footer): that sheet's opener got the focus back
    const o = opener.current;
    if (!(o instanceof HTMLElement) || !o.isConnected) opener.current = document.activeElement;
    const el = dialogRef.current?.querySelector<HTMLElement>("[data-sc-first]") ?? dialogRef.current;
    el?.focus();
    const back = opener.current;
    return () => { if (back instanceof HTMLElement && back.isConnected) back.focus(); };
  }, []);

  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (e.key === "Escape") {
      e.preventDefault();
      if (ask) setAsk(null);
      else close();
      return;
    }
    trapTab(e, dialogRef.current);
  };

  const num = (n: number) => n.toLocaleString(locale);
  const time = (ms: number) => {
    const d = new Date(ms);
    const sameDay = new Date().toDateString() === d.toDateString();
    return new Intl.DateTimeFormat(locale, sameDay ? { hour: "2-digit", minute: "2-digit" } : { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(d);
  };

  return (
    <div className="nte-layer nsc-layer" data-face={face} dir={rtl ? "rtl" : "ltr"} onKeyDown={onKeyDown}>
      <div className="nte-backdrop" onClick={close} aria-hidden />
      <div ref={dialogRef} className="nte-dialog nsc-dialog" role="dialog" aria-modal="true" aria-labelledby="nsc-title" tabIndex={-1} data-scrobble-sheet>
        <div className="nte-head">
          <span className="nte-badge" aria-hidden><Radio size={15} /></span>
          <div className="nte-head-text">
            <div id="nsc-title" className="nte-title">{t("scTitle")}</div>
            <div className="nte-sub">{t("scSub")}</div>
          </div>
          <button type="button" className="nte-icon" onClick={close} aria-label={t("close")} title={t("close")}>
            <X size={16} />
          </button>
        </div>

        <div className="nte-body nsc-body">
          <LastfmCard s={s} t={t} num={num} time={time} ask={ask === "lastfm"} setAsk={setAsk} />
          <ListenBrainzCard s={s} t={t} num={num} time={time} ask={ask === "listenbrainz"} setAsk={setAsk} />
          {s.state.noTags > 0 && (
            <div className="nte-note nsc-note" data-sc-notags>{t("scNoTags").replace("{{n}}", num(s.state.noTags))}</div>
          )}
        </div>

        <div className="nte-foot nsc-foot">
          <span className="nsc-rule">{t("scRule")}</span>
          <button type="button" className="nte-btn" onClick={close} data-sc-close>{t("close")}</button>
        </div>
      </div>
    </div>
  );
}

type T = (k: string) => string;
interface CardProps { s: Scrobbler; t: T; num: (n: number) => string; time: (ms: number) => string; ask: boolean; setAsk: (s: ServiceId | null) => void }

// ── Last.fm ──────────────────────────────────────────────────────────────────
function LastfmCard({ s, t, num, time, ask, setAsk }: CardProps) {
  const id: ServiceId = "lastfm";
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<Msg>(null);
  const [key, setKey] = useState("");
  const [secret, setSecret] = useState("");
  const [keyErr, setKeyErr] = useState(false);
  const connected = s.connected(id);
  const ready = s.lastfmReady();
  const own = s.lastfmKeys().own;
  const alive = useRef(true);
  // StrictMode-safe: dev mounts → unmounts → remounts, so set it again on (re)mount
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);

  const runRef = useRef(0);
  const connect = async () => {
    setMsg(null);
    setBusy(true);
    const run = ++runRef.current;
    const r = await s.connectLastfm((url) => openExternalUrl(url));
    if (run !== runRef.current) return; // cancelled, or a newer Connect took over
    if (alive.current) setBusy(false);
    if (r.ok) {
      uiApi.toast(t("scConnected").replace("{{service}}", "Last.fm").replace("{{name}}", r.name || ""), "success");
      return;
    }
    if (r.why === "cancelled") return;
    const text = t(r.why === "offline" ? "scErrOffline" : r.why === "expired" ? "scErrExpired" : r.why === "config" ? "scErrConfig" : "scErrGeneric").replace("{{service}}", "Last.fm");
    if (alive.current) setMsg({ kind: "error", text });
    else uiApi.toast(text, "error");
  };
  const saveKeys = async () => {
    const ok = await s.setLastfmKeys(key, secret);
    setKeyErr(!ok);
    if (ok) { setKey(""); setSecret(""); setMsg(null); }
  };
  const removeKeys = async () => {
    if (connected) await s.disconnect(id);
    await s.clearLastfmKeys();
  };
  const copyLink = async () => {
    const url = s.lastAuthUrl;
    if (!url) return;
    try { await navigator.clipboard.writeText(url); uiApi.toast(t("scLinkCopied"), "success"); }
    catch { uiApi.toast(t("scLinkCopyFail"), "error"); }
  };

  const authUi = (
          <div className="nsc-auth" data-sc-authorizing role="status">
            <Loader2 size={15} className="nte-spin" aria-hidden />
            <span className="nsc-auth-text">{t("scLfmWaiting")}</span>
            <div className="nsc-actions">
              <button type="button" className="nte-btn nte-btn-sm" onClick={() => s.lastAuthUrl && openExternalUrl(s.lastAuthUrl)} data-sc-reopen><ExternalLink size={13} /> {t("scLfmOpenAgain")}</button>
              <button type="button" className="nte-btn nte-btn-sm" onClick={copyLink} data-sc-copy><Copy size={13} /> {t("scCopyLink")}</button>
              <button type="button" className="nte-btn nte-btn-sm" onClick={() => { runRef.current++; setBusy(false); s.cancelLastfmAuth(); }} data-sc-cancel-auth>{t("lsCancel")}</button>
            </div>
          </div>
  );

  return (
    <ServiceShell id={id} s={s} t={t} num={num} time={time} ask={ask} setAsk={setAsk}
      onReconnect={connect} reconnectBusy={busy}
      reconnectForm={s.authorizing ? authUi : null}
      notConnected={
        s.authorizing ? authUi : !ready ? (
          <div className="nsc-keys" data-sc-keys>
            <p className="nsc-p">{t("scLfmNeedKey")}</p>
            <button type="button" className="nsc-link" onClick={() => openExternalUrl(LASTFM_CREATE_API)} data-sc-create-api>
              <ExternalLink size={12} /> {t("scLfmCreateApi")}
            </button>
            <div className="nsc-grid">
              <label className="nte-field">
                <span className="nte-label">{t("scLfmApiKey")}</span>
                <input className="nte-input nsc-mono" value={key} onChange={(e) => { setKey(e.target.value); setKeyErr(false); }} spellCheck={false} autoComplete="off" dir="ltr" aria-invalid={keyErr || undefined} data-sc-apikey data-sc-first />
              </label>
              <label className="nte-field">
                <span className="nte-label">{t("scLfmSecret")}</span>
                <input className="nte-input nsc-mono" type="password" value={secret} onChange={(e) => { setSecret(e.target.value); setKeyErr(false); }} spellCheck={false} autoComplete="off" dir="ltr" aria-invalid={keyErr || undefined} data-sc-secret
                  onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); void saveKeys(); } }} />
              </label>
            </div>
            {keyErr && <div className="nte-err" role="alert" data-sc-key-err>{t("scLfmKeyInvalid")}</div>}
            <div className="nsc-actions">
              <button type="button" className="nte-btn nte-btn-primary nte-btn-sm" onClick={saveKeys} disabled={!key.trim() || !secret.trim()} data-sc-savekeys><KeyRound size={13} /> {t("scLfmSaveKeys")}</button>
            </div>
          </div>
        ) : (
          <div className="nsc-connect">
            <p className="nsc-p">{t("scLfmConnectHint")}</p>
            <div className="nsc-actions">
              <button type="button" className="nte-btn nte-btn-primary nte-btn-sm" onClick={connect} disabled={busy} data-sc-connect="lastfm" data-sc-first>
                {busy ? <Loader2 size={13} className="nte-spin" /> : <ExternalLink size={13} />} {t("scLfmConnect")}
              </button>
              {own && <button type="button" className="nte-btn nte-btn-sm" onClick={removeKeys} data-sc-removekeys>{t("scLfmRemoveKeys")}</button>}
            </div>
          </div>
        )
      }
      extra={connected && own ? <span className="nsc-own" data-sc-own>{t("scLfmOwnKey")}</span> : null}
      msg={msg}
    />
  );
}

// ── ListenBrainz ─────────────────────────────────────────────────────────────
function ListenBrainzCard({ s, t, num, time, ask, setAsk }: CardProps) {
  const id: ServiceId = "listenbrainz";
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<Msg>(null);
  const [reconnecting, setReconnecting] = useState(false);
  const alive = useRef(true);
  // StrictMode-safe: dev mounts → unmounts → remounts, so set it again on (re)mount
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);

  const connect = async () => {
    if (!token.trim()) return;
    setMsg(null);
    setBusy(true);
    const r = await s.connectListenBrainz(token);
    if (!alive.current) return;
    setBusy(false);
    if (r.ok) {
      setToken("");
      setReconnecting(false);
      uiApi.toast(t("scConnected").replace("{{service}}", "ListenBrainz").replace("{{name}}", r.name || ""), "success");
      return;
    }
    setMsg({ kind: "error", text: t(r.why === "auth" ? "scErrToken" : r.why === "offline" ? "scErrOffline" : "scErrGeneric").replace("{{service}}", "ListenBrainz") });
  };

  const form = (
    <div className="nsc-connect" data-sc-lb-form>
      <p className="nsc-p">{t("scLbHint")}</p>
      <button type="button" className="nsc-link" onClick={() => openExternalUrl(LB_TOKEN_PAGE)} data-sc-lb-page>
        <ExternalLink size={12} /> {t("scLbGetToken")}
      </button>
      <div className="nsc-row">
        <label className="nte-field nsc-grow">
          <span className="nte-label">{t("scLbToken")}</span>
          <input className="nte-input nsc-mono" type="password" value={token} onChange={(e) => { setToken(e.target.value); setMsg(null); }}
            spellCheck={false} autoComplete="off" dir="ltr" aria-invalid={msg?.kind === "error" || undefined} data-sc-token
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); void connect(); } }} />
        </label>
        <button type="button" className="nte-btn nte-btn-primary nte-btn-sm nsc-row-btn" onClick={connect} disabled={busy || !token.trim()} data-sc-connect="listenbrainz">
          {busy ? <Loader2 size={13} className="nte-spin" /> : <CheckCircle2 size={13} />} {t("scLbConnect")}
        </button>
      </div>
    </div>
  );

  return (
    <ServiceShell id={id} s={s} t={t} num={num} time={time} ask={ask} setAsk={setAsk}
      onReconnect={() => { setReconnecting(true); setMsg(null); }} reconnectBusy={busy}
      notConnected={form}
      reconnectForm={reconnecting ? form : null}
      msg={msg}
    />
  );
}

// ── shared service card ──────────────────────────────────────────────────────
function ServiceShell({ id, s, t, num, time, ask, setAsk, notConnected, reconnectForm, onReconnect, reconnectBusy, extra, msg }: CardProps & {
  id: ServiceId; notConnected: ReactNode; reconnectForm?: ReactNode; onReconnect: () => void; reconnectBusy: boolean; extra?: ReactNode; msg: Msg;
}) {
  const connected = s.connected(id);
  const st = s.state[id];
  const pending = s.pending(id);
  const busy = s.busy(id);
  const retryAt = s.retryAt(id);
  const status = !connected ? "off" : st.needsAuth ? "auth" : !st.enabled ? "paused" : st.lastError === "offline" ? "offline" : st.lastError === "config" ? "config" : "on";
  const pill: Record<string, string> = { off: "scStNotConnected", auth: "scStReconnect", paused: "scStPaused", offline: "scStOffline", config: "scStConfig", on: "scStConnected" };

  return (
    <section className="nsc-card" data-sc-service={id} data-sc-status={status} aria-labelledby={`nsc-h-${id}`}>
      <div className="nsc-card-head">
        <span className="nsc-logo" data-logo={id} aria-hidden>{id === "lastfm" ? "fm" : "LB"}</span>
        <div className="nsc-card-title">
          <h3 id={`nsc-h-${id}`} className="nsc-h">{NAME[id]}</h3>
          {connected && <span className="nsc-user" dir="auto" data-sc-user>{st.user}</span>}
        </div>
        <span className="nsc-pill" data-tone={status === "on" ? "ok" : status === "off" || status === "paused" ? "mut" : "warn"} data-sc-pill>
          {t(pill[status])}
        </span>
      </div>

      {!connected && notConnected}

      {connected && (
        <>
          {status === "auth" && (
            <div className="nte-note nsc-warn" role="alert" data-sc-auth-note>
              <AlertTriangle size={14} aria-hidden /> <span>{t("scAuthLost").replace("{{service}}", NAME[id])}</span>
            </div>
          )}
          {status === "auth" && reconnectForm}
          {status === "offline" && (
            <div className="nte-note nsc-warn" data-sc-offline-note>
              <AlertTriangle size={14} aria-hidden />
              <span>{(retryAt > Date.now() ? t("scOfflineAt").replace("{{time}}", time(retryAt)) : t("scOffline")).replace("{{service}}", NAME[id])}</span>
            </div>
          )}
          {status === "config" && <div className="nte-note nsc-warn" data-sc-config-note><AlertTriangle size={14} aria-hidden /> <span>{t("scErrConfig")}</span></div>}

          <div className="nsc-switches">
            <SwitchRow label={t("scEnabled")} sub={t("scEnabledSub")} on={st.enabled} onChange={(v) => s.setPref(id, { enabled: v })} data={`${id}-enabled`} first />
            <SwitchRow label={t("scNowPlaying")} sub={t("scNowPlayingSub")} on={st.nowPlaying} onChange={(v) => s.setPref(id, { nowPlaying: v })} data={`${id}-np`} disabled={!st.enabled} />
          </div>

          <dl className="nsc-stats">
            <div data-sc-stat="pending"><dt>{t("scPending")}</dt><dd>{num(pending)}</dd></div>
            <div data-sc-stat="sent"><dt>{t("scSent")}</dt><dd>{num(st.sent)}</dd></div>
            {st.ignored > 0 && <div data-sc-stat="ignored"><dt>{t("scIgnored")}</dt><dd>{num(st.ignored)}</dd></div>}
            <div data-sc-stat="last"><dt>{t("scLastSent")}</dt><dd>{st.lastOkAt ? time(st.lastOkAt) : "—"}</dd></div>
          </dl>
          {extra}

          {ask ? (
            <div className="nsc-ask" role="alertdialog" aria-label={t("scDisconnect")} data-sc-ask>
              <span className="nsc-ask-text">{(pending ? t("scDisconnectAskPending").replace("{{n}}", num(pending)) : t("scDisconnectAsk")).replace("{{service}}", NAME[id])}</span>
              <button type="button" className="nte-btn nte-btn-sm" onClick={() => setAsk(null)} ref={focusOnMount}>{t("lsCancel")}</button>
              <button type="button" className="nte-btn nte-btn-sm nte-btn-danger" onClick={() => { setAsk(null); void s.disconnect(id); }} data-sc-disconnect-yes>{t("scDisconnect")}</button>
            </div>
          ) : (
            <div className="nsc-actions">
              {status === "auth" && !reconnectForm && (
                <button type="button" className="nte-btn nte-btn-primary nte-btn-sm" onClick={onReconnect} disabled={reconnectBusy} data-sc-reconnect>
                  {reconnectBusy ? <Loader2 size={13} className="nte-spin" /> : <RefreshCw size={13} />} {t("scReconnect")}
                </button>
              )}
              <button type="button" className="nte-btn nte-btn-sm" onClick={() => s.retryNow(id)} disabled={!pending || busy || !s.active(id)} data-sc-send>
                {busy ? <Loader2 size={13} className="nte-spin" /> : <Send size={13} />} {busy ? t("scSending") : t("scSendNow")}
              </button>
              <span className="nsc-grow" />
              <button type="button" className="nte-btn nte-btn-sm" onClick={() => setAsk(id)} data-sc-disconnect>{t("scDisconnect")}</button>
            </div>
          )}
        </>
      )}
      {msg && <div className={msg.kind === "error" ? "nte-err nsc-msg" : "nsc-msg"} role={msg.kind === "error" ? "alert" : "status"} data-sc-msg>{msg.text}</div>}
    </section>
  );
}

function SwitchRow({ label, sub, on, onChange, data, disabled, first }: { label: string; sub?: string; on: boolean; onChange: (v: boolean) => void; data: string; disabled?: boolean; first?: boolean }) {
  return (
    <div className="nsc-switch-row" data-disabled={disabled || undefined}>
      <div className="nsc-switch-text">
        <span className="nsc-switch-label">{label}</span>
        {sub && <span className="nsc-switch-sub">{sub}</span>}
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={on}
        aria-label={label}
        className="nsc-switch"
        disabled={disabled}
        onClick={() => onChange(!on)}
        data-sc-switch={data}
        {...(first ? { "data-sc-first": true } : {})}
      />
    </div>
  );
}
