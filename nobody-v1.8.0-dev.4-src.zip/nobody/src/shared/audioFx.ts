// ── NOBODY · shared audio FX (V1.6.1, Phase 3) ───────────────────────────────
// One EQ definition for every face: band layouts (6 or 10 bands), presets,
// preamp and the WebAudio filter chain itself. The shared engine (Cinema /
// EELA / ALOK) and the Classic player both build their chain from here, so
// a preset sounds the same whichever face is playing.

export type EqBandCount = 6 | 10;

export const EQ_FREQS_6 = [60, 150, 400, 1000, 2400, 15000] as const;
export const EQ_FREQS_10 = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000] as const;

export const EQ_MIN_DB = -12;
export const EQ_MAX_DB = 12;
export const PREAMP_MIN_DB = -12;
export const PREAMP_MAX_DB = 12;

export function eqFreqs(bands: EqBandCount | undefined): readonly number[] {
  return bands === 10 ? EQ_FREQS_10 : EQ_FREQS_6;
}

export function normBands(v: unknown): EqBandCount {
  return Number(v) === 10 ? 10 : 6;
}

/** Presets carry an explicit curve per layout (the 6-band values are the
 *  pre-1.6.1 ones, so existing users' presets keep matching). */
export const EQ_PRESETS: Record<string, { g6: number[]; g10: number[] }> = {
  flat: { g6: [0, 0, 0, 0, 0, 0], g10: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  bass: { g6: [7, 5, 2.5, 0, -1, -1.5], g10: [7, 7, 5.5, 3.5, 2, 0, -1, -1, -1.5, -1.5] },
  vocal: { g6: [-2, -1, 1.5, 4.5, 4, 1.5], g10: [-2, -2, -1, 0.5, 2, 4.5, 4, 3.5, 2.5, 1.5] },
  treble: { g6: [-1.5, -1, 0, 1, 4.5, 6.5], g10: [-1.5, -1.5, -1, -0.5, 0, 1, 4, 5, 6, 6.5] },
  rock: { g6: [4, 2.5, -0.5, -1, 1.5, 5], g10: [5, 4, 3, 1, -1, -1, 1, 3, 4, 5] },
  pop: { g6: [1, 3.5, 3.5, 0, -1, -1], g10: [-1, 1, 3, 4, 3, 0, -1, -1, -1, -1] },
  jazz: { g6: [2, 1.5, 0, -1, 0.5, 3], g10: [3, 2, 1, 2, -1, -1, 0, 1, 2, 3] },
  classical: { g6: [0, 0, 0, 0, -2.5, -4], g10: [0, 0, 0, 0, 0, 0, -2, -3, -3, -4] },
  hiphop: { g6: [5, 2.5, 0.5, -1, 0.5, 3], g10: [6, 5, 2, 3, -1, -1, 1, 0, 2, 3] },
  electronic: { g6: [5.5, 4, 1, 0, 3, 5], g10: [5.5, 5.5, 4.5, 2.5, 1, 0, 2.5, 3.5, 4.5, 5] },
  acoustic: { g6: [3, 2, 1.5, 2, 1.5, 2.5], g10: [3, 3, 2, 1.5, 1.5, 2, 1.5, 2, 2, 2.5] },
  loudness: { g6: [4, 0, -1.5, 0, -1.5, 2], g10: [6, 4, 0, 0, -2, 0, -1, -2, 4, 2] },
  cinema: { g6: [4.5, 3, 0, 2, 4, 3], g10: [4.5, 4.5, 3.5, 1.5, 0.5, 2, 3.5, 3.5, 3.5, 3] },
};

export const EQ_PRESET_IDS = Object.keys(EQ_PRESETS);

export function presetGains(id: string, bands: EqBandCount): number[] | null {
  const p = EQ_PRESETS[id];
  if (!p) return null;
  return [...(bands === 10 ? p.g10 : p.g6)];
}

/** Which preset (if any) the gains currently equal. */
export function matchPreset(gains: readonly number[], bands: EqBandCount): string | null {
  for (const id of EQ_PRESET_IDS) {
    const g = presetGains(id, bands)!;
    if (g.length === gains.length && g.every((v, i) => Math.abs(v - (gains[i] ?? 0)) < 0.01)) return id;
  }
  return null;
}

const clampDb = (v: unknown, lo = EQ_MIN_DB, hi = EQ_MAX_DB): number => {
  const n = Number(v);
  return isFinite(n) ? Math.max(lo, Math.min(hi, n)) : 0;
};

/** Gains sized/clamped for `bands`. A curve saved for the other layout is
 *  resampled (log-frequency interpolation) instead of being dropped. */
export function fitGains(gains: readonly unknown[] | undefined, bands: EqBandCount): number[] {
  const target = eqFreqs(bands);
  const g = Array.isArray(gains) ? gains.map((v) => clampDb(v)) : [];
  if (g.length === target.length) return g;
  if (g.length === EQ_FREQS_6.length || g.length === EQ_FREQS_10.length) {
    return resampleGains(g, g.length === 10 ? EQ_FREQS_10 : EQ_FREQS_6, target);
  }
  return target.map(() => 0);
}

export function resampleGains(g: readonly number[], from: readonly number[], to: readonly number[]): number[] {
  const lf = from.map((f) => Math.log(f));
  return to.map((f) => {
    const x = Math.log(f);
    if (x <= lf[0]) return g[0] ?? 0;
    if (x >= lf[lf.length - 1]) return g[lf.length - 1] ?? 0;
    for (let i = 0; i < lf.length - 1; i++) {
      if (x >= lf[i] && x <= lf[i + 1]) {
        const t = (x - lf[i]) / (lf[i + 1] - lf[i]);
        return Math.round(((g[i] ?? 0) + ((g[i + 1] ?? 0) - (g[i] ?? 0)) * t) * 2) / 2;
      }
    }
    return 0;
  });
}

export function clampPreamp(v: unknown): number {
  return clampDb(v, PREAMP_MIN_DB, PREAMP_MAX_DB);
}

export function dbToGain(db: number): number {
  return Math.pow(10, db / 20);
}

export function fmtFreq(f: number): string {
  return f >= 1000 ? `${f / 1000}k` : String(f);
}

export interface EqConfig {
  enabled: boolean;
  bands: EqBandCount;
  gains: number[];
  preampDb: number;
}

/** Read the persisted EQ block (settings store shape) into a clean config. */
export function readEqConfig(s: { eqEnabled?: boolean; eqBands?: number; eqGains?: number[]; eqPreamp?: number }): EqConfig {
  const bands = normBands(s.eqBands);
  return {
    enabled: !!s.eqEnabled,
    bands,
    gains: fitGains(s.eqGains, bands),
    preampDb: clampPreamp(s.eqPreamp ?? 0),
  };
}

/** preamp GainNode → N peaking filters → `dest`. `input` is what sources
 *  connect to. Changing the band count rebuilds the filters in place. */
export class FxChain {
  readonly input: GainNode;
  private filters: BiquadFilterNode[] = [];
  private bands: EqBandCount | 0 = 0;

  constructor(private ctx: AudioContext, private dest: AudioNode) {
    this.input = ctx.createGain();
    this.input.connect(dest);
  }

  apply(cfg: EqConfig) {
    if (cfg.bands !== this.bands) this.rebuild(cfg.bands);
    const on = cfg.enabled;
    this.filters.forEach((node, i) => {
      try { node.gain.value = on ? (cfg.gains[i] ?? 0) : 0; } catch { /* ignore */ }
    });
    try { this.input.gain.value = on ? dbToGain(cfg.preampDb) : 1; } catch { /* ignore */ }
  }

  private rebuild(bands: EqBandCount) {
    try { this.input.disconnect(); } catch { /* ignore */ }
    for (const f of this.filters) { try { f.disconnect(); } catch { /* ignore */ } }
    const freqs = eqFreqs(bands);
    const q = bands === 10 ? 1.41 : 1.1; // ~1 octave vs the wider 6-band layout
    this.filters = freqs.map((f) => {
      const node = this.ctx.createBiquadFilter();
      node.type = "peaking";
      node.frequency.value = f;
      node.Q.value = q;
      node.gain.value = 0;
      return node;
    });
    let chain: AudioNode = this.input;
    for (const node of this.filters) { chain.connect(node); chain = node; }
    chain.connect(this.dest);
    this.bands = bands;
  }
}
