// ── NOBODY · listening history bootstrap (1.7.0-dev.10) ─────────────────────
// Called once from main.tsx, before any face mounts.
import { useSettings } from "../../cinema/store/settings";
import { useLibrary } from "../../cinema/store/library";
import { listenTracker, wireListenTrackerLifecycle } from "./listenTracker";
import { installScrobbling } from "../scrobble";

let done = false;
export function installListeningHistory() {
  if (done) return;
  done = true;
  listenTracker.setEnabledGetter(() => useSettings.getState().statsEnabled !== false);
  // Classic never fed Most played / last played / smart "plays" rules: the
  // engine counts its own plays (pushRecent + recordPlay at 5 s), Classic
  // now does the same through the tracker's 5 s mark.
  listenTracker.onGenuine((id, src) => {
    if (src === "classic") useLibrary.getState().recordPlay(id);
  });
  // 1.7.0: scrobbling hooks first, so a listen recovered below is sent too
  installScrobbling();
  wireListenTrackerLifecycle();
  listenTracker.recover();
}
