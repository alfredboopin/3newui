// ── NOBODY · listening stats sheet (1.7.0-dev.11, Phase 4 · part 7b) ────────
// One sheet for Cinema / EELA / ALOK, mounted inside each face root on the
// tag editor's face-mapped .nte-* shell (palette, radius, RTL for free).
// Reads the listen log (listenLog.ts) and aggregates it with the pure
// computeStats(); updates live while open (a song closing appends a row).
//
// Keyboard: Esc closes (or backs out of the Clear prompt), Tab stays inside,
// ←/→ on the period and top-list tabs move the selection (RTL-aware), keys
// never reach the face.

import { focusOnMount, useFocusRescue } from "../sheetKeys";
import { useEffect, useMemo, useRef, useState } from "react";
import type { KeyboardEvent as ReactKeyboardEvent, ReactNode } from "react";
import { BarChart3, Download, Flame, Play, Radio, Trash2, X } from "lucide-react";
import { openScrobbleSheet } from "../scrobble/sheetStore";
import { useLibrary } from "../../cinema/store/library";
import { useSettings } from "../../cinema/store/settings";
import { uiApi } from "../../cinema/store/ui";
import { useT } from "../../cinema/lib/useT";
import { engine } from "../../cinema/lib/engine";
import { fold } from "../../cinema/lib/smartPlaylist";
import { splitGenres } from "../replayGain";
import { clearPlays, getPlays, onPlayLog, peekPlays, playLogRev, type PlayRecord } from "./listenLog";
import { listenTracker } from "./listenTracker";
import { STATS_RANGES, cleanTagName, computeStats, playsToCsv, splitDuration, type ListenStats, type StatsRange, type TopItem } from "./stats";
import { useStatsSheet, type StatsFace } from "./sheetStore";
import type { Track } from "../../cinema/types";
import "../tagEditor/tagEditor.css";
import "./statsSheet.css";

type TopKind = "tracks" | "artists" | "albums" | "genres";
const TOP_KINDS: TopKind[] = ["tracks", "artists", "albums", "genres"];
const TOP_LABEL: Record<TopKind, string> = { tracks: "lsTopSongs", artists: "lsTopArtists", albums: "lsTopAlbums", genres: "lsTopGenres" };
const LOCALE: Record<string, string> = { en: "en-US", fa: "fa-IR", tr: "tr-TR", ru: "ru-RU" };
/** first day of the week shown in the weekday chart (0 = Sunday) */
const WEEK_START: Record<string, number> = { en: 0, fa: 6, tr: 1, ru: 1 };

export function StatsSheet({ face }: { face: StatsFace }) {
  const open = useStatsSheet((s) => s.face === face);
  if (!open) return null;
  return <StatsBody face={face} />;
}

/** the log, live: re-read on every append / clear */
function usePlayLog(): { rows: readonly PlayRecord[] | null; rev: number } {
  const [state, setState] = useState(() => ({ rows: peekPlays() as readonly PlayRecord[] | null, rev: playLogRev() }));
  useEffect(() => {
    let alive = true;
    const pull = () => { getPlays().then((rows) => { if (alive) setState({ rows, rev: playLogRev() }); }, () => { if (alive) setState({ rows: [], rev: playLogRev() }); }); };
    pull();
    const off = onPlayLog(pull);
    return () => { alive = false; off(); };
  }, []);
  return state;
}

function StatsBody({ face }: { face: StatsFace }) {
  const t = useT();
  const lang = useSettings((s) => s.lang);
  const enabled = useSettings((s) => s.statsEnabled !== false);
  const setSetting = useSettings((s) => s.set);
  const close = useStatsSheet((s) => s.close);
  const range = useStatsSheet((s) => s.range);
  const setRange = useStatsSheet((s) => s.setRange);
  const tracks = useLibrary((s) => s.tracks);
  const order = useLibrary((s) => s.order);
  const { rows, rev } = usePlayLog();
  const [kind, setKind] = useState<TopKind>("tracks");
  const [askClear, setAskClear] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);
  useFocusRescue(dialogRef);
  const opener = useRef<Element | null>(typeof document !== "undefined" ? document.activeElement : null);
  const locale = LOCALE[lang] || "en-US";
  const rtl = lang === "fa";

  // focus in (the active period), focus back to the opener on unmount
  useEffect(() => {
    const el = dialogRef.current?.querySelector<HTMLElement>('[data-range][aria-checked="true"]') ?? dialogRef.current;
    el?.focus();
    const back = opener.current;
    return () => { if (back instanceof HTMLElement && back.isConnected) back.focus(); };
  }, []);

  const stats: ListenStats | null = useMemo(() => {
    if (!rows) return null;
    return computeStats(rows, {
      range,
      topN: 10,
      resolve: (id) => {
        const x = tracks[id];
        return x ? { title: x.title, artist: x.artist, album: x.album, genre: x.genre } : null;
      },
      unknownArtist: t("lsUnknownArtist"),
      unknownAlbum: t("unknownAlbum"),
      unknownGenre: t("lbUnknownGenre"),
    });
    // rev: the cached array is appended in place
  }, [rows, rev, range, tracks, t]);

  const num = (n: number) => n.toLocaleString(locale);
  const hh = (n: number) => n.toLocaleString(locale, { minimumIntegerDigits: 2, useGrouping: false });
  const dur = (ms: number, short = false) => {
    const { d, h, m } = splitDuration(ms);
    const parts: string[] = [];
    if (d) parts.push(`${num(d)} ${t("lsUnitD")}`);
    if (h || d) parts.push(`${num(h)} ${t("lsUnitH")}`);
    if (!d || !short) parts.push(`${num(m)} ${t("lsUnitM")}`);
    if (short && parts.length > 2) parts.length = 2;
    return parts.join(" ");
  };
  const fmtDay = (start: number, withYear = false) =>
    new Intl.DateTimeFormat(locale, { day: "numeric", month: "short", ...(withYear ? { year: "numeric" } : {}) }).format(new Date(start));

  // ── play from a top row ──
  const libList = useMemo(() => order.map((id) => tracks[id]).filter(Boolean) as Track[], [order, tracks]);
  const queueFor = (item: TopItem, k: TopKind, list: TopItem[]): string[] => {
    if (k === "tracks") return list.map((x) => x.id).filter((id) => !!tracks[id]);
    const match = (x: Track) => {
      const aKey = fold(cleanTagName(x.artist));
      if (k === "artists") return aKey === item.key;
      if (k === "albums") return `${fold(cleanTagName(x.album))}\u0001${aKey}` === item.key;
      const gs = splitGenres(x.genre);
      return gs.length ? gs.some((g) => fold(g) === item.key) : item.key === "";
    };
    return libList.filter(match).map((x) => x.id);
  };
  const playItem = (item: TopItem, k: TopKind, list: TopItem[]) => {
    const ids = queueFor(item, k, list);
    if (!ids.length) return;
    engine.setQueue(ids, ids.includes(item.id) ? item.id : ids[0]);
  };

  // ── actions ──
  const exportCsv = async () => {
    const all = rows ?? (await getPlays());
    if (!all.length) return;
    const csv = "\ufeff" + playsToCsv(all); // BOM: Excel reads UTF-8 (Persian / Cyrillic) right
    const stamp = new Date().toISOString().slice(0, 10);
    const file = `nobody-listening-${stamp}.csv`;
    try {
      const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = file;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      uiApi.toast(t("lsExported").replace("{{n}}", num(all.length)), "success", { sub: file });
    } catch {
      uiApi.toast(t("lsExportFail"), "error");
    }
  };
  const doClear = async () => {
    setAskClear(false);
    listenTracker.discard();
    await clearPlays();
    uiApi.toast(t("lsCleared"), "success");
  };

  // ── keyboard ──
  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (e.key === "Escape") {
      e.preventDefault();
      if (askClear) setAskClear(false);
      else close();
      return;
    }
    if (e.key === "Tab" && dialogRef.current) {
      const nodes = Array.from(
        dialogRef.current.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])'),
      ).filter((n) => n.offsetParent !== null || n === document.activeElement);
      if (!nodes.length) return;
      const first = nodes[0];
      const last = nodes[nodes.length - 1];
      const active = document.activeElement;
      if (e.shiftKey && (active === first || active === dialogRef.current)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && active === last) { e.preventDefault(); first.focus(); }
    }
  };
  /** roving arrows for a radio-like row; `step` +1 = visually next */
  const arrows = <T extends string>(e: ReactKeyboardEvent, list: readonly T[], cur: T, set: (v: T) => void, attr: string) => {
    let step = 0;
    if (e.key === "ArrowRight") step = rtl ? -1 : 1;
    else if (e.key === "ArrowLeft") step = rtl ? 1 : -1;
    else if (e.key === "Home") step = -list.length;
    else if (e.key === "End") step = list.length;
    if (!step) return;
    e.preventDefault();
    const i = Math.max(0, Math.min(list.length - 1, list.indexOf(cur) + step));
    set(list[i]);
    requestAnimationFrame(() => dialogRef.current?.querySelector<HTMLElement>(`[${attr}="${list[i]}"]`)?.focus());
  };

  const loading = !stats;
  const hasAny = !!rows && rows.length > 0;
  const empty = !!stats && stats.plays === 0;
  const topList: TopItem[] = !stats ? [] : (
    kind === "tracks" ? stats.topTracks
    : kind === "artists" ? stats.topArtists.filter((x) => x.key !== "")
    : kind === "albums" ? stats.topAlbums.filter((x) => !x.key.startsWith("\u0001"))
    : stats.topGenres
  );
  const topMax = topList.reduce((a, x) => Math.max(a, x.ms), 0) || 1;

  return (
    <div className="nte-layer nls-layer" data-face={face} dir={rtl ? "rtl" : "ltr"} onKeyDown={onKeyDown}>
      <div className="nte-backdrop" onClick={close} aria-hidden />
      <div ref={dialogRef} className="nte-dialog nls-dialog" role="dialog" aria-modal="true" aria-labelledby="nls-title" tabIndex={-1} data-stats-sheet>
        <div className="nte-head">
          <span className="nte-badge" aria-hidden><BarChart3 size={15} /></span>
          <div className="nte-head-text">
            <div id="nls-title" className="nte-title">{t("lsTitle")}</div>
            <div className="nte-sub">{t("lsSub")}</div>
          </div>
          <button type="button" className="nte-icon" onClick={close} aria-label={t("close")} title={t("close")}>
            <X size={16} />
          </button>
        </div>

        <div className="nte-body nls-body">
          {/* period */}
          <div className="nls-seg" role="radiogroup" aria-label={t("lsRange")}>
            {STATS_RANGES.map((r) => (
              <button
                key={r}
                type="button"
                role="radio"
                aria-checked={r === range}
                tabIndex={r === range ? 0 : -1}
                data-range={r}
                className="nls-seg-btn"
                onClick={() => setRange(r)}
                onKeyDown={(e) => arrows<StatsRange>(e, STATS_RANGES, range, setRange, "data-range")}
              >
                {t(`lsR_${r}`)}
              </button>
            ))}
          </div>

          {!enabled && <div className="nte-note nls-note" data-stats-off>{t("lsOff")}</div>}

          {loading && <div className="nls-empty">{t("lsLoading")}</div>}
          {!loading && !hasAny && <div className="nls-empty" data-stats-empty>{t("lsEmpty")}</div>}
          {!loading && hasAny && empty && <div className="nls-empty" data-stats-empty-range>{t("lsEmptyRange")}</div>}

          {stats && !empty && (
            <>
              {/* totals */}
              <div className="nls-cards">
                <Card label={t("lsTime")} value={dur(stats.totalMs, true)} big data-k="time" />
                <Card label={t("lsPlays")} value={num(stats.plays)} data-k="plays" />
                <Card label={t("lsSongs")} value={num(stats.uniqueTracks)} data-k="songs" />
                <Card label={t("lsArtists")} value={num(stats.uniqueArtists)} data-k="artists" />
                <Card label={t("lsNew")} value={num(stats.discoveries)} data-k="new" />
                <Card label={t("lsSkipRate")} value={`${num(Math.round(stats.skipRate * 100))}%`} data-k="skip" />
                <Card
                  label={t("lsStreak")}
                  value={t("lsDaysN").replace("{{n}}", num(stats.streak.current))}
                  sub={t("lsStreakBest").replace("{{n}}", num(stats.streak.best))}
                  icon={stats.streak.current > 1 ? <Flame size={13} /> : undefined}
                  data-k="streak"
                />
              </div>

              {/* per day */}
              <section className="nls-sec">
                <div className="nls-sec-head">
                  <h3 className="nls-h">{t("lsPerDay")}</h3>
                  <span className="nls-meta">
                    {t("lsActiveDays").replace("{{n}}", num(stats.activeDays))}
                    {stats.peakDay && ` · ${t("lsPeak").replace("{{day}}", fmtDay(stats.peakDay.start, range === "all" || range === "365d")).replace("{{time}}", dur(stats.peakDay.ms, true))}`}
                  </span>
                </div>
                <DayChart stats={stats} label={(b) => `${fmtDay(b.start, true)} · ${dur(b.ms, true)} · ${t("lsPlaysN").replace("{{n}}", num(b.plays))}`} edge={(s) => fmtDay(s, range === "all" || range === "365d")} />
              </section>

              {/* top lists */}
              <section className="nls-sec">
                <div className="nls-sec-head">
                  <h3 className="nls-h">{t("lsTop")}</h3>
                  <div className="nls-tabs" role="tablist" aria-label={t("lsTop")}>
                    {TOP_KINDS.map((k) => (
                      <button
                        key={k}
                        type="button"
                        role="tab"
                        aria-selected={k === kind}
                        tabIndex={k === kind ? 0 : -1}
                        data-top={k}
                        className="nls-tab"
                        onClick={() => setKind(k)}
                        onKeyDown={(e) => arrows<TopKind>(e, TOP_KINDS, kind, setKind, "data-top")}
                      >
                        {t(TOP_LABEL[k])}
                      </button>
                    ))}
                  </div>
                </div>
                <ol className="nls-top" role="tabpanel" aria-label={t(TOP_LABEL[kind])} data-top-list={kind}>
                  {topList.map((it, i) => {
                    // a song must still be in the library; a group needs one song that is
                    const can = kind === "tracks" ? !!tracks[it.id] : queueFor(it, kind, topList).length > 0;
                    return (
                      <li key={it.key} className="nls-row">
                        <button
                          type="button"
                          className="nls-row-btn"
                          disabled={!can}
                          onClick={() => playItem(it, kind, topList)}
                          title={can ? t("play") : t("lsNotInLib")}
                          data-top-row={it.key}
                        >
                          <span className="nls-rank">{num(i + 1)}</span>
                          <span className="nls-row-text">
                            <span className="nls-row-name" dir="auto">{it.name}</span>
                            {it.sub && <span className="nls-row-sub" dir="auto">{it.sub}</span>}
                          </span>
                          <span className="nls-row-num">
                            <span>{t("lsPlaysN").replace("{{n}}", num(it.plays))}</span>
                            <span className="nls-row-time">{dur(it.ms, true)}</span>
                          </span>
                          <span className="nls-row-bar" style={{ inlineSize: `${Math.max(2, (it.ms / topMax) * 100)}%` }} aria-hidden />
                          {can && <Play size={13} className="nls-row-play" aria-hidden />}
                        </button>
                      </li>
                    );
                  })}
                </ol>
              </section>

              {/* hour / weekday */}
              <div className="nls-two">
                <section className="nls-sec">
                  <h3 className="nls-h">{t("lsHours")}</h3>
                  <Histogram
                    values={stats.hours}
                    labels={stats.hours.map((_, h) => hh(h))}
                    tick={(i) => i % 6 === 0}
                    title={(i, v) => `${hh(i)}:${hh(0)} · ${dur(v, true)}`}
                    kind="hours"
                  />
                </section>
                <section className="nls-sec">
                  <h3 className="nls-h">{t("lsWeekdays")}</h3>
                  <WeekdayChart values={stats.weekdays} locale={locale} start={WEEK_START[lang] ?? 0} title={(name, v) => `${name} · ${dur(v, true)}`} />
                </section>
              </div>
            </>
          )}
        </div>

        <div className="nte-foot nls-foot">
          {askClear ? (
            <div className="nls-ask" role="alertdialog" aria-label={t("lsClear")} data-stats-ask>
              <span className="nls-ask-text">{t("lsClearAsk")}</span>
              <button type="button" className="nte-btn" onClick={() => setAskClear(false)} ref={focusOnMount}>{t("lsCancel")}</button>
              <button type="button" className="nte-btn nte-btn-danger" onClick={doClear} data-stats-clear-yes>{t("lsClearYes")}</button>
            </div>
          ) : (
            <>
              <label className="nls-keep">
                <input type="checkbox" checked={enabled} onChange={(e) => setSetting("statsEnabled", e.target.checked)} data-stats-keep />
                <span>{t("lsKeep")}</span>
              </label>
              <span className="nls-grow" />
              <button type="button" className="nte-btn nte-btn-sm" onClick={() => { close(); openScrobbleSheet(face); }} data-stats-scrobble>
                <Radio size={13} /> {t("scOpen")}
              </button>
              <button type="button" className="nte-btn nte-btn-sm" onClick={exportCsv} disabled={!hasAny} data-stats-export>
                <Download size={13} /> {t("lsExport")}
              </button>
              <button type="button" className="nte-btn nte-btn-sm" onClick={() => setAskClear(true)} disabled={!hasAny} data-stats-clear>
                <Trash2 size={13} /> {t("lsClear")}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Card({ label, value, sub, big, icon, ...rest }: { label: string; value: string; sub?: string; big?: boolean; icon?: ReactNode; "data-k"?: string }) {
  return (
    <div className="nls-card" data-big={big || undefined} data-stat={rest["data-k"]}>
      <div className="nls-card-label">{label}</div>
      <div className="nls-card-value">{icon}{value}</div>
      {sub && <div className="nls-card-sub">{sub}</div>}
    </div>
  );
}

function DayChart({ stats, label, edge }: { stats: ListenStats; label: (b: ListenStats["days"][number]) => string; edge: (start: number) => string }) {
  const days = stats.days;
  const max = days.reduce((a, b) => Math.max(a, b.ms), 0) || 1;
  if (!days.length) return null;
  return (
    <div className="nls-days-wrap">
      <div
        className="nls-days"
        data-n={days.length}
        style={{ gridTemplateColumns: `repeat(${days.length}, minmax(0, 1fr))`, columnGap: days.length > 120 ? 0 : days.length > 45 ? 1 : 2 }}
        role="img" aria-label={`${edge(days[0].start)} – ${edge(days[days.length - 1].start)}`}>
        {days.map((b) => (
          <span key={b.day} className="nls-day" data-zero={b.ms === 0 || undefined} title={label(b)}>
            <span className="nls-day-bar" style={{ blockSize: `${b.ms ? Math.max(4, (b.ms / max) * 100) : 0}%` }} />
          </span>
        ))}
      </div>
      <div className="nls-axis" aria-hidden>
        <span>{edge(days[0].start)}</span>
        <span>{edge(days[days.length - 1].start)}</span>
      </div>
    </div>
  );
}

function Histogram({ values, labels, tick, title, kind }: { values: number[]; labels: string[]; tick: (i: number) => boolean; title: (i: number, v: number) => string; kind: string }) {
  const max = values.reduce((a, v) => Math.max(a, v), 0) || 1;
  return (
    <div className="nls-hist" data-kind={kind}>
      {values.map((v, i) => (
        <span key={i} className="nls-hist-col" title={title(i, v)}>
          <span className="nls-hist-track"><span className="nls-hist-bar" style={{ blockSize: `${v ? Math.max(4, (v / max) * 100) : 0}%` }} /></span>
          <span className="nls-hist-lbl">{tick(i) ? labels[i] : "\u00a0"}</span>
        </span>
      ))}
    </div>
  );
}

function WeekdayChart({ values, locale, start, title }: { values: number[]; locale: string; start: number; title: (name: string, v: number) => string }) {
  const names = useMemo(() => {
    const f = new Intl.DateTimeFormat(locale, { weekday: "short" });
    // 2023-01-01 was a Sunday
    return Array.from({ length: 7 }, (_, d) => f.format(new Date(2023, 0, 1 + d)));
  }, [locale]);
  const idx = Array.from({ length: 7 }, (_, i) => (start + i) % 7);
  const max = values.reduce((a, v) => Math.max(a, v), 0) || 1;
  return (
    <div className="nls-hist nls-week" data-kind="weekdays">
      {idx.map((d) => (
        <span key={d} className="nls-hist-col" title={title(names[d], values[d])} data-weekday={d}>
          <span className="nls-hist-track"><span className="nls-hist-bar" style={{ blockSize: `${values[d] ? Math.max(4, (values[d] / max) * 100) : 0}%` }} /></span>
          <span className="nls-hist-lbl">{names[d]}</span>
        </span>
      ))}
    </div>
  );
}
