// ── NOBODY · listening history log (1.7.0-dev.10, Phase 4 · part 7) ─────────
// One row per listen, in its own IndexedDB database (`nobody-stats`) so the
// main library DB version is not touched. Rows are tiny (~150 B): 200k rows
// ≈ years of daily listening in ~30 MB. Oldest rows are dropped past the cap.
// No IndexedDB (or it fails to open) → an in-memory log for the session.
//
// Rows carry a title/artist/album snapshot so stats (and scrobbling, next)
// still make sense after a song leaves the library or is re-tagged.

export interface PlayRecord {
  /** IDB key (autoIncrement); absent before the row is stored */
  k?: number;
  /** listen start, epoch ms */
  at: number;
  /** stable track id */
  id: string;
  /** media time actually heard, ms (seeks and pauses excluded) */
  ms: number;
  /** track length, s (0 = unknown) */
  dur: number;
  title: string;
  artist: string;
  album: string;
  genre?: string;
  /** heard ≥ 50 % or ≥ 4 min of a > 30 s song (Last.fm scrobble rule) */
  full: boolean;
  /** left for another song before `full` */
  skip: boolean;
  /** which player produced it */
  src: "engine" | "classic";
}

export const LOG_CAP = 200_000;
const DB_NAME = "nobody-stats";
const STORE = "plays";

type Listener = () => void;
const listeners = new Set<Listener>();
let cache: PlayRecord[] | null = null;
let loading: Promise<PlayRecord[]> | null = null;
let dbp: Promise<IDBDatabase | null> | null = null;
let memoryOnly = false;
let rev = 0;

function emit() {
  rev++;
  for (const l of [...listeners]) { try { l(); } catch { /* listener bug */ } }
}

export function onPlayLog(fn: Listener): () => void {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}
export const playLogRev = () => rev;

function openDb(): Promise<IDBDatabase | null> {
  if (dbp) return dbp;
  dbp = new Promise<IDBDatabase | null>((resolve) => {
    try {
      if (typeof indexedDB === "undefined") { memoryOnly = true; return resolve(null); }
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains(STORE)) {
          const s = d.createObjectStore(STORE, { keyPath: "k", autoIncrement: true });
          s.createIndex("at", "at");
        }
      };
      req.onsuccess = () => {
        const d = req.result;
        d.onversionchange = () => { d.close(); dbp = null; };
        resolve(d);
      };
      req.onerror = () => { memoryOnly = true; resolve(null); };
      req.onblocked = () => { /* wait */ };
    } catch {
      memoryOnly = true;
      resolve(null);
    }
  });
  return dbp;
}

/** Every stored listen, oldest first. Cached after the first call. */
export function getPlays(): Promise<PlayRecord[]> {
  if (cache) return Promise.resolve(cache);
  if (loading) return loading;
  loading = (async () => {
    const d = await openDb();
    let rows: PlayRecord[] = [];
    if (d) {
      rows = await new Promise<PlayRecord[]>((resolve) => {
        try {
          const req = d.transaction(STORE, "readonly").objectStore(STORE).getAll();
          req.onsuccess = () => resolve((req.result as PlayRecord[]) || []);
          req.onerror = () => resolve([]);
        } catch { resolve([]); }
      });
    }
    rows = rows.filter(validRecord).sort((a, b) => a.at - b.at);
    // rows appended while loading (memory) are merged in
    cache = cache ? [...rows, ...cache] : rows;
    loading = null;
    return cache;
  })();
  return loading;
}

/** Synchronous view of what is loaded (null before the first getPlays()). */
export const peekPlays = (): PlayRecord[] | null => cache;

function validRecord(r: unknown): r is PlayRecord {
  const x = r as PlayRecord;
  return !!x && typeof x.id === "string" && Number.isFinite(x.at) && Number.isFinite(x.ms) && x.ms >= 0;
}

export async function appendPlay(rec: PlayRecord): Promise<void> {
  if (!validRecord(rec)) return;
  const row: PlayRecord = { ...rec };
  delete row.k;
  // never race a running load: its readonly getAll() would not see this row
  if (loading) await loading.catch(() => null);
  if (cache) cache.push(row); // else: not loaded yet → the next getPlays() reads it from IDB
  const d = memoryOnly ? null : await openDb();
  if (!d) {
    if (!cache) cache = [row];
    trimCache();
    emit();
    return;
  }
  await new Promise<void>((resolve) => {
    try {
      const tx = d.transaction(STORE, "readwrite");
      const st = tx.objectStore(STORE);
      const add = st.add(row);
      add.onsuccess = () => { row.k = add.result as number; };
      const cnt = st.count();
      cnt.onsuccess = () => {
        let extra = cnt.result - LOG_CAP;
        if (extra <= 0) return;
        const cur = st.openCursor();
        cur.onsuccess = () => {
          const c = cur.result;
          if (!c || extra <= 0) return;
          c.delete(); extra--; c.continue();
        };
      };
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
      tx.onabort = () => resolve();
    } catch { resolve(); }
  });
  trimCache();
  emit();
}

function trimCache() {
  if (cache && cache.length > LOG_CAP) cache.splice(0, cache.length - LOG_CAP);
}

/** Forget the whole history (Settings › Clear storage, or the stats sheet). */
export async function clearPlays(): Promise<void> {
  cache = [];
  const d = memoryOnly ? null : await openDb();
  if (d) {
    await new Promise<void>((resolve) => {
      try {
        const tx = d.transaction(STORE, "readwrite");
        tx.objectStore(STORE).clear();
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      } catch { resolve(); }
    });
  }
  emit();
}

/** 1.7.0 (duplicate finder): listens of a removed copy now belong to the
 *  kept one (`map`: old id → new id), so stats and top lists stay whole. */
export async function remapPlayIds(map: Record<string, string>): Promise<number> {
  const keys = Object.keys(map);
  if (!keys.length) return 0;
  if (loading) await loading.catch(() => null);
  let n = 0;
  if (cache) for (const r of cache) if (r.id in map) { r.id = map[r.id]; n++; }
  const d = memoryOnly ? null : await openDb();
  if (d) {
    n = await new Promise<number>((resolve) => {
      let m = 0;
      try {
        const tx = d.transaction(STORE, "readwrite");
        const cur = tx.objectStore(STORE).openCursor();
        cur.onsuccess = () => {
          const c = cur.result;
          if (!c) return;
          const row = c.value as PlayRecord;
          if (row && row.id in map) { c.update({ ...row, id: map[row.id] }); m++; }
          c.continue();
        };
        tx.oncomplete = () => resolve(Math.max(m, n));
        tx.onerror = () => resolve(n);
        tx.onabort = () => resolve(n);
      } catch { resolve(n); }
    });
  }
  if (n) emit();
  return n;
}

/** test hook: drop the in-memory cache so the next read hits IDB */
export function __resetPlayLogCache() { cache = null; loading = null; }
