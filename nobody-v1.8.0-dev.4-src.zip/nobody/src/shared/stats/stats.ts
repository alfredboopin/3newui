// ── NOBODY · listening stats (1.7.0-dev.10, Phase 4 · part 7) ───────────────
// Pure aggregation over the listen log. Day / hour / weekday buckets are in
// LOCAL time. Artists / albums / genres group case- and accent-insensitively
// (same fold as smart playlists: ي/ك → ی/ک, harakat, ZWNJ); the first
// spelling seen wins for display.

import { fold } from "../../cinema/lib/smartPlaylist";
import { splitGenres } from "../replayGain";
import type { PlayRecord } from "./listenLog";

export type StatsRange = "7d" | "30d" | "90d" | "365d" | "all";
export const STATS_RANGES: StatsRange[] = ["7d", "30d", "90d", "365d", "all"];
const RANGE_DAYS: Record<StatsRange, number> = { "7d": 7, "30d": 30, "90d": 90, "365d": 365, all: 0 };

export interface TopItem {
  key: string;
  name: string;
  /** artist line for tracks / albums */
  sub: string;
  /** a track id to play (tracks: the song; artists/albums: most played song) */
  id: string;
  plays: number;
  ms: number;
}

export interface DayBucket { day: string; start: number; ms: number; plays: number }

export interface ListenStats {
  from: number;
  to: number;
  totalMs: number;
  plays: number;
  fullPlays: number;
  skips: number;
  /** skips / (full + skips) — 0 when nothing to compare */
  skipRate: number;
  uniqueTracks: number;
  uniqueArtists: number;
  /** songs whose FIRST listen ever falls in the range */
  discoveries: number;
  topTracks: TopItem[];
  topArtists: TopItem[];
  topAlbums: TopItem[];
  topGenres: TopItem[];
  /** one bucket per local day in the range (all-time: from the first listen; ≤ 400 shown) */
  days: DayBucket[];
  hours: number[]; // 24 × ms
  weekdays: number[]; // 7 × ms, 0 = Sunday
  activeDays: number;
  streak: { current: number; best: number };
  /** busiest day in the range */
  peakDay: DayBucket | null;
}

export function startOfLocalDay(t: number): number {
  const d = new Date(t);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}
const addDays = (dayStart: number, n: number) => {
  const d = new Date(dayStart);
  d.setDate(d.getDate() + n);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
};
export function dayKey(t: number): string {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function rangeBounds(range: StatsRange, now: number, first?: number): { from: number; to: number } {
  const today = startOfLocalDay(now);
  const n = RANGE_DAYS[range];
  if (!n) return { from: first !== undefined ? startOfLocalDay(first) : today, to: now };
  return { from: addDays(today, -(n - 1)), to: now };
}

/* 1.7.0-dev.11: the library's own placeholders ("Unknown Artist" /
   "Unknown Album", stored verbatim in the row snapshot) group with the
   untagged bucket instead of showing up as a real artist / album. */
const PLACEHOLDER = new Set(["unknown artist", "unknown album", "unknown", "<unknown>"]);
export const cleanTagName = (v: string | undefined) => { const s = (v || "").trim(); return PLACEHOLDER.has(s.toLowerCase()) ? "" : s; };
const artistOf = (r: PlayRecord) => cleanTagName(r.artist);
const titleOf = (r: PlayRecord) => (r.title || "").trim();

interface Acc { name: string; sub: string; plays: number; ms: number; songs: Map<string, number> }
function bump(map: Map<string, Acc>, key: string, name: string, sub: string, r: PlayRecord) {
  let a = map.get(key);
  if (!a) { a = { name, sub, plays: 0, ms: 0, songs: new Map() }; map.set(key, a); }
  a.plays++;
  a.ms += r.ms;
  a.songs.set(r.id, (a.songs.get(r.id) || 0) + 1);
}
function top(map: Map<string, Acc>, n: number): TopItem[] {
  const out: TopItem[] = [];
  for (const [key, a] of map) {
    let best = ""; let bestN = -1;
    for (const [id, c] of a.songs) if (c > bestN) { best = id; bestN = c; }
    out.push({ key, name: a.name, sub: a.sub, id: best, plays: a.plays, ms: a.ms });
  }
  out.sort((x, y) => y.plays - x.plays || y.ms - x.ms || x.name.localeCompare(y.name));
  return out.slice(0, n);
}

export interface StatsOptions {
  range: StatsRange;
  now?: number;
  topN?: number;
  /** fills title/artist for rows logged without them (current library) */
  resolve?: (id: string) => { title: string; artist: string; album: string; genre?: string } | null | undefined;
  unknownArtist?: string;
  unknownAlbum?: string;
  unknownGenre?: string;
}

export function computeStats(all: readonly PlayRecord[], opt: StatsOptions): ListenStats {
  const now = opt.now ?? Date.now();
  const topN = opt.topN ?? 10;
  const first = all.length ? all[0].at : undefined;
  const { from, to } = rangeBounds(opt.range, now, first);
  const uArtist = opt.unknownArtist ?? "Unknown artist";
  const uAlbum = opt.unknownAlbum ?? "Unknown album";
  const uGenre = opt.unknownGenre ?? "Unknown genre";

  const firstSeen = new Map<string, number>();
  for (const r of all) if (!firstSeen.has(r.id)) firstSeen.set(r.id, r.at); // all is oldest-first

  const tracks = new Map<string, Acc>();
  const artists = new Map<string, Acc>();
  const albums = new Map<string, Acc>();
  const genres = new Map<string, Acc>();
  const dayMap = new Map<number, DayBucket>();
  const hours = new Array<number>(24).fill(0);
  const weekdays = new Array<number>(7).fill(0);
  let totalMs = 0, plays = 0, fullPlays = 0, skips = 0, discoveries = 0;

  for (const raw of all) {
    if (raw.at < from || raw.at > to) continue;
    let r = raw;
    if ((!r.title || !cleanTagName(r.artist)) && opt.resolve) {
      const m = opt.resolve(r.id);
      if (m) r = { ...r, title: r.title || m.title, artist: cleanTagName(r.artist) || m.artist, album: cleanTagName(r.album) || m.album, genre: r.genre || m.genre };
    }
    plays++;
    totalMs += r.ms;
    if (r.full) fullPlays++;
    if (r.skip) skips++;
    if (firstSeen.get(r.id) === raw.at) discoveries++;

    const artist = artistOf(r);
    const aKey = fold(artist) || "";
    const title = titleOf(r) || r.id;
    bump(tracks, r.id, title, artist || uArtist, r);
    bump(artists, aKey, artist || uArtist, "", r);
    const album = cleanTagName(r.album);
    bump(albums, `${fold(album) || ""}\u0001${aKey}`, album || uAlbum, artist || uArtist, r);
    const gs = splitGenres(r.genre);
    if (gs.length) { const seen = new Set<string>(); for (const g of gs) { const k = fold(g); if (seen.has(k)) continue; seen.add(k); bump(genres, k, g, "", r); } }
    else bump(genres, "", uGenre, "", r);

    const ds = startOfLocalDay(r.at);
    let b = dayMap.get(ds);
    if (!b) { b = { day: dayKey(ds), start: ds, ms: 0, plays: 0 }; dayMap.set(ds, b); }
    b.ms += r.ms; b.plays++;
    const d = new Date(r.at);
    hours[d.getHours()] += r.ms;
    weekdays[d.getDay()] += r.ms;
  }

  // continuous day series (cap 400 buckets: all-time shows the latest 400 days)
  const days: DayBucket[] = [];
  const lastDay = startOfLocalDay(to);
  let startDay = startOfLocalDay(from);
  let span = 0;
  for (let t = startDay; t <= lastDay; t = addDays(t, 1)) span++;
  if (span > 400) startDay = addDays(lastDay, -399);
  for (let t = startDay; t <= lastDay; t = addDays(t, 1)) days.push(dayMap.get(t) ?? { day: dayKey(t), start: t, ms: 0, plays: 0 });

  // streaks over ALL history (a streak doesn't care about the range picker)
  const allDays = new Set<number>();
  for (const r of all) allDays.add(startOfLocalDay(r.at));
  let best = 0;
  const sorted = [...allDays].sort((a, b) => a - b);
  let run = 0; let prev = -Infinity;
  for (const t of sorted) { run = addDays(prev, 1) === t ? run + 1 : 1; prev = t; if (run > best) best = run; }
  let current = 0;
  const today = startOfLocalDay(now);
  // a streak is still alive if you listened today OR yesterday
  let cur = allDays.has(today) ? today : addDays(today, -1);
  while (allDays.has(cur)) { current++; cur = addDays(cur, -1); }

  let peakDay: DayBucket | null = null;
  for (const b of dayMap.values()) if (!peakDay || b.ms > peakDay.ms) peakDay = b;

  return {
    from, to, totalMs, plays, fullPlays, skips,
    skipRate: fullPlays + skips ? skips / (fullPlays + skips) : 0,
    uniqueTracks: tracks.size,
    uniqueArtists: [...artists.keys()].filter((k) => k !== "").length,
    discoveries,
    topTracks: top(tracks, topN),
    topArtists: top(artists, topN),
    topAlbums: top(albums, topN),
    topGenres: top(genres, topN),
    days, hours, weekdays,
    activeDays: dayMap.size,
    streak: { current, best },
    peakDay,
  };
}

/** "12 h 05 m" style without locale words (callers add i18n units) */
export function splitDuration(ms: number): { d: number; h: number; m: number } {
  const totalMin = Math.floor(Math.max(0, ms) / 60000);
  return { d: Math.floor(totalMin / 1440), h: Math.floor((totalMin % 1440) / 60), m: totalMin % 60 };
}

/** CSV of the raw log (export button) — RFC 4180 quoting, ISO local-free UTC times */
export function playsToCsv(rows: readonly PlayRecord[]): string {
  // a leading = + - @ would run as a formula in Excel / Calc → prefix '
  const q = (v: unknown) => { let s = String(v ?? ""); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const head = "started_utc,artist,title,album,genre,listened_s,length_s,full,skipped,player";
  const lines = rows.map((r) => [new Date(r.at).toISOString(), r.artist, r.title, r.album, r.genre || "", Math.round(r.ms / 1000), Math.round(r.dur), r.full ? 1 : 0, r.skip ? 1 : 0, r.src].map(q).join(","));
  return [head, ...lines].join("\r\n") + "\r\n";
}
