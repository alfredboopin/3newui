// ── NOBODY · listening stats sheet open state (1.7.0-dev.11) ────────────────
// Same pattern as the tag / smart-playlist editors: one sheet per face,
// mounted inside that face's root; `face` pins which one shows.

import { create } from "zustand";
import { getUiMode } from "../../uiMode";
import type { TagEditorFace } from "../tagEditor/store";
import type { StatsRange } from "./stats";

export type StatsFace = TagEditorFace;
const RANGE_KEY = "nobody-stats-range";

function loadRange(): StatsRange {
  try {
    const v = localStorage.getItem(RANGE_KEY);
    if (v === "7d" || v === "30d" || v === "90d" || v === "365d" || v === "all") return v;
  } catch { /* storage off */ }
  return "30d";
}

interface StatsSheetState {
  face: StatsFace | null;
  range: StatsRange;
  open: (face?: StatsFace) => void;
  close: () => void;
  setRange: (r: StatsRange) => void;
}

export const useStatsSheet = create<StatsSheetState>((set) => ({
  face: null,
  range: loadRange(),
  open: (face) => {
    const mode = face ?? getUiMode();
    if (mode === "classic") return;
    set({ face: mode });
  },
  close: () => set({ face: null }),
  setRange: (range) => {
    try { localStorage.setItem(RANGE_KEY, range); } catch { /* storage off */ }
    set({ range });
  },
}));

export const openStatsSheet = (face?: StatsFace) => useStatsSheet.getState().open(face);
