// ── NOBODY · listen tracker (1.7.0-dev.10, Phase 4 · part 7) ────────────────
// Face-neutral: the engine (Cinema / EELA / ALOK) and Classic each feed it
// samples from their own <audio> timeupdate. It measures media time actually
// HEARD (positive steps ≤ 3 s; seeks, pauses and stalls add nothing) and
// closes a listen when the song changes, a repeat-one loop restarts it, the
// window is hidden / unloaded, or the player says the song ended.
//
// One open session at a time: only one player sounds at once (Classic
// silences the engine on handoff and vice versa), and a sample from the
// other source simply closes the open session first.
//
// The same rules decide scrobble eligibility (`full`): song > 30 s and heard
// ≥ 50 % or ≥ 4 min. Listens under MIN_MS are not stored at all.

import { appendPlay, type PlayRecord } from "./listenLog";

export interface ListenMeta {
  title: string;
  artist: string;
  album: string;
  genre?: string;
  /** seconds */
  duration?: number;
}

export type ListenSource = PlayRecord["src"];
export type ListenEnd = "change" | "loop" | "ended" | "flush";

export const MIN_MS = 5000;
/** the open listen is mirrored here (≤ every 5 s) so a killed / crashed app
 *  or an unload that beats the async IDB write doesn't lose it */
export const OPEN_KEY = "nobody-listen-open-v1";
const OPEN_SAVE_MS = 5000;
export const MAX_STEP_S = 3;

interface Session {
  id: string;
  src: ListenSource;
  at: number;
  ms: number;
  lastPos: number;
  dur: number;
  meta: ListenMeta | null;
}

type Sink = (rec: PlayRecord) => void | Promise<void>;
type GenuineHook = (id: string, src: ListenSource, meta: ListenMeta | null) => void;
/** 1.7.0 (scrobbling): every closed listen ≥ MIN_MS, whether or not the
 *  history is kept (scrobbling has its own switch). `why` = how it closed. */
type ClosedHook = (rec: PlayRecord, why: ListenEnd) => void;

export function isFullListen(ms: number, durS: number): boolean {
  if (!(durS > 30)) return false;
  return ms >= durS * 500 || ms >= 240_000;
}

export class ListenTracker {
  private s: Session | null = null;
  private enabled = () => true;
  private sink: Sink;
  private genuine = new Set<GenuineHook>();
  private closed = new Set<ClosedHook>();
  private genuineFired = false;
  private now: () => number;
  private store: Pick<Storage, "getItem" | "setItem" | "removeItem"> | null;
  private lastSaved = 0;

  constructor(sink: Sink = appendPlay, now: () => number = () => Date.now(), store?: Pick<Storage, "getItem" | "setItem" | "removeItem"> | null) {
    this.sink = sink;
    this.now = now;
    this.store = store !== undefined ? store : (typeof localStorage !== "undefined" ? localStorage : null);
  }

  /** Boot: store a listen that was still open when the app last went away. */
  recover() {
    if (!this.store) return;
    let raw: string | null = null;
    try { raw = this.store.getItem(OPEN_KEY); this.store.removeItem(OPEN_KEY); } catch { return; }
    if (!raw) return;
    try {
      const o = JSON.parse(raw) as Session;
      if (!o || typeof o.id !== "string" || !Number.isFinite(o.ms) || !Number.isFinite(o.at)) return;
      if (this.s) return; // a live session already started: it wins
      this.s = { id: o.id, src: o.src === "classic" ? "classic" : "engine", at: o.at, ms: o.ms, lastPos: 0, dur: Number(o.dur) || 0, meta: o.meta ?? null };
      this.close("flush");
    } catch { /* corrupt */ }
  }

  private saveOpen(force = false) {
    if (!this.store) return;
    const t = this.now();
    if (!force && t - this.lastSaved < OPEN_SAVE_MS) return;
    this.lastSaved = t;
    try {
      if (this.s && this.s.ms >= MIN_MS) this.store.setItem(OPEN_KEY, JSON.stringify(this.s));
      else this.store.removeItem(OPEN_KEY);
    } catch { /* quota */ }
  }

  /** gate (Settings › "Keep listening history"); checked when a listen closes */
  setEnabledGetter(fn: () => boolean) { this.enabled = fn; }

  /** fired once per listen when it passes MIN_MS of real listening */
  onGenuine(fn: GenuineHook): () => void {
    this.genuine.add(fn);
    return () => { this.genuine.delete(fn); };
  }

  /** 1.7.0: fired for every listen that closes with ≥ MIN_MS heard */
  onClosed(fn: ClosedHook): () => void {
    this.closed.add(fn);
    return () => { this.closed.delete(fn); };
  }

  get open(): { id: string; ms: number; src: ListenSource } | null {
    return this.s ? { id: this.s.id, ms: this.s.ms, src: this.s.src } : null;
  }

  /**
   * One sample from a player's timeupdate.
   * @param meta resolved lazily, only when a session opens (or still lacks it)
   */
  sample(src: ListenSource, id: string | null | undefined, pos: number, dur: number, playing: boolean, meta?: () => ListenMeta | null) {
    if (!id || !Number.isFinite(pos)) return;
    let s = this.s;
    if (s && (s.id !== id || s.src !== src)) { this.close("change"); s = null; }
    if (!s) {
      s = this.s = { id, src, at: this.now(), ms: 0, lastPos: pos, dur: Number.isFinite(dur) && dur > 0 ? dur : 0, meta: null };
      this.genuineFired = false;
      try { s.meta = meta?.() ?? null; } catch { s.meta = null; }
      return;
    }
    if (Number.isFinite(dur) && dur > 0) s.dur = dur;
    if (!s.meta && meta) { try { s.meta = meta(); } catch { /* later */ } }
    const d = pos - s.lastPos;
    if (d < -1) {
      // jumped back. Back to the start after the song was (almost) done =
      // repeat-one / replay → a new listen of the same song. Else: a seek.
      const nearEnd = s.dur > 0 && s.lastPos >= s.dur - 5;
      if (pos < 3 && (nearEnd || isFullListen(s.ms, s.dur || s.meta?.duration || 0))) {
        this.close("loop");
        this.sample(src, id, pos, dur, playing, meta);
        return;
      }
    } else if (playing && d > 0 && d <= MAX_STEP_S) {
      s.ms += d * 1000;
      if (!this.genuineFired && s.ms >= MIN_MS) {
        this.genuineFired = true;
        if (!s.meta && meta) { try { s.meta = meta(); } catch { /* later */ } }
        for (const fn of [...this.genuine]) { try { fn(s.id, s.src, s.meta); } catch { /* hook bug */ } }
      }
    }
    s.lastPos = pos;
    this.saveOpen();
  }

  /** The player reports the song finished (onEnded). */
  ended(src: ListenSource, id?: string | null, pos?: number) {
    const s = this.s;
    if (!s || s.src !== src || (id && s.id !== id)) return;
    if (pos !== undefined && Number.isFinite(pos)) {
      const d = pos - s.lastPos;
      if (d > 0 && d <= MAX_STEP_S) s.ms += d * 1000;
      s.lastPos = pos;
    }
    this.close("ended");
  }

  /** Drop the open listen without storing it (stats sheet › Clear history). */
  discard() {
    // keep the session object (same song keeps playing, Most played already
    // counted it) but forget what was heard so far
    if (this.s) { this.s.ms = 0; this.s.at = this.now(); }
    this.lastSaved = 0;
    try { this.store?.removeItem(OPEN_KEY); } catch { /* ignore */ }
  }

  /** Close + store the open listen (track change, hide, unload). */
  close(why: ListenEnd = "flush") {
    const s = this.s;
    this.s = null;
    this.lastSaved = 0;
    const dropOpen = () => { try { this.store?.removeItem(OPEN_KEY); } catch { /* ignore */ } };
    if (!s || s.ms < MIN_MS) { if (s) dropOpen(); return; }
    const durS = s.dur || s.meta?.duration || 0;
    const full = isFullListen(s.ms, durS);
    const rec: PlayRecord = {
      at: s.at,
      id: s.id,
      ms: Math.round(s.ms),
      dur: Math.round(durS * 10) / 10,
      title: s.meta?.title || "",
      artist: s.meta?.artist || "",
      album: s.meta?.album || "",
      genre: s.meta?.genre || undefined,
      full,
      skip: !full && why === "change",
      src: s.src,
    };
    // scrobbling listens to every closed listen, history on or off
    for (const fn of [...this.closed]) { try { fn({ ...rec }, why); } catch { /* hook bug */ } }
    if (!this.enabled()) { dropOpen(); return; }
    if (why === "flush" && this.store) {
      // unload: the async IDB write may not land before the process exits →
      // keep the mirror until it does; recover() stores it at the next boot.
      try { this.store.setItem(OPEN_KEY, JSON.stringify(s)); } catch { /* quota */ }
      try { Promise.resolve(this.sink(rec)).then(dropOpen, () => {}); } catch { /* storage failure */ }
      return;
    }
    dropOpen();
    try { void this.sink(rec); } catch { /* storage failure: drop */ }
  }
}

export const listenTracker = new ListenTracker();

let wired = false;
/** Hide / unload close the open listen (called once from main.tsx). */
export function wireListenTrackerLifecycle() {
  if (wired || typeof window === "undefined") return;
  wired = true;
  window.addEventListener("pagehide", () => listenTracker.close("flush"));
  window.addEventListener("beforeunload", () => listenTracker.close("flush"));
}
