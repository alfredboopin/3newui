// ── NOBODY · duplicate finder sheet open state (1.7.0) ──────────────────────
// One sheet per face, mounted inside that face's root (stats sheet pattern).

import { create } from "zustand";
import { getUiMode } from "../../uiMode";
import type { TagEditorFace } from "../tagEditor/store";
import { DUPE_MODES, type DupeMode } from "./dupes";

export type DupesFace = TagEditorFace;
const MODE_KEY = "nobody-dupes-mode";

function loadMode(): DupeMode {
  try {
    const v = localStorage.getItem(MODE_KEY) as DupeMode | null;
    if (v && DUPE_MODES.includes(v)) return v;
  } catch { /* storage off */ }
  return "song";
}

interface DupesSheetState {
  face: DupesFace | null;
  mode: DupeMode;
  open: (face?: DupesFace) => void;
  close: () => void;
  setMode: (m: DupeMode) => void;
}

export const useDupesSheet = create<DupesSheetState>((set) => ({
  face: null,
  mode: loadMode(),
  open: (face) => {
    const mode = face ?? getUiMode();
    if (mode === "classic") return;
    set({ face: mode });
  },
  close: () => set({ face: null }),
  setMode: (mode) => {
    try { localStorage.setItem(MODE_KEY, mode); } catch { /* storage off */ }
    set({ mode });
  },
}));

export const openDupesSheet = (face?: DupesFace) => useDupesSheet.getState().open(face);
