// ── NOBODY · duplicate finder core (1.7.0, Phase 4 · part 9) ────────────────
// Pure: groups library rows that are the same song, picks the copy to keep.
//
// Modes
//   song  (default) same title + artist (folded: case, accents, Arabic ي/ك →
//         Persian, ZWNJ; "feat. X", "(Remastered 2011)", "[Explicit]" and
//         leading track numbers ignored) AND lengths within 3 s, so a live
//         take or a radio edit of the same title stays apart.
//   tags  same title + artist, any length.
//   file  same file size + format + length (± 0.5 s): byte-for-byte copies
//         of one file in two folders, whatever their tags say.
//
// The suggested keeper: lossless over lossy, then higher bitrate, then the
// copy with cover / lyrics / rating / plays, then the shorter path.

import { fold } from "../../cinema/lib/smartPlaylist";

export type DupeMode = "song" | "tags" | "file";
export const DUPE_MODES: DupeMode[] = ["song", "tags", "file"];

export interface DupeTrack {
  id: string;
  title: string;
  artist: string;
  album?: string;
  duration: number;
  format?: string;
  bitrate?: number;
  fileSize?: number;
  fileName?: string;
  filePath?: string;
  hasCover?: boolean;
  hasLyrics?: boolean;
  rating?: number;
  plays?: number;
}

export interface DupeGroup {
  /** stable signature: sorted ids */
  sig: string;
  /** best first */
  ids: string[];
  /** suggested keeper (= ids[0]) */
  keep: string;
  /** bytes freed if every other copy goes */
  extraBytes: number;
  title: string;
  artist: string;
}

const LOSSLESS = new Set(["flac", "wav", "alac", "aif", "aiff", "ape", "wv", "dsf", "dff", "caf"]);
const PLACEHOLDER = new Set(["unknown artist", "unknown", "<unknown>", "unknown album"]);
export const SONG_TOLERANCE_S = 3;
const FILE_TOLERANCE_S = 0.5;

const VERSION_WORDS = /\b(remaster(ed)?(\s+\d{4})?|\d{4}\s+remaster(ed)?|explicit|clean|album version|original mix|bonus track|mono|stereo|deluxe( edition)?|hq|hd|official( audio| video)?|lyrics?)\b/i;

/** the part of a title that names the song */
export function songTitleKey(title: string, fileName?: string): string {
  let t = (title || "").trim();
  if (!t && fileName) t = fileName.replace(/\.[^.]+$/, "").replace(/^\s*\d{1,3}\s+(?=\D)/, "");
  t = t
    .replace(/^\s*\d{1,3}\s*[-._)\]]\s*/, "") // "01 - ", "1. ", "03) "
    .replace(/\s*[([{]\s*(feat\.?|ft\.?|featuring|with)\s[^)\]}]*[)\]}]/gi, "") // (feat. X)
    .replace(/\s+(feat\.?|ft\.?|featuring)\s.+$/i, "") // trailing feat. X
    .replace(/\s*[([{][^)\]}]*[)\]}]/g, (m) => (VERSION_WORDS.test(m) ? "" : m)) // (Remastered 2011) [Explicit]
    .replace(/\s+-\s+(remaster(ed)?(\s+\d{4})?|\d{4}\s+remaster(ed)?|explicit|album version)\s*$/i, "");
  return fold(t.replace(/[\u200c\u200d'’]/g, "")).replace(/[\u200c\u200d]/g, "").replace(/[\s"“”.,!?¿¡:;\-_/\\]+/g, " ").trim();
}

/** primary artist: "A feat. B", "A ft B", "A, B", "A & B", "A x B" → A */
export function artistKey(artist: string): string {
  const a = (artist || "").trim();
  if (!a || PLACEHOLDER.has(a.toLowerCase())) return "";
  const primary = a.split(/\s+(?:feat\.?|ft\.?|featuring|with|x|vs\.?)\s+|\s*[,;&/]\s*/i)[0] || a;
  return fold(primary).replace(/[\s'’".]+/g, " ").trim();
}

export const isLossless = (fmt?: string) => LOSSLESS.has(String(fmt || "").toLowerCase());

/** higher = better copy to keep */
export function qualityScore(t: DupeTrack): number {
  let s = 0;
  if (isLossless(t.format)) s += 10_000;
  s += Math.min(9_999, Math.max(0, Number(t.bitrate) || 0)) * 2;
  if (t.hasCover) s += 30;
  if (t.hasLyrics) s += 15;
  s += (t.rating || 0) * 20;
  s += Math.min(60, (t.plays || 0) * 3);
  return s;
}

function rank(list: DupeTrack[]): DupeTrack[] {
  return [...list].sort((a, b) =>
    qualityScore(b) - qualityScore(a)
    || (a.filePath || a.fileName || "").length - (b.filePath || b.fileName || "").length
    || a.id.localeCompare(b.id));
}

/** split one bucket into clusters whose lengths sit within `tol` of the
 *  cluster's first (shortest) member; unknown lengths join the first */
function byLength(list: DupeTrack[], tol: number): DupeTrack[][] {
  const known = list.filter((t) => t.duration > 0).sort((a, b) => a.duration - b.duration);
  const unknown = list.filter((t) => !(t.duration > 0));
  const out: DupeTrack[][] = [];
  let cur: DupeTrack[] = [];
  let start = 0;
  for (const t of known) {
    if (cur.length && t.duration - start > tol) { out.push(cur); cur = []; }
    if (!cur.length) start = t.duration;
    cur.push(t);
  }
  if (cur.length) out.push(cur);
  if (unknown.length) { if (out.length) out[0].push(...unknown); else out.push(unknown); }
  return out;
}

export interface FindOptions {
  /** group signatures the user marked "not duplicates" */
  ignored?: ReadonlySet<string>;
}

export const groupSig = (ids: string[]) => [...ids].sort().join("|");

export function findDuplicates(tracks: DupeTrack[], mode: DupeMode, opts: FindOptions = {}): DupeGroup[] {
  const buckets = new Map<string, DupeTrack[]>();
  for (const t of tracks) {
    if (!t || !t.id) continue;
    let key: string;
    if (mode === "file") {
      if (!(Number(t.fileSize) > 0)) continue;
      key = `${t.fileSize}\u0001${String(t.format || "").toLowerCase()}`;
    } else {
      const tk = songTitleKey(t.title, t.fileName);
      if (!tk) continue;
      const ak = artistKey(t.artist);
      // no artist: only the strict mode may still group them (same length)
      if (!ak && mode === "tags") continue;
      key = `${tk}\u0001${ak}`;
    }
    let b = buckets.get(key);
    if (!b) buckets.set(key, (b = []));
    b.push(t);
  }
  const groups: DupeGroup[] = [];
  for (const [key, list] of buckets) {
    if (list.length < 2) continue;
    const noArtist = mode !== "file" && key.endsWith("\u0001");
    const clusters = mode === "tags" ? [list]
      : mode === "file" ? byLength(list, FILE_TOLERANCE_S)
      : byLength(list, noArtist ? 1 : SONG_TOLERANCE_S);
    for (const c of clusters) {
      if (c.length < 2) continue;
      const ranked = rank(c);
      const ids = ranked.map((x) => x.id);
      const sig = groupSig(ids);
      if (opts.ignored?.has(sig)) continue;
      groups.push({
        sig,
        ids,
        keep: ids[0],
        extraBytes: ranked.slice(1).reduce((a, x) => a + (Number(x.fileSize) || 0), 0),
        title: ranked[0].title || ranked[0].fileName || "",
        artist: ranked[0].artist || "",
      });
    }
  }
  // biggest wins first, then by title
  return groups.sort((a, b) => b.ids.length - a.ids.length || b.extraBytes - a.extraBytes || fold(a.title).localeCompare(fold(b.title)));
}

// ── merge plan (pure): what the kept copy inherits ──────────────────────────

export interface MergeInput {
  playlists: { id: string; trackIds: string[]; smart?: unknown }[];
  ratings: Record<string, number>;
  playCounts: Record<string, number>;
  lastPlayed: Record<string, number>;
}
export interface MergeOutput {
  /** only playlists that changed */
  playlists: { id: string; trackIds: string[] }[];
  ratings: Record<string, number>;
  playCounts: Record<string, number>;
  lastPlayed: Record<string, number>;
}

/** `map`: removed id → kept id. Playlists: a removed id becomes the kept one
 *  (first position wins, no doubles); rating = best; plays = sum; last played = latest. */
export function planMerge(input: MergeInput, map: Record<string, string>): MergeOutput {
  const playlists: MergeOutput["playlists"] = [];
  for (const p of input.playlists) {
    if (p.smart || !p.trackIds.some((x) => x in map)) continue;
    const seen = new Set<string>();
    const ids: string[] = [];
    for (const raw of p.trackIds) {
      const x = map[raw] ?? raw;
      if (seen.has(x)) continue;
      seen.add(x);
      ids.push(x);
    }
    playlists.push({ id: p.id, trackIds: ids });
  }
  const ratings = { ...input.ratings };
  const playCounts = { ...input.playCounts };
  const lastPlayed = { ...input.lastPlayed };
  for (const [gone, keep] of Object.entries(map)) {
    if (ratings[gone]) { ratings[keep] = Math.max(ratings[keep] || 0, ratings[gone]); delete ratings[gone]; }
    if (playCounts[gone]) { playCounts[keep] = (playCounts[keep] || 0) + playCounts[gone]; delete playCounts[gone]; }
    if (lastPlayed[gone]) { lastPlayed[keep] = Math.max(lastPlayed[keep] || 0, lastPlayed[gone]); delete lastPlayed[gone]; }
  }
  return { playlists, ratings, playCounts, lastPlayed };
}

// ── "not duplicates" memory ──
export const IGNORED_KEY = "nobody-dupes-ignored-v1";
export function loadIgnored(store: Pick<Storage, "getItem"> | null = typeof localStorage !== "undefined" ? localStorage : null): Set<string> {
  try {
    const a = JSON.parse(store?.getItem(IGNORED_KEY) || "[]");
    return new Set(Array.isArray(a) ? a.filter((x) => typeof x === "string") : []);
  } catch { return new Set(); }
}
export function saveIgnored(set: Set<string>, store: Pick<Storage, "setItem"> | null = typeof localStorage !== "undefined" ? localStorage : null) {
  try { store?.setItem(IGNORED_KEY, JSON.stringify([...set].slice(-5000))); } catch { /* quota */ }
}

// ── library rows → finder input (pure) ──
export interface LibraryRowLike {
  id: string; title: string; artist: string; album?: string; duration: number; format?: string; bitrate?: number | string;
  fileSize?: number; fileName?: string; filePath?: string; hasCover?: boolean; isPlaceholderCover?: boolean;
  hasEmbeddedLyrics?: boolean; syncedLyrics?: unknown[]; plainLyrics?: string; demo?: boolean;
}
export function dupeTracksFrom(rows: Iterable<LibraryRowLike | undefined>, ratings: Record<string, number> = {}, playCounts: Record<string, number> = {}): DupeTrack[] {
  const out: DupeTrack[] = [];
  for (const r of rows) {
    if (!r || !r.id || r.demo) continue;
    const kbps = typeof r.bitrate === "string" ? parseFloat(r.bitrate) : r.bitrate;
    out.push({
      id: r.id,
      title: r.title,
      artist: r.artist,
      album: r.album,
      duration: Number(r.duration) || 0,
      format: r.format,
      bitrate: Number.isFinite(kbps) ? Number(kbps) : undefined,
      fileSize: r.fileSize,
      fileName: r.fileName,
      filePath: r.filePath,
      hasCover: !!r.hasCover && !r.isPlaceholderCover,
      hasLyrics: !!r.hasEmbeddedLyrics || !!(r.syncedLyrics && r.syncedLyrics.length) || !!(r.plainLyrics && r.plainLyrics.trim()),
      rating: ratings[r.id] || 0,
      plays: playCounts[r.id] || 0,
    });
  }
  return out;
}

/** "12.4 MB" style size; `locale` digits */
export function fmtBytes(n: number, locale = "en-US"): string {
  const u = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  let v = Math.max(0, n || 0);
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toLocaleString(locale, { maximumFractionDigits: i >= 2 ? 1 : 0 })} ${u[i]}`;
}
