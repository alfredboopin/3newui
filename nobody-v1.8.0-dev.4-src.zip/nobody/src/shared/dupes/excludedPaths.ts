// ── NOBODY · removed-from-library files (1.7.0, duplicate finder) ───────────
// A copy the duplicate finder removed from the library but left on disk sits
// inside a managed folder, so the next boot / rescan walk would import it
// again. Its path is remembered here and skipped by the folder walkers
// (loadDesktopFolders / scanDesktopFolder). Adding the file again by hand
// (Add music files, M3U import) forgets the exclusion.
// Paths are compared case-insensitively with / and \ unified (Windows).

const KEY = "nobody-excluded-paths-v1";
const CAP = 50_000;
let set: Set<string> | null = null;

export const normPath = (p: string) => p.replace(/\\/g, "/").replace(/\/+$/, "").toLowerCase();

function load(): Set<string> {
  if (set) return set;
  set = new Set();
  try {
    const a = JSON.parse((typeof localStorage !== "undefined" && localStorage.getItem(KEY)) || "[]");
    if (Array.isArray(a)) for (const x of a) if (typeof x === "string") set.add(x);
  } catch { /* corrupt → empty */ }
  return set;
}
function save() {
  try {
    const all = [...load()];
    localStorage.setItem(KEY, JSON.stringify(all.slice(-CAP)));
  } catch { /* quota */ }
}

export function isExcludedPath(p: string): boolean {
  const s = load();
  return s.size > 0 && s.has(normPath(p));
}
export function excludePaths(paths: string[]) {
  const s = load();
  let n = 0;
  for (const p of paths) if (p) { s.add(normPath(p)); n++; }
  if (n) save();
}
export function unexcludePaths(paths: string[]) {
  const s = load();
  if (!s.size) return;
  let n = 0;
  for (const p of paths) if (p && s.delete(normPath(p))) n++;
  if (n) save();
}
export const excludedCount = () => load().size;
export function clearExcluded() { set = new Set(); try { localStorage.removeItem(KEY); } catch { /* ignore */ } }
/** test hook */
export function __resetExcluded() { set = null; }
