// ── NOBODY · duplicate finder sheet (1.7.0, Phase 4 · part 9b) ──────────────
// One sheet for Cinema / EELA / ALOK on the .nte-* shell, mounted inside each
// face root. Pure grouping (dupes.ts) over the live library; resolving goes
// through actions.ts (kept copy inherits playlists / Liked / rating / plays /
// history; the playing song is never removed; files are only ever moved to
// the Recycle Bin, never deleted).
//
// Keyboard: Esc closes (or backs out of the confirm), Tab stays inside,
// ←/→ on the mode switch (RTL-aware), ↑/↓ inside a group's keep radios
// (native radio behaviour), keys never reach the face.

import { useEffect, useMemo, useRef, useState } from "react";
import type { KeyboardEvent as ReactKeyboardEvent } from "react";
import { Copy, EyeOff, FileAudio, Image as ImageIcon, Loader2, Music2, Play, Star, Trash2, Undo2, X } from "lucide-react";
import { useLibrary } from "../../cinema/store/library";
import { useSettings } from "../../cinema/store/settings";
import { uiApi, useUi } from "../../cinema/store/ui";
import { useT } from "../../cinema/lib/useT";
import { fmtTime } from "../../cinema/lib/utils";
import { engine } from "../../cinema/lib/engine";
import { rovingArrows, trapTab, focusOnMount, useFocusRescue } from "../sheetKeys";
import { DUPE_MODES, dupeTracksFrom, findDuplicates, fmtBytes, isLossless, loadIgnored, saveIgnored, type DupeGroup, type DupeMode } from "./dupes";
import { canTrash, resolveDuplicates } from "./actions";
import { useDupesSheet, type DupesFace } from "./sheetStore";
import type { Track } from "../../cinema/types";
import "../tagEditor/tagEditor.css";
import "./dupesSheet.css";

const LOCALE: Record<string, string> = { en: "en-US", fa: "fa-IR", tr: "tr-TR", ru: "ru-RU" };
const PAGE = 60;
const TRASH_KEY = "nobody-dupes-trash";

export function DuplicatesSheet({ face }: { face: DupesFace }) {
  const open = useDupesSheet((s) => s.face === face);
  if (!open) return null;
  return <DupesBody face={face} />;
}

function DupesBody({ face }: { face: DupesFace }) {
  const t = useT();
  const lang = useSettings((s) => s.lang);
  const close = useDupesSheet((s) => s.close);
  const mode = useDupesSheet((s) => s.mode);
  const setMode = useDupesSheet((s) => s.setMode);
  const tracks = useLibrary((s) => s.tracks);
  const order = useLibrary((s) => s.order);
  const ratings = useLibrary((s) => s.ratings);
  const playCounts = useLibrary((s) => s.playCounts);
  const currentId = useUi((s) => s.currentId);
  const [ignored, setIgnored] = useState<Set<string>>(() => loadIgnored());
  const [keepPick, setKeepPick] = useState<Record<string, string>>({});
  const [limit, setLimit] = useState(PAGE);
  const [ask, setAsk] = useState<string[] | null>(null);
  const [busy, setBusy] = useState(false);
  const trashable = canTrash();
  const [trash, setTrash] = useState<boolean>(() => { try { return localStorage.getItem(TRASH_KEY) === "1"; } catch { return false; } });
  const dialogRef = useRef<HTMLDivElement>(null);
  useFocusRescue(dialogRef);
  const opener = useRef<Element | null>(typeof document !== "undefined" ? document.activeElement : null);
  const rtl = lang === "fa";
  const locale = LOCALE[lang] || "en-US";
  const num = (n: number) => n.toLocaleString(locale);

  useEffect(() => {
    // opened from another sheet (stats footer): that sheet's opener got the focus back
    const o = opener.current;
    if (!(o instanceof HTMLElement) || !o.isConnected) opener.current = document.activeElement;
    const el = dialogRef.current?.querySelector<HTMLElement>('[data-dp-mode][aria-checked="true"]') ?? dialogRef.current;
    el?.focus();
    const back = opener.current;
    return () => { if (back instanceof HTMLElement && back.isConnected) back.focus(); };
  }, []);
  useEffect(() => { setLimit(PAGE); }, [mode]);

  const input = useMemo(() => dupeTracksFrom(order.map((id) => tracks[id]), ratings, playCounts), [order, tracks, ratings, playCounts]);
  const groups = useMemo(() => findDuplicates(input, mode, { ignored }), [input, mode, ignored]);
  const keepOf = (g: DupeGroup) => (keepPick[g.sig] && g.ids.includes(keepPick[g.sig]) ? keepPick[g.sig] : g.keep);
  const extraCopies = groups.reduce((a, g) => a + g.ids.length - 1, 0);
  const freed = groups.reduce((a, g) => { const k = keepOf(g); return a + g.ids.reduce((b, id) => b + (id === k ? 0 : tracks[id]?.fileSize || 0), 0); }, 0);

  const decisionsFor = (sigs: string[]) => {
    const set = new Set(sigs);
    return groups.filter((g) => set.has(g.sig)).map((g) => { const keep = keepOf(g); return { keep, remove: g.ids.filter((id) => id !== keep) }; });
  };
  const askCount = ask ? decisionsFor(ask).reduce((a, d) => a + d.remove.filter((id) => id !== currentId).length, 0) : 0;
  const askPlaying = ask ? decisionsFor(ask).some((d) => d.remove.includes(currentId || "")) : false;

  const notDupes = (g: DupeGroup) => {
    const next = new Set(ignored);
    next.add(g.sig);
    saveIgnored(next);
    setIgnored(next);
  };
  const showHidden = () => {
    const next = new Set<string>();
    saveIgnored(next);
    setIgnored(next);
  };
  const setTrashPref = (v: boolean) => {
    setTrash(v);
    try { localStorage.setItem(TRASH_KEY, v ? "1" : "0"); } catch { /* storage off */ }
  };

  const doResolve = async () => {
    if (!ask) return;
    const decisions = decisionsFor(ask);
    setAsk(null);
    setBusy(true);
    try {
      const r = await resolveDuplicates(decisions, { trash: trash && trashable });
      const sub: string[] = [];
      if (r.trashed) sub.push(t("dpToastTrashed").replace("{{n}}", num(r.trashed)));
      if (r.failed) sub.push(t("dpToastFailed").replace("{{n}}", num(r.failed)));
      if (r.playing) sub.push(t("dpToastPlaying").replace("{{n}}", num(r.playing)));
      if (r.removed) uiApi.toast(t("dpToastRemoved").replace("{{n}}", num(r.removed)), r.failed ? "info" : "success", sub.length ? { sub: sub.join(" · ") } : undefined);
      else uiApi.toast(t("dpToastNothing"), r.failed ? "error" : "info", sub.length ? { sub: sub.join(" · ") } : undefined);
    } catch {
      uiApi.toast(t("dpToastError"), "error");
    } finally {
      setBusy(false);
      requestAnimationFrame(() => (dialogRef.current?.querySelector<HTMLElement>("[data-dp-group] input:checked") ?? dialogRef.current?.querySelector<HTMLElement>('[data-dp-mode][aria-checked="true"]'))?.focus());
    }
  };

  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (e.key === "Escape") {
      e.preventDefault();
      if (ask) setAsk(null);
      else close();
      return;
    }
    trapTab(e, dialogRef.current);
  };

  const shown = groups.slice(0, limit);
  /** preview: the group's copies become the queue, so Next steps through them */
  const playTrack = (g: DupeGroup, id: string) => { const ids = g.ids.filter((x) => !!tracks[x]); if (ids.includes(id)) engine.setQueue(ids, id); };

  return (
    <div className="nte-layer ndp-layer" data-face={face} dir={rtl ? "rtl" : "ltr"} onKeyDown={onKeyDown}>
      <div className="nte-backdrop" onClick={close} aria-hidden />
      <div ref={dialogRef} className="nte-dialog ndp-dialog" role="dialog" aria-modal="true" aria-labelledby="ndp-title" tabIndex={-1} data-dupes-sheet aria-busy={busy || undefined}>
        <div className="nte-head">
          <span className="nte-badge" aria-hidden><Copy size={15} /></span>
          <div className="nte-head-text">
            <div id="ndp-title" className="nte-title">{t("dpTitle")}</div>
            <div className="nte-sub">{t("dpSub")}</div>
          </div>
          <button type="button" className="nte-icon" onClick={close} aria-label={t("close")} title={t("close")}>
            <X size={16} />
          </button>
        </div>

        <div className="nte-body ndp-body">
          <div className="ndp-top">
            <div className="nls-seg ndp-seg" role="radiogroup" aria-label={t("dpMode")}>
              {DUPE_MODES.map((m) => (
                <button key={m} type="button" role="radio" aria-checked={m === mode} tabIndex={m === mode ? 0 : -1} data-dp-mode={m} className="nls-seg-btn"
                  onClick={() => setMode(m)}
                  onKeyDown={(e) => rovingArrows<DupeMode>(e, DUPE_MODES, mode, setMode, dialogRef.current, "data-dp-mode", rtl)}>
                  {t(`dpM_${m}`)}
                </button>
              ))}
            </div>
            <p className="ndp-hint" data-dp-hint>{t(`dpM_${mode}Hint`)}</p>
          </div>

          {groups.length > 0 ? (
            <div className="ndp-summary" data-dp-summary role="status">
              {t("dpSummary").replace("{{g}}", num(groups.length)).replace("{{c}}", num(extraCopies)).replace("{{size}}", fmtBytes(freed, locale))}
            </div>
          ) : (
            <div className="nls-empty ndp-empty" data-dp-empty>{input.length < 2 ? t("dpEmptyLib") : t("dpEmpty")}</div>
          )}

          <ol className="ndp-groups">
            {shown.map((g) => {
              const keep = keepOf(g);
              const lead = tracks[keep];
              return (
                <li key={g.sig} className="ndp-group" data-dp-group={g.sig}>
                  <div className="ndp-group-head">
                    <div className="ndp-group-title">
                      <span className="ndp-name" dir="auto">{lead?.title || g.title}</span>
                      <span className="ndp-artist" dir="auto">{lead?.artist || g.artist}</span>
                    </div>
                    <span className="ndp-count">{t("dpCopies").replace("{{n}}", num(g.ids.length))}</span>
                  </div>
                  <div className="ndp-copies" role="radiogroup" aria-label={t("dpKeepWhich")}>
                    {g.ids.map((id) => {
                      const x = tracks[id];
                      if (!x) return null;
                      return (
                        <CopyRow key={id} x={x} group={g.sig} checked={id === keep} suggested={id === g.keep}
                          playing={id === currentId} rating={ratings[id] || 0} plays={playCounts[id] || 0}
                          onPick={() => setKeepPick((p) => ({ ...p, [g.sig]: id }))} onPlay={() => playTrack(g, id)} t={t} num={num} locale={locale} />
                      );
                    })}
                  </div>
                  <div className="ndp-group-actions">
                    <button type="button" className="nte-btn nte-btn-sm" onClick={() => notDupes(g)} disabled={busy} data-dp-ignore title={t("dpNotDupesHint")}>
                      <EyeOff size={13} /> {t("dpNotDupes")}
                    </button>
                    <span className="nsc-grow" />
                    <button type="button" className="nte-btn nte-btn-sm" onClick={() => setAsk([g.sig])} disabled={busy} data-dp-resolve>
                      <Trash2 size={13} /> {t("dpRemoveOthers").replace("{{n}}", num(g.ids.length - 1))}
                    </button>
                  </div>
                </li>
              );
            })}
          </ol>
          {groups.length > limit && (
            <button type="button" className="nte-btn ndp-more" onClick={() => setLimit((n) => n + PAGE)} data-dp-more>
              {t("dpShowMore").replace("{{n}}", num(Math.min(PAGE, groups.length - limit)))}
            </button>
          )}
        </div>

        <div className="nte-foot ndp-foot">
          {ask ? (
            <div className="nls-ask ndp-ask" role="alertdialog" aria-label={t("dpConfirmTitle")} data-dp-ask>
              <span className="nls-ask-text">
                {t("dpConfirm").replace("{{n}}", num(askCount))}{" "}
                {trash && trashable ? t("dpConfirmTrash") : t("dpConfirmLib")}
                {askPlaying ? ` ${t("dpConfirmPlaying")}` : ""}
              </span>
              <button type="button" className="nte-btn" onClick={() => setAsk(null)} ref={focusOnMount} data-dp-ask-no>{t("lsCancel")}</button>
              <button type="button" className="nte-btn nte-btn-danger" onClick={doResolve} disabled={!askCount} data-dp-ask-yes>{t("dpConfirmYes")}</button>
            </div>
          ) : (
            <>
              {trashable && (
                <label className="nls-keep" title={t("dpTrashHint")}>
                  <input type="checkbox" checked={trash} onChange={(e) => setTrashPref(e.target.checked)} data-dp-trash />
                  <span>{t("dpTrash")}</span>
                </label>
              )}
              {ignored.size > 0 && (
                <button type="button" className="nte-btn nte-btn-sm" onClick={showHidden} data-dp-unhide>
                  <Undo2 size={13} /> {t("dpShowHidden").replace("{{n}}", num(ignored.size))}
                </button>
              )}
              <span className="nls-grow" />
              {busy && <Loader2 size={15} className="nte-spin" aria-hidden />}
              <button type="button" className="nte-btn nte-btn-primary" onClick={() => setAsk(groups.map((g) => g.sig))} disabled={busy || !groups.length} data-dp-resolve-all>
                {t("dpResolveAll").replace("{{n}}", num(extraCopies))}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function CopyRow({ x, group, checked, suggested, playing, rating, plays, onPick, onPlay, t, num, locale }: {
  x: Track; group: string; checked: boolean; suggested: boolean; playing: boolean; rating: number; plays: number;
  onPick: () => void; onPlay: () => void; t: (k: string) => string; num: (n: number) => string; locale: string;
}) {
  const kbps = typeof x.bitrate === "string" ? parseFloat(x.bitrate) : x.bitrate;
  const where = x.filePath ? x.filePath.replace(/[\\/][^\\/]*$/, "") : x.album;
  const hasLyrics = !!x.hasEmbeddedLyrics || !!x.syncedLyrics?.length || !!x.plainLyrics?.trim();
  return (
    <div className="ndp-copy" data-keep={checked || undefined} data-dp-copy={x.id}>
      <label className="ndp-copy-main">
        <input type="radio" name={`ndp-${group}`} checked={checked} onChange={onPick} data-dp-keep={x.id} />
        <span className="ndp-copy-text">
          <span className="ndp-file" dir="auto">{x.fileName || x.title}</span>
          {where && <span className="ndp-path" dir="auto" title={x.filePath || undefined}>{where}</span>}
          <span className="ndp-meta">
            <span className="ndp-tag" data-lossless={isLossless(x.format) || undefined}><FileAudio size={11} aria-hidden /> {formatLabel(x)}</span>
            {Number(kbps) > 0 && <span className="ndp-tag">{num(Math.round(Number(kbps)))} kbps</span>}
            <span className="ndp-tag">{fmtTime(x.duration)}</span>
            {x.fileSize > 0 && <span className="ndp-tag">{fmtBytes(x.fileSize, locale)}</span>}
            {x.hasCover && !x.isPlaceholderCover && <span className="ndp-tag" title={t("dpHasCover")}><ImageIcon size={11} aria-label={t("dpHasCover")} /></span>}
            {hasLyrics && <span className="ndp-tag" title={t("dpHasLyrics")}><Music2 size={11} aria-label={t("dpHasLyrics")} /></span>}
            {rating > 0 && <span className="ndp-tag" title={t("rtRating")}><Star size={11} aria-hidden /> {num(rating)}</span>}
            {plays > 0 && <span className="ndp-tag">{t("lsPlaysN").replace("{{n}}", num(plays))}</span>}
          </span>
        </span>
        <span className="ndp-flags">
          {checked && <span className="ndp-flag" data-flag="keep">{t("dpKeep")}</span>}
          {!checked && <span className="ndp-flag" data-flag="remove">{playing ? t("dpPlayingKept") : t("dpWillRemove")}</span>}
          {suggested && <span className="ndp-flag" data-flag="best">{t("dpSuggested")}</span>}
          {playing && checked && <span className="ndp-flag" data-flag="playing">{t("dpPlaying")}</span>}
        </span>
      </label>
      <button type="button" className="nte-icon ndp-play" onClick={onPlay} aria-label={`${t("play")} · ${x.fileName || x.title}`} title={t("dpPreview")} data-dp-play={x.id}>
        <Play size={13} />
      </button>
    </div>
  );
}

const EXT_LABEL = /\.(mp3|flac|wav|ogg|oga|opus|m4a|aac|alac|aiff?|ape|wv|wma|dsf|dff|webm|mp4|caf|mpc)$/i;
/** "MP3", not the container name the desktop shell stores ("MPEG") */
function formatLabel(x: Track): string {
  const m = EXT_LABEL.exec(x.fileName || x.filePath || "");
  return (m ? m[1] : String(x.format || "?")).toUpperCase();
}
