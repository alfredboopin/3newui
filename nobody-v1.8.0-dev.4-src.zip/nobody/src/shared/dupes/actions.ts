// ── NOBODY · duplicate finder actions (1.7.0) ────────────────────────────────
// Resolve groups: the kept copy inherits playlists / Liked / rating / plays /
// listening history, then the other copies leave the library (bridge: the
// classic library, optionally to the Recycle Bin; standalone: IndexedDB).
// The song that is playing right now is never removed.

import { useLibrary } from "../../cinema/store/library";
import { engine } from "../../cinema/lib/engine";
import { getBridge } from "../../cinema/lib/desktopBridge";
import { removeStandaloneTrack } from "../../cinema/lib/folderManager";
import { remapPlayIds } from "../stats/listenLog";
import { dropSmartCache } from "../../cinema/lib/smartPlaylist";

export interface ResolveResult {
  removed: number;
  trashed: number;
  /** could not be moved to the Recycle Bin (open elsewhere / read-only) */
  failed: number;
  /** skipped because it is playing */
  playing: number;
}

export const canTrash = () => !!getBridge()?.removeTracks && typeof window !== "undefined" && !!window.electronAPI?.trashFiles;

/** `decisions`: kept id → the ids to remove */
export async function resolveDuplicates(decisions: { keep: string; remove: string[] }[], opts: { trash?: boolean } = {}): Promise<ResolveResult> {
  const lib = useLibrary.getState();
  const current = engine.currentId;
  const map: Record<string, string> = {};
  let playing = 0;
  for (const d of decisions) {
    for (const id of d.remove) {
      if (!id || id === d.keep || !lib.tracks[id]) continue;
      if (id === current) { playing++; continue; }
      map[id] = d.keep;
    }
  }
  const ids = Object.keys(map);
  if (!ids.length) return { removed: 0, trashed: 0, failed: 0, playing };

  const bridge = getBridge();
  let removed: string[] = ids;
  let trashed = 0;
  let failed = 0;
  if (bridge?.removeTracks) {
    const r = await bridge.removeTracks(ids, { trash: !!opts.trash && canTrash(), mergeInto: map });
    removed = r.removed;
    trashed = r.trashed;
    failed = r.failed.length;
    playing += r.playing.length;
  }
  const done: Record<string, string> = {};
  for (const id of removed) if (map[id]) done[id] = map[id];
  if (!Object.keys(done).length) return { removed: 0, trashed, failed, playing };

  // the kept copies inherit everything, then the rows go
  useLibrary.getState().mergeTrackData(done);
  await remapPlayIds(done).catch(() => 0);
  dropEngineQueue(new Set(Object.keys(done)));
  if (bridge) {
    // the classic notify rehydrates the mirror; drop leftovers right away
    useLibrary.getState().removeTracks(Object.keys(done));
  } else {
    for (const id of Object.keys(done)) await removeStandaloneTrack(id);
  }
  dropSmartCache();
  return { removed: Object.keys(done).length, trashed, failed, playing };
}

function dropEngineQueue(gone: Set<string>) {
  try {
    const order = engine.order || [];
    const queue = engine.queue || [];
    for (let i = order.length - 1; i >= 0; i--) {
      const id = queue[order[i]];
      if (id && gone.has(id) && id !== engine.currentId) engine.removeFromQueue(i);
    }
  } catch { /* engine shape changed: the missing-file skip still covers it */ }
}
