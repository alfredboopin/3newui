// ── NOBODY · Classic sound chain (V1.6.3, Phase 3 part 2c) ───────────────────
// Classic plays through its own <audio> (it only moves onto the shared engine
// in Phase 6). This module gives that element the SAME sound as the engine
// faces, from the SAME settings store:
//   element → ReplayGain gain → FxChain (preamp + 6/10 peaking bands) → out
// plus playback speed (settings.speed, pitch preserved).
//
// Safety rules (a MediaElementSource can only be created once per element and
// outputs silence for CORS-tainted media):
//   • the graph is built lazily, the first time a sound feature is actually
//     ON (EQ enabled or ReplayGain mode ≠ off) while a safe source is loaded
//     and playback starts. With both off (the default) Classic's audio path is
//     byte-for-byte the 1.6.2 one.
//   • safe = blob: (same origin), app:// (CORS, the element gets
//     crossOrigin="anonymous" via classicCrossOrigin()) or same-origin http(s).
//     Any other scheme (legacy Tauri asset://) never builds the graph: EQ /
//     ReplayGain are then unavailable, playback itself is untouched.

import { useSettings } from "../cinema/store/settings";
import { FxChain, readEqConfig } from "./audioFx";
import { readReplayGainPrefs, replayGainFactor, type ReplayGainInfo } from "./replayGain";

/** crossOrigin value Classic's <audio> must carry for `url` (set BEFORE src). */
export function classicCrossOrigin(url: string | undefined | null): "anonymous" | undefined {
  return url && url.startsWith("app://") ? "anonymous" : undefined;
}

function isGraphSafe(url: string): boolean {
  if (!url) return false;
  if (url.startsWith("blob:") || url.startsWith("app://")) return true;
  try {
    const u = new URL(url, location.href);
    return (u.protocol === "http:" || u.protocol === "https:") && u.origin === location.origin;
  } catch {
    return false;
  }
}

function soundWanted(): boolean {
  const s = useSettings.getState();
  return !!s.eqEnabled || readReplayGainPrefs(s).mode !== "off";
}

class ClassicSound {
  private el: HTMLAudioElement | null = null;
  private ctx: AudioContext | null = null;
  private rgNode: GainNode | null = null;
  private fx: FxChain | null = null;
  private rg: ReplayGainInfo | undefined;
  private unsub: (() => void) | null = null;
  /** true once the graph owns the element (can't be undone) */
  get active() { return !!this.ctx; }

  /** Bind to Classic's element (idempotent; the portal element is persistent). */
  attach(el: HTMLAudioElement | null) {
    if (!el || el === this.el) return;
    this.el = el;
    this.applyRate();
    if (!this.unsub) {
      this.unsub = useSettings.subscribe((st, prev) => {
        if (st.speed !== prev.speed) this.applyRate();
        if (
          st.eqEnabled !== prev.eqEnabled || st.eqGains !== prev.eqGains ||
          st.eqBands !== prev.eqBands || st.eqPreamp !== prev.eqPreamp
        ) this.applyEq();
        if (
          st.replayGain !== prev.replayGain || st.rgPreamp !== prev.rgPreamp ||
          st.rgFallback !== prev.rgFallback || st.rgPreventClip !== prev.rgPreventClip
        ) this.applyRg(true);
        // a feature was just switched on while Classic is already playing
        if (!this.ctx && this.el && !this.el.paused) this.ensureGraph();
      });
    }
  }

  /** Current track's loudness tags (call on every track change). */
  setTrack(rg: ReplayGainInfo | undefined) {
    this.rg = rg;
    this.applyRg(false); // new source: jump, no ramp (it hasn't sounded yet)
  }

  /** Call right before / as Classic starts playing. */
  onPlay() {
    this.applyRate();
    this.ensureGraph();
    if (this.ctx?.state === "suspended") this.ctx.resume().catch(() => undefined);
  }

  /** Speed must survive a src change: load() resets playbackRate to the default. */
  applyRate() {
    const el = this.el;
    if (!el) return;
    const s = useSettings.getState().speed ?? 1;
    const rate = Math.max(0.5, Math.min(2, Number(s) || 1));
    try {
      (el as any).preservesPitch = true;
      el.defaultPlaybackRate = rate;
      if (Math.abs(el.playbackRate - rate) > 1e-3) el.playbackRate = rate;
    } catch { /* ignore */ }
  }

  private ensureGraph() {
    const el = this.el;
    if (this.ctx || !el) return;
    if (!soundWanted()) return;
    const src = el.currentSrc || el.src;
    if (!isGraphSafe(src)) return;
    // app:// must be fetched in CORS mode or the graph outputs zeros
    if (src.startsWith("app://") && el.crossOrigin !== "anonymous") return;
    try {
      const ctx = new AudioContext();
      const source = ctx.createMediaElementSource(el);
      const rg = ctx.createGain();
      const fx = new FxChain(ctx, ctx.destination);
      source.connect(rg);
      rg.connect(fx.input);
      this.ctx = ctx;
      this.rgNode = rg;
      this.fx = fx;
      this.applyEq();
      this.applyRg(false);
      if (ctx.state === "suspended") ctx.resume().catch(() => undefined);
    } catch (e) {
      console.warn("[classic] sound graph unavailable:", e);
    }
  }

  private applyEq() {
    try { this.fx?.apply(readEqConfig(useSettings.getState())); } catch { /* ignore */ }
  }

  private applyRg(ramp: boolean) {
    const node = this.rgNode;
    if (!node || !this.ctx) return;
    const f = replayGainFactor(this.rg, readReplayGainPrefs(useSettings.getState()));
    try {
      const now = this.ctx.currentTime;
      node.gain.cancelScheduledValues(now);
      if (ramp) {
        node.gain.setValueAtTime(node.gain.value, now);
        node.gain.linearRampToValueAtTime(f, now + 0.03);
      } else node.gain.setValueAtTime(f, now);
    } catch {
      try { node.gain.value = f; } catch { /* ignore */ }
    }
  }
}

export const classicSound = new ClassicSound();
