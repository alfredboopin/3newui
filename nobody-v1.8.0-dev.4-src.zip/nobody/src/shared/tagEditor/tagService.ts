// ── NOBODY · tag editor service (V1.7.0, Phase 4 · part 2) ──────────────────
// Renderer side of the write-back core in electron/tags. Face-neutral: the
// dialog (Cinema / EELA / ALOK) only talks to this module.
//
//   editability(track)      → can this track be written to its file?
//   readTrackTags(track)    → tags:read (the FILE is the truth, not the library)
//   writeTrackTags(track,p) → tags:write, then hands the result to the bridge
//                             (bridge.patchTags lands in part 3: re-parse +
//                             patch the library in place + playback reload)
//
// Validation mirrors electron/tags/common.cjs normalizePatch so the user sees
// a field error inline instead of a generic E_INVALID after the round trip.

import type { Track } from "../../cinema/types";
import { getBridge, invalidateBridgeCover } from "../../cinema/lib/desktopBridge";
import { useLibrary } from "../../cinema/store/library";
import { db } from "../../cinema/lib/db";
import { invalidateCover } from "../../cinema/lib/covers";
import { normalizeGenre } from "../replayGain";
import { LIBRARY_FIELD_KEYS, hasTagOverride, type LibraryFieldKey } from "./libraryOverrides";

export { LIBRARY_FIELD_KEYS, type LibraryFieldKey };

export const TAG_FIELD_KEYS = [
  "title",
  "artist",
  "album",
  "albumArtist",
  "year",
  "genre",
  "track",
  "disc",
  "composer",
  "comment",
] as const;
export type TagFieldKey = (typeof TAG_FIELD_KEYS)[number];
export type TagFields = Record<TagFieldKey, string>;

export type TagErrorCode =
  | "E_INVALID"
  | "E_UNSUPPORTED"
  | "E_READONLY"
  | "E_BUSY"
  | "E_VERIFY"
  | "E_NOT_FOUND"
  | "E_NO_SPACE"
  | "E_CORRUPT"
  | "E_TOO_LARGE"
  | "E_IO"
  | "E_NO_DESKTOP";

export interface TagReadResult {
  format: string;
  tagType: string;
  fields: TagFields;
  hasCover: boolean;
}

export interface TagWriteResult extends TagReadResult {
  mode: "inplace" | "rewrite";
  size: number;
  mtimeMs: number;
}

export type CoverPatch =
  | { action: "keep" }
  | { action: "remove" }
  | { action: "set"; data: Uint8Array };

export interface TagPatch {
  fields: Partial<TagFields>;
  cover: CoverPatch;
}

type Ok<T> = { ok: true } & T;
type Fail = { ok: false; code: TagErrorCode };

/** Same list as electron/tags/index.cjs TAG_EXTS (the main process re-checks). */
export const TAGGABLE_EXTS = new Set(["mp3", "flac", "ogg", "oga", "opus", "m4a", "m4b", "mp4", "alac"]);
export const MAX_COVER_BYTES = 12 * 1024 * 1024;
const FIELD_MAX: Partial<Record<TagFieldKey, number>> = { comment: 8000 };
const FIELD_MAX_DEFAULT = 1000;

interface TagsApi {
  readTags: (path: string) => Promise<any>;
  writeTags: (path: string, patch: unknown) => Promise<any>;
}

function tagsApi(): TagsApi | null {
  const api = (typeof window !== "undefined" ? (window as any).electronAPI : null) as Partial<TagsApi> | null;
  return api && typeof api.readTags === "function" && typeof api.writeTags === "function" ? (api as TagsApi) : null;
}

function isAbsolutePath(p: string): boolean {
  return /^[a-zA-Z]:[\\/]/.test(p) || p.startsWith("\\\\") || p.startsWith("/");
}

function extOf(p: string): string {
  const name = p.split(/[\\/]/).pop() || "";
  const dot = name.lastIndexOf(".");
  return dot > 0 ? name.slice(dot + 1).toLowerCase() : "";
}

export type Editability =
  | { mode: "file"; path: string; ext: string }
  /** 1.7.0-dev.5: the file can't be written, but the LIBRARY row can.
   *  `persistent` = a desktop row (stable id) → survives restarts / rescans. */
  | { mode: "library"; reason: "noFile" | "format"; ext?: string; persistent: boolean }
  /** no file behind the track (web build, blob import, demo) */
  | { mode: "none"; reason: "noFile" }
  /** a real file, but a container the writer doesn't handle (WAV, AIFF, WMA…) */
  | { mode: "none"; reason: "format"; ext: string };

/** Where a library-only edit can go: the classic shell (bridge) owns bridged
 *  rows; the standalone web build owns its IDB library itself. */
function libraryRoute(id: string | undefined): "bridge" | "store" | null {
  if (!id) return null;
  const bridge = getBridge();
  if (bridge) {
    try {
      return typeof bridge.patchLibraryTags === "function" && bridge.hasTrack(id) ? "bridge" : null;
    } catch {
      return null;
    }
  }
  return useLibrary.getState().tracks[id] ? "store" : null;
}

export function editability(track: Pick<Track, "filePath" | "demo" | "format"> & { id?: string }): Editability {
  const p = track.filePath || "";
  const desktopFile = !!tagsApi() && !track.demo && !!p && isAbsolutePath(p);
  const ext = desktopFile ? extOf(p) : "";
  if (desktopFile && TAGGABLE_EXTS.has(ext)) return { mode: "file", path: p, ext };
  const route = track.demo ? null : libraryRoute(track.id);
  if (!desktopFile) {
    // no file: session-only in bridge mode (blob imports die with the
    // reload), persistent in the standalone build (its library is IDB)
    return route ? { mode: "library", reason: "noFile", persistent: route === "store" } : { mode: "none", reason: "noFile" };
  }
  const shownExt = ext || String(track.format || "?");
  return route
    ? { mode: "library", reason: "format", ext: shownExt, persistent: true }
    : { mode: "none", reason: "format", ext: shownExt };
}

/** A file read failed in a way that won't fix itself (unsupported / damaged
 *  container): offer a library-only edit instead of a dead read-only form. */
export function libraryFallback(track: Pick<Track, "id" | "filePath" | "demo">, code: TagErrorCode): Editability | null {
  if (code !== "E_UNSUPPORTED" && code !== "E_CORRUPT") return null;
  if (track.demo || !libraryRoute(track.id)) return null;
  return { mode: "library", reason: "format", ext: extOf(track.filePath || "") || undefined, persistent: true };
}

/** A library-only edit currently sits on top of this desktop row. */
export function hasLibraryOverride(track: Pick<Track, "id">): boolean {
  return hasTagOverride(track.id);
}

function cleanFields(raw: any): TagFields {
  const out = {} as TagFields;
  for (const k of TAG_FIELD_KEYS) out[k] = typeof raw?.[k] === "string" ? raw[k] : "";
  return out;
}

function failCode(res: any): TagErrorCode {
  const c = typeof res?.code === "string" ? res.code : "";
  return (c.startsWith("E_") ? c : "E_IO") as TagErrorCode;
}

export async function readTrackTags(track: Track): Promise<Ok<TagReadResult> | Fail> {
  const e = editability(track);
  const api = tagsApi();
  if (e.mode !== "file" || !api) return { ok: false, code: e.mode === "none" && e.reason === "format" ? "E_UNSUPPORTED" : "E_NO_DESKTOP" };
  try {
    const res = await api.readTags(e.path);
    if (!res?.ok) return { ok: false, code: failCode(res) };
    return {
      ok: true,
      format: String(res.format || e.ext),
      tagType: String(res.tagType || ""),
      fields: cleanFields(res.fields),
      hasCover: !!res.hasCover,
    };
  } catch {
    return { ok: false, code: "E_IO" };
  }
}

/* Serialize writes per track id in the renderer as well (main already locks
   per file): a double-click on Save must not queue two rewrites. */
const inFlight = new Set<string>();

export async function writeTrackTags(track: Track, patch: TagPatch): Promise<Ok<TagWriteResult> | Fail> {
  const e = editability(track);
  const api = tagsApi();
  if (e.mode !== "file" || !api) return { ok: false, code: "E_NO_DESKTOP" };
  if (inFlight.has(track.id)) return { ok: false, code: "E_BUSY" };
  inFlight.add(track.id);
  try {
    const wire: { fields: Partial<TagFields>; cover?: { action: string; data?: Uint8Array } } = { fields: patch.fields };
    if (patch.cover.action === "remove") wire.cover = { action: "remove" };
    else if (patch.cover.action === "set") wire.cover = { action: "set", data: patch.cover.data };
    const res = await api.writeTags(e.path, wire);
    if (!res?.ok) return { ok: false, code: failCode(res) };
    const result: TagWriteResult = {
      mode: res.mode === "rewrite" ? "rewrite" : "inplace",
      size: Number(res.size) || 0,
      mtimeMs: Number(res.mtimeMs) || 0,
      format: String(res.format || e.ext),
      tagType: String(res.tagType || ""),
      fields: cleanFields(res.fields),
      hasCover: !!res.hasCover,
    };
    /* Part 3 hook: the classic shell re-parses the file and patches the
       library row in place (same id), reloading playback on a rewrite.
       Optional so this part ships without it. */
    try {
      await getBridge()?.patchTags?.(track.id, {
        path: e.path,
        mode: result.mode,
        fields: result.fields,
        hasCover: result.hasCover,
        coverChanged: patch.cover.action !== "keep",
        size: result.size || undefined,
        mtimeMs: result.mtimeMs || undefined,
      });
    } catch {
      /* the file IS written; a failed library refresh must not report a failed save */
    }
    return { ok: true, ...result };
  } catch {
    return { ok: false, code: "E_IO" };
  } finally {
    inFlight.delete(track.id);
  }
}

// ── library-only edits (1.7.0-dev.5, P4 · 4) ──────────────────────────────

export interface LibraryPatch {
  fields: Partial<Record<LibraryFieldKey, string>>;
  /** JPEG / PNG bytes, already sniffed by readCoverFile */
  cover?: { data: Uint8Array; mime: string } | null;
}

export async function writeLibraryTags(track: Track, patch: LibraryPatch): Promise<{ ok: true } | Fail> {
  const route = track.demo ? null : libraryRoute(track.id);
  if (!route) return { ok: false, code: "E_NO_DESKTOP" };
  if (inFlight.has(track.id)) return { ok: false, code: "E_BUSY" };
  const fields: Partial<Record<LibraryFieldKey, string>> = {};
  for (const k of LIBRARY_FIELD_KEYS) {
    const v = patch.fields[k];
    if (typeof v !== "string") continue;
    if (validateField(k, v)) return { ok: false, code: "E_INVALID" };
    fields[k] = v.trim();
  }
  const blob = patch.cover ? new Blob([patch.cover.data as BlobPart], { type: patch.cover.mime }) : null;
  inFlight.add(track.id);
  try {
    if (route === "bridge") {
      const ok = await getBridge()!.patchLibraryTags!(track.id, { fields, cover: blob });
      if (!ok) return { ok: false, code: "E_IO" };
      if (blob) invalidateBridgeCover(track.id);
      return { ok: true };
    }
    // standalone web build: the IDB library IS the store
    const lib = useLibrary.getState();
    const cur = lib.tracks[track.id];
    if (!cur) return { ok: false, code: "E_NOT_FOUND" };
    const next: Partial<Track> = {};
    if (fields.title !== undefined) next.title = fields.title || cur.fileName.replace(/\.[^.]+$/, "") || cur.title;
    if (fields.artist !== undefined) next.artist = fields.artist || "Unknown Artist";
    if (fields.album !== undefined) next.album = fields.album || "Unknown Album";
    if (fields.year !== undefined) next.year = fields.year || undefined;
    if (fields.genre !== undefined) next.genre = normalizeGenre(fields.genre) || undefined;
    if (blob) {
      await db.putCover(track.id, blob).catch(() => void 0);
      invalidateCover(track.id);
      next.hasCover = true;
      next.isPlaceholderCover = false;
      next.coverKey = `user:${Date.now()}`;
    }
    lib.patchTrack(track.id, next);
    return { ok: true };
  } catch {
    return { ok: false, code: "E_IO" };
  } finally {
    inFlight.delete(track.id);
  }
}

export async function resetLibraryTags(track: Track): Promise<{ ok: true } | Fail> {
  const bridge = getBridge();
  if (!bridge?.resetLibraryTags) return { ok: false, code: "E_NO_DESKTOP" };
  if (inFlight.has(track.id)) return { ok: false, code: "E_BUSY" };
  inFlight.add(track.id);
  try {
    const ok = await bridge.resetLibraryTags(track.id);
    if (!ok) return { ok: false, code: "E_IO" };
    invalidateBridgeCover(track.id);
    return { ok: true };
  } catch {
    return { ok: false, code: "E_IO" };
  } finally {
    inFlight.delete(track.id);
  }
}

// ── validation (mirror of normalizePatch) ──────────────────────────────────

export type FieldError = "tooLong" | "year" | "number";

function numPairOk(s: string): boolean {
  const m = /^\s*(\d{1,5})?\s*(?:\/\s*(\d{1,5}))?\s*$/.exec(s);
  if (!m || (!m[1] && !m[2])) return false;
  return Number(m[1] || 0) <= 65535 && Number(m[2] || 0) <= 65535;
}

export function validateField(key: TagFieldKey, value: string): FieldError | null {
  const s = value.trim();
  if (s.length > (FIELD_MAX[key] ?? FIELD_MAX_DEFAULT)) return "tooLong";
  if (!s) return null;
  if (key === "year" && !/^\d{4}(-\d{2}(-\d{2})?)?$/.test(s)) return "year";
  if ((key === "track" || key === "disc") && !numPairOk(s)) return "number";
  return null;
}

/** Normalised compare key, so "3 / 12" vs "3/12" or "Rock;Pop" vs "Rock; Pop" isn't a change. */
export function fieldKey(key: TagFieldKey, value: string): string {
  let s = value.replace(/\r\n?/g, "\n").trim();
  if (key !== "comment") s = s.replace(/[\x00-\x1f\x7f]/g, " ");
  if (key === "genre")
    s = s
      .split(";")
      .map((g) => g.trim())
      .filter(Boolean)
      .join("; ");
  if (key === "track" || key === "disc") s = s.replace(/\s+/g, "");
  return s;
}

/** Only the fields the user actually changed go on the wire. */
export function diffFields(original: TagFields, edited: TagFields): Partial<TagFields> {
  const out: Partial<TagFields> = {};
  for (const k of TAG_FIELD_KEYS) {
    if (fieldKey(k, original[k]) !== fieldKey(k, edited[k])) out[k] = edited[k].trim();
  }
  return out;
}

// ── cover input ─────────────────────────────────────────────────────────────

export type CoverFileError = "type" | "size" | "read";

export async function readCoverFile(
  file: File,
): Promise<{ ok: true; data: Uint8Array; mime: "image/jpeg" | "image/png" } | { ok: false; error: CoverFileError }> {
  if (file.size === 0 || file.size > MAX_COVER_BYTES) return { ok: false, error: "size" };
  let data: Uint8Array;
  try {
    data = new Uint8Array(await file.arrayBuffer());
  } catch {
    return { ok: false, error: "read" };
  }
  // sniff the bytes, never trust the extension / MIME (main re-checks too)
  if (data.length > 3 && data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff) return { ok: true, data, mime: "image/jpeg" };
  if (data.length > 8 && data[0] === 0x89 && data[1] === 0x50 && data[2] === 0x4e && data[3] === 0x47) return { ok: true, data, mime: "image/png" };
  return { ok: false, error: "type" };
}

export function errorKey(code: TagErrorCode): string {
  switch (code) {
    case "E_READONLY": return "teErrReadonly";
    case "E_BUSY": return "teErrBusy";
    case "E_NOT_FOUND": return "teErrNotFound";
    case "E_NO_SPACE": return "teErrNoSpace";
    case "E_CORRUPT": return "teErrCorrupt";
    case "E_UNSUPPORTED": return "teErrUnsupported";
    case "E_TOO_LARGE": return "teErrTooLarge";
    case "E_VERIFY": return "teErrVerify";
    case "E_INVALID": return "teErrInvalid";
    case "E_NO_DESKTOP": return "teNoFile";
    default: return "teErrIo";
  }
}
