// ── NOBODY · tag editor open state (shared by Cinema / EELA / ALOK) ─────────
// One dialog per face is mounted INSIDE that face's root (face CSS variables
// are scoped there). `face` pins which one shows, so the hidden panes (all
// stay mounted) never open a second copy.

import { create } from "zustand";
import { getUiMode, type UiMode } from "../../uiMode";

export type TagEditorFace = Exclude<UiMode, "classic">;

interface TagEditorState {
  trackId: string | null;
  face: TagEditorFace | null;
  open: (trackId: string, face?: TagEditorFace) => void;
  close: () => void;
}

export const useTagEditor = create<TagEditorState>((set) => ({
  trackId: null,
  face: null,
  open: (trackId, face) => {
    const mode = face ?? getUiMode();
    if (mode === "classic") return;
    set({ trackId, face: mode });
  },
  close: () => set({ trackId: null, face: null }),
}));

export const openTagEditor = (trackId: string, face?: TagEditorFace) => useTagEditor.getState().open(trackId, face);
