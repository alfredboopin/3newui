// ── NOBODY · tag editor dialog (V1.7.0, Phase 4 · part 2) ───────────────────
// One component for Cinema / EELA / ALOK. Each face mounts it INSIDE its own
// root (face CSS variables are scoped there, so no body portal) and the
// shared store decides which face shows it. The FILE is the source of truth:
// fields come from tags:read, only changed fields go back on tags:write.
//
// 1.7.0-dev.5 (P4 · 4): when the file can't be written (WAV / AIFF, a web
// import, an unreadable container) the dialog switches to LIBRARY mode:
// title / artist / album / year / genre + cover, saved into the NOBODY
// library only (the file is never touched), with a reset back to the file.
//
// Keyboard: Esc closes (asks first when there are unsaved edits), Ctrl/⌘+S
// or Ctrl/⌘+Enter saves, Tab stays inside the dialog. Keys never leak to
// the face's global transport shortcuts.

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ChangeEvent, DragEvent, KeyboardEvent as ReactKeyboardEvent } from "react";
import { ImagePlus, Loader2, RotateCcw, Tags, Trash2, X } from "lucide-react";
import { useLibrary } from "../../cinema/store/library";
import { uiApi } from "../../cinema/store/ui";
import { useT } from "../../cinema/lib/useT";
import { CoverArt } from "../../cinema/components/CoverArt";
import type { Track } from "../../cinema/types";
import { useTagEditor, type TagEditorFace } from "./store";
import {
  LIBRARY_FIELD_KEYS,
  TAG_FIELD_KEYS,
  diffFields,
  editability,
  errorKey,
  hasLibraryOverride,
  libraryFallback,
  readCoverFile,
  readTrackTags,
  resetLibraryTags,
  validateField,
  writeLibraryTags,
  writeTrackTags,
  type CoverPatch,
  type Editability,
  type FieldError,
  type TagErrorCode,
  type TagFieldKey,
  type TagFields,
} from "./tagService";
import "./tagEditor.css";

export function TagEditorDialog({ face }: { face: TagEditorFace }) {
  const trackId = useTagEditor((s) => (s.face === face ? s.trackId : null));
  if (!trackId) return null;
  // key → a fresh form per track (never leaks edits from the previous one)
  return <TagEditorBody key={trackId} trackId={trackId} face={face} />;
}

type CoverState = { action: "keep" } | { action: "remove" } | { action: "set"; data: Uint8Array; url: string; mime: string };

type Phase =
  | { kind: "loading" }
  | { kind: "ready"; format: string; tagType: string; hasCover: boolean }
  /** library-only editing (file not writable); `persistent` = survives restarts */
  | { kind: "library"; why: "noFile" | "format" | "read"; ext?: string; code?: TagErrorCode; persistent: boolean }
  | { kind: "readonly"; why: "noFile" | "format" | "read"; ext?: string; code?: TagErrorCode };


const LABEL: Record<TagFieldKey, string> = {
  title: "teFieldTitle",
  artist: "teFieldArtist",
  album: "teFieldAlbum",
  albumArtist: "teFieldAlbumArtist",
  year: "teFieldYear",
  genre: "teFieldGenre",
  track: "teFieldTrack",
  disc: "teFieldDisc",
  composer: "teFieldComposer",
  comment: "teFieldComment",
};

const HINT: Partial<Record<TagFieldKey, string>> = {
  year: "teHintYear",
  genre: "teHintGenre",
  track: "teHintNumber",
  disc: "teHintNumber",
};

const FIELD_ERR: Record<FieldError, string> = {
  tooLong: "teErrTooLong",
  year: "teErrYear",
  number: "teErrNumber",
};

/** Grid placement: full-width rows and paired half rows. */
const WIDE = new Set<TagFieldKey>(["title", "album", "composer", "comment"]);
/** Values that are always Latin digits read better LTR, even in the FA UI. */
const LTR_FIELDS = new Set<TagFieldKey>(["year", "track", "disc"]);

function emptyFields(): TagFields {
  const f = {} as TagFields;
  for (const k of TAG_FIELD_KEYS) f[k] = "";
  return f;
}

function fieldsFromLibrary(tr: Track): TagFields {
  return { ...emptyFields(), title: tr.title || "", artist: tr.artist || "", album: tr.album || "", year: tr.year || "", genre: tr.genre || "" };
}

function TagEditorBody({ trackId, face }: { trackId: string; face: TagEditorFace }) {
  const t = useT();
  const close = useTagEditor((s) => s.close);
  const track = useLibrary((s) => s.tracks[trackId]) as Track | undefined;

  // editability is decided ONCE per open (a library patch must not flip the form)
  const [edit] = useState<Editability | null>(() => (track ? editability(track) : null));
  const [phase, setPhase] = useState<Phase>(() =>
    !edit || edit.mode === "file"
      ? { kind: "loading" }
      : edit.mode === "library"
        ? { kind: "library", why: edit.reason, ext: edit.ext, persistent: edit.persistent }
        : { kind: "readonly", why: edit.reason, ext: edit.reason === "format" ? edit.ext : undefined },
  );
  const [overridden] = useState(() => !!track && !!track.filePath && hasLibraryOverride(track));
  const [original, setOriginal] = useState<TagFields>(() => (track ? fieldsFromLibrary(track) : emptyFields()));
  const [fields, setFields] = useState<TagFields>(original);
  const [cover, setCover] = useState<CoverState>({ action: "keep" });
  const [coverErr, setCoverErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [saveErr, setSaveErr] = useState<TagErrorCode | null>(null);
  const [askDiscard, setAskDiscard] = useState(false);
  const [dropHot, setDropHot] = useState(false);

  const dialogRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const firstRef = useRef<HTMLInputElement>(null);
  const alive = useRef(true);
  const returnFocus = useRef<HTMLElement | null>(
    typeof document !== "undefined" ? (document.activeElement as HTMLElement | null) : null,
  );

  // ── lifecycle ──
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      try {
        returnFocus.current?.focus?.({ preventScroll: true });
      } catch {
        /* element gone */
      }
    };
  }, []);

  // the track was removed from the library while the dialog was open
  useEffect(() => {
    if (!track && !saving) close();
  }, [track, saving, close]);

  // read the file's real tags
  useEffect(() => {
    if (!track || edit?.mode !== "file") return;
    let cancelled = false;
    readTrackTags(track).then((res) => {
      if (cancelled || !alive.current) return;
      if (!res.ok) {
        // an unsupported / damaged container → library-only editing instead
        // of a dead form (busy / missing / denied stay read-only: retryable)
        const fb = libraryFallback(track, res.code);
        setPhase(fb ? { kind: "library", why: "read", code: res.code, persistent: true } : { kind: "readonly", why: "read", code: res.code });
        return;
      }
      setOriginal(res.fields);
      setFields(res.fields);
      setPhase({ kind: "ready", format: res.format, tagType: res.tagType, hasCover: res.hasCover });
    });
    return () => {
      cancelled = true;
    };
    // once per open; later library patches must not overwrite user edits
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // focus the first field once the form is live (or the dialog itself)
  useEffect(() => {
    if (phase.kind === "ready" || phase.kind === "library") firstRef.current?.focus({ preventScroll: true });
    else if (phase.kind === "readonly") dialogRef.current?.focus({ preventScroll: true });
  }, [phase.kind]);

  // release the preview object URL
  useEffect(() => {
    const url = cover.action === "set" ? cover.url : null;
    return () => {
      if (url) URL.revokeObjectURL(url);
    };
  }, [cover]);

  // ── derived ──
  const libMode = phase.kind === "library";
  const editable = phase.kind === "ready" || libMode;
  const keys: readonly TagFieldKey[] = libMode ? LIBRARY_FIELD_KEYS : TAG_FIELD_KEYS;
  const errors = useMemo(() => {
    const out: Partial<Record<TagFieldKey, FieldError>> = {};
    for (const k of keys) {
      const e = validateField(k, fields[k]);
      if (e) out[k] = e;
    }
    return out;
  }, [fields, keys]);
  const changed = useMemo(() => {
    const all = diffFields(original, fields);
    if (!libMode) return all;
    const out: Partial<TagFields> = {};
    for (const k of LIBRARY_FIELD_KEYS) if (k in all) out[k] = all[k];
    return out;
  }, [original, fields, libMode]);
  const dirty = editable && (Object.keys(changed).length > 0 || cover.action !== "keep");
  const invalid = Object.keys(errors).length > 0;
  const canSave = editable && dirty && !invalid && !saving;
  const fileHasCover = phase.kind === "ready" && phase.hasCover;

  // ── actions ──
  const requestClose = useCallback(() => {
    if (saving) return;
    if (dirty && !askDiscard) {
      setAskDiscard(true);
      return;
    }
    close();
  }, [saving, dirty, askDiscard, close]);

  const setField = (k: TagFieldKey, v: string) => {
    setFields((cur) => ({ ...cur, [k]: v }));
    setSaveErr(null);
    setAskDiscard(false);
  };

  const takeCoverFile = async (file: File | null | undefined) => {
    if (!file || !editable || saving) return;
    const res = await readCoverFile(file);
    if (!alive.current) return;
    if (!res.ok) {
      setCoverErr(res.error === "size" ? "teCoverErrSize" : res.error === "type" ? "teCoverErrType" : "teCoverErrRead");
      return;
    }
    setCoverErr(null);
    setSaveErr(null);
    setAskDiscard(false);
    const url = URL.createObjectURL(new Blob([res.data as BlobPart], { type: res.mime }));
    setCover({ action: "set", data: res.data, url, mime: res.mime });
  };

  const onPick = (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    void takeCoverFile(f);
  };

  const save = async () => {
    if (!track || !canSave) return;
    setSaving(true);
    setSaveErr(null);
    if (libMode) {
      const res = await writeLibraryTags(track, {
        fields: changed,
        cover: cover.action === "set" ? { data: cover.data, mime: cover.mime } : null,
      });
      if (!alive.current) return;
      setSaving(false);
      if (!res.ok) {
        setSaveErr(res.code);
        return;
      }
      uiApi.toast(`${t("teLibSaved")} · ${(changed.title ?? "").trim() || track.title}`, "success");
      close();
      return;
    }
    const coverPatch: CoverPatch =
      cover.action === "set" ? { action: "set", data: cover.data } : cover.action === "remove" ? { action: "remove" } : { action: "keep" };
    const res = await writeTrackTags(track, { fields: changed, cover: coverPatch });
    if (!alive.current) return;
    setSaving(false);
    if (!res.ok) {
      setSaveErr(res.code);
      return;
    }
    uiApi.toast(`${t("teSaved")} · ${res.fields.title || track.title}`, "success");
    close();
  };

  /** Drop the library-only edit and show the file's own tags again. */
  const resetToFile = async () => {
    if (!track || saving || resetting) return;
    setResetting(true);
    setSaveErr(null);
    const res = await resetLibraryTags(track);
    if (!alive.current) return;
    setResetting(false);
    if (!res.ok) {
      setSaveErr(res.code);
      return;
    }
    uiApi.toast(t("teLibResetDone"), "success");
    close();
  };
  const canReset = libMode && phase.persistent && overridden && !askDiscard;

  // ── keyboard: trap + shortcuts; nothing reaches the face's window listener ──
  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (e.key === "Escape") {
      e.preventDefault();
      if (askDiscard) setAskDiscard(false);
      else requestClose();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && (e.key === "s" || e.key === "S" || e.key === "Enter")) {
      e.preventDefault();
      void save();
      return;
    }
    if (e.key === "Tab" && dialogRef.current) {
      const nodes = Array.from(
        dialogRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), input:not([disabled]):not([type="file"]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((n) => n.offsetParent !== null || n === document.activeElement);
      if (!nodes.length) return;
      const first = nodes[0];
      const last = nodes[nodes.length - 1];
      const active = document.activeElement;
      if (e.shiftKey && (active === first || active === dialogRef.current)) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    }
  };

  // drag & drop an image on the cover (and swallow drags so the face's
  // "drop audio to import" overlay never opens under the dialog)
  const swallow = (e: DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };
  const onCoverDrop = (e: DragEvent) => {
    swallow(e);
    setDropHot(false);
    void takeCoverFile(e.dataTransfer?.files?.[0]);
  };

  if (!track) return null;

  const fileName = (track.filePath || track.fileName || "").split(/[\\/]/).pop() || track.title;
  const libraryMsg =
    phase.kind !== "library"
      ? null
      : phase.why === "noFile"
        ? t(phase.persistent ? "teLibNoFileKeep" : "teLibNoFileSession")
        : phase.why === "format"
          ? t("teLibFormat").replace("{{ext}}", (phase.ext || "?").toUpperCase())
          : `${t("teReadFail")}: ${t(errorKey(phase.code || "E_IO"))} ${t("teLibRead")}`;
  const readonlyMsg =
    phase.kind !== "readonly"
      ? libraryMsg
      : phase.why === "noFile"
        ? t("teNoFile")
        : phase.why === "format"
          ? t("teNoFormat").replace("{{ext}}", (phase.ext || "?").toUpperCase())
          : `${t("teReadFail")}: ${t(errorKey(phase.code || "E_IO"))}`;

  return (
    <div
      className="nte-layer"
      data-face={face}
      onKeyDown={onKeyDown}
      onDragEnter={swallow}
      onDragOver={swallow}
      onDragLeave={swallow}
      onDrop={swallow}
    >
      <div className="nte-backdrop" onClick={requestClose} aria-hidden />
      <div
        ref={dialogRef}
        className="nte-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="nte-title"
        tabIndex={-1}
        aria-busy={phase.kind === "loading" || saving}
      >
        {/* header */}
        <div className="nte-head">
          <span className="nte-badge" aria-hidden>
            <Tags size={15} />
          </span>
          <div className="nte-head-text">
            <div id="nte-title" className="nte-title">{t("teTitle")}</div>
            <div className="nte-sub" title={track.filePath || fileName} dir="auto">
              {fileName}
              {phase.kind === "ready" && (
                <>
                  <span aria-hidden> · </span>
                  <span className="nte-chip">{phase.format.toUpperCase()}</span>
                  {phase.tagType && phase.tagType !== "none" && <span className="nte-chip">{phase.tagType}</span>}
                </>
              )}
            </div>
          </div>
          <button type="button" className="nte-icon" onClick={requestClose} aria-label={t("close")} title={t("close")} disabled={saving}>
            <X size={16} />
          </button>
        </div>

        {/* body */}
        <div className="nte-body">
          {readonlyMsg && (
            <div className="nte-note" role="status">
              {readonlyMsg}
            </div>
          )}

          <div className="nte-main">
            {/* cover column */}
            <div className="nte-cover-col">
              <div
                className="nte-cover"
                data-hot={dropHot || undefined}
                data-editable={editable || undefined}
                onDragEnter={(e) => { swallow(e); if (editable) setDropHot(true); }}
                onDragOver={swallow}
                onDragLeave={(e) => { swallow(e); setDropHot(false); }}
                onDrop={onCoverDrop}
                onClick={() => editable && !saving && fileRef.current?.click()}
                title={editable ? t("teCoverDrop") : undefined}
              >
                {cover.action === "set" ? (
                  <img src={cover.url} alt="" draggable={false} />
                ) : cover.action === "remove" ? (
                  <div className="nte-cover-empty">{t("teCoverWillRemove")}</div>
                ) : (
                  <CoverArt trackId={track.id} rounded="rounded-none" />
                )}
                {cover.action !== "keep" && (
                  <span className="nte-cover-tag">{cover.action === "set" ? t("teCoverNew") : t("teCoverRemoved")}</span>
                )}
              </div>
              {editable && (
                <>
                  <div className="nte-cover-state">
                    {cover.action === "keep" ? (libMode ? t("teCoverLibrary") : fileHasCover ? t("teCoverInFile") : t("teCoverNone")) : "\u00a0"}
                  </div>
                  <div className="nte-cover-btns">
                    <button type="button" className="nte-btn nte-btn-sm" onClick={() => fileRef.current?.click()} disabled={saving}>
                      <ImagePlus size={13} /> {t("teCoverChoose")}
                    </button>
                    {cover.action === "keep" && fileHasCover && (
                      <button
                        type="button"
                        className="nte-btn nte-btn-sm"
                        onClick={() => { setCover({ action: "remove" }); setCoverErr(null); setAskDiscard(false); }}
                        disabled={saving}
                      >
                        <Trash2 size={13} /> {t("teCoverRemove")}
                      </button>
                    )}
                    {cover.action !== "keep" && (
                      <button
                        type="button"
                        className="nte-btn nte-btn-sm"
                        onClick={() => { setCover({ action: "keep" }); setCoverErr(null); }}
                        disabled={saving}
                      >
                        <RotateCcw size={13} /> {t("teCoverUndo")}
                      </button>
                    )}
                  </div>
                  {coverErr && <div className="nte-err" role="alert">{t(coverErr)}</div>}
                  <input ref={fileRef} type="file" accept="image/jpeg,image/png" hidden onChange={onPick} tabIndex={-1} />
                </>
              )}
            </div>

            {/* fields */}
            <div className="nte-grid">
              {phase.kind === "loading" ? (
                <div className="nte-loading">
                  <Loader2 size={16} className="nte-spin" /> {t("teLoading")}
                </div>
              ) : (
                keys.map((k, i) => {
                  const err = errors[k];
                  const hint = HINT[k];
                  const id = `nte-f-${k}`;
                  const common = {
                    id,
                    value: fields[k],
                    disabled: !editable || saving || resetting,
                    dir: LTR_FIELDS.has(k) ? ("ltr" as const) : ("auto" as const),
                    "aria-invalid": err ? true : undefined,
                    "aria-describedby": err || hint ? `${id}-d` : undefined,
                    spellCheck: false,
                    autoComplete: "off",
                  };
                  const touched = k in changed;
                  return (
                    <label key={k} className="nte-field" data-wide={WIDE.has(k) || (libMode && k === "genre") || undefined} data-changed={touched || undefined} htmlFor={id}>
                      <span className="nte-label">{t(LABEL[k])}</span>
                      {k === "comment" ? (
                        <textarea {...common} rows={3} className="nte-input nte-textarea" onChange={(e) => setField(k, e.target.value)} />
                      ) : (
                        <input
                          {...common}
                          ref={i === 0 ? firstRef : undefined}
                          className="nte-input"
                          inputMode={k === "track" || k === "disc" || k === "year" ? "numeric" : undefined}
                          placeholder={k === "title" && !fields.title ? track.title : undefined}
                          onChange={(e) => setField(k, e.target.value)}
                        />
                      )}
                      {(err || hint) && (
                        <span id={`${id}-d`} className={err ? "nte-err" : "nte-hint"}>
                          {t(err ? FIELD_ERR[err] : (hint as string))}
                        </span>
                      )}
                    </label>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* footer */}
        <div className="nte-foot">
          {askDiscard ? (
            <>
              <span className="nte-foot-msg">{t("teDiscardQ")}</span>
              <button type="button" className="nte-btn" onClick={() => setAskDiscard(false)} autoFocus>
                {t("teKeepEditing")}
              </button>
              <button type="button" className="nte-btn nte-btn-danger" onClick={close}>
                {t("teDiscard")}
              </button>
            </>
          ) : (
            <>
              {canReset && (
                <button type="button" className="nte-btn nte-btn-sm nte-reset" onClick={() => void resetToFile()} disabled={saving || resetting} title={t("teLibOverridden")}>
                  {resetting ? <Loader2 size={13} className="nte-spin" /> : <RotateCcw size={13} />} {t("teLibReset")}
                </button>
              )}
              <span className="nte-foot-msg" role={saveErr ? "alert" : undefined} data-err={saveErr ? true : undefined}>
                {saveErr ? t(errorKey(saveErr)) : libMode ? (overridden ? t("teLibOverridden") : t("teLibSafe")) : editable ? t("teSafeNote") : ""}
              </span>
              <button type="button" className="nte-btn" onClick={requestClose} disabled={saving || resetting}>
                {editable ? t("teCancel") : t("close")}
              </button>
              {editable && (
                <button type="button" className="nte-btn nte-btn-primary" onClick={() => void save()} disabled={!canSave || resetting} title="Ctrl+S">
                  {saving ? (
                    <>
                      <Loader2 size={14} className="nte-spin" /> {t("teSaving")}
                    </>
                  ) : (
                    t(libMode ? "teSaveLibrary" : "teSave")
                  )}
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
