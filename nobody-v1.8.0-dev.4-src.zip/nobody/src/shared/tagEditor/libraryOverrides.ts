// ── NOBODY · library-only tag overrides (V1.7.0-dev.5, Phase 4 · part 4) ────
// Some tracks can't have their tags written back: WAV / AIFF / WMA files
// (no writer), or files whose tags failed to read. The editor still lets the
// user fix them, but the change lives in the NOBODY library only.
//
// The classic library is rebuilt from disk on every boot, so a library-only
// edit has to be remembered separately and laid over the parsed tags at
// import / rescan time. Key = the stable track id (FNV hash of the path), so
// the override follows the file, never a random session id.
//
//   text fields → localStorage `nobody-tag-overrides-v1` (small, sync read at
//                 import time)
//   cover bytes → IndexedDB `nobody-overrides` / `covers` (can be MBs)
//
// Session-only tracks (web / blob imports have no stable id) never land here:
// the bridge patches their row and that's it.

import { normalizeGenre } from "../replayGain";

export const LIBRARY_FIELD_KEYS = ["title", "artist", "album", "year", "genre"] as const;
export type LibraryFieldKey = (typeof LIBRARY_FIELD_KEYS)[number];
export type LibraryFields = Partial<Record<LibraryFieldKey, string>>;

export interface TagOverride {
  /** only the fields the user changed (an empty string = cleared on purpose) */
  f: LibraryFields;
  /** a user cover is stored in IDB under the same key */
  cover?: boolean;
  /** last edit (ms) — the oldest entries go first past MAX_ENTRIES */
  at: number;
}

const LS_KEY = "nobody-tag-overrides-v1";
const MAX_ENTRIES = 5000;
const FIELD_MAX = 1000;

type Store = { v: 1; items: Record<string, TagOverride> };

let cache: Store | null = null;
const listeners = new Set<() => void>();

function emptyStore(): Store {
  return { v: 1, items: {} };
}

function cleanEntry(raw: any): TagOverride | null {
  if (!raw || typeof raw !== "object") return null;
  const f: LibraryFields = {};
  for (const k of LIBRARY_FIELD_KEYS) {
    const v = raw.f?.[k];
    if (typeof v === "string") f[k] = v.slice(0, FIELD_MAX);
  }
  const cover = raw.cover === true;
  if (!Object.keys(f).length && !cover) return null;
  return { f, cover: cover || undefined, at: Number(raw.at) || 0 };
}

function load(): Store {
  if (cache) return cache;
  const out = emptyStore();
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(LS_KEY) : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.v === 1 && parsed.items && typeof parsed.items === "object") {
        for (const [key, entry] of Object.entries(parsed.items)) {
          const clean = cleanEntry(entry);
          if (clean) out.items[key] = clean;
        }
      }
    }
  } catch {
    /* corrupt blob → start clean (only overrides are lost, never files) */
  }
  cache = out;
  return out;
}

function persist(store: Store) {
  const keys = Object.keys(store.items);
  if (keys.length > MAX_ENTRIES) {
    keys
      .sort((a, b) => store.items[a].at - store.items[b].at)
      .slice(0, keys.length - MAX_ENTRIES)
      .forEach((key) => {
        if (store.items[key].cover) void deleteOverrideCover(key);
        delete store.items[key];
      });
  }
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(store));
  } catch {
    /* quota: the in-memory copy still holds for this session */
  }
  listeners.forEach((cb) => {
    try {
      cb();
    } catch {
      /* ignore */
    }
  });
}

export function getTagOverride(key: string | number | undefined | null): TagOverride | null {
  if (key === undefined || key === null || key === "") return null;
  return load().items[String(key)] ?? null;
}

export function hasTagOverride(key: string | number | undefined | null): boolean {
  return getTagOverride(key) !== null;
}

/** Merge `fields` into the key's override (later edits win per field). */
export function setTagOverride(key: string | number, fields: LibraryFields, cover?: boolean): TagOverride {
  const store = load();
  const k = String(key);
  const prev = store.items[k];
  const f: LibraryFields = { ...(prev?.f ?? {}) };
  for (const name of LIBRARY_FIELD_KEYS) {
    const v = fields[name];
    if (typeof v === "string") f[name] = v.trim().slice(0, FIELD_MAX);
  }
  const next: TagOverride = { f, cover: cover ?? prev?.cover ?? undefined, at: Date.now() };
  if (!next.cover) delete next.cover;
  store.items[k] = next;
  persist(store);
  return next;
}

export function clearTagOverride(key: string | number): boolean {
  const store = load();
  const k = String(key);
  const prev = store.items[k];
  if (!prev) return false;
  delete store.items[k];
  persist(store);
  if (prev.cover) void deleteOverrideCover(k);
  return true;
}

export function subscribeTagOverrides(cb: () => void): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

/** Lay an override over parsed values. Empty title falls back to the caller's
 *  own default (file name), so a cleared title never shows as a blank row. */
export function applyTagOverride<T extends { title: string; artist: string; album: string; year: string; genre?: string }>(
  base: T,
  ov: TagOverride | null,
): T {
  if (!ov) return base;
  const out = { ...base };
  const f = ov.f;
  if (typeof f.title === "string" && f.title) out.title = f.title;
  if (typeof f.artist === "string") out.artist = f.artist || base.artist;
  if (typeof f.album === "string") out.album = f.album || base.album;
  if (typeof f.year === "string") out.year = f.year;
  if (typeof f.genre === "string") out.genre = normalizeGenre(f.genre) || undefined;
  return out;
}

/** Test hook: forget the in-memory copy (the next read reloads storage). */
export function _resetTagOverrideCache() {
  cache = null;
}

// ── cover bytes (IndexedDB, own tiny database: never bumps nobody-db) ──────

const DB_NAME = "nobody-overrides";
const STORE = "covers";
let dbPromise: Promise<IDBDatabase | null> | null = null;

function openDb(): Promise<IDBDatabase | null> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise<IDBDatabase | null>((resolve) => {
    try {
      if (typeof indexedDB === "undefined") return resolve(null);
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
      };
      req.onsuccess = () => {
        const db = req.result;
        db.onversionchange = () => {
          db.close();
          dbPromise = null;
        };
        resolve(db);
      };
      req.onerror = () => resolve(null);
      req.onblocked = () => resolve(null);
    } catch {
      resolve(null);
    }
  }).then((db) => {
    // a failed open must not poison the session (same rule as cinema db.ts)
    if (!db) dbPromise = null;
    return db;
  });
  return dbPromise;
}

function run<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T> | void): Promise<T | undefined> {
  return openDb().then(
    (db) =>
      new Promise<T | undefined>((resolve) => {
        if (!db) return resolve(undefined);
        try {
          const tx = db.transaction(STORE, mode);
          const req = fn(tx.objectStore(STORE));
          tx.oncomplete = () => resolve(req ? (req.result as T) : undefined);
          tx.onerror = () => resolve(undefined);
          tx.onabort = () => resolve(undefined);
        } catch {
          resolve(undefined);
        }
      }),
  );
}

export async function putOverrideCover(key: string | number, blob: Blob): Promise<boolean> {
  const db = await openDb();
  if (!db) return false;
  await run("readwrite", (s) => s.put(blob, String(key)));
  return true;
}

export async function getOverrideCover(key: string | number): Promise<Blob | null> {
  const res = await run<Blob>("readonly", (s) => s.get(String(key)));
  return res instanceof Blob ? res : null;
}

export async function deleteOverrideCover(key: string | number): Promise<void> {
  await run("readwrite", (s) => s.delete(String(key)));
}
