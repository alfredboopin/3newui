// ── NOBODY · star rating (1.7.0-dev.6, Phase 4 · part 5) ────────────────────
// One widget for Cinema / EELA / ALOK. Ratings live in the library store
// (localStorage, per stable track id) so every face shows the same stars.
//
// Mouse: hover previews, click sets, clicking the current star clears it.
// Keyboard (focus the widget): ←/→ (mirrored in RTL), Home = clear,
// End = 5, digits 0–5. Clicks and keys never reach the row underneath or the
// face's global transport shortcuts.

import { memo, useState } from "react";
import type { KeyboardEvent, MouseEvent, PointerEvent } from "react";
import { useLibrary } from "../../cinema/store/library";
import { useT } from "../../cinema/lib/useT";
import "./rating.css";

interface Props {
  trackId: string;
  /** star size in px */
  size?: number;
  className?: string;
  /** show the stars only while hovered / focused / rated (dense track rows) */
  quiet?: boolean;
  /** track title, appended to the accessible name in lists */
  title?: string;
}

const STARS = [1, 2, 3, 4, 5];

function StarIcon({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden focusable="false">
      <path d="M12 2.6l2.82 5.72 6.31.92-4.57 4.45 1.08 6.29L12 17.01l-5.64 2.97 1.08-6.29L2.87 9.24l6.31-.92z" />
    </svg>
  );
}

export const StarRating = memo(function StarRating({ trackId, size = 14, className, quiet, title }: Props) {
  const t = useT();
  const value = useLibrary((s) => s.ratings[trackId] || 0);
  const setRating = useLibrary((s) => s.setRating);
  const [hover, setHover] = useState(0);
  const shown = hover || value;

  const label = value ? t("rtStars").replace("{{n}}", String(value)) : t("rtNone");
  const name = title ? `${t("rtRating")}: ${title}` : t("rtRating");

  const pick = (n: number) => setRating(trackId, n === value ? 0 : n);

  const onKey = (e: KeyboardEvent<HTMLSpanElement>) => {
    const rtl = getComputedStyle(e.currentTarget).direction === "rtl";
    let next: number | null = null;
    if (e.key === "ArrowRight") next = value + (rtl ? -1 : 1);
    else if (e.key === "ArrowLeft") next = value + (rtl ? 1 : -1);
    else if (e.key === "ArrowUp") next = value + 1;
    else if (e.key === "ArrowDown") next = value - 1;
    else if (e.key === "Home" || e.key === "Delete" || e.key === "Backspace") next = 0;
    else if (e.key === "End") next = 5;
    else if (/^[0-5]$/.test(e.key) && !e.ctrlKey && !e.metaKey && !e.altKey) next = +e.key;
    if (next === null) {
      // Enter / Space would otherwise "click" the row (play) — keep them here
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); }
      return;
    }
    e.preventDefault();
    e.stopPropagation();
    setRating(trackId, Math.max(0, Math.min(5, next)));
  };

  const stop = (e: MouseEvent | PointerEvent) => e.stopPropagation();

  return (
    <span
      className={["nrt", className].filter(Boolean).join(" ")}
      data-quiet={quiet ? true : undefined}
      data-rated={value ? true : undefined}
      role="slider"
      tabIndex={0}
      aria-label={name}
      aria-valuemin={0}
      aria-valuemax={5}
      aria-valuenow={value}
      aria-valuetext={label}
      title={label}
      onKeyDown={onKey}
      onClick={stop}
      onPointerDown={stop}
      onDoubleClick={stop}
      onPointerLeave={() => setHover(0)}
      style={{ ["--nrt-size" as string]: `${size}px` }}
    >
      {STARS.map((n) => (
        <span
          key={n}
          className="nrt-star"
          data-on={n <= shown ? true : undefined}
          data-preview={hover ? true : undefined}
          onPointerEnter={(e) => { if (e.pointerType === "mouse") setHover(n); }}
          onClick={(e) => { e.stopPropagation(); pick(n); setHover(0); }}
        >
          <StarIcon size={size} />
        </span>
      ))}
    </span>
  );
});
