// ── NOBODY · smart playlist editor (1.7.0-dev.6, Phase 4 · part 5) ──────────
// One dialog for Cinema / EELA / ALOK, mounted inside each face root (it
// reuses the tag editor's face-mapped .nte-* shell). Rules are edited on a
// local draft; the live preview runs the real rule engine against the
// library, so what you see is exactly what the playlist will hold.
//
// Keyboard: Esc closes (asks first when there are unsaved edits), Ctrl/⌘+S
// or Ctrl/⌘+Enter saves, Tab stays inside. Keys never reach the face.

import { useEffect, useMemo, useRef, useState } from "react";
import type { DragEvent, KeyboardEvent as ReactKeyboardEvent } from "react";
import { ArrowDownUp, Plus, Shuffle, Sparkles, X } from "lucide-react";
import { useLibrary } from "../../cinema/store/library";
import { uiApi } from "../../cinema/store/ui";
import { useT } from "../../cinema/lib/useT";
import { useSmartInputs } from "../../cinema/lib/usePlaylistTracks";
import { SORT_LABEL_KEY } from "../../cinema/lib/trackSort";
import { splitGenres } from "../replayGain";
import {
  FIELD_KIND,
  SMART_FIELDS,
  SMART_LIMIT_MAX,
  SMART_SORT_KEYS,
  SMART_TEMPLATES,
  defaultRule,
  emptyDef,
  evaluateSmart,
  normalizeSmartDef,
  opsFor,
  retypeRule,
  ruleError,
  templateDef,
  type DateUnit,
  type SmartField,
  type SmartLimit,
  type SmartOp,
  type SmartPlaylistDef,
  type SmartRule,
  type SmartSortKey,
  type SmartTemplateId,
} from "../../cinema/lib/smartPlaylist";
import { useSmartEditor, type SmartEditorFace } from "./store";
import "../tagEditor/tagEditor.css";
import "./smartPlaylist.css";

const MAX_RULES = 50;
const PREVIEW_ROWS = 6;

export function SmartPlaylistDialog({ face }: { face: SmartEditorFace }) {
  const target = useSmartEditor((s) => (s.face === face ? s.target : null));
  if (!target) return null;
  return <SmartBody key={target} target={target} face={face} />;
}

function fmtTotal(sec: number): string {
  sec = Math.max(0, Math.round(sec));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return h ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
}

/** Up to `cap` distinct values (first spelling wins), for the value datalists. */
function distinct(values: Iterable<string>, cap = 400): string[] {
  const seen = new Map<string, string>();
  for (const v of values) {
    const s = v?.trim();
    if (!s) continue;
    const k = s.toLocaleLowerCase();
    if (!seen.has(k)) seen.set(k, s);
    if (seen.size >= cap) break;
  }
  return [...seen.values()].sort((a, b) => a.localeCompare(b));
}

function SmartBody({ target, face }: { target: string; face: SmartEditorFace }) {
  const t = useT();
  const close = useSmartEditor((s) => s.close);
  const onCreated = useSmartEditor((s) => s.onCreated);
  const existing = useLibrary((s) => (target === "new" ? null : s.playlists.find((p) => p.id === target && p.smart) ?? null));
  const createSmartPlaylist = useLibrary((s) => s.createSmartPlaylist);
  const updateSmartPlaylist = useLibrary((s) => s.updateSmartPlaylist);
  const playlists = useLibrary((s) => s.playlists);
  const inputs = useSmartInputs();
  const isNew = target === "new";

  // initial state — frozen at open, so a background library change never resets the form
  const initial = useRef<{ name: string; def: SmartPlaylistDef } | null>(null);
  if (!initial.current) {
    initial.current = existing?.smart
      ? { name: existing.name, def: normalizeSmartDef(existing.smart) ?? emptyDef() }
      : { name: "", def: emptyDef() };
  }
  const [name, setName] = useState(initial.current.name);
  const [nameTouched, setNameTouched] = useState(!isNew);
  const [def, setDef] = useState<SmartPlaylistDef>(initial.current.def);
  const [askDiscard, setAskDiscard] = useState(false);
  const [tried, setTried] = useState(false);
  const dialogRef = useRef<HTMLDivElement>(null);
  const opener = useRef<Element | null>(typeof document !== "undefined" ? document.activeElement : null);

  // the playlist was deleted elsewhere while editing → just close
  useEffect(() => {
    if (!isNew && !existing) close();
  }, [isNew, existing, close]);

  // focus in, focus back to the opener on unmount
  useEffect(() => {
    const el = dialogRef.current?.querySelector<HTMLElement>("#nsp-name");
    el?.focus();
    const back = opener.current;
    return () => { if (back instanceof HTMLElement && back.isConnected) back.focus(); };
  }, []);

  const dirty = name !== initial.current.name || JSON.stringify(def) !== JSON.stringify(initial.current.def);

  // ── value suggestions ──
  const suggestions = useMemo(() => {
    const list = Object.values(inputs.tracks);
    return {
      artist: distinct(list.map((x) => x.artist)),
      album: distinct(list.map((x) => (x.album === "Unknown Album" ? "" : x.album))),
      genre: distinct(list.flatMap((x) => splitGenres(x.genre))),
      format: distinct(list.map((x) => (x.format || "").toUpperCase())),
    } as Partial<Record<SmartField, string[]>>;
  }, [inputs.tracks]);

  // ── live preview (the real engine) ──
  const preview = useMemo(() => {
    const lib = inputs.order.map((id) => inputs.tracks[id]).filter(Boolean);
    const hits = evaluateSmart(def, lib, {
      playCounts: inputs.playCounts,
      ratings: inputs.ratings,
      lastPlayed: inputs.lastPlayed,
      liked: new Set(inputs.likedIds),
    });
    return { count: hits.length, total: hits.reduce((a, x) => a + (x.duration || 0), 0), head: hits.slice(0, PREVIEW_ROWS) };
  }, [def, inputs]);

  const errors = def.rules.map(ruleError);
  const hasErrors = errors.some(Boolean);
  const limitBad = !!def.limit && !(def.limit.n > 0 && def.limit.n <= SMART_LIMIT_MAX);
  const finalName = name.trim();
  const canSave = !hasErrors && !limitBad && !!finalName && (isNew || dirty);

  // ── edits ──
  const patchRule = (id: string, patch: Partial<SmartRule>) =>
    setDef((d) => ({ ...d, rules: d.rules.map((r) => (r.id === id ? { ...r, ...patch } : r)) }));
  const setField = (id: string, field: SmartField) =>
    setDef((d) => ({ ...d, rules: d.rules.map((r) => (r.id === id ? retypeRule(r, field) : r)) }));
  const setOp = (id: string, op: SmartOp) =>
    setDef((d) => ({
      ...d,
      rules: d.rules.map((r) => {
        if (r.id !== id) return r;
        const next: SmartRule = { ...r, op };
        if (op === "between" && next.value2 === undefined) next.value2 = typeof r.value === "number" ? r.value : undefined;
        if ((op === "inLast" || op === "notInLast") && !(Number(r.value) > 0)) { next.value = 30; next.unit = next.unit || "days"; }
        return next;
      }),
    }));
  const addRule = () =>
    setDef((d) => (d.rules.length >= MAX_RULES ? d : { ...d, rules: [...d.rules, defaultRule(d.rules.length ? "genre" : "artist")] }));
  const removeRule = (id: string) => setDef((d) => ({ ...d, rules: d.rules.filter((r) => r.id !== id) }));
  const applyTemplate = (id: SmartTemplateId) => {
    setDef(templateDef(id));
    if (!nameTouched || !name.trim()) setName(uniqueName(t(`spTpl_${id}`)));
    setTried(false);
  };
  const setSort = (key: SmartSortKey) => setDef((d) => ({ ...d, sort: { ...d.sort, key } }));
  const setLimit = (limit: SmartLimit | null) => setDef((d) => ({ ...d, limit }));

  const uniqueName = (base: string) => {
    const taken = new Set(playlists.filter((p) => p.id !== target).map((p) => p.name));
    if (!taken.has(base)) return base;
    for (let i = 2; i < 999; i++) if (!taken.has(`${base} (${i})`)) return `${base} (${i})`;
    return base;
  };

  // ── save / close ──
  const save = () => {
    setTried(true);
    if (!canSave) return;
    if (isNew) {
      const id = createSmartPlaylist(finalName, def);
      uiApi.toast(`${t("spCreated")} · ${finalName}`, "success");
      onCreated?.(id);
    } else if (existing) {
      updateSmartPlaylist(existing.id, { name: finalName, def });
      uiApi.toast(`${t("spSaved")} · ${finalName}`, "success");
    }
    close();
  };
  const requestClose = () => {
    if (dirty && !askDiscard) setAskDiscard(true);
    else close();
  };

  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (e.key === "Escape") {
      e.preventDefault();
      if (askDiscard) setAskDiscard(false);
      else requestClose();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && (e.key === "s" || e.key === "S" || e.key === "Enter")) {
      e.preventDefault();
      save();
      return;
    }
    if (e.key === "Tab" && dialogRef.current) {
      const nodes = Array.from(
        dialogRef.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      ).filter((n) => n.offsetParent !== null || n === document.activeElement);
      if (!nodes.length) return;
      const first = nodes[0];
      const last = nodes[nodes.length - 1];
      const active = document.activeElement;
      if (e.shiftKey && (active === first || active === dialogRef.current)) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      }
    }
  };
  const swallow = (e: DragEvent) => { e.preventDefault(); e.stopPropagation(); };

  const sortLabel = (k: SmartSortKey) => (k === "random" ? t("spSortRandom") : t(SORT_LABEL_KEY[k]));
  const nameErr = tried && !finalName;

  return (
    <div className="nte-layer nsp-layer" data-face={face} onKeyDown={onKeyDown} onDragEnter={swallow} onDragOver={swallow} onDrop={swallow}>
      <div className="nte-backdrop" onClick={requestClose} aria-hidden />
      <div ref={dialogRef} className="nte-dialog nsp-dialog" role="dialog" aria-modal="true" aria-labelledby="nsp-title" tabIndex={-1}>
        <div className="nte-head">
          <span className="nte-badge" aria-hidden>
            <Sparkles size={15} />
          </span>
          <div className="nte-head-text">
            <div id="nsp-title" className="nte-title">{t(isNew ? "spTitleNew" : "spTitleEdit")}</div>
            <div className="nte-sub">{t("spAutoNote")}</div>
          </div>
          <button type="button" className="nte-icon" onClick={requestClose} aria-label={t("close")} title={t("close")}>
            <X size={16} />
          </button>
        </div>

        <div className="nte-body nsp-body">
          {/* name */}
          <div className="nte-field nsp-name" data-invalid={nameErr || undefined}>
            <label className="nte-label" htmlFor="nsp-name">{t("spName")}</label>
            <input
              id="nsp-name"
              className="nte-input"
              value={name}
              maxLength={120}
              dir="auto"
              placeholder={t("spDefaultName")}
              onChange={(e) => { setName(e.target.value); setNameTouched(true); }}
              aria-invalid={nameErr || undefined}
            />
            {nameErr && <span className="nte-err">{t("spErrName")}</span>}
          </div>

          {/* templates (new only) */}
          {isNew && (
            <div className="nsp-tpls" role="group" aria-label={t("spTemplates")}>
              <span className="nsp-tpls-label">{t("spTemplates")}</span>
              {SMART_TEMPLATES.map((id) => (
                <button key={id} type="button" className="nsp-chip" onClick={() => applyTemplate(id)}>
                  {t(`spTpl_${id}`)}
                </button>
              ))}
            </div>
          )}

          {/* match */}
          <div className="nsp-match">
            <span>{t("spMatchPre")}</span>
            <select
              className="nte-input nsp-select nsp-select-sm"
              value={def.match}
              onChange={(e) => setDef((d) => ({ ...d, match: e.target.value === "any" ? "any" : "all" }))}
              aria-label={t("spMatchPre")}
              disabled={def.rules.length < 2}
            >
              <option value="all">{t("spMatchAll")}</option>
              <option value="any">{t("spMatchAny")}</option>
            </select>
            <span>{t("spMatchPost")}</span>
          </div>

          {/* rules */}
          <div className="nsp-rules" role="list">
            {def.rules.length === 0 && <div className="nsp-empty">{t("spNoRules")}</div>}
            {def.rules.map((r, i) => (
              <RuleRow
                key={r.id}
                rule={r}
                index={i}
                error={tried || r.value !== "" ? errors[i] : null}
                suggestions={suggestions[r.field]}
                onField={(f) => setField(r.id, f)}
                onOp={(op) => setOp(r.id, op)}
                onPatch={(p) => patchRule(r.id, p)}
                onRemove={() => removeRule(r.id)}
              />
            ))}
          </div>
          <button type="button" className="nte-btn nte-btn-sm nsp-add" onClick={addRule} disabled={def.rules.length >= MAX_RULES}>
            <Plus size={13} /> {t("spAddRule")}
          </button>

          {/* order + limit */}
          <div className="nsp-order">
            <label className="nsp-inline">
              <span>{t("spSortBy")}</span>
              <select className="nte-input nsp-select" value={def.sort.key} onChange={(e) => setSort(e.target.value as SmartSortKey)}>
                {SMART_SORT_KEYS.map((k) => (
                  <option key={k} value={k}>{sortLabel(k)}</option>
                ))}
              </select>
            </label>
            {def.sort.key === "random" ? (
              <button
                type="button"
                className="nte-btn nte-btn-sm"
                onClick={() => setDef((d) => ({ ...d, seed: (Math.random() * 0x7fffffff) | 0 }))}
                title={t("spReshuffle")}
              >
                <Shuffle size={13} /> {t("spReshuffle")}
              </button>
            ) : (
              <button
                type="button"
                className="nte-btn nte-btn-sm"
                aria-pressed={def.sort.reverse}
                data-on={def.sort.reverse || undefined}
                onClick={() => setDef((d) => ({ ...d, sort: { ...d.sort, reverse: !d.sort.reverse } }))}
              >
                <ArrowDownUp size={13} /> {t("sortReverse")}
              </button>
            )}
          </div>
          <div className="nsp-order">
            <label className="nsp-inline nsp-check">
              <input
                type="checkbox"
                checked={!!def.limit}
                onChange={(e) => setLimit(e.target.checked ? { n: 25, unit: "songs" } : null)}
              />
              <span>{t("spLimit")}</span>
            </label>
            {def.limit && (
              <>
                <input
                  className="nte-input nsp-num"
                  type="number"
                  min={1}
                  max={SMART_LIMIT_MAX}
                  value={Number.isFinite(def.limit.n) && def.limit.n > 0 ? def.limit.n : ""}
                  onChange={(e) => setLimit({ ...def.limit!, n: Math.floor(Number(e.target.value)) })}
                  aria-label={t("spLimit")}
                  aria-invalid={limitBad || undefined}
                />
                <select
                  className="nte-input nsp-select nsp-select-sm"
                  value={def.limit.unit}
                  onChange={(e) => setLimit({ ...def.limit!, unit: e.target.value as SmartLimit["unit"] })}
                  aria-label={t("spLimit")}
                >
                  <option value="songs">{t("spL_songs")}</option>
                  <option value="minutes">{t("spL_minutes")}</option>
                  <option value="hours">{t("spL_hours")}</option>
                </select>
                {def.limit.unit === "songs" ? null : <span className="nsp-hint">{t("spLimitTimeHint")}</span>}
              </>
            )}
          </div>

          {/* preview */}
          <div className="nsp-preview" aria-live="polite">
            <div className="nsp-preview-head">
              <span className="nte-label">{t("spPreview")}</span>
              <span className="nsp-preview-count tnum">
                {t("spMatches").replace("{{n}}", preview.count.toLocaleString())}
                {preview.count > 0 && <> · {fmtTotal(preview.total)}</>}
              </span>
            </div>
            {preview.count === 0 ? (
              <div className="nsp-empty">{t("spPreviewNone")}</div>
            ) : (
              <ol className="nsp-preview-list">
                {preview.head.map((tr) => (
                  <li key={tr.id} dir="auto">
                    <b>{tr.title}</b> <span>— {tr.artist}</span>
                  </li>
                ))}
                {preview.count > PREVIEW_ROWS && (
                  <li className="nsp-more">{t("spPreviewMore").replace("{{n}}", (preview.count - PREVIEW_ROWS).toLocaleString())}</li>
                )}
              </ol>
            )}
          </div>
        </div>

        <div className="nte-foot">
          {askDiscard ? (
            <>
              <span className="nte-foot-msg">{t("teDiscardQ")}</span>
              <button type="button" className="nte-btn" onClick={() => setAskDiscard(false)} autoFocus>
                {t("teKeepEditing")}
              </button>
              <button type="button" className="nte-btn nte-btn-danger" onClick={close}>
                {t("teDiscard")}
              </button>
            </>
          ) : (
            <>
              <span className="nte-foot-msg" role={tried && hasErrors ? "alert" : undefined} data-err={tried && (hasErrors || limitBad) ? true : undefined}>
                {tried && (hasErrors || limitBad) ? t("spFixRules") : ""}
              </span>
              <button type="button" className="nte-btn" onClick={requestClose}>
                {t("teCancel")}
              </button>
              <button
                type="button"
                className="nte-btn nte-btn-primary"
                onClick={save}
                disabled={tried ? !canSave : !isNew && !dirty}
                title="Ctrl+S"
              >
                {t(isNew ? "spCreate" : "spSave")}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ── one rule row ─────────────────────────────────────────────────────────────

const OP_LABEL = (field: SmartField, op: SmartOp) => {
  // the rating / plays / year family reads better with the shared number labels
  if (field === "liked") return op === "isTrue" ? "spO_likedYes" : "spO_likedNo";
  return `spO_${op}`;
};

function RuleRow({
  rule, index, error, suggestions, onField, onOp, onPatch, onRemove,
}: {
  rule: SmartRule;
  index: number;
  error: null | "value" | "range";
  suggestions?: string[];
  onField: (f: SmartField) => void;
  onOp: (op: SmartOp) => void;
  onPatch: (p: Partial<SmartRule>) => void;
  onRemove: () => void;
}) {
  const t = useT();
  const kind = FIELD_KIND[rule.field];
  const listId = suggestions?.length ? `nsp-dl-${rule.id}` : undefined;
  const needsValue = !(rule.op === "isEmpty" || rule.op === "isNotEmpty" || rule.op === "never" || kind === "bool");
  const unitSuffix = rule.field === "duration" ? t("spMin") : rule.field === "bitrate" ? "kbps" : "";
  const numVal = (v: string) => (v.trim() === "" ? "" : Number(v));
  const label = `${t("spRule")} ${index + 1}`;

  const numberInput = (key: "value" | "value2", aria: string) =>
    rule.field === "rating" ? (
      <select
        className="nte-input nsp-select nsp-select-sm"
        value={String(rule[key] ?? 0)}
        onChange={(e) => onPatch({ [key]: Number(e.target.value) } as Partial<SmartRule>)}
        aria-label={aria}
      >
        <option value="0">{t("spUnrated")}</option>
        {[1, 2, 3, 4, 5].map((n) => (
          <option key={n} value={n}>{"★".repeat(n)}</option>
        ))}
      </select>
    ) : (
      <input
        className="nte-input nsp-num"
        type="number"
        inputMode="decimal"
        min={0}
        step={rule.field === "duration" ? 0.5 : 1}
        value={rule[key] === undefined || rule[key] === "" ? "" : String(rule[key])}
        onChange={(e) => onPatch({ [key]: numVal(e.target.value) } as Partial<SmartRule>)}
        aria-label={aria}
        aria-invalid={error ? true : undefined}
      />
    );

  return (
    <div className="nsp-rule" role="listitem" aria-label={label} data-invalid={error ? true : undefined}>
      <select className="nte-input nsp-select" value={rule.field} onChange={(e) => onField(e.target.value as SmartField)} aria-label={`${label}: ${t("spField")}`}>
        {SMART_FIELDS.map((f) => (
          <option key={f} value={f}>{t(`spF_${f}`)}</option>
        ))}
      </select>
      <select className="nte-input nsp-select" value={rule.op} onChange={(e) => onOp(e.target.value as SmartOp)} aria-label={`${label}: ${t("spOperator")}`}>
        {opsFor(rule.field).map((op) => (
          <option key={op} value={op}>{t(OP_LABEL(rule.field, op))}</option>
        ))}
      </select>

      <div className="nsp-val">
        {needsValue && kind === "text" && (
          <>
            <input
              className="nte-input"
              value={String(rule.value ?? "")}
              dir="auto"
              list={listId}
              maxLength={500}
              onChange={(e) => onPatch({ value: e.target.value })}
              aria-label={`${label}: ${t("spValue")}`}
              aria-invalid={error ? true : undefined}
            />
            {listId && (
              <datalist id={listId}>
                {suggestions!.map((s) => <option key={s} value={s} />)}
              </datalist>
            )}
          </>
        )}
        {needsValue && kind === "number" && (
          <>
            {numberInput("value", `${label}: ${t("spValue")}`)}
            {rule.op === "between" && (
              <>
                <span className="nsp-and">{t("spAnd")}</span>
                {numberInput("value2", `${label}: ${t("spValue")} 2`)}
              </>
            )}
            {unitSuffix && <span className="nsp-unit">{unitSuffix}</span>}
          </>
        )}
        {needsValue && kind === "date" && (
          <>
            <input
              className="nte-input nsp-num"
              type="number"
              min={1}
              step={1}
              value={rule.value === undefined || rule.value === "" ? "" : String(rule.value)}
              onChange={(e) => onPatch({ value: numVal(e.target.value) })}
              aria-label={`${label}: ${t("spValue")}`}
              aria-invalid={error ? true : undefined}
            />
            <select
              className="nte-input nsp-select nsp-select-sm"
              value={rule.unit || "days"}
              onChange={(e) => onPatch({ unit: e.target.value as DateUnit })}
              aria-label={`${label}: ${t("spUnit")}`}
            >
              <option value="days">{t("spU_days")}</option>
              <option value="weeks">{t("spU_weeks")}</option>
              <option value="months">{t("spU_months")}</option>
            </select>
          </>
        )}
      </div>

      <button type="button" className="nte-icon nsp-x" onClick={onRemove} aria-label={`${t("spRemoveRule")}: ${index + 1}`} title={t("spRemoveRule")}>
        <X size={14} />
      </button>
      {error && <span className="nte-err nsp-rule-err">{t(error === "range" ? "spErrRange" : "spErrValue")}</span>}
    </div>
  );
}
