// ── NOBODY · smart playlist editor open state (Cinema / EELA / ALOK) ────────
// Same pattern as the tag editor: one dialog per face, mounted inside that
// face's root; `face` pins which one shows.

import { create } from "zustand";
import { getUiMode } from "../../uiMode";
import type { TagEditorFace } from "../tagEditor/store";

export type SmartEditorFace = TagEditorFace;

interface SmartEditorState {
  /** playlist id being edited, or "new" */
  target: string | null;
  face: SmartEditorFace | null;
  /** called with the new playlist id after "Create" (the view selects it) */
  onCreated: ((id: string) => void) | null;
  open: (target: string, face?: SmartEditorFace, onCreated?: (id: string) => void) => void;
  close: () => void;
}

export const useSmartEditor = create<SmartEditorState>((set) => ({
  target: null,
  face: null,
  onCreated: null,
  open: (target, face, onCreated) => {
    const mode = face ?? getUiMode();
    if (mode === "classic") return;
    set({ target, face: mode, onCreated: onCreated ?? null });
  },
  close: () => set({ target: null, face: null, onCreated: null }),
}));

export const openSmartEditor = (target: string, face?: SmartEditorFace, onCreated?: (id: string) => void) =>
  useSmartEditor.getState().open(target, face, onCreated);
