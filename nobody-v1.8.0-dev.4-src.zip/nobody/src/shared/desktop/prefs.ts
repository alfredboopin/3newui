// ── NOBODY · desktop preferences (1.8.0) ────────────────────────────────────
// Kept by the main process (userData/desktop.json) because "close to tray"
// must work before / without the UI. This store mirrors it for the four
// Settings screens.

import { create } from "zustand";
import { deskApi, type DeskPrefs } from "./api";

interface DesktopPrefsState extends DeskPrefs {
  loaded: boolean;
  busy: "closeToTray" | "openWith" | null;
  error: "openWith" | null;
  load: () => Promise<void>;
  set: (key: "closeToTray" | "openWith", value: boolean) => Promise<boolean>;
}

export const useDesktopPrefs = create<DesktopPrefsState>((set, get) => ({
  loaded: false,
  closeToTray: false,
  openWith: false,
  platform: "",
  trayAvailable: false,
  openWithSupported: false,
  busy: null,
  error: null,
  load: async () => {
    const api = deskApi();
    if (!api?.deskGetPrefs) return;
    try {
      const p = await api.deskGetPrefs();
      set({ ...p, loaded: true });
    } catch { /* main too old */ }
  },
  set: async (key, value) => {
    const api = deskApi();
    if (!api?.deskSetPref || get().busy) return false;
    set({ busy: key, error: null, [key]: value } as Partial<DesktopPrefsState>);
    try {
      const r = await api.deskSetPref(key, value);
      const now = typeof r?.value === "boolean" ? r.value : r?.ok ? value : !value;
      set({ busy: null, [key]: now, error: r?.ok ? null : key === "openWith" ? "openWith" : null } as Partial<DesktopPrefsState>);
      return !!r?.ok;
    } catch {
      set({ busy: null, [key]: !value, error: key === "openWith" ? "openWith" : null } as Partial<DesktopPrefsState>);
      return false;
    }
  },
}));

/** true when the desktop shell exposes the 1.8.0 surface */
export const hasDesktopIntegration = () => !!deskApi()?.deskGetPrefs;
