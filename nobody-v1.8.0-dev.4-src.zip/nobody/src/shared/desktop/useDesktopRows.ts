// ── NOBODY · Settings rows for the desktop options (1.8.0) ──────────────────
// One model, four looks (Cinema / EELA / ALOK use the cinema dict, Classic
// passes its own strings). Rows exist only inside the desktop shell.

import { useEffect } from "react";
import { useDesktopPrefs, hasDesktopIntegration } from "./prefs";
import { useHotkeys, hasHotkeys } from "./hotkeys";

export interface DesktopRow {
  id: "tray" | "openwith" | "hotkeys";
  on: boolean;
  disabled: boolean;
  busy: boolean;
  /** subtitle key override: not available here / last write failed */
  note: "na" | "fail" | null;
  toggle: () => void;
}

export function useDesktopRows(): DesktopRow[] {
  const p = useDesktopPrefs();
  const hk = useHotkeys();
  useEffect(() => { if (!p.loaded) void p.load(); }, [p.loaded]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (!hk.loaded && hasHotkeys()) void hk.load(); }, [hk.loaded]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!hasDesktopIntegration() || !p.loaded) return [];
  const rows: DesktopRow[] = [
    {
      id: "tray",
      on: p.closeToTray && p.trayAvailable,
      disabled: !p.trayAvailable,
      busy: p.busy === "closeToTray",
      note: p.trayAvailable ? null : "na",
      toggle: () => { if (p.trayAvailable) void p.set("closeToTray", !p.closeToTray); },
    },
    {
      id: "openwith",
      on: p.openWith && p.openWithSupported,
      disabled: !p.openWithSupported,
      busy: p.busy === "openWith",
      note: !p.openWithSupported ? "na" : p.error === "openWith" ? "fail" : null,
      toggle: () => { if (p.openWithSupported) void p.set("openWith", !p.openWith); },
    },
  ];
  // 1.8.0-dev.2: global hotkeys (the list itself is <HotkeyList/>, shown under this row when on)
  if (hk.loaded) rows.push({
    id: "hotkeys",
    on: hk.enabled && hk.supported,
    disabled: !hk.supported,
    busy: hk.busy,
    note: hk.supported ? null : "na",
    toggle: () => { if (hk.supported && !hk.busy) void hk.setEnabled(!hk.enabled); },
  });
  return rows;
}

/** cinema-dict keys for a row */
export const rowKeys = (r: DesktopRow) => r.id === "tray"
  ? { label: "dkTray", sub: r.note === "na" ? "dkTrayNA" : "dkTraySub" }
  : r.id === "hotkeys"
    ? { label: "hkTitle", sub: r.note === "na" ? "hkNA" : "hkSub" }
    : { label: "dkOpenWith", sub: r.note === "na" ? "dkOpenWithNA" : r.note === "fail" ? "dkOpenWithFail" : "dkOpenWithSub" };
