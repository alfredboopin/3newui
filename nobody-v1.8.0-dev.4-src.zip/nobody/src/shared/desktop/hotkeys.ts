// ── NOBODY · global hotkeys, renderer side (1.8.0-dev.2, Phase 5 · part 2) ──
// The main process owns registration (globalShortcut) and the stored map
// (desktop.json). This store mirrors it for the four Settings screens and
// records new combos.
//
// Recording uses KeyboardEvent.code (the PHYSICAL key), never .key: with a
// Persian / Russian / Turkish layout active, .key is "ش" or "ф", while the
// OS-level shortcut is bound to the key position. Same rules as main's
// normalizeAccelerator (main stays the authority).

import { create } from "zustand";
import { deskApi, type DeskHotkeys, type HotkeyAction, type HotkeyStatus } from "./api";

export const HOTKEY_ACTIONS: HotkeyAction[] = ["play-pause", "next", "prev", "stop", "vol-up", "vol-down", "show-hide"];
/** cinema-dict label key per action */
export const HOTKEY_LABEL: Record<HotkeyAction, string> = {
  "play-pause": "hkPlayPause", next: "hkNext", prev: "hkPrev", stop: "hkStop",
  "vol-up": "hkVolUp", "vol-down": "hkVolDown", "show-hide": "hkShowHide",
};

const CODE_KEY: Record<string, string> = {
  Space: "Space", ArrowUp: "Up", ArrowDown: "Down", ArrowLeft: "Left", ArrowRight: "Right",
  Home: "Home", End: "End", PageUp: "PageUp", PageDown: "PageDown", Insert: "Insert", Delete: "Delete",
  Enter: "Enter", Tab: "Tab", Minus: "-", Equal: "=", Comma: ",", Period: ".", Slash: "/", Semicolon: ";",
  Quote: "'", BracketLeft: "[", BracketRight: "]", Backslash: "\\", Backquote: "`",
  NumpadAdd: "numadd", NumpadSubtract: "numsub", NumpadMultiply: "nummult", NumpadDivide: "numdiv", NumpadDecimal: "numdec",
};
const MOD_CODES = new Set(["ControlLeft", "ControlRight", "AltLeft", "AltRight", "ShiftLeft", "ShiftRight", "MetaLeft", "MetaRight", "OSLeft", "OSRight"]);
const RESERVED = new Set(["Ctrl+Alt+Delete", "Alt+Tab", "Alt+F4", "Ctrl+Shift+Escape", "Super+L", "Super+D", "Super+Tab", "Alt+Space", "Ctrl+Escape", "Alt+Escape", "Super+Space"]);

export function keyFromCode(code: string): string | null {
  let m = /^Key([A-Z])$/.exec(code); if (m) return m[1];
  m = /^Digit([0-9])$/.exec(code); if (m) return m[1];
  m = /^Numpad([0-9])$/.exec(code); if (m) return "num" + m[1];
  m = /^F([1-9]|1[0-9]|2[0-4])$/.exec(code); if (m) return "F" + m[1];
  return CODE_KEY[code] ?? null;
}

export type Recorded =
  | { kind: "cancel" } | { kind: "clear" } | { kind: "wait" }
  | { kind: "invalid"; why: "mods" | "reserved" | "key" }
  | { kind: "ok"; accel: string };

/** one keydown while recording → what it means */
export function readCombo(e: { code: string; ctrlKey: boolean; altKey: boolean; shiftKey: boolean; metaKey: boolean }): Recorded {
  const anyMod = e.ctrlKey || e.altKey || e.shiftKey || e.metaKey;
  if (e.code === "Escape" && !anyMod) return { kind: "cancel" };
  if ((e.code === "Backspace" || e.code === "Delete") && !anyMod) return { kind: "clear" };
  if (MOD_CODES.has(e.code)) return { kind: "wait" };
  const key = keyFromCode(e.code);
  if (!key) return { kind: "invalid", why: "key" };
  const mods = [e.ctrlKey && "Ctrl", e.altKey && "Alt", e.shiftKey && "Shift", e.metaKey && "Super"].filter(Boolean) as string[];
  const fHigh = /^F(1[3-9]|2[0-4])$/.test(key);
  if (!fHigh && !e.ctrlKey && !e.altKey && !e.metaKey) return { kind: "invalid", why: "mods" };
  const accel = [...mods, key].join("+");
  if (RESERVED.has(accel)) return { kind: "invalid", why: "reserved" };
  return { kind: "ok", accel };
}

const SHOW: Record<string, string> = { Super: "Win", Up: "↑", Down: "↓", Left: "←", Right: "→", Space: "Space", Plus: "+", numadd: "Num +", numsub: "Num −", nummult: "Num ×", numdiv: "Num ÷", numdec: "Num ." };
/** "Ctrl+Alt+Right" → ["Ctrl", "Alt", "→"] (shown as key caps, always LTR) */
export function accelParts(accel: string): string[] {
  if (!accel) return [];
  return accel.split("+").map((p) => SHOW[p] ?? (/^num[0-9]$/.test(p) ? "Num " + p.slice(3) : p));
}

export type HotkeyNote =
  | { action: HotkeyAction; kind: "invalid"; why: "mods" | "reserved" | "key" }
  | { action: HotkeyAction; kind: "moved"; from: HotkeyAction }
  | { action: HotkeyAction | null; kind: "fail" };

interface HotkeysState {
  loaded: boolean;
  supported: boolean;
  enabled: boolean;
  map: Record<HotkeyAction, string>;
  defaults: Record<HotkeyAction, string>;
  status: Partial<Record<HotkeyAction, HotkeyStatus>>;
  busy: boolean;
  recording: HotkeyAction | null;
  note: HotkeyNote | null;
  load: () => Promise<void>;
  setEnabled: (on: boolean) => Promise<boolean>;
  assign: (action: HotkeyAction, accel: string) => Promise<boolean>;
  clear: (action: HotkeyAction) => Promise<boolean>;
  reset: () => Promise<boolean>;
  startRecording: (action: HotkeyAction) => void;
  stopRecording: () => void;
  setNote: (n: HotkeyNote | null) => void;
}

const EMPTY = Object.fromEntries(HOTKEY_ACTIONS.map((a) => [a, ""])) as Record<HotkeyAction, string>;
const take = (h: DeskHotkeys) => ({ supported: h.supported !== false, enabled: !!h.enabled, map: { ...EMPTY, ...h.map }, defaults: { ...EMPTY, ...h.defaults }, status: { ...h.status } });

export const useHotkeys = create<HotkeysState>((set, get) => {
  async function send(patch: { enabled?: boolean; map?: Partial<Record<HotkeyAction, string>> }, action: HotkeyAction | null): Promise<boolean> {
    const api = deskApi();
    if (!api?.deskSetHotkeys || get().busy) return false;
    set({ busy: true });
    try {
      const r = await api.deskSetHotkeys(patch);
      set({ busy: false, ...take(r) });
      if (!r.ok) {
        // main refuses a combo the renderer let through (shouldn't happen): say so
        if (r.code === "E_INVALID" && r.action) set({ note: { action: r.action, kind: "invalid", why: "key" } });
        else set({ note: { action, kind: "fail" } });
      }
      return !!r.ok;
    } catch {
      set({ busy: false, note: { action, kind: "fail" } });
      return false;
    }
  }
  return {
    loaded: false, supported: false, enabled: false, map: { ...EMPTY }, defaults: { ...EMPTY }, status: {},
    busy: false, recording: null, note: null,
    load: async () => {
      const api = deskApi();
      if (!api?.deskGetHotkeys) return;
      try { const h = await api.deskGetHotkeys(); set({ loaded: true, ...take(h) }); } catch { /* older main */ }
    },
    setEnabled: (on) => { set({ note: null, enabled: on }); return send({ enabled: on }, null); },
    assign: async (action, accel) => {
      const { map } = get();
      const patch: Partial<Record<HotkeyAction, string>> = { [action]: accel };
      // already used by another action: move it here (the other one is cleared)
      const from = HOTKEY_ACTIONS.find((a) => a !== action && map[a] === accel) || null;
      if (from) patch[from] = "";
      set({ note: null });
      const ok = await send({ map: patch }, action);
      if (ok && from) set({ note: { action, kind: "moved", from } });
      return ok;
    },
    clear: (action) => { set({ note: null }); return send({ map: { [action]: "" } }, action); },
    reset: () => { set({ note: null }); return send({ map: { ...get().defaults } }, null); },
    startRecording: (action) => {
      if (get().recording === action) return;
      set({ recording: action, note: null });
      void deskApi()?.deskHotkeysSuspend?.(true).catch(() => undefined);
    },
    stopRecording: () => {
      if (!get().recording) return;
      set({ recording: null });
      void deskApi()?.deskHotkeysSuspend?.(false).then((h) => { if (h) set({ status: { ...h.status } }); }).catch(() => undefined);
    },
    setNote: (n) => set({ note: n }),
  };
});

export const hasHotkeys = () => !!deskApi()?.deskGetHotkeys;
