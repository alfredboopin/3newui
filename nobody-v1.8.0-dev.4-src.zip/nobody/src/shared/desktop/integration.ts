// ── NOBODY · desktop integration, renderer side (1.8.0, Phase 5 · part 1) ───
// Installed once from main.tsx (UI-agnostic, like the media-key bridge):
//   • tray / thumbnail-toolbar / jump-list text in the UI language
//   • now playing → tray tooltip + menu, ⏯ icon, taskbar window title
//     (Classic reports its own song; the engine faces read the ui mirror)
//   • "Open with" / double-clicked / dropped-on-exe files: imported by path
//     (they stay in the library across restarts) and played; .m3u/.m3u8
//     become a playlist. Files that arrive before the library is ready wait
//     in the main process (desk:ready hands them over).
// Player commands from the tray / thumbar / jump list come back as the
// existing media:key IPC, so Classic and the engine need nothing new.

import { useSettings } from "../../cinema/store/settings";
import { useLibrary } from "../../cinema/store/library";
import { useUi, uiApi } from "../../cinema/store/ui";
import { tStatic } from "../../cinema/lib/useT";
import { engine } from "../../cinema/lib/engine";
import { getBridge } from "../../cinema/lib/desktopBridge";
import { getUiMode, UI_SWITCH_EVENT } from "../../uiMode";
import { importPlaylistBytes } from "../m3u/playlistIO";
import { deskApi, type DeskNowPlaying, type DeskOpenPayload } from "./api";
import { useDesktopPrefs } from "./prefs";

const LABEL_KEYS = { play: "dkPlay", pause: "dkPause", next: "dkNext", prev: "dkPrev", show: "dkShow", hide: "dkHide", quit: "dkQuit", nothing: "dkNothing", trayNote: "dkTrayNote" } as const;

let installed = false;
let classicNp: DeskNowPlaying = { title: "", artist: "", playing: false };
let lastSent = "";

export function labelsFor(lang: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, key] of Object.entries(LABEL_KEYS)) out[k] = tStatic(lang as never, key);
  return out;
}

function engineNp(): DeskNowPlaying {
  const ui = useUi.getState();
  const tr = ui.currentId ? useLibrary.getState().tracks[ui.currentId] : undefined;
  return { title: tr?.title || "", artist: tr?.artist || "", playing: !!tr && !!ui.isPlaying };
}
function publish() {
  const api = deskApi();
  if (!api?.deskNowPlaying) return;
  const np = getUiMode() === "classic" ? classicNp : engineNp();
  const key = `${np.title}\u0001${np.artist}\u0001${np.playing}`;
  if (key === lastSent) return;
  lastSent = key;
  try { api.deskNowPlaying(np); } catch { /* ignore */ }
}

/** Classic calls this on every song / play-state change */
export function setClassicNowPlaying(np: DeskNowPlaying) {
  classicNp = { title: np.title || "", artist: np.artist || "", playing: !!np.playing };
  if (getUiMode() === "classic") publish();
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
/** the bridge exists and the library mirror has hydrated (≤ 20 s).
 *  1.8.0-dev.2: Classic never hydrates the mirror (only the engine faces
 *  mount it), so an "Open with" in Classic used to wait the full 20 s.
 *  Once the bridge is up we hydrate it ourselves (once, shared). */
let hydrating: Promise<void> | null = null;
async function libraryReady(): Promise<boolean> {
  const end = Date.now() + 20000;
  while (Date.now() < end) {
    if (getBridge()) {
      if (useLibrary.getState().hydrated) return true;
      if (!hydrating) hydrating = useLibrary.getState().hydrate().catch(() => undefined);
      await Promise.race([hydrating, sleep(2000)]);
      if (useLibrary.getState().hydrated) return true;
    }
    await sleep(100);
  }
  return !!getBridge();
}

const baseName = (p: string) => p.split(/[\\/]/).pop() || p;
const keyOf = (p: string) => p.replace(/\\/g, "/").toLowerCase();

function play(ids: string[]) {
  if (!ids.length) return;
  if (getUiMode() === "classic") {
    const b = getBridge() as unknown as { playIds?: (ids: string[]) => boolean } | null;
    if (b?.playIds?.(ids)) return;
  }
  engine.setQueue(ids, ids[0]);
}

/** import + play what the OS handed us. Exported for the UI harness. */
export async function handleOpened(p: DeskOpenPayload): Promise<{ ids: string[]; playlists: string[] }> {
  const files = (p?.files || []).filter((x) => typeof x === "string" && x);
  const lists = (p?.playlists || []).filter((x) => typeof x === "string" && x);
  const out = { ids: [] as string[], playlists: [] as string[] };
  if (!files.length && !lists.length) return out;
  await libraryReady();
  const t = (k: string) => tStatic(useSettings.getState().lang as never, k);
  const bridge = getBridge();

  if (files.length && bridge?.importFilePaths) {
    try {
      const res = await bridge.importFilePaths(files, { remember: true });
      await useLibrary.getState().rehydrateTracks();
      const tracks = useLibrary.getState().tracks;
      const byKey = new Map(Object.entries(res.ids || {}).map(([path, id]) => [keyOf(path), id]));
      const seen = new Set<string>();
      for (const f of files) {
        const id = byKey.get(keyOf(f));
        if (id && tracks[id] && !seen.has(id)) { seen.add(id); out.ids.push(id); }
      }
    } catch { /* reported below */ }
  }

  const api = deskApi();
  let listIds: string[] = [];
  for (const path of lists) {
    try {
      const r = await api?.deskReadPlaylist?.(path);
      if (!r?.bytes) continue;
      const sum = await importPlaylistBytes(r.bytes, r.path || path, baseName(path));
      if (!sum.playlistId) continue;
      out.playlists.push(sum.playlistId);
      uiApi.toast(t("dkOpenedList").replace("{{name}}", sum.name).replace("{{n}}", String(sum.songs)), "success");
      if (!listIds.length) listIds = useLibrary.getState().playlists.find((x) => x.id === sum.playlistId)?.trackIds.filter((id) => !!useLibrary.getState().tracks[id]) || [];
    } catch { /* next */ }
  }

  if (out.ids.length) {
    play(out.ids);
    const first = useLibrary.getState().tracks[out.ids[0]];
    uiApi.toast(out.ids.length === 1 ? t("dkOpenedOne").replace("{{title}}", first?.title || baseName(files[0])) : t("dkOpenedMany").replace("{{n}}", String(out.ids.length)), "success");
  } else if (listIds.length) {
    play(listIds);
  } else if (files.length || !out.playlists.length) {
    uiApi.toast(t("dkOpenedNone"), "error");
  }
  return out;
}

export function installDesktopIntegration(): void {
  const api = deskApi();
  if (!api || installed) return;
  installed = true;

  // labels in the UI language
  let lang = useSettings.getState().lang;
  try { api.deskSetLabels?.(labelsFor(lang)); } catch { /* ignore */ }
  useSettings.subscribe((s) => {
    if (s.lang === lang) return;
    lang = s.lang;
    try { api.deskSetLabels?.(labelsFor(lang)); } catch { /* ignore */ }
  });

  // now playing
  useUi.subscribe(() => { if (getUiMode() !== "classic") publish(); });
  useLibrary.subscribe(() => { if (getUiMode() !== "classic") publish(); });
  window.addEventListener(UI_SWITCH_EVENT, () => setTimeout(publish, 0));
  publish();

  void useDesktopPrefs.getState().load();

  // files opened with NOBODY
  let chain: Promise<unknown> = Promise.resolve();
  const enqueue = (p: DeskOpenPayload) => { chain = chain.then(() => handleOpened(p)).catch(() => undefined); };
  api.onDeskOpen?.((p) => enqueue(p));
  void (async () => {
    await libraryReady();
    try {
      const first = await api.deskReady?.();
      if (first && (first.files?.length || first.playlists?.length)) enqueue(first);
    } catch { /* older main */ }
  })();
}
