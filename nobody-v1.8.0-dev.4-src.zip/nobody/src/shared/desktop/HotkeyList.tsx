// ── NOBODY · global hotkey list (1.8.0-dev.2, Phase 5 · part 2) ────────────
// Shown under the "Global shortcuts" Settings row in all four faces when the
// feature is on. One component, face-tinted through CSS (data-face).
//
// Recording: click a combo → "Press keys…". While recording, a window-level
// CAPTURE listener eats every key (the face's own shortcuts never see them)
// and main suspends our global shortcuts so the old combo can be re-pressed.
// Esc cancels, Backspace / Delete clears, focus loss cancels.

import { useEffect, useRef } from "react";
import { RotateCcw, X } from "lucide-react";
import { useT, tStatic } from "../../cinema/lib/useT";
import { HOTKEY_ACTIONS, HOTKEY_LABEL, accelParts, readCombo, useHotkeys, type HotkeyNote } from "./hotkeys";
import type { HotkeyAction } from "./api";
import "./hotkeys.css";

type Face = "classic" | "cinema" | "eela" | "alok";

export function HotkeyList({ face, lang }: { face: Face; lang?: string }) {
  const tHook = useT();
  const t = lang ? (k: string) => tStatic(lang as never, k) : tHook;
  const hk = useHotkeys();
  const rootRef = useRef<HTMLDivElement>(null);
  const recording = hk.recording;

  // while recording: every key is ours
  useEffect(() => {
    if (!recording) return;
    const onKey = (e: KeyboardEvent) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      if (e.repeat) return;
      const r = readCombo(e);
      const s = useHotkeys.getState();
      if (r.kind === "wait") return;
      if (r.kind === "cancel") { s.stopRecording(); refocus(recording); return; }
      if (r.kind === "clear") { s.stopRecording(); void s.clear(recording).finally(() => refocus(recording)); return; }
      if (r.kind === "invalid") { s.setNote({ action: recording, kind: "invalid", why: r.why }); return; }
      s.stopRecording();
      // the buttons are disabled while main saves: focus only comes back once they're enabled again
      if (s.map[recording] !== r.accel) void s.assign(recording, r.accel).finally(() => refocus(recording));
      else refocus(recording);
    };
    const onUp = (e: KeyboardEvent) => { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); };
    const onBlur = () => useHotkeys.getState().stopRecording();
    window.addEventListener("keydown", onKey, true);
    window.addEventListener("keyup", onUp, true);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("keydown", onKey, true);
      window.removeEventListener("keyup", onUp, true);
      window.removeEventListener("blur", onBlur);
    };
  }, [recording]);
  // leaving Settings mid-recording
  useEffect(() => () => useHotkeys.getState().stopRecording(), []);

  const refocus = (a: HotkeyAction) => requestAnimationFrame(() => rootRef.current?.querySelector<HTMLElement>(`[data-hk="${a}"] .ndh-keys`)?.focus());

  if (!hk.loaded || !hk.supported || !hk.enabled) return null;

  const noteText = (n: HotkeyNote | null, a: HotkeyAction): string | null => {
    if (n && n.action === a) {
      if (n.kind === "invalid") return t(n.why === "reserved" ? "hkReserved" : n.why === "key" ? "hkBadKey" : "hkInvalid");
      if (n.kind === "moved") return t("hkMoved").replace("{{action}}", t(HOTKEY_LABEL[n.from]));
      if (n.kind === "fail") return t("hkSaveFail");
    }
    if (hk.status[a] === "taken") return t("hkTaken");
    return null;
  };
  const globalFail = hk.note && hk.note.kind === "fail" && hk.note.action === null;
  const isDefault = HOTKEY_ACTIONS.every((a) => hk.map[a] === hk.defaults[a]);

  return (
    <div ref={rootRef} className="ndh" data-face={face} data-hotkey-list aria-busy={hk.busy || undefined}>
      {HOTKEY_ACTIONS.map((a) => {
        const label = t(HOTKEY_LABEL[a]);
        const parts = accelParts(hk.map[a]);
        const rec = recording === a;
        const note = noteText(hk.note, a);
        const warn = note !== null && !(hk.note?.action === a && hk.note.kind === "moved");
        return (
          <div key={a} className="ndh-row" data-hk={a} data-status={hk.status[a] || "unset"} data-recording={rec || undefined}>
            <span className="ndh-label">{label}</span>
            <div className="ndh-ctl">
              <button
                type="button"
                className="ndh-keys"
                aria-label={t("hkEdit").replace("{{action}}", label)}
                aria-pressed={rec}
                disabled={hk.busy}
                onClick={() => (rec ? hk.stopRecording() : hk.startRecording(a))}
              >
                {rec ? <span className="ndh-press">{t("hkPress")}</span>
                  : parts.length ? <bdi dir="ltr" className="ndh-caps">{parts.map((p, i) => <kbd key={i}>{p}</kbd>)}</bdi>
                  : <span className="ndh-none">{t("hkNone")}</span>}
              </button>
              <button
                type="button"
                className="ndh-clear"
                aria-label={t("hkClearOne").replace("{{action}}", label)}
                title={t("hkClearOne").replace("{{action}}", label)}
                disabled={hk.busy || !hk.map[a]}
                style={hk.map[a] ? undefined : { visibility: "hidden" }}
                onClick={() => void hk.clear(a)}
              >
                <X size={13} />
              </button>
            </div>
            {note && <span className="ndh-note" data-warn={warn || undefined} role={warn ? "alert" : "status"}>{note}</span>}
          </div>
        );
      })}
      <div className="ndh-foot">
        <span className="ndh-hint">{globalFail ? t("hkSaveFail") : recording ? t("hkHintRec") : t("hkHint")}</span>
        <button type="button" className="ndh-reset" disabled={hk.busy || isDefault} onClick={() => void hk.reset()} data-hk-reset>
          <RotateCcw size={12} /> {t("hkReset")}
        </button>
      </div>
    </div>
  );
}
