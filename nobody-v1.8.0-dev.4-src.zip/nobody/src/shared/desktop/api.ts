// ── NOBODY · desktop integration bridge types (1.8.0, Phase 5 · part 1) ─────
// The preload surface added in electron/preload.cjs. Every member is optional:
// the web build and older shells simply don't have them.

export interface DeskOpenPayload { files: string[]; playlists: string[] }
export interface DeskPrefs {
  closeToTray: boolean;
  openWith: boolean;
  platform: string;
  trayAvailable: boolean;
  openWithSupported: boolean;
}
export interface DeskNowPlaying { title: string; artist: string; playing: boolean }
export type HotkeyAction = "play-pause" | "next" | "prev" | "stop" | "vol-up" | "vol-down" | "show-hide";
export type HotkeyStatus = "ok" | "taken" | "unset" | "off";
export interface DeskHotkeys {
  enabled: boolean;
  map: Record<HotkeyAction, string>;
  status: Partial<Record<HotkeyAction, HotkeyStatus>>;
  defaults: Record<HotkeyAction, string>;
  actions: HotkeyAction[];
  supported: boolean;
}
export type DeskHotkeysResult = DeskHotkeys & { ok: boolean; code?: "E_INVALID" | "E_DUPLICATE" | "E_UNSUPPORTED"; action?: HotkeyAction; other?: HotkeyAction };
export interface DeskApi {
  deskReady?: () => Promise<DeskOpenPayload>;
  onDeskOpen?: (cb: (p: DeskOpenPayload) => void) => () => void;
  deskReadPlaylist?: (path: string) => Promise<{ path: string; bytes?: Uint8Array; error?: string }>;
  deskGetPrefs?: () => Promise<DeskPrefs>;
  deskSetPref?: (key: "closeToTray" | "openWith", value: boolean) => Promise<{ ok: boolean; value?: boolean; code?: string }>;
  deskSetLabels?: (labels: Record<string, string>) => void;
  deskNowPlaying?: (np: DeskNowPlaying) => void;
  /* 1.8.0-dev.2 */
  deskGetHotkeys?: () => Promise<DeskHotkeys>;
  deskSetHotkeys?: (patch: { enabled?: boolean; map?: Partial<Record<HotkeyAction, string>> }) => Promise<DeskHotkeysResult>;
  deskHotkeysSuspend?: (on: boolean) => Promise<DeskHotkeys>;
}
export const deskApi = (): DeskApi | null => {
  const a = typeof window !== "undefined" ? (window as unknown as { electronAPI?: DeskApi }).electronAPI : undefined;
  return a && typeof a.deskReady === "function" ? a : null;
};
