// ── NOBODY · ReplayGain / loudness normalisation (V1.6.1, Phase 3) ────────────
// Pure helpers shared by the tag parsers, the shared engine (Cinema / EELA /
// ALOK) and the Classic player, so every face turns the same tags into the
// same gain. No DOM, no React.
//
// Sources understood by the parsers:
//   REPLAYGAIN_TRACK_GAIN / _PEAK, REPLAYGAIN_ALBUM_GAIN / _PEAK
//     (ID3 TXXX, Vorbis/FLAC comments, MP4 freeform ----:com.apple.iTunes)
//   R128_TRACK_GAIN / R128_ALBUM_GAIN (Opus, Q7.8 dB relative to -23 LUFS;
//     shifted +5 dB onto the ReplayGain 2 reference of -18 LUFS)

export interface ReplayGainInfo {
  /** dB */
  trackGain?: number;
  /** linear sample peak (1.0 = full scale) */
  trackPeak?: number;
  albumGain?: number;
  albumPeak?: number;
}

export type ReplayGainMode = "off" | "track" | "album";

export interface ReplayGainPrefs {
  mode: ReplayGainMode;
  /** extra dB added to tagged tracks (-12..+12) */
  preamp: number;
  /** dB applied to tracks WITHOUT any gain tag (-12..0) */
  fallback: number;
  /** cap the gain so the tagged peak never exceeds full scale */
  preventClip: boolean;
}

export const RG_DEFAULTS: ReplayGainPrefs = { mode: "off", preamp: 0, fallback: 0, preventClip: true };

const num = (v: string): number => {
  const m = /[-+]?\d+(?:[.,]\d+)?/.exec(v);
  return m ? Number(m[0].replace(",", ".")) : NaN;
};

/** Fold one tag (any container) into `rg`. Returns true when the key was a
 *  loudness tag (consumed), false otherwise. */
export function applyReplayGainTag(rg: ReplayGainInfo, rawKey: string, rawValue: string): boolean {
  const key = rawKey.trim().toUpperCase().replace(/\s+/g, "_");
  const value = String(rawValue || "").trim();
  if (!value) return false;
  switch (key) {
    case "REPLAYGAIN_TRACK_GAIN": {
      const g = num(value);
      if (isFinite(g) && g > -60 && g < 40) rg.trackGain = g;
      return true;
    }
    case "REPLAYGAIN_ALBUM_GAIN": {
      const g = num(value);
      if (isFinite(g) && g > -60 && g < 40) rg.albumGain = g;
      return true;
    }
    case "REPLAYGAIN_TRACK_PEAK": {
      const p = num(value);
      if (isFinite(p) && p > 0 && p < 20) rg.trackPeak = p;
      return true;
    }
    case "REPLAYGAIN_ALBUM_PEAK": {
      const p = num(value);
      if (isFinite(p) && p > 0 && p < 20) rg.albumPeak = p;
      return true;
    }
    case "R128_TRACK_GAIN": {
      const q = parseInt(value, 10);
      if (isFinite(q) && rg.trackGain === undefined) rg.trackGain = q / 256 + 5;
      return true;
    }
    case "R128_ALBUM_GAIN": {
      const q = parseInt(value, 10);
      if (isFinite(q) && rg.albumGain === undefined) rg.albumGain = q / 256 + 5;
      return true;
    }
    default:
      return false;
  }
}

export function hasReplayGain(rg: ReplayGainInfo | undefined | null): rg is ReplayGainInfo {
  return !!rg && (rg.trackGain !== undefined || rg.albumGain !== undefined);
}

/** Compact copy with only the defined fields (or undefined when empty). */
export function cleanReplayGain(rg: ReplayGainInfo | undefined | null): ReplayGainInfo | undefined {
  if (!rg) return undefined;
  const out: ReplayGainInfo = {};
  if (rg.trackGain !== undefined) out.trackGain = Math.round(rg.trackGain * 100) / 100;
  if (rg.trackPeak !== undefined) out.trackPeak = Math.round(rg.trackPeak * 1e6) / 1e6;
  if (rg.albumGain !== undefined) out.albumGain = Math.round(rg.albumGain * 100) / 100;
  if (rg.albumPeak !== undefined) out.albumPeak = Math.round(rg.albumPeak * 1e6) / 1e6;
  return Object.keys(out).length ? out : undefined;
}

/** Linear gain factor for one track under the given prefs (1 = unchanged).
 *  "album" falls back to the track gain and vice-versa; untagged tracks get
 *  the fallback dB. Clamped to −24..+12 dB so a broken tag can't blast. */
export function replayGainFactor(rg: ReplayGainInfo | undefined | null, prefs: ReplayGainPrefs): number {
  if (prefs.mode === "off") return 1;
  let db: number;
  let peak: number | undefined;
  if (hasReplayGain(rg)) {
    const albumFirst = prefs.mode === "album";
    const g = albumFirst ? (rg.albumGain ?? rg.trackGain) : (rg.trackGain ?? rg.albumGain);
    peak = albumFirst
      ? (rg.albumGain !== undefined ? rg.albumPeak : rg.trackPeak) ?? rg.trackPeak ?? rg.albumPeak
      : (rg.trackGain !== undefined ? rg.trackPeak : rg.albumPeak) ?? rg.albumPeak ?? rg.trackPeak;
    db = (g ?? 0) + (Number(prefs.preamp) || 0);
  } else {
    db = Number(prefs.fallback) || 0;
  }
  db = Math.max(-24, Math.min(12, db));
  let f = Math.pow(10, db / 20);
  if (prefs.preventClip && peak && peak > 0 && f * peak > 1) f = 1 / peak;
  return f;
}

export function readReplayGainPrefs(s: {
  replayGain?: ReplayGainMode;
  rgPreamp?: number;
  rgFallback?: number;
  rgPreventClip?: boolean;
}): ReplayGainPrefs {
  const mode: ReplayGainMode = s.replayGain === "track" || s.replayGain === "album" ? s.replayGain : "off";
  return {
    mode,
    preamp: clampNum(s.rgPreamp, -12, 12, 0),
    fallback: clampNum(s.rgFallback, -12, 0, 0),
    preventClip: s.rgPreventClip !== false,
  };
}

function clampNum(v: unknown, lo: number, hi: number, dflt: number): number {
  const n = Number(v);
  if (!isFinite(n)) return dflt;
  return Math.max(lo, Math.min(hi, n));
}

// ── genre helpers ────────────────────────────────────────────────────────────

/** ID3v1 / Winamp genre table (index = numeric id). */
export const ID3_GENRES = [
  "Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal",
  "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial",
  "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk",
  "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise",
  "Alternative Rock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic",
  "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta",
  "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychedelic", "Rave", "Showtunes",
  "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock",
  "Folk", "Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebop", "Latin", "Revival", "Celtic", "Bluegrass",
  "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic",
  "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove",
  "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle",
  "Duet", "Punk Rock", "Drum Solo", "A Cappella", "Euro-House", "Dance Hall", "Goa", "Drum & Bass", "Club-House", "Hardcore",
  "Terror", "Indie", "BritPop", "Afro-Punk", "Polsk Punk", "Beat", "Christian Gangsta Rap", "Heavy Metal", "Black Metal", "Crossover",
  "Contemporary Christian", "Christian Rock", "Merengue", "Salsa", "Thrash Metal", "Anime", "JPop", "Synthpop",
];

/** Normalise a raw genre tag: "(17)", "17", "(17)Rock", "(RX)", "Rock\0Pop",
 *  "Rock;Pop" → "Rock; Pop". Returns undefined for empty / junk. */
export function normalizeGenre(raw: string | undefined | null): string | undefined {
  if (!raw) return undefined;
  const parts: string[] = [];
  for (let piece of String(raw).split(/\0|;|\|/)) {
    piece = piece.trim();
    if (!piece) continue;
    // ID3v2.3 "(nn)" references, optionally followed by a refinement
    const refs = /^((?:\(\d+\)|\(RX\)|\(CR\))+)(.*)$/i.exec(piece);
    if (refs) {
      const rest = refs[2].trim();
      if (rest) { parts.push(rest); continue; }
      for (const m of refs[1].matchAll(/\((\d+|RX|CR)\)/gi)) {
        const id = m[1].toUpperCase();
        if (id === "RX") parts.push("Remix");
        else if (id === "CR") parts.push("Cover");
        else if (ID3_GENRES[Number(id)]) parts.push(ID3_GENRES[Number(id)]);
      }
      continue;
    }
    if (/^\d{1,3}$/.test(piece)) {
      const g = ID3_GENRES[Number(piece)];
      if (g) parts.push(g);
      continue;
    }
    parts.push(piece);
  }
  const seen = new Set<string>();
  const out = parts.filter((p) => {
    const k = p.toLowerCase();
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  return out.length ? out.join("; ").slice(0, 200) : undefined;
}

/** Individual genres of a (normalised) genre string. */
export function splitGenres(genre: string | undefined | null): string[] {
  if (!genre) return [];
  return genre.split(";").map((g) => g.trim()).filter(Boolean);
}
