// ── NOBODY · M3U / M3U8 core (pure, no DOM / Electron) ─ 1.7.0-dev.9 (P4 · 6) ──
// parse   BOM, CRLF/CR/LF, #EXTM3U, #PLAYLIST, #EXTINF (attrs + "Artist - Title"),
//         #EXTART, file:// URLs, remote URLs skipped, relative paths resolved
//         against the playlist's folder, "\x" root-relative on Windows.
// decode  UTF-8/UTF-16 BOM → fatal UTF-8 → legacy code pages; the candidate
//         whose paths match the most library files wins (old Persian .m3u
//         files from Winamp/foobar are windows-1256).
// match   exact normalised path → unique file name → folded artist+title
//         (± 3 s when both durations are known).
// build   #EXTM3U + #PLAYLIST + #EXTINF, paths relative to the playlist when
//         they share a drive / share / root, CRLF.
import { fold } from "../../cinema/lib/smartPlaylist";

export interface M3UEntry {
  /** absolute, normalised with the platform's separators */
  path: string;
  /** the line exactly as written (for reports) */
  raw: string;
  title?: string;
  artist?: string;
  /** seconds; undefined when the playlist says -1 / nothing */
  duration?: number;
  line: number;
}

export interface ParsedM3U {
  name?: string;
  extended: boolean;
  entries: M3UEntry[];
  /** http(s)/rtsp/… streams — not supported by the library */
  remote: number;
  /** path lines that could not be resolved (relative path, no base folder) */
  unresolved: number;
}

// ── paths ────────────────────────────────────────────────────────────────────

const DRIVE_RE = /^[a-zA-Z]:[\\/]/;
const UNC_RE = /^(?:\\\\|\/\/)[^\\/]+[\\/][^\\/]+/;

export const isWinPath = (p: string) => DRIVE_RE.test(p) || UNC_RE.test(p);
export const isAbsolutePath = (p: string) => isWinPath(p) || p.startsWith("/");

/** Resolve "."/".." and duplicate separators. Keeps the drive / UNC root. */
export function normalizePath(p: string, win = isWinPath(p)): string {
  if (!p) return "";
  let root = "";
  let rest = p.replace(/\\/g, "/");
  if (/^[a-zA-Z]:\//.test(rest)) { root = rest.slice(0, 2).toUpperCase() + "/"; rest = rest.slice(3); }
  else if (/^\/\/[^/]+\/[^/]+/.test(rest)) {
    const m = /^\/\/([^/]+)\/([^/]+)\/?/.exec(rest)!;
    root = `//${m[1]}/${m[2]}/`;
    rest = rest.slice(m[0].length);
  } else if (rest.startsWith("/")) { root = "/"; rest = rest.slice(1); }
  const out: string[] = [];
  for (const seg of rest.split("/")) {
    if (!seg || seg === ".") continue;
    if (seg === "..") { if (out.length) out.pop(); continue; }
    out.push(seg);
  }
  let joined = root + out.join("/");
  if (root.startsWith("//") && !out.length) joined = root.slice(0, -1);
  return win ? joined.replace(/\//g, "\\") : joined;
}

export function dirnameOf(p: string): string {
  const i = Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\"));
  return i <= 0 ? (i === 0 ? p.slice(0, 1) : "") : p.slice(0, i);
}

export const basenameOf = (p: string) => p.split(/[\\/]/).pop() || p;

/** Case/Unicode-insensitive key used to compare a playlist path with a library path. */
export function pathKey(p: string | undefined | null): string {
  if (!p) return "";
  return normalizePath(p, false).normalize("NFC").toLocaleLowerCase();
}

function decodeFileUrl(u: string): string | null {
  // file:///C:/a%20b.mp3 · file://localhost/C:/x · file://server/share/x · file:///home/x
  const m = /^file:\/\/([^/]*)(\/.*)?$/i.exec(u);
  if (!m) return null;
  let host = m[1];
  let rest = m[2] || "";
  try { rest = decodeURIComponent(rest); host = decodeURIComponent(host); } catch { /* keep raw */ }
  if (host && host.toLowerCase() !== "localhost") return `//${host}${rest}`;
  if (/^\/[a-zA-Z]:[\\/]/.test(rest) || /^\/[a-zA-Z]\|/.test(rest)) return rest.slice(1).replace("|", ":");
  return rest;
}

/** Resolve one path line of a playlist. null = remote URL; "" = unresolvable. */
export function resolveEntryPath(line: string, baseDir: string): string | null {
  let p = line.trim();
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(p)) {
    if (!/^file:/i.test(p)) return null;
    const f = decodeFileUrl(p);
    if (f === null) return "";
    p = f;
  }
  const baseWin = isWinPath(baseDir);
  if (DRIVE_RE.test(p) || UNC_RE.test(p)) return normalizePath(p, true);
  if (/^[\\/]/.test(p)) {
    // "\Music\x.mp3" on Windows = root of the playlist's drive; POSIX = absolute
    if (baseWin) {
      const drive = /^[a-zA-Z]:/.exec(baseDir)?.[0];
      const unc = UNC_RE.exec(baseDir)?.[0];
      if (drive) return normalizePath(drive + p, true);
      if (unc) return normalizePath(unc + p, true);
    }
    if (p.startsWith("\\")) return "";
    return normalizePath(p, false);
  }
  if (/^[a-zA-Z]:[^\\/]/.test(p)) return ""; // drive-relative "C:foo.mp3"
  if (!baseDir) return "";
  return normalizePath(`${baseDir}/${p}`, baseWin);
}

// ── parse ────────────────────────────────────────────────────────────────────

function parseExtinf(body: string): { duration?: number; artist?: string; title?: string } {
  // "#EXTINF:123 tvg-name="x, y" group="z",Artist - Title"
  let i = 0;
  let inQ = false;
  for (; i < body.length; i++) {
    const c = body[i];
    if (c === '"') inQ = !inQ;
    else if (c === "," && !inQ) break;
  }
  const head = body.slice(0, i).trim();
  const display = i < body.length ? body.slice(i + 1).trim() : "";
  const durRaw = /^-?\d+(?:\.\d+)?/.exec(head)?.[0];
  const dur = durRaw !== undefined ? Number(durRaw) : NaN;
  const out: { duration?: number; artist?: string; title?: string } = {};
  if (isFinite(dur) && dur > 0) out.duration = dur;
  if (display) {
    const sep = display.indexOf(" - ");
    if (sep > 0) { out.artist = display.slice(0, sep).trim(); out.title = display.slice(sep + 3).trim(); }
    else out.title = display;
  }
  return out;
}

export function parseM3U(text: string, baseDir = ""): ParsedM3U {
  const res: ParsedM3U = { extended: false, entries: [], remote: 0, unresolved: 0 };
  const lines = text.replace(/^\uFEFF/, "").split(/\r\n|\r|\n/);
  let pending: { duration?: number; artist?: string; title?: string } | null = null;
  let pendingArtist: string | undefined;
  lines.forEach((rawLine, idx) => {
    const line = rawLine.replace(/\x00/g, "").trim();
    if (!line) return;
    if (line.startsWith("#")) {
      const up = line.toUpperCase();
      if (up.startsWith("#EXTM3U")) res.extended = true;
      else if (up.startsWith("#PLAYLIST:")) { const n = line.slice(10).trim(); if (n) res.name = n; }
      else if (up.startsWith("#EXTINF:")) pending = parseExtinf(line.slice(8));
      else if (up.startsWith("#EXTART:")) pendingArtist = line.slice(8).trim() || undefined;
      return;
    }
    const path = resolveEntryPath(line, baseDir);
    const meta = pending;
    pending = null;
    const art = pendingArtist;
    pendingArtist = undefined;
    if (path === null) { res.remote++; return; }
    if (!path) { res.unresolved++; return; }
    const e: M3UEntry = { path, raw: line, line: idx + 1 };
    if (meta) Object.assign(e, meta);
    if (art && !e.artist) e.artist = art;
    res.entries.push(e);
  });
  return res;
}

// ── decode ───────────────────────────────────────────────────────────────────

const LEGACY_BY_LANG: Record<string, string[]> = {
  fa: ["windows-1256", "windows-1252", "windows-1251", "windows-1254"],
  ru: ["windows-1251", "windows-1252", "windows-1256", "windows-1254"],
  tr: ["windows-1254", "windows-1252", "windows-1256", "windows-1251"],
  en: ["windows-1252", "windows-1256", "windows-1251", "windows-1254"],
};

export interface DecodeResult { text: string; encoding: string }

/**
 * `score(text)` (optional) = how many paths of that decoding exist in the
 * library; it picks between the legacy code pages. Without a winner the
 * UI-language order decides.
 */
export function decodeM3U(bytes: Uint8Array, lang = "en", score?: (text: string) => number): DecodeResult {
  if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf)
    return { text: new TextDecoder("utf-8").decode(bytes.subarray(3)), encoding: "utf-8" };
  if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe)
    return { text: new TextDecoder("utf-16le").decode(bytes.subarray(2)), encoding: "utf-16le" };
  if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff)
    return { text: new TextDecoder("utf-16be").decode(bytes.subarray(2)), encoding: "utf-16be" };
  try {
    return { text: new TextDecoder("utf-8", { fatal: true }).decode(bytes), encoding: "utf-8" };
  } catch { /* not UTF-8 → legacy */ }
  const order = LEGACY_BY_LANG[lang] || LEGACY_BY_LANG.en;
  let best: DecodeResult | null = null;
  let bestScore = -1;
  for (const enc of order) {
    let text: string;
    try { text = new TextDecoder(enc).decode(bytes); } catch { continue; }
    const s = score ? score(text) : 0;
    if (s > bestScore) { best = { text, encoding: enc }; bestScore = s; }
    if (!score) break;
  }
  return best ?? { text: new TextDecoder("utf-8").decode(bytes), encoding: "utf-8" };
}

// ── match ────────────────────────────────────────────────────────────────────

export interface MatchTrack {
  id: string;
  filePath?: string;
  fileName?: string;
  title: string;
  artist: string;
  duration: number;
}

export type MatchKind = "path" | "name" | "tags";
export interface MatchResult { entry: M3UEntry; id: string | null; kind: MatchKind | null }

export interface LibraryIndex {
  byPath: Map<string, string>;
  byName: Map<string, string | null>; // null = ambiguous
  byTags: Map<string, MatchTrack[]>;
}

const tagKey = (artist: string | undefined, title: string | undefined) => `${fold(artist)}\x1f${fold(title)}`;

export function indexLibrary(tracks: Iterable<MatchTrack>): LibraryIndex {
  const idx: LibraryIndex = { byPath: new Map(), byName: new Map(), byTags: new Map() };
  for (const t of tracks) {
    if (t.filePath) idx.byPath.set(pathKey(t.filePath), t.id);
    const nm = t.filePath ? basenameOf(t.filePath) : t.fileName;
    if (nm) {
      const k = fold(nm);
      idx.byName.set(k, idx.byName.has(k) && idx.byName.get(k) !== t.id ? null : t.id);
    }
    if (t.title) {
      const k = tagKey(t.artist, t.title);
      const arr = idx.byTags.get(k);
      if (arr) arr.push(t); else idx.byTags.set(k, [t]);
    }
  }
  return idx;
}

export function matchEntry(e: M3UEntry, idx: LibraryIndex): MatchResult {
  const byPath = idx.byPath.get(pathKey(e.path));
  if (byPath) return { entry: e, id: byPath, kind: "path" };
  const byName = idx.byName.get(fold(basenameOf(e.path)));
  if (byName) return { entry: e, id: byName, kind: "name" };
  if (e.title) {
    const cands = idx.byTags.get(tagKey(e.artist, e.title));
    if (cands && cands.length) {
      if (e.duration && e.duration > 0) {
        const close = cands.filter((c) => !c.duration || Math.abs(c.duration - e.duration!) <= 3);
        if (close.length) {
          close.sort((a, b) => Math.abs((a.duration || 1e9) - e.duration!) - Math.abs((b.duration || 1e9) - e.duration!));
          return { entry: e, id: close[0].id, kind: "tags" };
        }
      } else if (cands.length === 1) return { entry: e, id: cands[0].id, kind: "tags" };
    }
  }
  return { entry: e, id: null, kind: null };
}

export const matchAll = (entries: M3UEntry[], idx: LibraryIndex) => entries.map((e) => matchEntry(e, idx));

/** Decoder scorer: count of path lines that hit the library exactly. */
export function libraryScorer(idx: LibraryIndex, baseDir: string): (text: string) => number {
  return (text) => {
    const p = parseM3U(text, baseDir);
    let n = 0;
    for (const e of p.entries) if (idx.byPath.has(pathKey(e.path)) || idx.byName.get(fold(basenameOf(e.path)))) n++;
    return n;
  };
}

// ── build ────────────────────────────────────────────────────────────────────

export interface ExportItem {
  path?: string;
  fileName?: string;
  title: string;
  artist?: string;
  duration?: number;
}

const oneLine = (s: string | undefined) => (s || "").replace(/[\r\n\x00]+/g, " ").trim();

function rootOf(p: string): string {
  const n = normalizePath(p, false);
  if (/^[A-Za-z]:\//.test(n)) return n.slice(0, 3).toLowerCase();
  const unc = /^\/\/[^/]+\/[^/]+/.exec(n);
  if (unc) return unc[0].toLowerCase() + "/";
  return n.startsWith("/") ? "/" : "";
}

/** `file` relative to folder `dir` when both share a root; otherwise null. */
export function relativePath(dir: string, file: string): string | null {
  const win = isWinPath(dir) || isWinPath(file);
  const rd = rootOf(dir);
  const rf = rootOf(file);
  if (!rd || rd !== rf) return null;
  const a = normalizePath(dir, false).slice(rd.length).split("/").filter(Boolean);
  const b = normalizePath(file, false).slice(rf.length).split("/").filter(Boolean);
  const eq = (x: string, y: string) => (win ? x.toLowerCase() === y.toLowerCase() : x === y);
  let i = 0;
  while (i < a.length && i < b.length - 1 && eq(a[i], b[i])) i++;
  const parts = [...Array(a.length - i).fill(".."), ...b.slice(i)];
  let rel = parts.join(win ? "\\" : "/");
  if (rel.startsWith("#")) rel = (win ? ".\\" : "./") + rel;
  return rel;
}

export function buildM3U(items: ExportItem[], opts: { targetPath?: string; name?: string; relative?: boolean } = {}): string {
  const dir = opts.targetPath ? dirnameOf(opts.targetPath) : "";
  const out = ["#EXTM3U"];
  if (opts.name) out.push(`#PLAYLIST:${oneLine(opts.name)}`);
  for (const it of items) {
    const abs = it.path && isAbsolutePath(it.path) ? normalizePath(it.path) : "";
    let line = abs;
    if (abs && dir && opts.relative !== false) line = relativePath(dir, abs) ?? abs;
    if (!line) line = oneLine(it.fileName || it.path);
    if (!line) continue;
    const dur = it.duration && it.duration > 0 ? Math.round(it.duration) : -1;
    const artist = oneLine(it.artist);
    const title = oneLine(it.title) || basenameOf(line);
    out.push(`#EXTINF:${dur},${artist ? `${artist} - ` : ""}${title}`);
    out.push(line);
  }
  return out.join("\r\n") + "\r\n";
}

/** Encode for disk: .m3u8 = UTF-8; .m3u = UTF-8 with BOM (players that
 *  assume ANSI for .m3u see the BOM and switch to UTF-8). */
export function encodeM3U(text: string, targetPath: string): Uint8Array {
  const body = new TextEncoder().encode(text);
  if (!/\.m3u$/i.test(targetPath)) return body;
  const out = new Uint8Array(body.length + 3);
  out.set([0xef, 0xbb, 0xbf]);
  out.set(body, 3);
  return out;
}

export const playlistNameFromFile = (p: string) => basenameOf(p).replace(/\.m3u8?$/i, "").trim() || "Playlist";
