// ── NOBODY · M3U / M3U8 import + export (all faces) ─ 1.7.0-dev.9 (P4 · 6) ──
// Desktop: main opens the pickers (bytes in, one granted path out).
// Web build: <input type=file> in, blob download out.
// Songs that are on disk but not in the library are imported file-by-file
// through the bridge and remembered across restarts.
import { useLibrary, LIKED_ID } from "../../cinema/store/library";
import { useSettings } from "../../cinema/store/settings";
import { uiApi } from "../../cinema/store/ui";
import { tStatic } from "../../cinema/lib/useT";
import { getBridge } from "../../cinema/lib/desktopBridge";
import { playlistTrackIds } from "../../cinema/lib/usePlaylistTracks";
import { mapPool } from "../pool";
import type { Playlist, Track } from "../../cinema/types";
import {
  buildM3U, decodeM3U, dirnameOf, encodeM3U, indexLibrary, isAbsolutePath, libraryScorer,
  matchAll, parseM3U, pathKey, playlistNameFromFile, type MatchTrack,
} from "./m3u";
import { create } from "zustand";

const AUDIO_RE = /\.(mp3|wav|flac|ogg|oga|opus|m4a|aac|alac|aif|aiff|caf|webm|mp4|wma|ape|amr|3gp|dsf|mpc)$/i;

/** One import/export at a time; views disable their buttons while busy. */
export const useM3UBusy = create<{ busy: boolean }>(() => ({ busy: false }));

const tr = (k: string, vars: Record<string, string | number> = {}) => {
  const lang = useSettings.getState().lang;
  let s = tStatic(lang, k);
  for (const [n, v] of Object.entries(vars)) s = s.split(`{{${n}}}`).join(String(v));
  return s;
};

const api = () => (typeof window !== "undefined" ? window.electronAPI : undefined);

function toMatch(t: Track): MatchTrack {
  return { id: t.id, filePath: t.filePath, fileName: t.fileName, title: t.title, artist: t.artist === "Unknown Artist" ? "" : t.artist, duration: t.duration };
}

interface PickedList { path: string; name: string; bytes?: Uint8Array; error?: string }

function pickWebLists(): Promise<PickedList[]> {
  return new Promise((resolve) => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".m3u,.m3u8,audio/x-mpegurl,audio/mpegurl,application/vnd.apple.mpegurl";
    input.multiple = true;
    input.onchange = async () => {
      const files = Array.from(input.files ?? []).slice(0, 50);
      const out: PickedList[] = [];
      for (const f of files) {
        if (f.size > 8 * 1024 * 1024) { out.push({ path: "", name: f.name, error: "E_TOO_LARGE" }); continue; }
        try { out.push({ path: "", name: f.name, bytes: new Uint8Array(await f.arrayBuffer()) }); }
        catch { out.push({ path: "", name: f.name, error: "E_READ" }); }
      }
      resolve(out);
    };
    input.oncancel = () => resolve([]);
    input.click();
  });
}

function uniqueName(base: string): string {
  const taken = new Set(useLibrary.getState().playlists.map((p) => p.name.toLocaleLowerCase()));
  if (!taken.has(base.toLocaleLowerCase())) return base;
  for (let i = 2; i < 1000; i++) {
    const n = `${base} (${i})`;
    if (!taken.has(n.toLocaleLowerCase())) return n;
  }
  return base;
}

export interface ImportSummary {
  name: string;
  playlistId: string | null;
  songs: number;
  addedToLibrary: number;
  missing: number;
  remote: number;
  duplicates: number;
  encoding: string;
}

/** Import one decoded playlist. Exported for the UI harness / tests. */
export async function importPlaylistBytes(bytes: Uint8Array, filePath: string, fileName: string): Promise<ImportSummary> {
  const lang = useSettings.getState().lang;
  const baseDir = filePath ? dirnameOf(filePath) : "";
  const libTracks = Object.values(useLibrary.getState().tracks);
  let idx = indexLibrary(libTracks.map(toMatch));
  const { text, encoding } = decodeM3U(bytes, lang, libraryScorer(idx, baseDir));
  const parsed = parseM3U(text, baseDir);
  let results = matchAll(parsed.entries, idx);

  // songs on disk that the library doesn't have yet → file-level import
  let addedToLibrary = 0;
  const bridge = getBridge();
  const electron = api();
  const missing = results.filter((r) => !r.id && isAbsolutePath(r.entry.path) && AUDIO_RE.test(r.entry.path));
  if (missing.length && bridge?.importFilePaths && electron?.stat) {
    const uniq = Array.from(new Map(missing.map((r) => [pathKey(r.entry.path), r.entry.path])).values());
    const exists = await mapPool(uniq, 6, async (p) => {
      const info = await electron.stat(p);
      return info?.isFile ? p : null;
    });
    const onDisk = exists.filter((p): p is string => !!p);
    if (onDisk.length) {
      const res = await bridge.importFilePaths(onDisk, { remember: true });
      addedToLibrary = res.added;
      await useLibrary.getState().rehydrateTracks();
      const byKey = new Map(Object.entries(res.ids).map(([p, id]) => [pathKey(p), id]));
      const tracks = useLibrary.getState().tracks;
      results = results.map((r) => {
        if (r.id) return r;
        const id = byKey.get(pathKey(r.entry.path));
        return id && tracks[id] ? { ...r, id, kind: "path" as const } : r;
      });
      idx = indexLibrary(Object.values(tracks).map(toMatch));
      // name/tag fallback once more against the grown library
      results = results.map((r) => (r.id ? r : matchAll([r.entry], idx)[0]));
    }
  }

  const ids = results.map((r) => r.id).filter((x): x is string => !!x);
  const uniqueIds = Array.from(new Set(ids));
  const name = uniqueName(parsed.name || playlistNameFromFile(filePath || fileName));
  const summary: ImportSummary = {
    name,
    playlistId: null,
    songs: uniqueIds.length,
    addedToLibrary,
    missing: results.filter((r) => !r.id).length + parsed.unresolved,
    remote: parsed.remote,
    duplicates: ids.length - uniqueIds.length,
    encoding,
  };
  if (uniqueIds.length) summary.playlistId = useLibrary.getState().createPlaylistFrom(name, uniqueIds);
  return summary;
}

function toastSummary(s: ImportSummary) {
  if (!s.playlistId) {
    uiApi.toast(tr("m3uNothing", { name: s.name }), "error", { sub: s.remote ? tr("m3uRemote", { n: s.remote }) : undefined });
    return;
  }
  const bits: string[] = [];
  if (s.addedToLibrary) bits.push(tr("m3uAddedLib", { n: s.addedToLibrary }));
  if (s.missing) bits.push(tr("m3uMissing", { n: s.missing }));
  if (s.remote) bits.push(tr("m3uRemote", { n: s.remote }));
  if (s.duplicates) bits.push(tr("m3uDupes", { n: s.duplicates }));
  uiApi.toast(tr("m3uImported", { name: s.name, n: s.songs }), s.missing ? "info" : "success", { sub: bits.join(" · ") || undefined });
}

/** Picker → import every chosen playlist. Resolves with the last created id. */
export async function importPlaylistsInteractive(): Promise<string | null> {
  if (useM3UBusy.getState().busy) return null;
  const electron = api();
  let picked: PickedList[];
  try {
    picked = electron?.pickPlaylistImport
      ? (await electron.pickPlaylistImport()).map((p) => ({ ...p, name: p.path.split(/[\\/]/).pop() || p.path }))
      : await pickWebLists();
  } catch {
    uiApi.toast(tr("m3uReadError", { name: "M3U" }), "error");
    return null;
  }
  if (!picked.length) return null;
  useM3UBusy.setState({ busy: true });
  const progress = uiApi.toast(tr("m3uWorking"), "progress", { sticky: true });
  let last: string | null = null;
  try {
    for (const p of picked) {
      if (p.error || !p.bytes) {
        uiApi.toast(tr(p.error === "E_TOO_LARGE" ? "m3uTooLarge" : "m3uReadError", { name: p.name }), "error");
        continue;
      }
      try {
        const s = await importPlaylistBytes(p.bytes, p.path, p.name);
        toastSummary(s);
        if (s.playlistId) last = s.playlistId;
      } catch {
        uiApi.toast(tr("m3uReadError", { name: p.name }), "error");
      }
    }
  } finally {
    uiApi.dismissToast(progress);
    useM3UBusy.setState({ busy: false });
  }
  return last;
}

/** Text of a playlist as M3U8 (resolved songs: smart lists and Liked too). */
export function playlistToM3U(pl: Playlist, targetPath?: string): { text: string; count: number; name: string } {
  const s = useLibrary.getState();
  const name = pl.id === LIKED_ID || pl.system ? tr("likedSongs") : pl.name;
  const items = playlistTrackIds(pl, s)
    .map((id) => s.tracks[id])
    .filter(Boolean)
    .map((t) => ({ path: t.filePath, fileName: t.fileName, title: t.title, artist: t.artist === "Unknown Artist" ? "" : t.artist, duration: t.duration }));
  return { text: buildM3U(items, { targetPath, name }), count: items.length, name };
}

export async function exportPlaylistInteractive(pl: Playlist): Promise<boolean> {
  if (useM3UBusy.getState().busy) return false;
  const electron = api();
  const { name, count } = playlistToM3U(pl);
  if (!count) return false;
  useM3UBusy.setState({ busy: true });
  try {
    if (electron?.pickPlaylistExport && electron.writePlaylist) {
      const target = await electron.pickPlaylistExport(name);
      if (!target) return false;
      const { text } = playlistToM3U(pl, target);
      await electron.writePlaylist(target, text);
      uiApi.toast(tr("m3uExported", { n: count }), "success", { sub: target.split(/[\\/]/).pop() });
      return true;
    }
    const file = `${name.replace(/[\\/:*?"<>|]+/g, "_").trim() || "playlist"}.m3u8`;
    const { text } = playlistToM3U(pl);
    const url = URL.createObjectURL(new Blob([encodeM3U(text, file)], { type: "audio/x-mpegurl" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = file;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
    uiApi.toast(tr("m3uExported", { n: count }), "success", { sub: file });
    return true;
  } catch {
    uiApi.toast(tr("m3uExportFail"), "error");
    return false;
  } finally {
    useM3UBusy.setState({ busy: false });
  }
}
