// ── NOBODY · bounded async pool (V1.5.4 · Phase 2) ───────────────────────────
// Runs `fn` over `items` with at most `limit` calls in flight and returns the
// results IN INPUT ORDER. A rejected item yields `undefined` (reported through
// `onError`) instead of aborting the whole batch.

export async function mapPool<T, R>(
  items: readonly T[],
  limit: number,
  fn: (item: T, index: number) => Promise<R>,
  onError?: (err: unknown, item: T, index: number) => void
): Promise<(R | undefined)[]> {
  const out: (R | undefined)[] = new Array(items.length);
  let next = 0;
  const worker = async () => {
    while (true) {
      const i = next++;
      if (i >= items.length) return;
      try {
        out[i] = await fn(items[i], i);
      } catch (err) {
        out[i] = undefined;
        onError?.(err, items[i], i);
      }
    }
  };
  const n = Math.max(1, Math.min(limit | 0 || 1, items.length));
  await Promise.all(Array.from({ length: n }, worker));
  return out;
}
