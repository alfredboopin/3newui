// ── NOBODY ALOK · shared track row ───────────────────────────────────────────
// Circular-thumb row used by every panel list. Click = play (engine.setQueue
// over the visible ids), heart = toggleLike, hover "add to queue", and a
// playlist popover (existing lists + inline create). V1.6.4: "play next".

import { memo, useEffect, useRef, useState } from "react";
import { Heart, ListPlus, ListStart, X, FolderPlus, Check, Plus, PenLine } from "lucide-react";
import { openTagEditor } from "../../shared/tagEditor/store";
import { engine } from "../../cinema/lib/engine";
import { playNextWithToast } from "../../cinema/lib/queueActions";
import { useLibrary, isManualPlaylist } from "../../cinema/store/library";
import { LIKED_ID } from "../../cinema/store/library";
import { useUi, uiApi } from "../../cinema/store/ui";
import { useT } from "../../cinema/lib/useT";
import { CoverArt } from "../../cinema/components/CoverArt";
import { fmtTime } from "../../cinema/lib/utils";
import type { Track } from "../../cinema/types";

interface Props {
  track: Track;
  playIds: string[];
  /** show a remove (×) action instead of nothing — used in playlist detail */
  onRemove?: () => void;
  removeTitle?: string;
}

/* V1.5.4 (P2): memoised + boolean selectors. Every row used to subscribe to
   `currentId` and the whole playlists array, so a track change or a like
   re-rendered EVERY row of the panel. Now a row only re-renders when its own
   "is current" / "is liked" flips; the playlist list is read lazily by the
   popover (mounted only while open). */
export const TrackRow = memo(function TrackRow({ track, playIds, onRemove, removeTitle }: Props) {
  const t = useT();
  const isCurrent = useUi((s) => s.currentId === track.id);
  const liked = useLibrary((s) => s.playlists.find((p) => p.id === LIKED_ID)?.trackIds.includes(track.id) ?? false);
  const toggleLike = useLibrary((s) => s.toggleLike);

  const [popOpen, setPopOpen] = useState(false);
  const popRef = useRef<HTMLDivElement>(null);

  // close the popover on any outside click
  useEffect(() => {
    if (!popOpen) return;
    const onDown = (e: MouseEvent) => {
      if (popRef.current && !popRef.current.contains(e.target as Node)) setPopOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [popOpen]);

  return (
    <div
      className="na-row"
      data-playing={isCurrent}
      role="button"
      tabIndex={0}
      onClick={() => engine.setQueue(playIds, track.id, true)}
      onKeyDown={(e) => { if (e.key === "Enter") engine.setQueue(playIds, track.id, true); }}
      aria-label={`${track.title} — ${track.artist}`}
    >
      <span className="na-row-main">
        <span className="na-row-thumb">
          <CoverArt trackId={track.id} rounded="rounded-full" />
        </span>
        <span className="na-row-titles">
          <span className="na-row-title" style={{ display: "block" }}>{track.title}</span>
          <span className="na-row-sub" style={{ display: "block" }}>{track.artist}</span>
        </span>
      </span>
      <span className="na-row-acts" onClick={(e) => e.stopPropagation()}>
        <span className="na-row-time na-mono">{fmtTime(track.duration)}</span>
        <button
          className="na-icon-btn"
          data-on={liked}
          onClick={() => toggleLike(track.id)}
          title={t("like")}
          aria-label={`${t("like")}: ${track.title}`}
        >
          <Heart size={14} fill={liked ? "currentColor" : "none"} />
        </button>
        <span className="na-pop-wrap" ref={popRef}>
          <button
            className="na-icon-btn"
            data-on={popOpen}
            onClick={() => setPopOpen(!popOpen)}
            title={t("addToPlaylist")}
            aria-label={`${t("addToPlaylist")}: ${track.title}`}
            aria-expanded={popOpen}
          >
            <FolderPlus size={15} />
          </button>
          {popOpen && <PlaylistPop track={track} onDone={() => setPopOpen(false)} />}
        </span>
        <button
          className="na-icon-btn"
          onClick={() => playNextWithToast(track.id, track.title, t)}
          title={t("playNext")}
          aria-label={`${t("playNext")}: ${track.title}`}
        >
          <ListStart size={15} />
        </button>
        <button
          className="na-icon-btn"
          onClick={() => {
            engine.addToQueue(track.id);
            uiApi.toast(`${track.title} — ${t("addToQueue")}`, "info");
          }}
          title={t("addToQueue")}
          aria-label={`${t("addToQueue")}: ${track.title}`}
        >
          <ListPlus size={15} />
        </button>
        <button
          className="na-icon-btn"
          onClick={() => openTagEditor(track.id, "alok")}
          title={t("teEditTags")}
          aria-label={`${t("teEditTags")}: ${track.title}`}
        >
          <PenLine size={14} />
        </button>
        {onRemove && (
          <button
            className="na-icon-btn"
            onClick={onRemove}
            title={removeTitle ?? t("remove")}
            aria-label={`${removeTitle ?? t("remove")}: ${track.title}`}
          >
            <X size={15} />
          </button>
        )}
      </span>
    </div>
  );
});

/** Playlist popover — owns the playlists subscription, mounted only while open. */
function PlaylistPop({ track, onDone }: { track: Track; onDone: () => void }) {
  const t = useT();
  const playlists = useLibrary((s) => s.playlists);
  const addToPlaylist = useLibrary((s) => s.addToPlaylist);
  const createPlaylist = useLibrary((s) => s.createPlaylist);
  const [newName, setNewName] = useState("");
  // smart lists fill themselves from rules: adding to them would do nothing
  const userLists = playlists.filter(isManualPlaylist);

  const createAndAdd = () => {
    const name = newName.trim();
    if (!name) return;
    const pid = createPlaylist(name);
    addToPlaylist(pid, track.id);
    setNewName("");
    onDone();
    uiApi.toast(`${track.title} → ${name}`, "success");
  };

  return (
    <div className="na-pop" role="menu" aria-label={t("addToPlaylist")}>
      <div className="na-pop-title">{t("addToPlaylist")}</div>
      <input
        className="na-pop-input"
        value={newName}
        onChange={(e) => setNewName(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter") createAndAdd(); }}
        placeholder={t("alNewPlaylist")}
        aria-label={t("alNewPlaylist")}
      />
      {newName.trim() && (
        <button className="na-pop-btn" onClick={createAndAdd}>
          <Plus size={13} /> {t("alCreatePlaylist")} «{newName.trim()}»
        </button>
      )}
      {userLists.map((p) => {
        const inList = p.trackIds.includes(track.id);
        return (
          <button
            key={p.id}
            className="na-pop-btn"
            data-on={inList}
            onClick={() => { addToPlaylist(p.id, track.id); }}
          >
            {inList ? <Check size={13} /> : <ListMusicMini />}
            <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</span>
            {inList && <Check size={12} style={{ marginInlineStart: "auto", opacity: 0.8 }} />}
          </button>
        );
      })}
      {userLists.length === 0 && !newName.trim() && (
        <div className="na-pop-btn" style={{ cursor: "default", opacity: 0.6 }}>
          {t("emptyPlaylist")}
        </div>
      )}
    </div>
  );
}

/* tiny placeholder icon so playlist rows read as list entries */
function ListMusicMini() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M21 15V6" /><path d="M18.5 18a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" /><path d="M12 12H3" /><path d="M16 6H3" /><path d="M12 18H3" />
    </svg>
  );
}
