// ── NOBODY ALOK · FX bottom sheet ────────────────────────────────────────────
// EQ on/off + 6 or 10 band sliders + preamp + shared presets (useSoundFx,
// V1.6.2), Volume leveling (ReplayGain), playback speed
// (engine.setRate 0.5–2, pitch preserved by the engine) and the sleep timer
// with a live countdown. Logic adapted from cinema's FxSheet, restyled to the
// ALOK mono/hairline aesthetic.

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { engine } from "../../cinema/lib/engine";
import { useSoundFx, fmtDb, RG_MODES } from "../../cinema/lib/useSoundFx";
import { EQ_MAX_DB, EQ_MIN_DB, PREAMP_MAX_DB, PREAMP_MIN_DB, fmtFreq } from "../../shared/audioFx";
import type { DictKey } from "../../cinema/i18n";
import { useSettings } from "../../cinema/store/settings";
import { useAlokUi } from "../store/alokUi";
import { useT } from "../../cinema/lib/useT";

const SLEEP_OPTIONS = [0, 5, 15, 30, 60]; // 0 = end of track
const SPEED_CHIPS = [0.75, 1, 1.25, 1.5, 2];

export function FxSheet() {
  const t = useT();
  const show = useAlokUi((s) => s.showFx);
  const setShow = useAlokUi((s) => s.setShowFx);
  const settings = useSettings();
  const [, force] = useState(0); // re-render for countdown + engine-driven chips

  // engine pushes coarse state (play/pause/sleep changes) — reflect instantly
  useEffect(() => engine.on("state", () => force((n) => n + 1)), []);

  // countdown tick while a timed sleep is active
  useEffect(() => {
    if (!show || engine.sleepMode !== "timed") return;
    const iv = window.setInterval(() => force((n) => n + 1), 1000);
    return () => window.clearInterval(iv);
  }, [show, engine.sleepMode]);

  const fx = useSoundFx();
  const rgOff = fx.rg.mode === "off";
  const speed = settings.speed ?? 1;

  const sleepActive = engine.sleepMode !== "off";
  const remainMs = Math.max(0, engine.sleepEndsAtMs - Date.now());
  const remainLabel = `${Math.floor(remainMs / 60000)}:${String(Math.floor((remainMs % 60000) / 1000)).padStart(2, "0")}`;

  const speedPct = Math.round(((speed - 0.5) / (2 - 0.5)) * 100);

  return (
    <AnimatePresence>
      {show && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="na-panel-scrim"
            style={{ zIndex: 54, background: "color-mix(in srgb, #050507 45%, transparent)" }}
            onClick={() => setShow(false)}
            aria-hidden
          />
          <motion.div
            className="na-fx"
            role="dialog"
            aria-label={t("alFx")}
            initial={{ y: 120, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 120, opacity: 0 }}
            transition={{ duration: 0.36, ease: [0.22, 1, 0.36, 1] }}
            style={{ willChange: "transform, opacity" }}
          >
            <div className="na-sheet-head">
              <div className="na-sheet-title">{t("alFx")}</div>
              <button className="na-panel-x" onClick={() => setShow(false)} title={t("close")} aria-label={t("close")}>
                <X size={15} />
              </button>
            </div>

            <div className="na-scroll min-h-0 flex-1">
              {/* ── equalizer (V1.6.2 · P3: 6/10 bands, preamp, shared presets) ── */}
              <section className="na-fx-section">
                <div className="na-fx-head">
                  <span className="na-fx-label">{t("alEq")}</span>
                  <span className="flex items-center gap-2.5">
                    <span className="na-seg" role="group" aria-label={t("fxBands")} style={{ padding: 2 }}>
                      {([6, 10] as const).map((b) => (
                        <button
                          key={b}
                          className="na-seg-btn na-mono"
                          style={{ padding: "3px 10px", fontSize: 10.5 }}
                          data-on={fx.bands === b}
                          aria-pressed={fx.bands === b}
                          onClick={() => fx.setBands(b)}
                        >
                          {b}
                        </button>
                      ))}
                    </span>
                    <span
                      role="switch"
                      aria-checked={fx.eqOn}
                      tabIndex={0}
                      className="na-switch"
                      data-on={fx.eqOn}
                      onClick={fx.toggleEq}
                      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fx.toggleEq(); } }}
                      aria-label={t("alEq")}
                    />
                  </span>
                </div>

                <div className="na-eq-grid" style={{ opacity: fx.eqOn ? 1 : 0.4 }}>
                  <div className="na-eq-band" style={{ flex: "none", paddingInlineEnd: 6, borderInlineEnd: "1px solid var(--na-line-soft)" }}>
                    <span className="na-eq-val">{fmtDb(fx.preamp)}</span>
                    <input
                      type="range"
                      min={PREAMP_MIN_DB}
                      max={PREAMP_MAX_DB}
                      step={0.5}
                      value={fx.preamp}
                      onChange={(e) => fx.setPreamp(Number(e.target.value))}
                      onDoubleClick={() => fx.setPreamp(0)}
                      className="na-vert"
                      disabled={!fx.eqOn}
                      aria-label={t("fxPreamp")}
                      title={t("fxPreampSub")}
                    />
                    <span className="na-eq-hz" style={{ color: "var(--na-accent)" }}>PRE</span>
                  </div>
                  {fx.freqs.map((f, i) => (
                    <div key={`${fx.bands}-${f}`} className="na-eq-band">
                      <span className="na-eq-val">{fmtDb(fx.gains[i] ?? 0)}</span>
                      <input
                        type="range"
                        min={EQ_MIN_DB}
                        max={EQ_MAX_DB}
                        step={0.5}
                        value={fx.gains[i] ?? 0}
                        onChange={(e) => fx.setGain(i, Number(e.target.value))}
                        onDoubleClick={() => fx.setGain(i, 0)}
                        className="na-vert"
                        disabled={!fx.eqOn}
                        aria-label={`${f} Hz`}
                      />
                      <span className="na-eq-hz">{fmtFreq(f)}</span>
                    </div>
                  ))}
                </div>

                <div className="na-pill-row">
                  {fx.presets.map((name) => (
                    <button
                      key={name}
                      disabled={!fx.eqOn}
                      className="na-chip"
                      data-on={fx.activePreset === name}
                      onClick={() => fx.applyPreset(name)}
                    >
                      {t(`fxPreset_${name}` as DictKey)}
                    </button>
                  ))}
                  {fx.eqOn && !fx.activePreset && (
                    <span className="na-chip" data-on="true">{t("fxPresetCustom")}</span>
                  )}
                  {fx.eqOn && (fx.activePreset !== "flat" || Math.abs(fx.preamp) > 0.01) && (
                    <button className="na-chip" onClick={fx.resetEq}>{t("fxReset")}</button>
                  )}
                </div>
              </section>

              {/* ── volume leveling / ReplayGain (V1.6.2 · P3) ── */}
              <section className="na-fx-section">
                <div className="na-fx-head">
                  <span className="na-fx-label">{t("fxRg")}</span>
                  <span className="na-seg" role="group" aria-label={t("fxRg")} style={{ padding: 2 }}>
                    {RG_MODES.map((m) => (
                      <button
                        key={m}
                        className="na-seg-btn"
                        style={{ padding: "3px 10px", fontSize: 10.5 }}
                        data-on={fx.rg.mode === m}
                        aria-pressed={fx.rg.mode === m}
                        onClick={() => fx.setRg({ mode: m })}
                      >
                        {t(m === "off" ? "fxRgOff" : m === "track" ? "fxRgTrack" : "fxRgAlbum")}
                      </button>
                    ))}
                  </span>
                </div>
                <div className="text-[10.5px] leading-relaxed" style={{ fontSize: 10.5, color: "var(--na-faint)", marginBottom: 10 }}>
                  {t("fxRgSub")}
                </div>
                <div style={{ opacity: rgOff ? 0.4 : 1, pointerEvents: rgOff ? "none" : undefined, transition: "opacity 0.2s" }} aria-disabled={rgOff}>
                  <AlokDbRow label={t("fxRgPreamp")} value={fx.rg.preamp} min={-12} max={12} disabled={rgOff} onChange={(v) => fx.setRg({ preamp: v })} />
                  <AlokDbRow label={t("fxRgFallback")} value={fx.rg.fallback} min={-12} max={0} disabled={rgOff} onChange={(v) => fx.setRg({ fallback: v })} />
                  <div className="flex items-center justify-between" style={{ marginTop: 10 }}>
                    <span style={{ fontSize: 11.5, color: "var(--na-mut)" }}>{t("fxRgClip")}</span>
                    <span
                      role="switch"
                      aria-checked={fx.rg.preventClip}
                      tabIndex={rgOff ? -1 : 0}
                      className="na-switch"
                      data-on={fx.rg.preventClip}
                      onClick={() => fx.setRg({ preventClip: !fx.rg.preventClip })}
                      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); fx.setRg({ preventClip: !fx.rg.preventClip }); } }}
                      aria-label={t("fxRgClip")}
                    />
                  </div>
                  {fx.rgNow.hasTrack && (
                    <div className="na-mono flex items-center justify-between" style={{ marginTop: 10, paddingTop: 8, borderTop: "1px solid var(--na-line-soft)", fontSize: 10.5 }}>
                      <span style={{ color: "var(--na-faint)" }}>{t("fxRgNow")}</span>
                      <span style={{ color: "var(--na-accent)" }}>
                        {fmtDb(fx.rgNow.db)} dB{!fx.rgNow.tagged && <span style={{ color: "var(--na-faint)" }}> · {t("fxRgNoTag")}</span>}
                      </span>
                    </div>
                  )}
                </div>
                <div className="mt-2.5 text-[10.5px] leading-relaxed" style={{ fontSize: 10.5, color: "var(--na-faint)" }}>
                  {t("fxRgHint")}
                </div>
              </section>

              {/* ── speed ── */}
              <section className="na-fx-section">
                <div className="na-fx-head">
                  <span className="na-fx-label">{t("alSpeed")}</span>
                  <span className="na-mono text-[11px] text-[var(--na-mut)]" style={{ fontSize: 11 }}>
                    {speed.toFixed(2)}×
                  </span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={2}
                  step={0.05}
                  value={speed}
                  onChange={(e) => engine.setRate(Number(e.target.value))}
                  className="na-range w-full"
                  style={{ ["--na-val" as any]: `${speedPct}%` }}
                  aria-label={t("alSpeed")}
                />
                <div className="na-pill-row">
                  {SPEED_CHIPS.map((r) => (
                    <button
                      key={r}
                      className="na-chip na-mono"
                      data-on={Math.abs(speed - r) < 0.01}
                      onClick={() => engine.setRate(r)}
                    >
                      {r}×
                    </button>
                  ))}
                  {Math.abs(speed - 1) > 0.01 && (
                    <button className="na-chip" onClick={() => engine.setRate(1)}>
                      {t("fxReset")}
                    </button>
                  )}
                </div>
              </section>

              {/* ── sleep timer ── */}
              <section className="na-fx-section">
                <div className="na-fx-head">
                  <span className="na-fx-label">{t("alSleep")}</span>
                  {sleepActive && (
                    <span className="na-mono flex items-center gap-2 text-[11px]" style={{ fontSize: 11, color: "var(--na-accent)" }}>
                      <span
                        aria-hidden
                        style={{
                          width: 6,
                          height: 6,
                          borderRadius: 999,
                          background: "var(--na-accent)",
                          animation: "na-blink 1.1s steps(1) infinite",
                          display: "inline-block",
                        }}
                      />
                      {engine.sleepMode === "track" ? t("alSleepTrack") : remainLabel}
                      <button
                        onClick={() => engine.cancelSleepTimer()}
                        className="na-icon-btn"
                        style={{ width: 26, height: 26 }}
                        aria-label={t("fxSleepCancel")}
                      >
                        ×
                      </button>
                    </span>
                  )}
                </div>
                <div className="na-pill-row" style={{ marginTop: 0 }}>
                  {SLEEP_OPTIONS.map((m) => (
                    <button
                      key={m}
                      className="na-chip na-mono"
                      data-on={
                        (m === 0 && engine.sleepMode === "track") ||
                        (m > 0 && engine.sleepMode === "timed" && engine.sleepMinutes === m)
                      }
                      onClick={() => engine.startSleepTimer(m)}
                    >
                      {m === 0 ? t("alSleepTrack") : `${m} ${t("alMin")}`}
                    </button>
                  ))}
                </div>
                <div className="mt-2.5 text-[10.5px] leading-relaxed" style={{ fontSize: 10.5, color: "var(--na-faint)" }}>
                  {t("fxSleepHint")}
                </div>
              </section>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/** ReplayGain dB row: label, value, hairline range (ALOK styling). */
function AlokDbRow({ label, value, min, max, disabled, onChange }: {
  label: string; value: number; min: number; max: number; disabled?: boolean; onChange: (v: number) => void;
}) {
  const pct = Math.round(((value - min) / (max - min)) * 100);
  return (
    <div style={{ marginTop: 10 }}>
      <div className="flex items-center justify-between" style={{ marginBottom: 6 }}>
        <span style={{ fontSize: 11.5, color: "var(--na-mut)" }}>{label}</span>
        <span className="na-mono" style={{ fontSize: 11, color: "var(--na-mut)" }}>{fmtDb(value)} dB</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={0.5}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
        onDoubleClick={() => onChange(0)}
        className="na-range w-full"
        style={{ ["--na-val" as any]: `${pct}%` }}
        aria-label={label}
      />
    </div>
  );
}
