// ── NOBODY · playlist → track ids (manual AND smart), 1.7.0-dev.6 ───────────
// Every face shows playlist songs through these helpers, so a smart playlist
// looks exactly like a manual one to the views (counts, Play all, shuffle).

import { useCallback, useMemo } from "react";
import { useLibrary, LIKED_ID } from "../store/library";
import type { Playlist } from "../types";
import { smartIdsFor, type SmartInputs } from "./smartPlaylist";

const NONE: readonly string[] = [];

type LibState = ReturnType<typeof useLibrary.getState>;

function inputsOf(s: LibState): SmartInputs {
  return {
    tracks: s.tracks,
    order: s.order,
    playCounts: s.playCounts,
    ratings: s.ratings,
    lastPlayed: s.lastPlayed,
    likedIds: s.playlists.find((p) => p.id === LIKED_ID)?.trackIds ?? NONE,
  };
}

/** Non-React access (command palette actions, tests). */
export function playlistTrackIds(p: Playlist, s: LibState = useLibrary.getState()): string[] {
  if (p.smart) return smartIdsFor(p.id, p.smart, inputsOf(s));
  return p.trackIds.filter((id) => !!s.tracks[id]);
}

/** The inputs a smart playlist depends on, as one stable object. */
export function useSmartInputs(): SmartInputs {
  const tracks = useLibrary((s) => s.tracks);
  const order = useLibrary((s) => s.order);
  const playCounts = useLibrary((s) => s.playCounts);
  const ratings = useLibrary((s) => s.ratings);
  const lastPlayed = useLibrary((s) => s.lastPlayed);
  const likedIds = useLibrary((s) => s.playlists.find((p) => p.id === LIKED_ID)?.trackIds ?? NONE);
  return useMemo(
    () => ({ tracks, order, playCounts, ratings, lastPlayed, likedIds }),
    [tracks, order, playCounts, ratings, lastPlayed, likedIds]
  );
}

/** `(playlist) => ids` — cheap to call per row of a playlist rail. */
export function usePlaylistResolver(): (p: Playlist) => string[] {
  const inp = useSmartInputs();
  return useCallback(
    (p: Playlist) => (p.smart ? smartIdsFor(p.id, p.smart, inp) : p.trackIds.filter((id) => !!inp.tracks[id])),
    [inp]
  );
}

export function usePlaylistTrackIds(p: Playlist | null | undefined): string[] {
  const resolve = usePlaylistResolver();
  return useMemo(() => (p ? resolve(p) : []), [p, resolve]);
}

/** Stars of one track (0 = unrated); re-renders only when THAT rating changes. */
export function useRating(id: string | null | undefined): number {
  return useLibrary((s) => (id ? s.ratings[id] || 0 : 0));
}
