// ── NOBODY · smart playlists (1.7.0-dev.6, Phase 4 · part 5) ────────────────
// A smart playlist is a normal Playlist row with a `smart` definition: its
// songs are never stored, they are computed from the library every time the
// inputs change (tracks, play counts, ratings, likes, last-played times).
// Pure module: no React, no store reads (the store / hook pass a context in).
//
// Definition: match all/any of N rules → sort → optional limit.
// Text compare is case-, accent- and Arabic/Persian-letter-insensitive
// ("Café" = "cafe", "علي" = "علی"). Rules with an empty / invalid value are
// ignored (the editor flags them), so a half-typed rule never empties a list.

import type { Track } from "../types";
import { sortTracksBy, type TrackSortKey } from "./trackSort";
import { splitGenres } from "../../shared/replayGain";

export type SmartField =
  | "title" | "artist" | "album" | "genre" | "format" | "path"
  | "year" | "duration" | "bitrate" | "rating" | "plays"
  | "added" | "lastPlayed"
  | "liked";

export type SmartKind = "text" | "number" | "date" | "bool";

export type SmartOp =
  // text
  | "contains" | "notContains" | "is" | "isNot" | "startsWith" | "endsWith" | "isEmpty" | "isNotEmpty"
  // number
  | "eq" | "neq" | "gte" | "lte" | "between"
  // date
  | "inLast" | "notInLast" | "never"
  // bool
  | "isTrue" | "isFalse";

export type DateUnit = "days" | "weeks" | "months";

export interface SmartRule {
  id: string;
  field: SmartField;
  op: SmartOp;
  /** text value, or the (first) number */
  value?: string | number;
  /** upper bound for `between` */
  value2?: number;
  /** date rules */
  unit?: DateUnit;
}

export type SmartSortKey = TrackSortKey | "random";

export interface SmartLimit {
  n: number;
  unit: "songs" | "minutes" | "hours";
}

export interface SmartPlaylistDef {
  v: 1;
  match: "all" | "any";
  rules: SmartRule[];
  sort: { key: SmartSortKey; reverse: boolean };
  limit: SmartLimit | null;
  /** seed of the "random" order (new seed = reshuffle) */
  seed: number;
}

export const FIELD_KIND: Record<SmartField, SmartKind> = {
  title: "text", artist: "text", album: "text", genre: "text", format: "text", path: "text",
  year: "number", duration: "number", bitrate: "number", rating: "number", plays: "number",
  added: "date", lastPlayed: "date",
  liked: "bool",
};

export const SMART_FIELDS: SmartField[] = [
  "title", "artist", "album", "genre", "year", "rating", "plays", "liked",
  "lastPlayed", "added", "duration", "format", "bitrate", "path",
];

export const OPS_BY_KIND: Record<SmartKind, SmartOp[]> = {
  text: ["contains", "notContains", "is", "isNot", "startsWith", "endsWith", "isEmpty", "isNotEmpty"],
  number: ["eq", "neq", "gte", "lte", "between"],
  date: ["inLast", "notInLast", "never"],
  bool: ["isTrue", "isFalse"],
};

/** `never` only makes sense for "last played" (every song has an import date). */
export function opsFor(field: SmartField): SmartOp[] {
  const ops = OPS_BY_KIND[FIELD_KIND[field]];
  return field === "added" ? ops.filter((o) => o !== "never") : ops;
}

export const SMART_SORT_KEYS: SmartSortKey[] = [
  "imported", "title", "artist", "album", "rating", "plays", "recent", "duration", "random",
];

export const SMART_LIMIT_MAX = 100000;

export interface SmartCtx {
  playCounts: Record<string, number>;
  ratings: Record<string, number>;
  liked: ReadonlySet<string>;
  /** trackId → epoch ms of the last "genuine" play */
  lastPlayed: Record<string, number>;
  now?: number;
}

// ── text folding ─────────────────────────────────────────────────────────────

const ARABIC_TO_PERSIAN: Record<string, string> = { "\u064A": "\u06CC", "\u0649": "\u06CC", "\u0643": "\u06A9", "\u0629": "\u0647" };

export function fold(s: string | undefined | null): string {
  if (!s) return "";
  return s
    .normalize("NFKD")
    .replace(/[\u0300-\u036f\u064B-\u065F\u0670]/g, "") // Latin accents + Arabic harakat
    .replace(/[\u064A\u0649\u0643\u0629]/g, (c) => ARABIC_TO_PERSIAN[c] || c)
    .replace(/\u200C/g, " ") // ZWNJ
    .replace(/\s+/g, " ")
    .trim()
    .toLocaleLowerCase();
}

// ── rule evaluation ──────────────────────────────────────────────────────────

const DAY = 86400000;
const UNIT_MS: Record<DateUnit, number> = { days: DAY, weeks: 7 * DAY, months: 30 * DAY };

function textOf(tr: Track, f: SmartField): string {
  switch (f) {
    case "title": return tr.title;
    case "artist": return tr.artist;
    case "album": return tr.album === "Unknown Album" ? "" : tr.album;
    case "genre": return tr.genre || "";
    case "format": return tr.format || "";
    case "path": return tr.filePath || tr.fileName || "";
    default: return "";
  }
}

function yearOf(tr: Track): number {
  const m = /\d{4}/.exec(tr.year || "");
  return m ? +m[0] : NaN;
}

function numberOf(tr: Track, f: SmartField, ctx: SmartCtx): number {
  switch (f) {
    case "year": return yearOf(tr);
    case "duration": return tr.duration || 0;
    case "bitrate": return bitrateOf(tr.bitrate);
    case "rating": return ctx.ratings[tr.id] || 0;
    case "plays": return ctx.playCounts[tr.id] || 0;
    default: return NaN;
  }
}

/** Bridged rows used to carry "320 kbps" strings: read the number either way. */
function bitrateOf(v: unknown): number {
  if (typeof v === "number") return isFinite(v) ? v : 0;
  const m = typeof v === "string" ? /\d+/.exec(v) : null;
  return m ? +m[0] : 0;
}

const num = (v: unknown): number => (typeof v === "number" ? v : typeof v === "string" && v.trim() !== "" ? Number(v) : NaN);

/** Does this rule constrain anything? Half-typed rules are skipped. */
export function ruleIsActive(r: SmartRule): boolean {
  const kind = FIELD_KIND[r.field];
  if (!kind || !opsFor(r.field).includes(r.op)) return false;
  if (kind === "bool") return true;
  if (kind === "text") return r.op === "isEmpty" || r.op === "isNotEmpty" || fold(String(r.value ?? "")) !== "";
  if (kind === "date") return r.op === "never" || (isFinite(num(r.value)) && num(r.value) > 0);
  // number
  if (!isFinite(num(r.value))) return false;
  return r.op !== "between" || isFinite(num(r.value2));
}

type Pred = (tr: Track) => boolean;

function compile(r: SmartRule, ctx: SmartCtx, now: number): Pred {
  const kind = FIELD_KIND[r.field];
  if (kind === "bool") {
    // liked is the only boolean field
    return r.op === "isTrue" ? (tr) => ctx.liked.has(tr.id) : (tr) => !ctx.liked.has(tr.id);
  }
  if (kind === "text") {
    const v = fold(String(r.value ?? ""));
    const isGenre = r.field === "genre";
    const all = (tr: Track) => fold(textOf(tr, r.field));
    // genre "is / is not" compares against EACH value of a multi-genre tag
    const parts = (tr: Track) => (isGenre ? splitGenres(tr.genre).map(fold) : [all(tr)]);
    switch (r.op) {
      case "contains": return (tr) => all(tr).includes(v);
      case "notContains": return (tr) => !all(tr).includes(v);
      case "is": return (tr) => parts(tr).includes(v);
      case "isNot": return (tr) => !parts(tr).includes(v);
      case "startsWith": return (tr) => parts(tr).some((p) => p.startsWith(v));
      case "endsWith": return (tr) => parts(tr).some((p) => p.endsWith(v));
      case "isEmpty": return (tr) => all(tr) === "";
      case "isNotEmpty": return (tr) => all(tr) !== "";
      default: return () => true;
    }
  }
  if (kind === "date") {
    const at = r.field === "added" ? (tr: Track) => tr.addedAt || tr.importedAt || 0 : (tr: Track) => ctx.lastPlayed[tr.id] || 0;
    if (r.op === "never") return (tr) => !at(tr);
    const cutoff = now - num(r.value) * UNIT_MS[r.unit || "days"];
    if (r.op === "inLast") return (tr) => { const a = at(tr); return a > 0 && a >= cutoff; };
    // notInLast: only songs that HAVE a date (never played → use "never")
    return (tr) => { const a = at(tr); return a > 0 && a < cutoff; };
  }
  // number — duration is stored in seconds, edited in minutes
  const scale = r.field === "duration" ? 60 : 1;
  const a = num(r.value) * scale;
  const b = num(r.value2) * scale;
  const val = (tr: Track) => numberOf(tr, r.field, ctx);
  // duration minutes are typed with 1 decimal at most → compare within half a second
  const eps = r.field === "duration" ? 0.5 : 1e-9;
  switch (r.op) {
    case "eq": return (tr) => Math.abs(val(tr) - a) <= eps;
    case "neq": return (tr) => { const x = val(tr); return !isFinite(x) || Math.abs(x - a) > eps; };
    case "gte": return (tr) => val(tr) >= a - eps;
    case "lte": return (tr) => val(tr) <= a + eps;
    case "between": {
      const lo = Math.min(a, b), hi = Math.max(a, b);
      return (tr) => { const x = val(tr); return x >= lo - eps && x <= hi + eps; };
    }
    default: return () => true;
  }
}

/** Seeded, stable "random" order: same seed → same order (no reshuffle on every render). */
function hashOrder(id: string, seed: number): number {
  let h = (seed ^ 0x9e3779b9) >>> 0;
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  h ^= h >>> 15;
  h = Math.imul(h, 0x2c1b3c6d) >>> 0;
  return h ^ (h >>> 12);
}

/** All matching tracks, sorted and limited. `library` = tracks in library order. */
export function evaluateSmart(def: SmartPlaylistDef, library: readonly Track[], ctx: SmartCtx): Track[] {
  const now = ctx.now ?? Date.now();
  const preds = def.rules.filter(ruleIsActive).map((r) => compile(r, ctx, now));
  let hits: Track[];
  if (!preds.length) hits = library.slice();
  else if (def.match === "any") hits = library.filter((tr) => preds.some((p) => p(tr)));
  else hits = library.filter((tr) => preds.every((p) => p(tr)));

  if (def.sort.key === "random") {
    const keyed = hits.map((tr) => [hashOrder(tr.id, def.seed), tr] as const);
    keyed.sort((x, y) => x[0] - y[0]);
    hits = keyed.map((k) => k[1]);
  } else {
    let recentRank: Map<string, number> | undefined;
    if (def.sort.key === "recent") {
      // rank by last-played time (the full history, not just the 60 recents)
      const played = hits.filter((tr) => ctx.lastPlayed[tr.id]).sort((x, y) => ctx.lastPlayed[y.id] - ctx.lastPlayed[x.id]);
      recentRank = new Map(played.map((tr, i) => [tr.id, i]));
    }
    hits = sortTracksBy(hits, def.sort.key, def.sort.reverse, { playCounts: ctx.playCounts, ratings: ctx.ratings, recentRank });
  }

  const lim = def.limit;
  if (lim && lim.n > 0) {
    if (lim.unit === "songs") hits = hits.slice(0, lim.n);
    else {
      const cap = lim.n * (lim.unit === "hours" ? 3600 : 60);
      const out: Track[] = [];
      let total = 0;
      for (const tr of hits) {
        const d = tr.duration || 0;
        if (total + d > cap) break;
        total += d;
        out.push(tr);
      }
      hits = out;
    }
  }
  return hits;
}

// ── defaults, templates, validation ──────────────────────────────────────────

let ruleSeq = 0;
export const newRuleId = () => `r${Date.now().toString(36)}${(ruleSeq++).toString(36)}`;

export function defaultRule(field: SmartField = "artist"): SmartRule {
  const kind = FIELD_KIND[field];
  const op = opsFor(field)[0];
  const r: SmartRule = { id: newRuleId(), field, op };
  if (kind === "text") r.value = "";
  if (kind === "number") r.value = field === "rating" ? 4 : field === "year" ? new Date().getFullYear() : field === "plays" ? 5 : "";
  if (kind === "date") { r.value = 30; r.unit = "days"; }
  if (field === "rating") r.op = "gte";
  return r;
}

/** Keep what still fits after the field changed (e.g. text → number). */
export function retypeRule(r: SmartRule, field: SmartField): SmartRule {
  if (FIELD_KIND[field] === FIELD_KIND[r.field] && opsFor(field).includes(r.op)) return { ...r, field };
  return { ...defaultRule(field), id: r.id };
}

export function emptyDef(): SmartPlaylistDef {
  return {
    v: 1,
    match: "all",
    rules: [defaultRule("artist")],
    sort: { key: "imported", reverse: false },
    limit: null,
    seed: (Math.random() * 0x7fffffff) | 0,
  };
}

export type SmartTemplateId = "topRated" | "recentlyAdded" | "neverPlayed" | "heavyRotation" | "forgotten" | "random50";

export const SMART_TEMPLATES: SmartTemplateId[] = ["topRated", "recentlyAdded", "heavyRotation", "neverPlayed", "forgotten", "random50"];

export function templateDef(id: SmartTemplateId): SmartPlaylistDef {
  const base = emptyDef();
  const rule = (field: SmartField, op: SmartOp, value?: number, unit?: DateUnit): SmartRule => ({ id: newRuleId(), field, op, value, unit });
  switch (id) {
    case "topRated":
      return { ...base, rules: [rule("rating", "gte", 4)], sort: { key: "rating", reverse: false } };
    case "recentlyAdded":
      return { ...base, rules: [rule("added", "inLast", 30, "days")], sort: { key: "imported", reverse: false } };
    case "heavyRotation":
      return { ...base, rules: [rule("lastPlayed", "inLast", 30, "days"), rule("plays", "gte", 3)], sort: { key: "plays", reverse: false }, limit: { n: 50, unit: "songs" } };
    case "neverPlayed":
      return { ...base, rules: [rule("lastPlayed", "never")], sort: { key: "random", reverse: false } };
    case "forgotten":
      return { ...base, rules: [rule("rating", "gte", 4), rule("lastPlayed", "notInLast", 3, "months")], sort: { key: "random", reverse: false } };
    case "random50":
      return { ...base, rules: [], sort: { key: "random", reverse: false }, limit: { n: 50, unit: "songs" } };
  }
}

const isObj = (x: unknown): x is Record<string, unknown> => !!x && typeof x === "object" && !Array.isArray(x);

/** Sanitise a stored / imported definition. Unknown or broken parts are dropped, never thrown. */
export function normalizeSmartDef(raw: unknown): SmartPlaylistDef | null {
  if (!isObj(raw)) return null;
  const rules: SmartRule[] = [];
  if (Array.isArray(raw.rules)) {
    for (const x of raw.rules.slice(0, 50)) {
      if (!isObj(x)) continue;
      const field = x.field as SmartField;
      if (!FIELD_KIND[field]) continue;
      const op = x.op as SmartOp;
      if (!opsFor(field).includes(op)) continue;
      const r: SmartRule = { id: typeof x.id === "string" && x.id ? x.id : newRuleId(), field, op };
      const kind = FIELD_KIND[field];
      if (kind === "text") r.value = typeof x.value === "string" ? x.value.slice(0, 500) : "";
      if (kind === "number" || kind === "date") {
        const n = num(x.value);
        r.value = isFinite(n) ? n : "";
        if (op === "between") { const n2 = num(x.value2); if (isFinite(n2)) r.value2 = n2; }
      }
      if (kind === "date") r.unit = x.unit === "weeks" || x.unit === "months" ? x.unit : "days";
      rules.push(r);
    }
  }
  const sortRaw = isObj(raw.sort) ? raw.sort : {};
  const key = SMART_SORT_KEYS.includes(sortRaw.key as SmartSortKey) ? (sortRaw.key as SmartSortKey) : "imported";
  let limit: SmartLimit | null = null;
  if (isObj(raw.limit)) {
    const n = Math.floor(num(raw.limit.n));
    const unit = raw.limit.unit === "minutes" || raw.limit.unit === "hours" ? raw.limit.unit : "songs";
    if (isFinite(n) && n > 0) limit = { n: Math.min(n, SMART_LIMIT_MAX), unit };
  }
  const seed = Math.floor(num(raw.seed));
  return {
    v: 1,
    match: raw.match === "any" ? "any" : "all",
    rules,
    sort: { key, reverse: !!sortRaw.reverse },
    limit,
    seed: isFinite(seed) ? seed | 0 : 1,
  };
}

/** Per-rule validation for the editor (null = fine). */
export function ruleError(r: SmartRule): null | "value" | "range" {
  const kind = FIELD_KIND[r.field];
  if (kind === "bool" || r.op === "isEmpty" || r.op === "isNotEmpty" || r.op === "never") return null;
  if (kind === "text") return fold(String(r.value ?? "")) ? null : "value";
  const a = num(r.value);
  if (!isFinite(a) || a < 0) return "value";
  if (kind === "date" && a <= 0) return "value";
  if (r.field === "rating" && a > 5) return "range";
  if (r.op === "between") {
    const b = num(r.value2);
    if (!isFinite(b) || b < 0) return "value";
    if (r.field === "rating" && b > 5) return "range";
  }
  return null;
}

// ── memoised resolution (one cache entry per smart playlist) ─────────────────

export interface SmartInputs {
  tracks: Record<string, Track>;
  order: string[];
  playCounts: Record<string, number>;
  ratings: Record<string, number>;
  lastPlayed: Record<string, number>;
  /** the Liked playlist's trackIds array (identity changes on every like) */
  likedIds: readonly string[];
}

interface CacheEntry { def: SmartPlaylistDef; in: SmartInputs; minute: number; ids: string[] }
const cache = new Map<string, CacheEntry>();
let libCache: { tracks: Record<string, Track>; order: string[]; list: Track[] } | null = null;
let likedCache: { ids: readonly string[]; set: Set<string> } | null = null;

function sameInputs(a: SmartInputs, b: SmartInputs) {
  return a.tracks === b.tracks && a.order === b.order && a.playCounts === b.playCounts &&
    a.ratings === b.ratings && a.lastPlayed === b.lastPlayed && a.likedIds === b.likedIds;
}

/** Track ids of a smart playlist. Re-evaluated only when an input (or the
 *  minute, for "in the last N days" rules) changes. */
export function smartIdsFor(pid: string, def: SmartPlaylistDef, inp: SmartInputs, now = Date.now()): string[] {
  const minute = Math.floor(now / 60000);
  const hit = cache.get(pid);
  const timeRules = def.rules.some((r) => FIELD_KIND[r.field] === "date" && r.op !== "never");
  if (hit && hit.def === def && sameInputs(hit.in, inp) && (!timeRules || hit.minute === minute)) return hit.ids;
  if (!libCache || libCache.tracks !== inp.tracks || libCache.order !== inp.order) {
    libCache = { tracks: inp.tracks, order: inp.order, list: inp.order.map((id) => inp.tracks[id]).filter(Boolean) };
  }
  if (!likedCache || likedCache.ids !== inp.likedIds) likedCache = { ids: inp.likedIds, set: new Set(inp.likedIds) };
  const ids = evaluateSmart(def, libCache.list, {
    playCounts: inp.playCounts,
    ratings: inp.ratings,
    lastPlayed: inp.lastPlayed,
    liked: likedCache.set,
    now,
  }).map((tr) => tr.id);
  cache.set(pid, { def, in: inp, minute, ids });
  return ids;
}

export function dropSmartCache(pid?: string) {
  if (pid) cache.delete(pid);
  else cache.clear();
}
