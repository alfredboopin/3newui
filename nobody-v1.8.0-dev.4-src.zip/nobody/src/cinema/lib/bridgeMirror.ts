// 1.7.0-dev.8: ONE live mirror of the classic library for every engine face.
// Only the visible face is mounted (AppSwitch RAM fix), and only Cinema used
// to subscribe to the bridge. Booting straight into EELA or ALOK on desktop
// hydrated against classic's still-empty library (its folder import is async),
// so the library stayed empty, the deferred resume never retried, and rescans,
// imports and tag edits never reached those faces.
import { useEffect } from "react";
import { getBridge } from "./desktopBridge";
import { useLibrary } from "../store/library";
import { engine } from "./engine";
import { getUiMode } from "../../uiMode";

let users = 0;
let unsub: (() => void) | null = null;
let timer = 0;

function onBridgeChange() {
  window.clearTimeout(timer);
  timer = window.setTimeout(() => {
    void useLibrary.getState().rehydrateTracks().then(() => {
      // classic re-imports its folders ASYNC at boot: the first restoreResume()
      // ran against an empty mirror and deferred; retry now that it filled.
      if (getUiMode() !== "classic") engine.retryDeferredResume();
    });
  }, 250);
}

/** Ref-counted: safe under StrictMode double effects and face switches. */
export function acquireBridgeMirror(): () => void {
  const bridge = getBridge();
  if (!bridge) return () => undefined;
  if (users++ === 0) {
    unsub = bridge.subscribe(onBridgeChange);
    // changes that landed before anyone listened (boot import finished
    // between hydrate() and this effect) are caught by one catch-up pass
    onBridgeChange();
  }
  let released = false;
  return () => {
    if (released) return;
    released = true;
    if (--users === 0) {
      window.clearTimeout(timer);
      unsub?.();
      unsub = null;
    }
  };
}

export function useBridgeMirror() {
  useEffect(() => acquireBridgeMirror(), []);
}
