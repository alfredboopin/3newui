// ── NOBODY · queue actions shared by the Cinema / EELA / ALOK queue sheets ────

import { engine } from "./engine";
import { useLibrary } from "../store/library";
import { useSettings } from "../store/settings";
import { uiApi } from "../store/ui";

type T = (k: string) => string;

/** V1.6.4 (P3): save the queue, in LISTEN order, as a new playlist.
 *  Name = "Queue · <date time>" (made unique); duplicates collapse to their
 *  first occurrence, same rule as addToPlaylist. Returns the playlist id. */
export function saveQueueAsPlaylist(t: T): string | null {
  const ids = engine.queueIds;
  if (!ids.length) return null;
  const lib = useLibrary.getState();
  const lang = useSettings.getState().lang || "en";
  let stamp = "";
  try {
    stamp = new Intl.DateTimeFormat(lang, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date());
  } catch {
    stamp = new Date().toLocaleString();
  }
  const base = `${t("queueDefaultName")} · ${stamp}`;
  const taken = new Set(lib.playlists.map((p) => p.name));
  let name = base;
  for (let n = 2; taken.has(name); n++) name = `${base} (${n})`;
  const id = lib.createPlaylistFrom(name, ids);
  uiApi.toast(`${t("queueSavedAs")} “${name}”`, "success");
  return id;
}

/** "Play next" + toast, for row menus in every engine face. */
export function playNextWithToast(id: string, title: string, t: T) {
  engine.playNext(id);
  uiApi.toast(`${t("playNext")} · ${title}`, "success");
}
