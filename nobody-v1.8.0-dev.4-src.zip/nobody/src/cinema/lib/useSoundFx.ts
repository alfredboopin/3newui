// ── NOBODY · useSoundFx (V1.6.2, Phase 3 part 2b) ────────────────────────────
// Headless state + actions for the Sound controls (EQ 6/10 bands, preamp,
// shared presets, ReplayGain). Cinema's FxSheet, ALOK's FxSheet and EELA's
// Settings › Sound card all render from this hook, so they can't drift apart.
//
// Reads come from the settings store (the engine's source of truth, see
// engine.ts syncEqFromSettings / applyReplayGainAll); writes go through the
// engine API so the WebAudio chain updates in the same tick.

import { useSettings } from "../store/settings";
import { useUi } from "../store/ui";
import { useLibrary } from "../store/library";
import { engine } from "./engine";
import { EQ_PRESET_IDS, eqFreqs, matchPreset, readEqConfig, type EqBandCount } from "../../shared/audioFx";
import {
  hasReplayGain,
  readReplayGainPrefs,
  replayGainFactor,
  type ReplayGainMode,
  type ReplayGainPrefs,
} from "../../shared/replayGain";

export const RG_MODES: ReplayGainMode[] = ["off", "track", "album"];

/** "+1.5" / "0.0" / "−3.0" (real minus sign reads better in RTL too). */
export function fmtDb(v: number, digits = 1): string {
  const n = Math.abs(v) < 0.05 ? 0 : v;
  const s = Math.abs(n).toFixed(digits);
  return n > 0 ? `+${s}` : n < 0 ? `\u2212${s}` : s;
}

export interface SoundFx {
  eqOn: boolean;
  bands: EqBandCount;
  freqs: readonly number[];
  gains: number[];
  preamp: number;
  /** preset id the curve equals, null = custom (only while the EQ is on) */
  activePreset: string | null;
  presets: string[];
  rg: ReplayGainPrefs;
  /** now-playing readout: dB applied by ReplayGain, whether the track is tagged */
  rgNow: { hasTrack: boolean; tagged: boolean; db: number };

  toggleEq: () => void;
  setGain: (i: number, db: number) => void;
  setBands: (b: EqBandCount) => void;
  setPreamp: (db: number) => void;
  applyPreset: (id: string) => void;
  resetEq: () => void;
  setRg: (patch: Partial<ReplayGainPrefs>) => void;
}

export function useSoundFx(): SoundFx {
  // narrow selectors: a slider drag elsewhere in settings doesn't re-render us
  const eqEnabled = useSettings((s) => s.eqEnabled);
  const eqBands = useSettings((s) => s.eqBands);
  const eqGains = useSettings((s) => s.eqGains);
  const eqPreamp = useSettings((s) => s.eqPreamp);
  const replayGain = useSettings((s) => s.replayGain);
  const rgPreamp = useSettings((s) => s.rgPreamp);
  const rgFallback = useSettings((s) => s.rgFallback);
  const rgPreventClip = useSettings((s) => s.rgPreventClip);
  const currentId = useUi((s) => s.currentId);
  const curRg = useLibrary((s) => (currentId ? s.tracks[currentId]?.rg : undefined));

  const cfg = readEqConfig({ eqEnabled, eqBands, eqGains, eqPreamp });
  const rg = readReplayGainPrefs({ replayGain, rgPreamp, rgFallback, rgPreventClip });
  const factor = replayGainFactor(curRg, rg);

  return {
    eqOn: cfg.enabled,
    bands: cfg.bands,
    freqs: eqFreqs(cfg.bands),
    gains: cfg.gains,
    preamp: cfg.preampDb,
    activePreset: cfg.enabled ? matchPreset(cfg.gains, cfg.bands) : null,
    presets: EQ_PRESET_IDS,
    rg,
    rgNow: {
      hasTrack: !!currentId,
      tagged: hasReplayGain(curRg),
      db: factor > 0 ? 20 * Math.log10(factor) : 0,
    },

    toggleEq: () => engine.setEq(!cfg.enabled, cfg.gains),
    setGain: (i, db) => {
      const next = [...cfg.gains];
      next[i] = db;
      engine.setEq(cfg.enabled, next);
    },
    setBands: (b) => {
      // a named preset stays that preset (its hand-tuned curve for the other
      // layout); a custom curve is resampled by the engine
      const keep = cfg.enabled ? matchPreset(cfg.gains, cfg.bands) : null;
      engine.setEqBands(b);
      if (keep) engine.applyEqPreset(keep);
    },
    setPreamp: (db) => engine.setEqPreamp(db),
    applyPreset: (id) => engine.applyEqPreset(id),
    resetEq: () => {
      engine.setEqPreamp(0);
      engine.applyEqPreset("flat");
    },
    setRg: (patch) => engine.setReplayGain(patch),
  };
}
