// ── NOBODY · shared track sorting (V1.6.5, Phase 3 part 4) ───────────────────
// One comparator set for Cinema / EELA / ALOK so "Title" or "Album" means the
// same thing in every face. Pure functions: no React, no store reads.
//
// Natural direction per key (what the label promises), `reverse` flips it:
//   recent   → most recently played first      (never-played always last)
//   imported → newest import first             ("Recently added")
//   title / artist / album → A→Z, numeric-aware ("Track 2" < "Track 10")
//   duration → longest first
//   plays    → most played first
//   rating   → highest rated first (1.7.0-dev.6; unrated songs always last)
// Empty artist/album values always sink to the end, in both directions.
// Tie-breaks keep albums in file order (01 - …, 02 - …) under Album/Artist.

import type { Track } from "../types";

export type TrackSortKey = "recent" | "imported" | "title" | "artist" | "album" | "duration" | "plays" | "rating";

export const ALL_SORT_KEYS: TrackSortKey[] = ["recent", "imported", "title", "artist", "album", "duration", "plays", "rating"];

export interface SortCtx {
  playCounts?: Record<string, number>;
  /** 1.7.0-dev.6: trackId → stars 1..5 (missing / 0 = unrated) */
  ratings?: Record<string, number>;
  /** trackId → recents index (0 = most recent) */
  recentRank?: Map<string, number>;
}

const collator = new Intl.Collator(undefined, { numeric: true, sensitivity: "base" });
const txt = (a: string | undefined, b: string | undefined) => collator.compare(a || "", b || "");
const file = (a: Track, b: Track) => txt(a.filePath || a.fileName, b.filePath || b.fileName);

type Cmp = (a: Track, b: Track) => number;

function comparator(key: TrackSortKey, ctx: SortCtx): Cmp {
  const plays = ctx.playCounts || {};
  const rank = ctx.recentRank;
  const stars = ctx.ratings || {};
  switch (key) {
    case "recent":
      return (a, b) => (rank?.get(a.id) ?? 0) - (rank?.get(b.id) ?? 0) || txt(a.title, b.title);
    case "imported":
      return (a, b) => (b.importedAt || 0) - (a.importedAt || 0) || file(a, b);
    case "title":
      return (a, b) => txt(a.title, b.title) || txt(a.artist, b.artist) || file(a, b);
    case "artist":
      return (a, b) => txt(a.artist, b.artist) || txt(a.album, b.album) || file(a, b);
    case "album":
      return (a, b) => txt(a.album, b.album) || txt(a.artist, b.artist) || file(a, b);
    case "duration":
      return (a, b) => (b.duration || 0) - (a.duration || 0) || txt(a.title, b.title);
    case "plays":
      return (a, b) => (plays[b.id] || 0) - (plays[a.id] || 0) || txt(a.title, b.title);
    case "rating":
      return (a, b) => (stars[b.id] || 0) - (stars[a.id] || 0) || txt(a.artist, b.artist) || txt(a.title, b.title);
  }
}

/** Items with no value for the key: kept at the end in BOTH directions. */
function missing(key: TrackSortKey, tr: Track, ctx: SortCtx): boolean {
  if (key === "recent") return !ctx.recentRank?.has(tr.id);
  if (key === "artist") return !tr.artist?.trim();
  if (key === "album") return !tr.album?.trim();
  if (key === "rating") return !((ctx.ratings?.[tr.id] ?? 0) > 0);
  return false;
}

/** New sorted array (input untouched). Stable. */
export function sortTracksBy(list: readonly Track[], key: TrackSortKey, reverse = false, ctx: SortCtx = {}): Track[] {
  const cmp = comparator(key, ctx);
  const have: Track[] = [];
  const none: Track[] = [];
  for (const tr of list) (missing(key, tr, ctx) ? none : have).push(tr);
  have.sort(reverse ? (a, b) => cmp(b, a) : cmp);
  // the "no value" tail keeps a sensible order of its own (by title)
  if (none.length > 1) none.sort((a, b) => txt(a.title, b.title) || file(a, b));
  return none.length ? have.concat(none) : have;
}

export function recentRankOf(recents: readonly { trackId: string }[]): Map<string, number> {
  const m = new Map<string, number>();
  recents.forEach((r, i) => { if (!m.has(r.trackId)) m.set(r.trackId, i); });
  return m;
}

// ── persisted choice per face ────────────────────────────────────────────────

export interface SortPref { key: TrackSortKey; reverse: boolean }

export function loadSortPref(storageKey: string, allowed: readonly TrackSortKey[], fallback: TrackSortKey): SortPref {
  try {
    const raw = localStorage.getItem(storageKey);
    if (raw) {
      const p = JSON.parse(raw) as Partial<SortPref> | null;
      if (p && allowed.includes(p.key as TrackSortKey)) return { key: p.key as TrackSortKey, reverse: !!p.reverse };
    }
  } catch { /* corrupt → default */ }
  return { key: fallback, reverse: false };
}

export function saveSortPref(storageKey: string, pref: SortPref) {
  try { localStorage.setItem(storageKey, JSON.stringify(pref)); } catch { /* best-effort */ }
}

/** i18n key of each sort label (shared dict). */
export const SORT_LABEL_KEY: Record<TrackSortKey, string> = {
  recent: "recentlyPlayed",
  imported: "sortImported",
  title: "sortTitle",
  artist: "sortArtist",
  album: "sortAlbum",
  duration: "sortDuration",
  plays: "sortPlays",
  rating: "sortRating",
};
