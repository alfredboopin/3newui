// ── NOBODY · audio engine (module singleton) ─────────────────────────────────
// HTMLAudioElement + WebAudio analyser. Coarse events only — the per-frame
// hooks (currentTime, analyser bytes) are read directly by components via rAF,
// never funneled through React state.

import { db } from "./db";
import { Emitter, clamp } from "./utils";
import { getBridge } from "./desktopBridge";
import { useLibrary } from "../store/library";
import { useUi, uiApi } from "../store/ui";
import { useSettings } from "../store/settings";
import type { RepeatMode } from "../types";
import { onMediaKey } from "../../mediaKeys";
import { getUiMode } from "../../uiMode";
import { FxChain, EQ_FREQS_6, eqFreqs, fitGains, normBands, clampPreamp, presetGains, readEqConfig, type EqBandCount } from "../../shared/audioFx";
import { listenTracker } from "../../shared/stats/listenTracker";
import { readReplayGainPrefs, replayGainFactor, type ReplayGainPrefs } from "../../shared/replayGain";

const RESUME_KEY = "nobody-resume";

// ── V1.6.0 (P3): gapless + crossfade ─────────────────────────────────────────
/** Gapless: the next element starts this many seconds before the current
 *  one ends, with a tiny equal-power overlap so the seam has no click. */
const GAPLESS_LEAD_S = 0.045;
const GAPLESS_OVERLAP_S = 0.03;
/** Start buffering the next track this long before the transition point. */
const PRELOAD_AHEAD_S = 12;
const MAX_CROSSFADE_S = 12;
// ── V1.7.0 (P4 · part 3): hot reload after a tag rewrite ─────────────────────
/** Swap overlap when the same song moves to a fresh element. */
const HOT_SWAP_OVERLAP_S = 0.03;
/** Seek the fresh element this far ahead of the live one, then wait for
 *  the live one to catch up (a seek + canplay usually takes < 150 ms). */
const HOT_SEEK_LEAD_S = 0.3;
/** Start-up latency compensation when timing the start. Measured in
 *  Chromium: both elements share one output path, so 0 lands within
 *  ±2 ms (0.02 left the fresh element ~20 ms ahead). */
const HOT_PLAY_LATENCY_S = 0;
/** Give up on the seamless path after this long and hard-reload instead. */
const HOT_LOAD_TIMEOUT_MS = 6000;
/** IDB `session` key holding a large resume queue ({ rev, ids }). */
const RESUME_QUEUE_KEY = "resume-queue";
/** Queues up to this many ids stay inline in the localStorage head. */
const INLINE_QUEUE_MAX = 2000;
/** Coalesce bursts (volume drags, rapid Next) into one write. */
const RESUME_DEBOUNCE_MS = 600;

interface ResumeBlob {
  trackId: string | null;
  position: number;
  queue: string[];
  repeat: RepeatMode;
  shuffle: boolean;
  volume: number;
}

/** V1.5.5 (P2): what actually lives in localStorage. v1 blobs (no `v`)
 *  carry the full queue inline and are still read. */
interface ResumeHead {
  v: 2;
  trackId: string | null;
  position: number;
  repeat: RepeatMode;
  shuffle: boolean;
  volume: number;
  /** inline queue (≤ INLINE_QUEUE_MAX ids) — absent when it lives in IDB */
  queue?: string[];
  /** revision of the IDB queue this head belongs to */
  queueRev?: number;
  queueLen: number;
}

interface ResumeQueueRow { rev: number; ids: string[] }

class Engine extends Emitter<"state" | "track"> {
  audio: HTMLAudioElement;
  queue: string[] = [];
  order: number[] = []; // positions into queue (identity, or shuffled)
  pos = 0;
  repeat: RepeatMode = "off";
  shuffle = false;
  private actx: AudioContext | null = null;
  private analyserNode: AnalyserNode | null = null;
  private freq: Uint8Array<ArrayBuffer> | null = null;
  // V1.6.0 (P3): object URLs are tracked PER element (two elements now) —
  // only URLs this engine created are revoked (bridge URLs belong to classic)
  private urls = new Map<HTMLAudioElement, { url: string; owned: boolean }>();
  /** Both media elements. `audio` is always the audible/"current" one; the
   *  other is the standby that pre-buffers the next track (gapless /
   *  crossfade) or is fading out during a crossfade. */
  private els: HTMLAudioElement[] = [];
  private fadeGains = new Map<HTMLAudioElement, GainNode>();
  /** V1.6.1 (P3): per-element ReplayGain stage (element → rg → fade → fx). */
  private rgGains = new Map<HTMLAudioElement, GainNode>();
  /** Track id each element currently holds (for its ReplayGain value). */
  private elTrack = new Map<HTMLAudioElement, string>();
  private prep: { el: HTMLAudioElement; id: string; pos: number; ready: boolean; token: number } | null = null;
  private prepSeq = 0;
  private outgoing: { el: HTMLAudioElement; timer: number } | null = null;
  /** V1.7.0 (P4 · 3): a hot reload in progress (the fresh element for the
   *  SAME track). Blocks pre-buffering / transitions onto that element. */
  private reload: { el: HTMLAudioElement; id: string; token: number } | null = null;
  private reloadSeq = 0;
  private xfadeTimer: number | null = null;
  private playedMs = 0;
  private lastTick = 0;
  private loggedRecent = false;
  private saveTimer: number | null = null;
  // V1.5.3 (P1): load-generation token — every loadCurrent()/stopAndClear()
  // bumps it; an async source resolve that finishes after a newer request is
  // discarded instead of hijacking playback / revoking the live object URL.
  private loadGen = 0;
  // V1.5.3 (P1): consecutive unplayable sources — bounds the "skip missing
  // file" fallback so an all-missing queue can no longer loop forever.
  private failStreak = 0;

  // ── equalizer (WebAudio peaking filters, shared FxChain) ──
  /** The pre-1.6.1 6-band layout (kept for older imports). */
  static readonly EQ_FREQS: readonly number[] = EQ_FREQS_6;
  private fx: FxChain | null = null;
  eqEnabled = false;
  eqBands: EqBandCount = 6;
  eqGains: number[] = [0, 0, 0, 0, 0, 0]; // dB per band, -12..+12
  eqPreamp = 0; // dB, applied only while the EQ is on

  constructor() {
    super();
    // V1.6.0 (P3): two elements; every listener is gated to the CURRENT one
    // so the standby / fading-out element never drives state or next().
    for (let i = 0; i < 2; i++) {
      const el = new Audio();
      el.preload = "auto";
      el.addEventListener("ended", () => { if (el === this.audio) this.onEnded(); });
      el.addEventListener("play", () => {
        if (el !== this.audio) return;
        // covers every start path (handoff, media keys, resume) — the classic
        // element must never keep playing while this engine is audible
        this.silenceClassic();
        this.pushState();
        this.planTransition();
      });
      el.addEventListener("pause", () => {
        if (el !== this.audio) return;
        this.clearXfadeTimer();
        this.pushState();
      });
      el.addEventListener("timeupdate", () => { if (el === this.audio) this.onTick(); });
      el.addEventListener("seeked", () => { if (el === this.audio) this.planTransition(); });
      el.addEventListener("ratechange", () => { if (el === this.audio) this.planTransition(); });
      this.els.push(el);
    }
    this.audio = this.els[0];
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) this.flushResume();
    });
    window.addEventListener("beforeunload", () => this.flushResume());
    // V1.6.1 (P3): the settings store is the single source of truth for the
    // sound chain — any face (Classic included) that writes EQ / ReplayGain
    // settings is picked up here, whether or not it went through setEq().
    useSettings.subscribe((st, prev) => {
      if (
        st.eqEnabled !== prev.eqEnabled || st.eqGains !== prev.eqGains ||
        st.eqBands !== prev.eqBands || st.eqPreamp !== prev.eqPreamp
      ) this.syncEqFromSettings();
      if (
        st.replayGain !== prev.replayGain || st.rgPreamp !== prev.rgPreamp ||
        st.rgFallback !== prev.rgFallback || st.rgPreventClip !== prev.rgPreventClip
      ) this.applyReplayGainAll();
    });
    // a folder rescan can bring new loudness tags for the loaded tracks
    useLibrary.subscribe((st, prev) => { if (st.tracks !== prev.tracks) this.applyReplayGainAll(); });
  }

  // ── state mirror ────────────────────────────────────────────────────────────
  pushState() {
    const currentId = this.queue[this.order[this.pos]] ?? null;
    useUi.getState().mirror({
      currentId,
      isPlaying: !this.audio.paused,
      repeat: this.repeat,
      shuffle: this.shuffle,
      queueLength: this.queue.length,
      queueIndex: this.pos,
      // LISTEN order (shuffle-aware) — mirrors what next/prev actually plays,
      // so queue sheets can use display indexes for jump/remove/reorder.
      queueIds: this.order.map((q) => this.queue[q]).filter(Boolean),
      hasAudio: !!this.audio.src,
    });
    this.emit("state");
  }

  get currentId(): string | null {
    return this.queue[this.order[this.pos]] ?? null;
  }

  /** LISTEN order (shuffle-aware) ids — what next/prev will actually play. */
  get queueIds(): string[] {
    return this.order.map((q) => this.queue[q]).filter(Boolean);
  }

  get analyser(): AnalyserNode | null {
    return this.analyserNode;
  }

  /** Frequency bytes for the current frame, or null when analyser unavailable. */
  freqData(): Uint8Array | null {
    if (!this.analyserNode || !this.freq) return null;
    this.analyserNode.getByteFrequencyData(this.freq);
    return this.freq;
  }

  private ensureGraph() {
    if (this.actx) {
      if (this.actx.state === "suspended") this.actx.resume().catch(() => void 0);
      return;
    }
    try {
      this.actx = new AudioContext();
      // V1.6.0 (P3) + V1.6.1: element → ReplayGain gain → fade gain →
      // preamp → 6/10 peaking bands (shared FxChain) → analyser → out.
      // The per-element gains carry the crossfade and each track's own
      // loudness correction, so both songs of a fade are normalised.
      const analyser = this.actx.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.82;
      analyser.connect(this.actx.destination);
      this.fx = new FxChain(this.actx, analyser);
      for (const el of this.els) {
        const src = this.actx.createMediaElementSource(el);
        const rg = this.actx.createGain();
        const g = this.actx.createGain();
        g.gain.value = el === this.audio ? 1 : 0;
        src.connect(rg);
        rg.connect(g);
        g.connect(this.fx.input);
        this.fadeGains.set(el, g);
        this.rgGains.set(el, rg);
      }
      this.applyEq();
      this.applyReplayGainAll();
      this.analyserNode = analyser;
      this.freq = new Uint8Array(new ArrayBuffer(analyser.frequencyBinCount));
    } catch {
      /* graph optional — playback still works */
    }
  }

  // ── equalizer control ──────────────────────────────────────────────────────
  /** Band centre frequencies of the active layout (6 or 10 bands). */
  get eqFreqs(): readonly number[] { return eqFreqs(this.eqBands); }

  setEq(enabled: boolean, gains: number[]) {
    this.eqEnabled = enabled;
    this.eqGains = fitGains(gains, this.eqBands);
    this.applyEq();
    this.persistEq();
  }

  /** V1.6.1 (P3): switch 6 ⇄ 10 bands; the current curve is resampled. */
  setEqBands(bands: EqBandCount) {
    const n = normBands(bands);
    if (n === this.eqBands) return;
    const g = fitGains(this.eqGains, n);
    this.eqBands = n;
    this.eqGains = g;
    this.applyEq();
    this.persistEq();
  }

  /** V1.6.1 (P3): EQ preamp in dB (−12..+12), active while the EQ is on. */
  setEqPreamp(db: number) {
    this.eqPreamp = clampPreamp(db);
    this.applyEq();
    this.persistEq();
  }

  /** V1.6.1 (P3): load a shared preset (turns the EQ on). */
  applyEqPreset(id: string) {
    const g = presetGains(id, this.eqBands);
    if (g) this.setEq(true, g);
  }

  private applyEq() {
    try {
      this.fx?.apply({ enabled: this.eqEnabled, bands: this.eqBands, gains: this.eqGains, preampDb: this.eqPreamp });
    } catch { /* graph not built yet */ }
  }

  private persistEq() {
    const s = useSettings.getState();
    if (s.eqEnabled !== this.eqEnabled) s.set("eqEnabled", this.eqEnabled);
    if (normBands(s.eqBands) !== this.eqBands || s.eqBands === undefined) s.set("eqBands", this.eqBands);
    if (JSON.stringify(s.eqGains) !== JSON.stringify(this.eqGains)) s.set("eqGains", [...this.eqGains]);
    if ((s.eqPreamp ?? 0) !== this.eqPreamp) s.set("eqPreamp", this.eqPreamp);
  }

  /** Adopt the persisted EQ block (boot, or another face wrote settings). */
  private syncEqFromSettings() {
    const cfg = readEqConfig(useSettings.getState());
    this.eqEnabled = cfg.enabled;
    this.eqBands = cfg.bands;
    this.eqGains = cfg.gains;
    this.eqPreamp = cfg.preampDb;
    this.applyEq();
  }

  // ── V1.6.1 (P3): ReplayGain / loudness normalisation ──────────────────────
  get replayGainPrefs(): ReplayGainPrefs { return readReplayGainPrefs(useSettings.getState()); }

  setReplayGain(patch: Partial<ReplayGainPrefs>) {
    const s = useSettings.getState();
    if (patch.mode !== undefined) s.set("replayGain", patch.mode);
    if (patch.preamp !== undefined) s.set("rgPreamp", clamp(patch.preamp, -12, 12));
    if (patch.fallback !== undefined) s.set("rgFallback", clamp(patch.fallback, -12, 0));
    if (patch.preventClip !== undefined) s.set("rgPreventClip", patch.preventClip);
    this.applyReplayGainAll(); // the subscription does it too; idempotent
  }

  /** Linear gain the current track gets from ReplayGain (1 = none/off). */
  get replayGainFactorNow(): number {
    const id = this.elTrack.get(this.audio);
    return this.rgFactorFor(id);
  }

  private rgFactorFor(id: string | undefined): number {
    const prefs = readReplayGainPrefs(useSettings.getState());
    if (prefs.mode === "off" || !id) return 1;
    const tr = useLibrary.getState().tracks[id];
    return replayGainFactor(tr?.rg, prefs);
  }

  private applyReplayGain(el: HTMLAudioElement) {
    const g = this.rgGains.get(el);
    if (!g) return;
    const f = this.rgFactorFor(this.elTrack.get(el));
    try {
      if (Math.abs(g.gain.value - f) > 1e-4) {
        // short ramp: a mid-song mode change must not click
        const ctx = this.actx;
        if (ctx && ctx.state === "running" && !el.paused) {
          g.gain.cancelScheduledValues(ctx.currentTime);
          g.gain.setTargetAtTime(f, ctx.currentTime, 0.03);
        } else {
          g.gain.value = f;
        }
      }
    } catch { /* ignore */ }
  }

  private applyReplayGainAll() {
    for (const el of this.els) this.applyReplayGain(el);
  }

  /** Called once at app boot — adopt persisted EQ/speed before first play. */
  applyPersistedAudioPrefs() {
    this.syncEqFromSettings();
    const s = useSettings.getState();
    if (s.speed && s.speed !== 1) this.setRate(s.speed);
  }

  // ── queue management ─────────────────────────────────────────────────────────
  setQueue(ids: string[], startId?: string, autoplay = true) {
    this.queue = ids.filter(Boolean);
    this.queueRev++;
    this.order = this.queue.map((_, i) => i);
    let start = 0;
    if (startId) {
      const idx = this.queue.indexOf(startId);
      if (idx >= 0) start = idx;
    }
    if (this.shuffle) this.reshuffle(start);
    this.pos = this.order.indexOf(start);
    if (this.pos < 0) this.pos = 0;
    this.loadCurrent(autoplay);
  }

  addToQueue(id: string, playNext = false) {
    if (!this.queue.length) { this.setQueue([id], id, true); return; }
    const insertAt = playNext ? this.order[this.pos] + 1 : this.queue.length; // QUEUE position
    this.queue.splice(insertAt, 0, id);
    this.queueRev++;
    this.order = this.order.map((q) => (q >= insertAt ? q + 1 : q));
    if (playNext) this.order.splice(this.pos + 1, 0, insertAt);
    else this.order.push(insertAt);
    this.pushState();
    this.saveResume();
  }

  removeFromQueue(listenPos: number) {
    const qPos = this.order[listenPos];
    if (qPos === undefined) return;
    const wasPlaying = !this.audio.paused;
    const removingCurrent = listenPos === this.pos;
    this.queue.splice(qPos, 1);
    this.queueRev++;
    this.order.splice(listenPos, 1);
    this.order = this.order.map((q) => (q > qPos ? q - 1 : q));
    if (listenPos < this.pos) this.pos--;
    if (!this.queue.length) { this.stopAndClear(); return; }
    if (this.pos >= this.order.length) this.pos = this.order.length - 1;
    if (removingCurrent) {
      // load whatever now sits at the current listen position, preserving play state
      this.loadCurrent(wasPlaying);
      return;
    }
    this.pushState();
    this.saveResume();
  }

  clearQueue() {
    this.stopAndClear();
  }

  /** Reorder the queue by one slot (dir -1 = up, +1 = down) at a LISTEN position. */
  moveInQueue(listenPos: number, dir: -1 | 1) {
    this.moveQueueItem(listenPos, listenPos + dir);
  }

  /** V1.6.4 (P3): move one item from LISTEN position `from` to `to` (the index
   *  it ends up at). Playback is never interrupted: the current song keeps
   *  playing and `pos` follows it.
   *  • Shuffle off: the move is written into `queue` itself and `order` stays
   *    the identity, so the new order survives a restart (resume saves `queue`)
   *    and turning shuffle on/off later doesn't undo it. The old up/down swap
   *    only permuted `order`, which resume and setShuffle(false) threw away.
   *  • Shuffle on: only the listen order changes (the queue itself is the
   *    unshuffled source list; resume reshuffles anyway).
   *  A pre-buffered next track that is no longer next is dropped and re-planned
   *  (the transition also re-validates it, so this is belt and braces). */
  moveQueueItem(from: number, to: number) {
    const n = this.order.length;
    if (!Number.isInteger(from) || !Number.isInteger(to)) return;
    if (from < 0 || from >= n || to < 0 || to >= n || from === to) return;
    const cur = this.pos;
    if (!this.shuffle) {
      // normalise a legacy non-identity order (pre-1.6.4 swaps) into the queue
      if (this.order.some((q, i) => q !== i)) {
        this.queue = this.order.map((q) => this.queue[q]).filter(Boolean);
        this.order = this.queue.map((_, i) => i);
      }
      const [id] = this.queue.splice(from, 1);
      this.queue.splice(to, 0, id);
      this.queueRev++;
    } else {
      const [q] = this.order.splice(from, 1);
      this.order.splice(to, 0, q);
    }
    if (from === cur) this.pos = to;
    else if (from < cur && to >= cur) this.pos = cur - 1;
    else if (from > cur && to <= cur) this.pos = cur + 1;
    if (this.prep) {
      // keep a pre-buffered track that is still the one up next (its listen
      // position may have shifted); anything else is dropped and re-planned
      const p = this.prep;
      const np = this.autoNextPos();
      if (np !== null && this.queue[this.order[np]] === p.id) p.pos = np;
      else this.dropPrep();
    }
    this.pushState();
    this.saveResume();
    if (!this.audio.paused) this.planTransition();
  }

  /** V1.6.4 (P3): "Play next" for any track (already queued or not). A track
   *  that is already queued further ahead is MOVED right after the current
   *  one instead of being duplicated; otherwise it is inserted there. */
  playNext(id: string) {
    if (!id) return;
    if (!this.queue.length) { this.setQueue([id], id, true); return; }
    if (this.currentId === id) return; // already playing
    const ids = this.queueIds;
    const ahead = ids.indexOf(id, this.pos + 1);
    if (ahead > this.pos + 1) { this.moveQueueItem(ahead, this.pos + 1); return; }
    if (ahead === this.pos + 1) return; // already next
    this.addToQueue(id, true);
    if (!this.audio.paused) this.planTransition();
  }

  jumpTo(listenPos: number, autoplay = true) {
    if (listenPos < 0 || listenPos >= this.order.length) return;
    this.pos = listenPos;
    this.loadCurrent(autoplay);
  }

  private reshuffle(keepQPos?: number) {
    const arr = this.queue.map((_, i) => i);
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    if (keepQPos !== undefined) {
      const at = arr.indexOf(keepQPos);
      if (at > 0) { arr.splice(at, 1); arr.unshift(keepQPos); }
    }
    this.order = arr;
  }

  setShuffle(v: boolean) {
    this.shuffle = v;
    const curQ = this.order[this.pos];
    if (v) this.reshuffle(curQ);
    else this.order = this.queue.map((_, i) => i);
    this.pos = Math.max(0, this.order.indexOf(curQ));
    this.pushState();
    this.saveResume();
  }

  cycleRepeat() {
    this.repeat = this.repeat === "off" ? "all" : this.repeat === "all" ? "one" : "off";
    this.pushState();
    this.saveResume();
  }

  // ── transport ──────────────────────────────────────────────────────────────
  /** Resolve a playable source for a track: bridged classic URL (asset:// or
   *  blob:// owned by classic) first, then the local IndexedDB blob store. */
  private async applySource(id: string, gen = this.loadGen, el: HTMLAudioElement = this.audio): Promise<boolean> {
    const bridge = getBridge();
    const bridgedUrl = bridge ? bridge.resolveSource(id) : null;
    if (bridgedUrl) {
      this.releaseUrl(el);
      this.urls.set(el, { url: bridgedUrl, owned: false });
      this.setCrossOriginFor(bridgedUrl, el);
      this.bindTrack(el, id);
      el.src = bridgedUrl;
      return true;
    }
    const blob = await db.getFile(id);
    if (gen !== this.loadGen) return false; // superseded while awaiting IDB
    if (!blob) return false;
    this.releaseUrl(el);
    const url = URL.createObjectURL(blob);
    this.urls.set(el, { url, owned: true });
    this.setCrossOriginFor(url, el);
    this.bindTrack(el, id);
    el.src = url;
    return true;
  }

  /** V1.6.1 (P3): remember which track an element holds and set its
   *  ReplayGain BEFORE the new source makes a sound. */
  private bindTrack(el: HTMLAudioElement, id: string) {
    this.elTrack.set(el, id);
    const g = this.rgGains.get(el);
    if (g) { try { g.gain.cancelScheduledValues(0); g.gain.value = this.rgFactorFor(id); } catch { /* ignore */ } }
  }

  /** Revoke the object URL an element was playing (if this engine made it). */
  private releaseUrl(el: HTMLAudioElement) {
    const u = this.urls.get(el);
    if (u?.owned) URL.revokeObjectURL(u.url);
    this.urls.delete(el);
  }

  /** QA fix (UI-switch silence bug): EVERY engine source flows through the
   *  WebAudio graph (createMediaElementSource). Chromium silences that graph
   *  — "MediaElementAudioSource outputs zeroes" — whenever the media
   *  resource is CORS-cross-origin. Under Electron, classic desktop tracks
   *  resolve to app:// URLs, a different origin from the file:// renderer,
   *  so the whole Cinema/EELA/ALOK surface played SILENT (element running,
   *  zero output) the moment a classic folder import was handed over.
   *  Asking for the resource in CORS mode fixes the taint: the app://
   *  handler answers Access-Control-Allow-Origin: * (electron/main.cjs).
   *  blob: URLs are same-origin (no-op) and foreign schemes (Tauri
   *  asset://) keep their previous behavior — crossOrigin stays unset. */
  private setCrossOriginFor(url: string, el: HTMLAudioElement = this.audio) {
    try {
      if (url.startsWith("app://")) el.crossOrigin = "anonymous";
      else el.removeAttribute("crossorigin");
    } catch { /* ignore */ }
  }

  async loadCurrent(autoplay: boolean) {
    // a manual load (next/prev/jump/setQueue) always hard-cuts: kill any
    // fade in progress and drop the pre-buffered track
    this.cancelTransition();
    this.dropPrep();
    const gen = ++this.loadGen;
    const id = this.currentId;
    if (!id) { this.stopAndClear(); return; }
    let ok = false;
    try { ok = await this.applySource(id, gen); } catch { ok = false; }
    if (gen !== this.loadGen) return; // a newer load won the race
    if (!ok) {
      // V1.5.3 (P1): skip the unplayable item, but never more than one full
      // lap of the queue — then stop and tell the listener once.
      this.failStreak++;
      if (this.failStreak >= this.order.length) {
        this.failStreak = 0;
        this.audio.pause();
        this.pushState();
        try { uiApi.toast("No playable files in the queue", "error"); } catch { /* ui gone */ }
        return;
      }
      this.pos = (this.pos + 1) % this.order.length;
      void this.loadCurrent(autoplay);
      return;
    }
    this.failStreak = 0;
    this.playedMs = 0;
    this.lastTick = 0;
    this.loggedRecent = false;
    this.emit("track", id);
    if (autoplay) {
      await this.play();
      if (gen !== this.loadGen) return;
    } else {
      this.pushState();
    }
    this.saveResume();
  }

  async play() {
    if (!this.audio.src && this.currentId) { await this.loadCurrent(true); return; }
    this.ensureGraph();
    // ── single-source rule: whenever THIS engine starts, silence the classic
    // shell's audio element. Both UIs stay mounted, so without this guard the
    // two elements can overlap and the user hears two songs at once.
    this.silenceClassic();
    try {
      await this.audio.play();
    } catch (e: any) {
      // AbortError = the source changed mid-start (expected on rapid next);
      // anything else (NotAllowed / NotSupported) is a real failure.
      if (e?.name && e.name !== "AbortError") console.warn("[engine] play() failed:", e.name);
    }
    this.pushState();
  }

  /** Pause the classic shell's <audio> (if it is playing). Best-effort. */
  private silenceClassic() {
    try {
      const w = globalThis as any;
      w.__NOBODY_BRIDGE__?.pause?.();
    } catch { /* ignore */ }
  }

  pause() {
    this.cancelTransition();
    this.audio.pause();
    this.pushState();
    this.saveResume();
  }

  toggle() {
    if (this.audio.paused) this.play();
    else this.pause();
  }

  next(auto = false) {
    if (!this.queue.length) return;
    if (this.repeat === "one" && auto) {
      this.audio.currentTime = 0;
      this.play();
      return;
    }
    if (this.pos + 1 >= this.order.length) {
      if (this.repeat === "all") {
        if (this.shuffle) this.reshuffle();
        this.pos = 0;
        this.loadCurrent(true);
      } else if (!auto) {
        this.pos = 0;
        this.loadCurrent(true);
      } else {
        this.audio.pause();
        this.pushState();
      }
      return;
    }
    this.pos++;
    this.loadCurrent(true);
  }

  prev() {
    if (this.audio.currentTime > 3.5) { this.seek(0); return; }
    if (this.pos > 0) { this.pos--; this.loadCurrent(true); }
    else this.seek(0);
  }

  seek(t: number) {
    if (!isFinite(this.audio.duration)) return;
    this.cancelTransition();
    this.audio.currentTime = clamp(t, 0, this.audio.duration || 0);
    this.playedMs = 0; // seeking restarts the "genuine play" measurement
  }

  setVolume(v: number) {
    const vol = clamp(v, 0, 1);
    for (const el of this.els) el.volume = vol; // the fading-out one follows too
    this.pushState();
    this.saveResume();
  }

  get volume() { return this.audio.volume; }

  private stopAndClear() {
    this.loadGen++; // invalidate any in-flight source resolve
    this.failStreak = 0;
    this.cancelTransition();
    this.dropPrep();
    this.audio.pause();
    this.audio.removeAttribute("src");
    // PHASE-3 audit follow-up (Electron migration §5): clearing the queue
    // used to drop the owned blob URL without revoking it — every
    // clearQueue() pinned the last local file's bytes in RAM until reload.
    this.releaseUrl(this.audio);
    this.queue = [];
    this.queueRev++;
    this.order = [];
    this.pos = 0;
    this.pushState();
    this.saveResume();
  }

  private onEnded() {
    if (this.sleepMode === "track") {
      this.cancelSleepTimer();
      this.pushState();
      return; // stay silent — the listener asked to sleep at end of track
    }
    // the precise timer can lose the race (background throttling, a short
    // tail) — a pre-buffered next track still starts instantly from here
    if (this.startTransition(0, true)) return;
    this.next(true);
  }

  // ── V1.6.0 (P3): gapless + crossfade ──────────────────────────────────────
  // Two media elements. While the current one plays, the next track is
  // pre-buffered on the standby element ~12 s before the transition point.
  // Gapless: the standby starts ~45 ms before the end with a 30 ms
  // equal-power overlap (as seamless as <audio> allows — MP3 encoder padding
  // can still leave a few ms). Crossfade (1–12 s): equal-power gain curves on
  // per-element GainNodes. At the transition `audio` is swapped to the new
  // element, so every face (they all read engine.audio live) follows along.
  // Manual next/prev/jump, pause and seek always hard-cut.

  /** null = feature off; fade 0 = gapless; > 0 = crossfade seconds. */
  private transitionCfg(): { fade: number } | null {
    const s = useSettings.getState();
    const xf = clamp(Number(s.crossfade) || 0, 0, MAX_CROSSFADE_S);
    if (xf > 0) return { fade: xf };
    if (s.gapless !== false) return { fade: 0 };
    return null;
  }

  /** Listen position an automatic advance would go to (no mutation). */
  private autoNextPos(): number | null {
    if (!this.queue.length || this.repeat === "one" || this.sleepMode === "track") return null;
    if (this.pos + 1 < this.order.length) return this.pos + 1;
    // repeat-all wrap: only when the order stays the same (shuffle reshuffles)
    if (this.repeat === "all" && !this.shuffle && this.order.length > 1) return 0;
    return null;
  }

  private clearXfadeTimer() {
    if (this.xfadeTimer !== null) { window.clearTimeout(this.xfadeTimer); this.xfadeTimer = null; }
  }

  /** Called on every timeupdate / play / seek / rate change of the current
   *  element: pre-buffers the next track and arms a precise start timer. */
  private planTransition() {
    this.clearXfadeTimer();
    const a = this.audio;
    if (a.paused || this.outgoing || this.reload) return;
    const cfg = this.transitionCfg();
    const nextPos = cfg ? this.autoNextPos() : null;
    if (!cfg || nextPos === null) { this.dropPrep(); return; }
    const d = a.duration;
    if (!isFinite(d) || d <= 0) return;
    const rate = a.playbackRate || 1;
    const remain = (d - a.currentTime) / rate; // wall-clock seconds left
    const fade = Math.min(cfg.fade, d / rate / 2);
    const lead = fade > 0 ? fade : GAPLESS_LEAD_S;
    if (remain <= lead + PRELOAD_AHEAD_S) void this.prepareNext(nextPos);
    if (remain <= lead + 1.5) {
      this.xfadeTimer = window.setTimeout(() => {
        this.xfadeTimer = null;
        this.startTransition(fade, false);
      }, Math.max(0, (remain - lead) * 1000));
    }
  }

  private standby(): HTMLAudioElement {
    return this.els[0] === this.audio ? this.els[1] : this.els[0];
  }

  private async prepareNext(nextPos: number) {
    const id = this.queue[this.order[nextPos]];
    if (!id) return;
    if (this.prep && this.prep.id === id && this.prep.pos === nextPos) return;
    this.dropPrep();
    const el = this.standby();
    if (this.outgoing?.el === el) return; // still fading out — retry later
    if (this.reload) return; // V1.7.0: the standby is busy re-opening the current song
    const token = ++this.prepSeq;
    const gen = this.loadGen;
    this.prep = { el, id, pos: nextPos, ready: false, token };
    let ok = false;
    try { ok = await this.applySource(id, gen, el); } catch { ok = false; }
    if (!this.prep || this.prep.token !== token) return; // superseded
    if (!ok || gen !== this.loadGen) { this.dropPrep(); return; }
    const g = this.fadeGains.get(el);
    if (g) { try { g.gain.cancelScheduledValues(0); g.gain.value = 0; } catch { /* ignore */ } }
    this.prep.ready = true;
  }

  /** Forget the pre-buffered track and free its element. */
  private dropPrep() {
    const p = this.prep;
    if (!p) return;
    this.prep = null;
    if (p.el === this.audio || p.el === this.outgoing?.el) return;
    try { p.el.pause(); p.el.removeAttribute("src"); p.el.load(); } catch { /* ignore */ }
    this.releaseUrl(p.el);
  }

  private setGainCurve(g: GainNode, from: number, to: number, at: number, dur: number) {
    const param = g.gain;
    try {
      param.cancelScheduledValues(at);
      const n = 64;
      const curve = new Float32Array(n);
      for (let i = 0; i < n; i++) {
        const x = i / (n - 1);
        // equal-power: constant perceived loudness through the fade
        curve[i] = from < to ? Math.sin((x * Math.PI) / 2) : Math.cos((x * Math.PI) / 2);
      }
      param.setValueAtTime(from, at);
      param.setValueCurveAtTime(curve, at, Math.max(0.005, dur));
    } catch {
      try { param.value = to; } catch { /* ignore */ }
    }
  }

  /** Swap to the pre-buffered track. Returns false when nothing valid is
   *  ready (the caller falls back to the normal next()). */
  private startTransition(fade: number, fromEnded: boolean): boolean {
    const p = this.prep;
    const nextPos = this.autoNextPos();
    if (!p || !p.ready || nextPos !== p.pos || this.queue[this.order[nextPos]] !== p.id) return false;
    if (!fromEnded && this.audio.paused) return false;
    const old = this.audio;
    const nu = p.el;
    this.prep = null;
    this.clearXfadeTimer();
    let f = fromEnded ? 0 : fade;
    if (isFinite(nu.duration) && nu.duration > 0) f = Math.min(f, nu.duration / 2);

    // the new element inherits the listener's current output settings
    nu.volume = old.volume;
    nu.muted = old.muted;
    try {
      nu.playbackRate = old.playbackRate || 1;
      (nu as any).preservesPitch = true;
    } catch { /* ignore */ }
    try { if (nu.currentTime > 0) nu.currentTime = 0; } catch { /* ignore */ }

    this.ensureGraph();
    const gOld = this.fadeGains.get(old);
    const gNew = this.fadeGains.get(nu);
    const ctx = this.actx;
    const canFade = !!(ctx && gOld && gNew && ctx.state === "running");
    const dur = f > 0 && canFade ? f : GAPLESS_OVERLAP_S;
    if (canFade && !fromEnded) {
      const t0 = ctx!.currentTime;
      this.setGainCurve(gNew!, 0, 1, t0, dur);
      this.setGainCurve(gOld!, 1, 0, t0, dur);
    } else {
      if (gNew) { try { gNew.gain.cancelScheduledValues(0); gNew.gain.value = 1; } catch { /* ignore */ } }
    }

    // swap: from here on `audio` is the new track for every face
    this.audio = nu;
    this.pos = nextPos;
    this.loadGen++; // any in-flight manual load is now stale
    this.failStreak = 0;
    this.playedMs = 0;
    this.lastTick = 0;
    this.loggedRecent = false;
    // mark the old element as fading BEFORE play(): the new element's "play"
    // event re-plans and must not pre-buffer onto the still-audible tail
    if (fromEnded) {
      this.retireElement(old);
    } else {
      this.outgoing = {
        el: old,
        timer: window.setTimeout(() => this.finishOutgoing(), dur * 1000 + 80),
      };
    }
    this.silenceClassic();
    nu.play().catch((e: any) => {
      if (e?.name && e.name !== "AbortError") console.warn("[engine] transition play() failed:", e.name);
    });
    this.emit("track", p.id);
    this.pushState();
    this.saveResume();
    return true;
  }

  /** Stop + unload an element that is no longer current. */
  private retireElement(el: HTMLAudioElement) {
    if (el === this.audio) return;
    try { el.pause(); el.removeAttribute("src"); el.load(); } catch { /* ignore */ }
    this.releaseUrl(el);
    const g = this.fadeGains.get(el);
    if (g) { try { g.gain.cancelScheduledValues(0); g.gain.value = 0; } catch { /* ignore */ } }
  }

  private finishOutgoing() {
    const o = this.outgoing;
    if (!o) return;
    this.outgoing = null;
    window.clearTimeout(o.timer);
    this.retireElement(o.el);
    this.planTransition();
  }

  /** Hard-cut any fade in progress: outgoing silenced, current at full gain. */
  private cancelTransition() {
    this.clearXfadeTimer();
    this.abortReload();
    if (this.outgoing) {
      const o = this.outgoing;
      this.outgoing = null;
      window.clearTimeout(o.timer);
      this.retireElement(o.el);
    }
    const g = this.fadeGains.get(this.audio);
    if (g) {
      try { g.gain.cancelScheduledValues(0); g.gain.value = 1; } catch { /* ignore */ }
    }
  }

  /** Silence everything this engine outputs (used by the classic handoff). */
  silence() {
    this.cancelTransition();
    this.dropPrep();
    try { this.audio.pause(); } catch { /* ignore */ }
  }

  // ── V1.7.0 (P4 · part 3): hot reload after a tag rewrite ──────────────────
  // A `rewrite` save (tag editor) replaces the file with a new byte layout
  // (bigger ID3 tag, moved moov…). The live element keeps playing from what
  // it already buffered, but its next range request would read the NEW file
  // at OLD offsets. So the same song is re-opened on the standby element
  // (new `?r=` URL), seeked to the live position, and swapped in with a
  // 30 ms equal-power overlap: no gap, no restart, same queue position,
  // same "genuinely played" counter. Any manual action (next / seek / pause
  // / load) during the reload aborts it (cancelTransition → abortReload).
  // If the fresh element can't open the file it is retried once; after that
  // the live element is left alone (never a wrong song, never a hard stop).

  /** Re-open the current (or pre-buffered) track from a fresh source.
   *  Returns true when the current element was swapped / reloaded. */
  async hotReload(id: string, url?: string | null, retry = 1): Promise<boolean> {
    // pre-buffered next = the edited file → forget it; planTransition will
    // resolve the new URL on the next tick
    if (this.prep?.id === id) this.dropPrep();
    const old = this.audio;
    if (this.currentId !== id || this.elTrack.get(old) !== id || !old.src) return false;
    const src = url || getBridge()?.resolveSource(id) || null;
    if (!src) return false;
    // a crossfade tail of the PREVIOUS song is cut, a pending transition
    // re-plans after the swap; this also aborts an older reload
    this.cancelTransition();
    this.dropPrep();
    const gen = this.loadGen;
    const token = ++this.reloadSeq;
    const nu = this.standby();
    const wasPlaying = !old.paused;
    this.reload = { el: nu, id, token };
    const alive = () => this.reload?.token === token && this.loadGen === gen && this.audio === old;

    // same output settings as the live element, silent until the swap
    try { nu.pause(); } catch { /* ignore */ }
    this.releaseUrl(nu);
    this.urls.set(nu, { url: src, owned: false });
    this.setCrossOriginFor(src, nu);
    this.bindTrack(nu, id);
    nu.volume = old.volume;
    nu.muted = old.muted;
    try {
      nu.playbackRate = old.playbackRate || 1;
      nu.defaultPlaybackRate = old.playbackRate || 1;
      (nu as any).preservesPitch = true;
    } catch { /* ignore */ }
    const gNew = this.fadeGains.get(nu);
    if (gNew) { try { gNew.gain.cancelScheduledValues(0); gNew.gain.value = 0; } catch { /* ignore */ } }
    nu.src = src;

    const deadline = performance.now() + HOT_LOAD_TIMEOUT_MS;
    const left = () => Math.max(0, deadline - performance.now());
    let ok = await waitMedia(nu, ["loadedmetadata"], left());
    if (!alive()) return false;

    if (ok) {
      // seek ahead of the live element, then let it catch up so both play
      // the same sample at the swap
      ok = false;
      const rate = old.playbackRate || 1;
      for (let attempt = 0; attempt < 3 && left() > 0; attempt++) {
        const lead = wasPlaying ? HOT_SEEK_LEAD_S * (attempt + 1) * rate : 0;
        const dur = isFinite(nu.duration) && nu.duration > 0 ? nu.duration : Infinity;
        const target = Math.min(Math.max(0, old.currentTime + lead), Math.max(0, dur - 0.05));
        try { nu.currentTime = target; } catch { break; }
        const seeked = await waitMedia(nu, ["seeked"], left());
        if (!alive()) return false;
        if (!seeked) break;
        if (nu.readyState < 3) {
          const ready = await waitMedia(nu, ["canplay"], left());
          if (!alive()) return false;
          if (!ready) break;
        }
        if (!wasPlaying || old.paused) { ok = true; break; }
        const ahead = nu.currentTime - old.currentTime;
        if (ahead >= 0) {
          const waitMs = ((ahead / rate) - HOT_PLAY_LATENCY_S) * 1000;
          if (waitMs > 0) await sleepMs(waitMs);
          if (!alive()) return false;
          ok = true;
          break;
        }
        // the live element overtook the seek — retry with a bigger lead
      }
    }

    if (!ok) {
      // the fresh element couldn't open / seek the file (e.g. the atomic
      // rename was still retrying on Windows): try once more, then leave the
      // live element alone — it keeps playing what it has buffered
      this.reload = null;
      this.retireElement(nu);
      if (retry > 0) {
        await sleepMs(400);
        if (this.loadGen !== gen || this.audio !== old || this.reloadSeq !== token) return false;
        return this.hotReload(id, src, retry - 1);
      }
      console.warn("[engine] hot reload failed; the current element keeps playing");
      return false;
    }

    const playing = wasPlaying && !old.paused;
    this.ensureGraph();
    const gOld = this.fadeGains.get(old);
    const ctx = this.actx;
    if (playing) {
      // still marked as reloading: a pause / seek / next during play()
      // aborts (abortReload retires `nu`) and is caught by alive()
      try { await nu.play(); } catch (e: any) {
        if (e?.name && e.name !== "AbortError") console.warn("[engine] hot reload play() failed:", e.name);
      }
      if (!alive()) return false;
      if (nu.paused) {
        this.reload = null;
        this.retireElement(nu);
        return false;
      }
    }
    this.reload = null;
    const canFade = !!(ctx && gOld && gNew && ctx.state === "running");
    if (playing && canFade) {
      const t0 = ctx!.currentTime;
      this.setGainCurve(gNew!, 0, 1, t0, HOT_SWAP_OVERLAP_S);
      this.setGainCurve(gOld!, 1, 0, t0, HOT_SWAP_OVERLAP_S);
    } else if (gNew) {
      try { gNew.gain.cancelScheduledValues(0); gNew.gain.value = 1; } catch { /* ignore */ }
    }

    // swap: same song, same queue position, same played-time counter
    this.audio = nu;
    if (playing && canFade) {
      this.outgoing = {
        el: old,
        timer: window.setTimeout(() => this.finishOutgoing(), HOT_SWAP_OVERLAP_S * 1000 + 80),
      };
    } else {
      this.retireElement(old);
    }
    this.pushState();
    this.saveResume();
    if (!this.outgoing) this.planTransition();
    return true;
  }

  /** Drop an unfinished hot reload (its element goes back to standby). */
  private abortReload() {
    const r = this.reload;
    if (!r) return;
    this.reload = null;
    this.reloadSeq++;
    if (r.el !== this.audio) this.retireElement(r.el);
  }

  // ── "genuinely playing" recent logger ─────────────────────────────────────
  private onTick() {
    const now = performance.now();
    /* 1.7.0-dev.10 (P4 · 7): listening history. Classic feeds the same
       tracker from its own element; only one of them sounds at a time. */
    {
      const id = this.currentId;
      const a = this.audio;
      listenTracker.sample("engine", id, a.currentTime, a.duration, !a.paused, () => {
        const tr = id ? useLibrary.getState().tracks[id] : undefined;
        return tr ? { title: tr.title, artist: tr.artist, album: tr.album, genre: tr.genre, duration: tr.duration } : null;
      });
    }
    if (!this.audio.paused && this.lastTick) {
      this.playedMs += now - this.lastTick;
      if (!this.loggedRecent && this.playedMs > 5000) {
        this.loggedRecent = true;
        const id = this.currentId;
        if (id) {
          useLibrary.getState().pushRecent(id);
          /* V1.2.0: "genuinely played" also feeds the Most-Played category. */
          useLibrary.getState().recordPlay(id);
        }
      }
    }
    this.lastTick = now;
    this.planTransition();
    if (this.saveTimer === null) {
      this.saveTimer = window.setTimeout(() => { this.saveTimer = null; this.flushResume(); }, 4000);
    }
  }

  // ── resume ─────────────────────────────────────────────────────────────────
  // V1.5.5 (P2): the whole queue used to be JSON-stringified into
  // localStorage on EVERY pause / volume step / track change (10k ids ≈
  // 400 KB of sync string work, and big queues overflowed the quota so
  // saving silently stopped). Now:
  //   • saveResume() is debounced; flushResume() writes immediately (hide,
  //     unload, the 4 s playback tick);
  //   • a small head (track, position, flags) always goes to localStorage;
  //   • queues > INLINE_QUEUE_MAX live in IDB `session`, rewritten ONLY when
  //     the queue actually changed (queueRev), never for a position update.
  private queueRev = 0;
  private savedQueueRev = -1;
  private resumeTimer: number | null = null;

  /** Debounced — safe to call on every state change. */
  saveResume() {
    if (this.resumeTimer !== null) return;
    this.resumeTimer = window.setTimeout(() => { this.resumeTimer = null; this.writeResume(); }, RESUME_DEBOUNCE_MS);
  }

  /** Write now (sync for the head; the IDB queue write is fire-and-forget). */
  flushResume() {
    if (this.resumeTimer !== null) { window.clearTimeout(this.resumeTimer); this.resumeTimer = null; }
    this.writeResume();
  }

  private writeResume() {
    const q = this.queue;
    const inline = q.length <= INLINE_QUEUE_MAX;
    const head: ResumeHead = {
      v: 2,
      trackId: this.currentId,
      position: this.audio.currentTime || 0,
      repeat: this.repeat,
      shuffle: this.shuffle,
      volume: this.audio.volume,
      queueLen: q.length,
    };
    if (inline) head.queue = q;
    else head.queueRev = this.queueRev;
    try { localStorage.setItem(RESUME_KEY, JSON.stringify(head)); } catch { /* full */ }
    if (this.savedQueueRev === this.queueRev) return;
    const rev = this.queueRev;
    this.savedQueueRev = rev;
    if (inline) {
      // small again → drop a stale big copy (best-effort)
      void db.deleteSession(RESUME_QUEUE_KEY).catch(() => undefined);
    } else {
      const row: ResumeQueueRow = { rev, ids: q.slice() };
      void db.putSession(RESUME_QUEUE_KEY, row).catch((err) => {
        console.warn("[engine] resume queue save failed", err);
        if (this.savedQueueRev === rev) this.savedQueueRev = -1; // retry next write
      });
    }
  }

  /** Read head + (if needed) the IDB queue back into one ResumeBlob. */
  private async readResume(): Promise<ResumeBlob | null> {
    let raw: any = null;
    try {
      const s = localStorage.getItem(RESUME_KEY);
      if (s) raw = JSON.parse(s);
    } catch { /* ignore */ }
    if (!raw || typeof raw !== "object") return null;
    const base = {
      trackId: raw.trackId ?? null,
      position: Number(raw.position) || 0,
      repeat: (raw.repeat ?? "off") as RepeatMode,
      shuffle: !!raw.shuffle,
      volume: typeof raw.volume === "number" ? raw.volume : 0.9,
    };
    if (raw.v !== 2 || Array.isArray(raw.queue)) {
      return { ...base, queue: Array.isArray(raw.queue) ? raw.queue : [] }; // v1 blob / inline
    }
    let ids: string[] = [];
    try {
      const row = await db.getSession<ResumeQueueRow>(RESUME_QUEUE_KEY);
      if (row && Array.isArray(row.ids)) {
        ids = row.ids;
        // rev mismatch = the head was flushed on unload before the async IDB
        // write landed; the older queue is still the best we have as long as
        // it contains the saved track
        if (row.rev !== raw.queueRev && base.trackId && !ids.includes(base.trackId)) ids = [];
      }
    } catch (err) {
      console.warn("[engine] resume queue read failed", err);
    }
    if (!ids.length && base.trackId) ids = [base.trackId]; // at least the song
    return { ...base, queue: ids };
  }

  // ── playback rate ─────────────────────────────────────────────────────────
  setRate(r: number) {
    const rate = clamp(r, 0.5, 2);
    for (const el of this.els) {
      try {
        el.playbackRate = rate;
        (el as any).preservesPitch = true; // chipmunk-free by default
      } catch { /* ignore */ }
    }
    const s = useSettings.getState();
    if (s.speed !== rate) s.set("speed", rate);
    this.pushState();
  }

  get rate() { return this.audio.playbackRate || 1; }

  // ── sleep timer ───────────────────────────────────────────────────────────
  private sleepTimer: number | null = null;
  private sleepEndsAt = 0;
  sleepMode: "off" | "timed" | "track" = "off";
  sleepMinutes = 0; // configured duration (UI chip matching)

  /** minutes=0 → "when track ends"; otherwise pause after that many minutes. */
  startSleepTimer(minutes: number) {
    this.cancelSleepTimer();
    this.sleepMinutes = minutes;
    if (minutes <= 0) {
      this.sleepMode = "track";
      this.pushState();
      return;
    }
    this.sleepMode = "timed";
    this.sleepEndsAt = Date.now() + minutes * 60_000;
    this.sleepTimer = window.setTimeout(() => {
      this.sleepTimer = null;
      this.sleepMode = "off";
      this.pause();
      // V1.6.1 (P3): ONE sleep timer for every face — Classic reuses it
      this.silenceClassic();
      this.announceSleepEnd();
    }, minutes * 60_000);
    this.pushState();
  }

  private announceSleepEnd() {
    try {
      const lang = useSettings.getState().lang;
      const msg =
        lang === "fa" ? "خواب‌سنج تمام شد — پخش متوقف شد"
        : lang === "tr" ? "Uyku zamanlayıcısı doldu — çalma duraklatıldı"
        : "Sleep timer ended — playback paused";
      uiApi.toast(msg, "info");
    } catch { /* ui may be gone */ }
  }

  cancelSleepTimer() {
    if (this.sleepTimer !== null) { window.clearTimeout(this.sleepTimer); this.sleepTimer = null; }
    this.sleepEndsAt = 0;
    this.sleepMinutes = 0;
    const wasOff = this.sleepMode === "off";
    this.sleepMode = "off";
    if (!wasOff) this.pushState();
  }

  get sleepEndsAtMs() { return this.sleepEndsAt; }

  /** V1.6.1 (P3): Classic's own <audio> asks this at the end of a song.
   *  true = an "end of track" sleep was armed; it is consumed (off) and the
   *  caller must stay silent. */
  consumeSleepAtTrackEnd(): boolean {
    if (this.sleepMode !== "track") return false;
    this.cancelSleepTimer();
    this.announceSleepEnd();
    return true;
  }

  // ── resume ──────────────────────────────────────────────────────────────────
  /** QA: a resume attempted before the (async) classic folder re-scan has
   *  filled the mirror is kept here so it can be retried when the library
   *  arrives — otherwise a restart straight into a engine-driven UI silently
   *  lost the previous session. */
  private resumeDeferred: ResumeBlob | null = null;

  async restoreResume(): Promise<string | null> {
    const data = await this.readResume();
    if (!data) return null;
    this.resumeDeferred = null;
    const lib = useLibrary.getState();
    const queue = (data.queue || []).filter((id) => lib.tracks[id]);
    this.repeat = data.repeat ?? "off";
    { const vol = clamp(data.volume ?? 0.9, 0, 1); for (const el of this.els) el.volume = vol; }
    if (!queue.length || !data.trackId || !lib.tracks[data.trackId]) {
      this.resumeDeferred = data; // retry via retryDeferredResume() once tracks exist
      this.pushState();
      return null;
    }
    this.queue = queue;
    this.queueRev++;
    this.order = queue.map((_, i) => i);
    if (data.shuffle) {
      const cur = queue.indexOf(data.trackId);
      this.reshuffle(cur >= 0 ? cur : 0);
      this.shuffle = true;
    }
    this.pos = Math.max(0, this.order.indexOf(queue.indexOf(data.trackId)));
    // load WITHOUT autoplay, seek to position once metadata is ready
    const id = this.currentId!;
    const gen = ++this.loadGen;
    const ok = await this.applySource(id, gen);
    if (gen !== this.loadGen) return null;
    if (ok) {
      const target = data.position || 0;
      const onMeta = () => {
        if (isFinite(this.audio.duration)) this.audio.currentTime = clamp(target, 0, this.audio.duration - 0.5);
        this.audio.removeEventListener("loadedmetadata", onMeta);
      };
      this.audio.addEventListener("loadedmetadata", onMeta);
    }
    this.pushState();
    this.emit("track", id);
    return id;
  }

  /** Re-run a resume that was deferred because the library mirror wasn't
   *  filled yet. No-op when anything is already loaded (never clobber live
   *  playback) — callers invoke it after a mirror rehydrate. */
  retryDeferredResume(): boolean {
    if (!this.resumeDeferred || this.queue.length || this.audio.src) return false;
    this.resumeDeferred = null;
    void this.restoreResume();
    return true;
  }
}

/** Resolve on the first of `events` (true), on `error` / timeout (false). */
function waitMedia(el: HTMLAudioElement, events: string[], timeoutMs: number): Promise<boolean> {
  return new Promise((resolve) => {
    let done = false;
    const finish = (v: boolean) => {
      if (done) return;
      done = true;
      window.clearTimeout(timer);
      for (const e of events) el.removeEventListener(e, onOk);
      el.removeEventListener("error", onErr);
      resolve(v);
    };
    const onOk = () => finish(true);
    const onErr = () => finish(false);
    const timer = window.setTimeout(() => finish(false), Math.max(0, timeoutMs));
    for (const e of events) el.addEventListener(e, onOk);
    el.addEventListener("error", onErr);
    if (timeoutMs <= 0) finish(false);
  });
}

function sleepMs(ms: number): Promise<void> {
  return new Promise((r) => window.setTimeout(r, Math.max(0, ms)));
}

export const engine = new Engine();
export const EQ_FREQS = Engine.EQ_FREQS;

// ── module-level switch bridge (BUG FIX: music died when returning to Classic)
// switchUiMode captures playback via window.__NOBODY_CINEMA__.captureHandoff().
// That bridge used to live inside cinema/App.tsx as a COMPONENT effect — tied
// to the cinema pane's mount lifecycle. Two reported breakages came from that:
//   • the engine keeps playing while the VISIBLE pane is eela or alok, so the
//     capture must work there too (it did, while every pane stayed mounted);
//   • with the new single-active-pane shell (RAM fix) the cinema pane is
//     UNMOUNTED most of the time — its cleanup even deleted the bridge, so a
//     switch back to Classic found no captureHandoff and the song stopped.
// Exposing it at MODULE scope (this file is imported by classic, cinema, EELA
// and ALOK alike, and ES modules live for the whole session) makes the capture
// always available, from every engine-driven UI, in every direction.
try {
  const w = globalThis as any;
  const engineBridge = {
    captureHandoff: () => ({
      trackId: engine.currentId,
      position: engine.audio.currentTime || 0,
      isPlaying: !engine.audio.paused,
      volume: engine.audio.volume,
      queueIds: engine.queueIds,
    }),
    pause: () => {
      // V1.6.0 (P3): also stops a crossfade tail on the standby element
      try { engine.silence(); } catch { /* ignore */ }
    },
  };
  // Merge over any earlier exposure instead of clobbering extra keys.
  w.__NOBODY_CINEMA__ = Object.assign({}, w.__NOBODY_CINEMA__, engineBridge);
} catch { /* non-window environment */ }

// ── V1.4.0 (#9): hardware media keys ─────────────────────────────────────────
// electron/main.cjs owns the OS global shortcuts (they fire even when the
// window is minimized/unfocused) and forwards every press through the
// mediaKeys bridge installed at root level. The engine answers only when an
// engine-driven face (cinema / eela / alok) is the active one — classic
// drives its own <audio> element. Module scope, AFTER the singleton above:
// this subscription lives for the whole session, whichever face is visible.
// try/catch so a web runtime without the bridge can never break the module.
try {
  onMediaKey((action) => {
    if (getUiMode() === "classic") return;
    if (action === "play-pause") engine.toggle();
    else if (action === "next") engine.next();
    else if (action === "prev") engine.prev();
    else if (action === "stop") engine.pause();
    // 1.8.0-dev.2: global volume hotkeys, 5 % steps (same as the ↑/↓ keys)
    else if (action === "vol-up") engine.setVolume(Math.round(Math.min(1, engine.volume + 0.05) * 100) / 100);
    else if (action === "vol-down") engine.setVolume(Math.round(Math.max(0, engine.volume - 0.05) * 100) / 100);
  });
} catch { /* web runtime / bridge absent — nothing to do */ }
