// ── NOBODY · "date added" for desktop (bridged) tracks, 1.7.0-dev.7 ─────────
// Classic library rows carry no import time: the bridge sets
// `importedAt = 1e12 + order` (a stable sort key that reads as Sept 2001), so a
// smart rule "date added in the last 30 days" matched nothing on desktop.
//
// This registry remembers when each stable track id was FIRST seen
// (localStorage, id → epoch ms). On the very first session that has no
// registry yet (upgrade from ≤ dev.6), the file's mtime is used instead of
// "now", so an existing library doesn't all look "added today". Afterwards a
// new id is stamped with the time it first shows up.

const KEY = "nobody-added-at-v1";
const MAX = 60000;
/** sanity window for mtime hints: after 1990, not in the future */
const MIN_HINT = Date.UTC(1990, 0, 1);

let map: Record<string, number> | null = null;
let migrating = false;
let saveTimer: ReturnType<typeof setTimeout> | null = null;

function load(): Record<string, number> {
  if (map) return map;
  map = {};
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY) : null;
    if (raw === null) migrating = true;
    else {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        for (const [k, v] of Object.entries(parsed)) if (typeof v === "number" && isFinite(v) && v > 0) map[k] = v;
      }
    }
  } catch {
    /* unreadable → start fresh, but don't treat it as an upgrade */
  }
  return map;
}

function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    if (!map) return;
    try {
      let entries = Object.entries(map);
      if (entries.length > MAX) {
        // keep the newest stamps; the oldest rows simply fall back to "long ago"
        entries = entries.sort((a, b) => b[1] - a[1]).slice(0, MAX);
        map = Object.fromEntries(entries);
      }
      localStorage.setItem(KEY, JSON.stringify(map));
    } catch {
      /* quota: keep the in-memory stamps for this session */
    }
  }, 800);
}

/** First-seen time of a track id; stamps it now (or from `mtimeHint` while
 *  upgrading) when unknown. */
export function addedAtFor(id: string, mtimeHint?: number, now = Date.now()): number {
  const m = load();
  const known = m[id];
  if (known) return known;
  const hint = typeof mtimeHint === "number" && isFinite(mtimeHint) && mtimeHint >= MIN_HINT && mtimeHint <= now ? mtimeHint : 0;
  const at = migrating && hint ? hint : now;
  m[id] = at;
  scheduleSave();
  return at;
}

/** "size:mtime" change stamp → mtime ms (undefined when unknown). */
export function mtimeFromStamp(stamp: string | undefined | null): number | undefined {
  if (!stamp) return undefined;
  const n = Number(stamp.split(":")[1]);
  return isFinite(n) && n > 0 ? n : undefined;
}

/** Tests only. */
export function _resetAddedAt(state: { migrating: boolean; map?: Record<string, number> }) {
  map = state.map ?? {};
  migrating = state.migrating;
}
