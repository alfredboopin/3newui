// ── NOBODY · library store (in-memory mirror of IndexedDB) ───────────────────

import { create } from "zustand";
import { db } from "../lib/db";
import { invalidateCover } from "../lib/covers";
import type { Batch, Playlist, RecentEntry, Track } from "../types";
import { uuid } from "../lib/utils";
import { dropSmartCache, normalizeSmartDef, type SmartPlaylistDef } from "../lib/smartPlaylist";
import { planMerge } from "../../shared/dupes/dupes";

export const LIKED_ID = "liked";

/* V1.2.0: localStorage key for play counts (see playCounts above). */
const PLAY_COUNTS_KEY = "nobody-play-counts";

function loadPlayCounts(): Record<string, number> {
  try {
    const raw = localStorage.getItem(PLAY_COUNTS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function savePlayCounts(counts: Record<string, number>) {
  try {
    localStorage.setItem(PLAY_COUNTS_KEY, JSON.stringify(counts));
  } catch {
    /* storage full — counts are best-effort */
  }
}

/* 1.7.0-dev.6 (P4 · 5): star ratings (1..5) and last-played times. Same
 * reasoning as play counts: kept outside the Track rows (bridge rows are a
 * mirror of the classic library and get rebuilt) and keyed by stable id, so
 * they survive restarts, rescans and tag edits. */
export const RATINGS_KEY = "nobody-ratings-v1";
export const LAST_PLAYED_KEY = "nobody-last-played-v1";

function loadNumberMap(key: string, max: number): Record<string, number> {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    const out: Record<string, number> = {};
    for (const [k, v] of Object.entries(parsed)) {
      if (typeof v === "number" && isFinite(v) && v > 0 && v <= max) out[k] = v;
    }
    return out;
  } catch {
    return {};
  }
}

function saveNumberMap(key: string, map: Record<string, number>) {
  try {
    localStorage.setItem(key, JSON.stringify(map));
  } catch {
    /* storage full — best-effort */
  }
}

/** Ratings are whole stars; anything else from storage / callers is clamped. */
export function clampRating(r: unknown): number {
  const n = Math.round(Number(r));
  return isFinite(n) ? Math.max(0, Math.min(5, n)) : 0;
}

/** Playlists that can be edited by hand (not Liked, not smart). */
export const isManualPlaylist = (p: Playlist) => !p.system && !p.smart;

function sanitizePlaylist(p: Playlist): Playlist | null {
  if (!p || typeof p.id !== "string") return null;
  const trackIds = Array.isArray(p.trackIds) ? p.trackIds.filter((x) => typeof x === "string") : [];
  if (p.smart === undefined) return trackIds === p.trackIds ? p : { ...p, trackIds };
  const smart = normalizeSmartDef(p.smart);
  // a broken definition becomes an empty manual playlist instead of vanishing
  return smart ? { ...p, trackIds: [], smart } : { ...p, trackIds, smart: undefined };
}

interface LibraryStore {
  hydrated: boolean;
  tracks: Record<string, Track>;
  order: string[]; // ids sorted by importedAt asc
  batches: Batch[];
  playlists: Playlist[];
  recents: RecentEntry[];
  /* V1.2.0: per-track play counters for the "Most Played" library category.
   * Kept OUTSIDE the Track records (bridge-mode tracks are a mirror of the
   * classic library and would drop the field on every rehydrate); persisted
   * to localStorage keyed by stable track id so counts survive restarts and
   * work identically in bridge and IndexedDB modes. */
  playCounts: Record<string, number>;
  recordPlay: (id: string) => void;
  /** 1.7.0-dev.6: trackId → 1..5 stars (absent = unrated) */
  ratings: Record<string, number>;
  /** 0 clears the rating */
  setRating: (id: string, stars: number) => void;
  /** 1.7.0-dev.6: trackId → epoch ms of the last genuine play (feeds smart rules) */
  lastPlayed: Record<string, number>;

  hydrate: () => Promise<void>;
  rehydrateTracks: () => Promise<void>;
  addImported: (tracks: Track[], batch: Batch) => void;
  patchTrack: (id: string, patch: Partial<Track>) => void;
  removeTrack: (id: string) => void;
  /** V1.5.4 (P2): one store update + one IDB transaction for N tracks. */
  removeTracks: (ids: string[]) => void;
  toggleLike: (id: string) => void;
  /** 1.7.0 duplicate finder: `map` removed id → kept id. Playlists (Liked
   *  too) point at the kept copy, best rating / summed plays / latest play
   *  move over. Call BEFORE the rows are removed. */
  mergeTrackData: (map: Record<string, string>) => void;
  isLiked: (id: string) => boolean;

  createPlaylist: (name: string) => string;
  /** V1.6.4 (P3): new playlist pre-filled with `ids` (deduped, unknown ids
   *  dropped) in ONE store update + ONE IDB write — "save queue as playlist". */
  createPlaylistFrom: (name: string, ids: string[]) => string;
  renamePlaylist: (id: string, name: string) => void;
  deletePlaylist: (id: string) => void;
  addToPlaylist: (pid: string, tid: string) => void;
  removeFromPlaylist: (pid: string, tid: string) => void;
  moveInPlaylist: (pid: string, from: number, to: number) => void;
  /** 1.7.0-dev.6: rule-based playlists */
  createSmartPlaylist: (name: string, def: SmartPlaylistDef) => string;
  updateSmartPlaylist: (id: string, patch: { name?: string; def?: SmartPlaylistDef }) => void;

  pushRecent: (tid: string) => void;
  clearRecents: () => void;
}

function savePlaylist(p: Playlist) {
  db.putPlaylist(p).catch(() => void 0);
}

export const useLibrary = create<LibraryStore>((set, get) => ({
  hydrated: false,
  tracks: {},
  order: [],
  batches: [],
  playlists: [{ id: LIKED_ID, name: "Liked Songs", trackIds: [], createdAt: 0, system: true }],
  recents: [],
  playCounts: loadPlayCounts(),
  ratings: loadNumberMap(RATINGS_KEY, 5),
  lastPlayed: loadNumberMap(LAST_PLAYED_KEY, Number.MAX_SAFE_INTEGER),

  recordPlay: (id) => {
    if (!id) return;
    const counts = { ...get().playCounts, [id]: (get().playCounts[id] || 0) + 1 };
    const lastPlayed = { ...get().lastPlayed, [id]: Date.now() };
    set({ playCounts: counts, lastPlayed });
    savePlayCounts(counts);
    saveNumberMap(LAST_PLAYED_KEY, lastPlayed);
  },

  setRating: (id, stars) => {
    if (!id) return;
    const r = clampRating(stars);
    const cur = get().ratings;
    if ((cur[id] || 0) === r) return;
    const next = { ...cur };
    if (r) next[id] = r;
    else delete next[id];
    set({ ratings: next });
    saveNumberMap(RATINGS_KEY, next);
  },

  hydrate: async () => {
    const [tracks, batches, playlists, recents] = await Promise.all([
      db.getAllTracks().catch(() => [] as Track[]),
      db.getBatches().catch(() => [] as Batch[]),
      db.getAllPlaylists().catch(() => [] as Playlist[]),
      db.getRecents().catch(() => [] as RecentEntry[]),
    ]);
    const map: Record<string, Track> = {};
    tracks.forEach((t) => (map[t.id] = t));
    const order = tracks.sort((a, b) => a.importedAt - b.importedAt).map((t) => t.id);
    const clean = playlists.map(sanitizePlaylist).filter(Boolean) as Playlist[];
    const liked = clean.find((p) => p.id === LIKED_ID);
    const rest = clean.filter((p) => p.id !== LIKED_ID);
    set({
      hydrated: true,
      tracks: map,
      order,
      batches: batches.sort((a, b) => b.importedAt - a.importedAt),
      playlists: [
        liked ?? { id: LIKED_ID, name: "Liked Songs", trackIds: [], createdAt: 0, system: true },
        ...rest.sort((a, b) => a.createdAt - b.createdAt),
      ],
      recents: recents
        .filter((r) => map[r.trackId])
        .sort((a, b) => b.at - a.at)
        .slice(0, 60),
    });
  },

  /** Re-read tracks (bridge mode: classic library changed underneath us).
   *  Preserves playlists/recents — merges the fresh track map in place. */
  rehydrateTracks: async () => {
    const tracks = await db.getAllTracks().catch(() => [] as Track[]);
    const prev = get().tracks;
    const map: Record<string, Track> = {};
    tracks.forEach((t) => {
      map[t.id] = t;
      // V1.7.0 (P4 · 3): the cover image changed underneath us (tag editor,
      // Smart Fetch in Classic…) → drop the cached URL / backdrop / palette
      // ONCE here, before any consumer re-fetches with the new coverKey.
      const old = prev[t.id];
      if (old && old.coverKey !== t.coverKey) invalidateCover(t.id);
    });
    const order = tracks.sort((a, b) => a.importedAt - b.importedAt).map((t) => t.id);
    set({ tracks: map, order, hydrated: true });
  },

  addImported: (newTracks, batch) => {
    const { tracks, order, batches } = get();
    const map = { ...tracks };
    const ids: string[] = [];
    for (const t of newTracks) {
      if (!map[t.id]) { map[t.id] = t; ids.push(t.id); }
    }
    const existingBatch = batches.find((b) => b.id === batch.id);
    set({
      tracks: map,
      order: [...order, ...ids],
      batches: existingBatch
        ? batches.map((b) => (b.id === batch.id ? { ...b, count: b.count + ids.length } : b))
        : [batch, ...batches],
    });
    db.putTracks(newTracks).catch(() => void 0);
    db.putBatch(existingBatch ? { ...existingBatch, count: existingBatch.count + ids.length } : batch).catch(() => void 0);
  },

  patchTrack: (id, patch) => {
    const cur = get().tracks[id];
    if (!cur) return;
    const next = { ...cur, ...patch };
    set({ tracks: { ...get().tracks, [id]: next } });
    db.putTrack(next).catch(() => void 0);
  },

  removeTrack: (id) => get().removeTracks([id]),

  removeTracks: (ids) => {
    const { tracks, order, batches, playlists, recents } = get();
    const doomed = new Set(ids.filter((id) => tracks[id]));
    if (!doomed.size) return;
    const map = { ...tracks };
    const perBatch = new Map<string, number>();
    for (const id of doomed) {
      const b = map[id].batchId;
      if (b) perBatch.set(b, (perBatch.get(b) ?? 0) + 1);
      delete map[id];
      invalidateCover(id);
    }
    const nextBatches = batches.map((b) => (perBatch.has(b.id) ? { ...b, count: b.count - perBatch.get(b.id)! } : b));
    const changed: Playlist[] = [];
    const nextPlaylists = playlists.map((p) => {
      if (!p.trackIds.some((x) => doomed.has(x))) return p;
      const np = { ...p, trackIds: p.trackIds.filter((x) => !doomed.has(x)) };
      changed.push(np);
      return np;
    });
    set({
      tracks: map,
      order: order.filter((x) => !doomed.has(x)),
      batches: nextBatches.filter((b) => b.count > 0),
      playlists: nextPlaylists,
      recents: recents.filter((r) => !doomed.has(r.trackId)),
    });
    db.deleteTracksBulk([...doomed]).catch(() => void 0);
    changed.forEach((p) => savePlaylist(p)); // only playlists that actually changed
    for (const b of nextBatches) if (b.count <= 0) db.deleteBatch(b.id).catch(() => void 0);
  },

  toggleLike: (id) => {
    const playlists = get().playlists.map((p) => {
      if (p.id !== LIKED_ID) return p;
      const has = p.trackIds.includes(id);
      const next = { ...p, trackIds: has ? p.trackIds.filter((x) => x !== id) : [id, ...p.trackIds] };
      savePlaylist(next);
      return next;
    });
    set({ playlists });
  },

  mergeTrackData: (map) => {
    if (!Object.keys(map).length) return;
    const st = get();
    const plan = planMerge({ playlists: st.playlists, ratings: st.ratings, playCounts: st.playCounts, lastPlayed: st.lastPlayed }, map);
    const changed = new Map(plan.playlists.map((p) => [p.id, p.trackIds]));
    const playlists = st.playlists.map((p) => (changed.has(p.id) ? { ...p, trackIds: changed.get(p.id)! } : p));
    set({ playlists, ratings: plan.ratings, playCounts: plan.playCounts, lastPlayed: plan.lastPlayed });
    for (const p of playlists) if (changed.has(p.id)) savePlaylist(p);
    saveNumberMap(RATINGS_KEY, plan.ratings);
    savePlayCounts(plan.playCounts);
    saveNumberMap(LAST_PLAYED_KEY, plan.lastPlayed);
    dropSmartCache();
  },

  isLiked: (id) => get().playlists.find((p) => p.id === LIKED_ID)?.trackIds.includes(id) ?? false,

  createPlaylist: (name) => {
    const p: Playlist = { id: uuid(), name, trackIds: [], createdAt: Date.now() };
    set({ playlists: [...get().playlists, p] });
    savePlaylist(p);
    return p.id;
  },

  createPlaylistFrom: (name, ids) => {
    const tracks = get().tracks;
    const seen = new Set<string>();
    const trackIds: string[] = [];
    for (const id of ids) {
      if (!id || seen.has(id) || !tracks[id]) continue;
      seen.add(id);
      trackIds.push(id);
    }
    const p: Playlist = { id: uuid(), name, trackIds, createdAt: Date.now() };
    set({ playlists: [...get().playlists, p] });
    savePlaylist(p);
    return p.id;
  },

  renamePlaylist: (id, name) => {
    set({ playlists: get().playlists.map((p) => (p.id === id ? { ...p, name } : p)) });
    const p = get().playlists.find((x) => x.id === id);
    if (p) savePlaylist(p);
  },

  deletePlaylist: (id) => {
    dropSmartCache(id);
    set({ playlists: get().playlists.filter((p) => p.id !== id) });
    db.deletePlaylist(id).catch(() => void 0);
  },

  addToPlaylist: (pid, tid) => {
    set({
      playlists: get().playlists.map((p) =>
        p.id === pid && !p.smart && !p.trackIds.includes(tid) ? { ...p, trackIds: [...p.trackIds, tid] } : p
      ),
    });
    const p = get().playlists.find((x) => x.id === pid);
    if (p) savePlaylist(p);
  },

  removeFromPlaylist: (pid, tid) => {
    set({ playlists: get().playlists.map((p) => (p.id === pid && !p.smart ? { ...p, trackIds: p.trackIds.filter((x) => x !== tid) } : p)) });
    const p = get().playlists.find((x) => x.id === pid);
    if (p) savePlaylist(p);
  },

  moveInPlaylist: (pid, from, to) => {
    set({
      playlists: get().playlists.map((p) => {
        if (p.id !== pid || p.smart) return p;
        const arr = [...p.trackIds];
        const [x] = arr.splice(from, 1);
        arr.splice(to, 0, x);
        const next = { ...p, trackIds: arr };
        savePlaylist(next);
        return next;
      }),
    });
  },

  createSmartPlaylist: (name, def) => {
    const smart = normalizeSmartDef(def);
    const p: Playlist = { id: uuid(), name, trackIds: [], createdAt: Date.now(), smart: smart ?? undefined };
    set({ playlists: [...get().playlists, p] });
    savePlaylist(p);
    return p.id;
  },

  updateSmartPlaylist: (id, patch) => {
    let changed: Playlist | null = null;
    set({
      playlists: get().playlists.map((p) => {
        if (p.id !== id || !p.smart) return p;
        const smart = patch.def ? normalizeSmartDef(patch.def) ?? p.smart : p.smart;
        changed = { ...p, name: patch.name?.trim() || p.name, smart };
        return changed;
      }),
    });
    if (changed) { dropSmartCache(id); savePlaylist(changed); }
  },

  pushRecent: (tid) => {
    const entry = { trackId: tid, at: Date.now() };
    const prev = get().recents;
    // V1.5.3 (P1): IDB is keyed by timestamp, so every replay used to add a
    // duplicate row forever — drop the track's older rows (and the tail that
    // falls out of the 60-entry window) so the store stays bounded.
    const stale = prev.filter((r) => r.trackId === tid);
    const next = [entry, ...prev.filter((r) => r.trackId !== tid)];
    const overflow = next.slice(60);
    set({ recents: next.slice(0, 60) });
    db.addRecent(entry).catch(() => void 0);
    for (const r of [...stale, ...overflow]) db.deleteRecent(r.at).catch(() => void 0);
  },

  clearRecents: () => {
    set({ recents: [] });
    db.clearRecents().catch(() => void 0);
  },
}));
