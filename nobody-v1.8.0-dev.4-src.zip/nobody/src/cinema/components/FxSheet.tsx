// ── NOBODY · Fx sheet — equalizer / speed / sleep timer ──────────────────────
// The "advanced player" control room in one glass sheet. EQ drives the
// engine's WebAudio peaking chain, speed maps to playbackRate (pitch kept),
// sleep timer pauses playback after N minutes or at the end of the track.
// V1.6.2 (P3): 6/10 bands + preamp + the shared presets (src/shared/audioFx)
// and a Volume leveling (ReplayGain) section, all via useSoundFx.

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SlidersHorizontal, X, Timer, Gauge, AudioWaveform, Power, Volume2 } from "lucide-react";
import { engine } from "../lib/engine";
import { useSoundFx, fmtDb, RG_MODES } from "../lib/useSoundFx";
import { EQ_MAX_DB, EQ_MIN_DB, PREAMP_MAX_DB, PREAMP_MIN_DB, fmtFreq } from "../../shared/audioFx";
import type { DictKey } from "../i18n";
import { useUi } from "../store/ui";
import { useSettings } from "../store/settings";
import { useT } from "../lib/useT";
import { cn } from "../utils/cn";

const SLEEP_OPTIONS = [0, 5, 15, 30, 60]; // 0 = end of track

export function FxSheet() {
  const t = useT();
  const show = useUi((s) => s.showFx);
  const setShow = useUi((s) => s.setShowFx);
  const settings = useSettings();
  const [, force] = useState(0); // re-render for countdown + engine-driven chips

  // engine pushes coarse state (play/pause/sleep changes) — reflect instantly
  useEffect(() => engine.on("state", () => force((n) => n + 1)), []);

  // countdown tick while a timed sleep is active
  useEffect(() => {
    if (engine.sleepMode !== "timed") return;
    const iv = window.setInterval(() => force((n) => n + 1), 1000);
    return () => window.clearInterval(iv);
  }, [show, engine.sleepMode]);

  const fx = useSoundFx();
  const rgOff = fx.rg.mode === "off";
  const speed = settings.speed ?? 1;

  const speedChips = [0.75, 1, 1.25, 1.5, 2];
  const sleepActive = engine.sleepMode !== "off";
  const remainMs = Math.max(0, engine.sleepEndsAtMs - Date.now());
  const remainLabel = `${Math.floor(remainMs / 60000)}:${String(Math.floor((remainMs % 60000) / 1000)).padStart(2, "0")}`;

  return (
    <AnimatePresence>
      {show && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[57] bg-black/50"
            onClick={() => setShow(false)}
          />
          <motion.div
            role="dialog"
            aria-label={t("fxTitle")}
            initial={{ opacity: 0, y: 26, scale: 0.985 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 18, scale: 0.99 }}
            transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
            className="glass fixed inset-x-0 bottom-0 z-[58] mx-auto flex max-h-[88vh] w-[min(560px,96vw)] flex-col overflow-hidden rounded-t-[26px]"
          >
            {/* header */}
            <div className="flex items-center justify-between border-b px-5 py-4" style={{ borderColor: "var(--line)" }}>
              <div className="flex items-center gap-2.5">
                <span className="flex h-8 w-8 items-center justify-center rounded-xl" style={{ background: "color-mix(in srgb, var(--accent) 16%, transparent)" }}>
                  <SlidersHorizontal size={15} className="t-accent" />
                </span>
                <div>
                  <div className="font-display text-lg italic leading-tight">{t("fxTitle")}</div>
                  <div className="t-faint text-[10.5px]">{t("fxSub")}</div>
                </div>
              </div>
              <button onClick={() => setShow(false)} aria-label={t("close")} className="t-mut rounded-full p-2 transition-colors hover:bg-white/10">
                <X size={16} />
              </button>
            </div>

            <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
              {/* ── equalizer (V1.6.2 · P3: 6/10 bands, preamp, shared presets) ── */}
              <section>
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[12.5px] font-semibold">
                    <AudioWaveform size={14} className="t-accent" /> {t("fxEq")}
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="flex rounded-full border p-0.5" style={{ borderColor: "var(--line2)" }} role="group" aria-label={t("fxBands")}>
                      {([6, 10] as const).map((b) => (
                        <button
                          key={b}
                          onClick={() => fx.setBands(b)}
                          aria-pressed={fx.bands === b}
                          className={cn(
                            "tnum rounded-full px-2.5 py-0.5 text-[10.5px] transition-all",
                            fx.bands === b ? "bg-accent font-semibold" : "t-mut hover:text-[var(--fg)]"
                          )}
                        >
                          {t(b === 6 ? "fxBands6" : "fxBands10")}
                        </button>
                      ))}
                    </div>
                    <button
                      role="switch"
                      aria-checked={fx.eqOn}
                      onClick={fx.toggleEq}
                      className="switch"
                      data-on={fx.eqOn}
                      aria-label={t("fxEq")}
                    />
                  </div>
                </div>

                <div className={cn("flex items-end gap-1 rounded-2xl px-2 py-4 transition-opacity", !fx.eqOn && "opacity-40")} style={{ background: "var(--bg2)" }}>
                  {/* preamp column, set apart by a hairline */}
                  <div className="flex shrink-0 flex-col items-center gap-1.5 pe-2" style={{ borderInlineEnd: "1px solid var(--line)" }}>
                    <span className="tnum t-faint text-[9.5px]">{fmtDb(fx.preamp)}</span>
                    <input
                      type="range"
                      min={PREAMP_MIN_DB}
                      max={PREAMP_MAX_DB}
                      step={0.5}
                      value={fx.preamp}
                      onChange={(e) => fx.setPreamp(Number(e.target.value))}
                      onDoubleClick={() => fx.setPreamp(0)}
                      className="nc-vert-range nobody-range"
                      disabled={!fx.eqOn}
                      aria-label={t("fxPreamp")}
                      title={t("fxPreampSub")}
                    />
                    <span className="t-accent text-[9.5px] font-semibold">{t("fxPreamp")}</span>
                  </div>
                  <div className="flex min-w-0 flex-1 items-end justify-between gap-0.5">
                    {fx.freqs.map((f, i) => (
                      <div key={`${fx.bands}-${f}`} className="flex min-w-0 flex-1 flex-col items-center gap-1.5">
                        <span className="tnum t-faint text-[9.5px]">{fmtDb(fx.gains[i] ?? 0)}</span>
                        <input
                          type="range"
                          min={EQ_MIN_DB}
                          max={EQ_MAX_DB}
                          step={0.5}
                          value={fx.gains[i] ?? 0}
                          onChange={(e) => fx.setGain(i, Number(e.target.value))}
                          onDoubleClick={() => fx.setGain(i, 0)}
                          className="nc-vert-range nobody-range"
                          disabled={!fx.eqOn}
                          aria-label={`${f} Hz`}
                        />
                        <span className="tnum t-mut text-[9.5px]">{fmtFreq(f)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  {fx.presets.map((name) => (
                    <button
                      key={name}
                      disabled={!fx.eqOn}
                      onClick={() => fx.applyPreset(name)}
                      className={cn(
                        "rounded-full border px-3 py-1 text-[11px] transition-all disabled:opacity-40",
                        fx.activePreset === name ? "bg-accent font-semibold" : "t-mut hover:text-[var(--fg)]"
                      )}
                      style={{ borderColor: fx.activePreset === name ? "transparent" : "var(--line2)" }}
                    >
                      {t(`fxPreset_${name}` as DictKey)}
                    </button>
                  ))}
                  {fx.eqOn && !fx.activePreset && (
                    <span className="t-accent rounded-full border px-3 py-1 text-[11px] font-semibold" style={{ borderColor: "var(--accent)" }}>
                      {t("fxPresetCustom")}
                    </span>
                  )}
                  {fx.eqOn && (fx.activePreset !== "flat" || Math.abs(fx.preamp) > 0.01) && (
                    <button
                      onClick={fx.resetEq}
                      className="t-faint rounded-full border px-3 py-1 text-[11px] transition-colors hover:text-[var(--fg)]"
                      style={{ borderColor: "var(--line2)" }}
                    >
                      {t("fxReset")}
                    </button>
                  )}
                </div>
              </section>

              {/* ── volume leveling / ReplayGain (V1.6.2 · P3) ── */}
              <section className="mt-6">
                <div className="mb-1 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-[12.5px] font-semibold">
                    <Volume2 size={14} className="t-accent" /> {t("fxRg")}
                  </div>
                  <div className="flex rounded-full border p-0.5" style={{ borderColor: "var(--line2)" }} role="group" aria-label={t("fxRg")}>
                    {RG_MODES.map((m) => (
                      <button
                        key={m}
                        onClick={() => fx.setRg({ mode: m })}
                        aria-pressed={fx.rg.mode === m}
                        className={cn(
                          "rounded-full px-2.5 py-0.5 text-[10.5px] transition-all",
                          fx.rg.mode === m ? "bg-accent font-semibold" : "t-mut hover:text-[var(--fg)]"
                        )}
                      >
                        {t(m === "off" ? "fxRgOff" : m === "track" ? "fxRgTrack" : "fxRgAlbum")}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="t-faint mb-3 text-[11px] leading-relaxed">{t("fxRgSub")}</p>

                <div className={cn("space-y-3 rounded-2xl px-4 py-3.5 transition-opacity", rgOff && "pointer-events-none opacity-40")} style={{ background: "var(--bg2)" }} aria-disabled={rgOff}>
                  <RangeRow
                    label={t("fxRgPreamp")}
                    value={fx.rg.preamp}
                    min={-12}
                    max={12}
                    disabled={rgOff}
                    onChange={(v) => fx.setRg({ preamp: v })}
                  />
                  <RangeRow
                    label={t("fxRgFallback")}
                    value={fx.rg.fallback}
                    min={-12}
                    max={0}
                    disabled={rgOff}
                    onChange={(v) => fx.setRg({ fallback: v })}
                  />
                  <div className="flex items-center justify-between">
                    <span className="text-[11.5px]">{t("fxRgClip")}</span>
                    <button
                      role="switch"
                      aria-checked={fx.rg.preventClip}
                      onClick={() => fx.setRg({ preventClip: !fx.rg.preventClip })}
                      className="switch"
                      data-on={fx.rg.preventClip}
                      disabled={rgOff}
                      aria-label={t("fxRgClip")}
                    />
                  </div>
                  {fx.rgNow.hasTrack && (
                    <div className="flex items-center justify-between border-t pt-2.5 text-[11px]" style={{ borderColor: "var(--line)" }}>
                      <span className="t-mut">{t("fxRgNow")}</span>
                      <span className="tnum t-accent">
                        {fmtDb(fx.rgNow.db)} dB{!fx.rgNow.tagged && <span className="t-faint"> · {t("fxRgNoTag")}</span>}
                      </span>
                    </div>
                  )}
                </div>
                <p className="t-faint mt-2 text-[10.5px] leading-relaxed">{t("fxRgHint")}</p>
              </section>

              {/* ── speed ── */}
              <section className="mt-6">
                <div className="mb-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[12.5px] font-semibold">
                    <Gauge size={14} className="t-accent" /> {t("fxSpeed")}
                  </div>
                  <span className="tnum t-mut text-[12px]">{speed.toFixed(2)}×</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={2}
                  step={0.05}
                  value={speed}
                  onChange={(e) => engine.setRate(Number(e.target.value))}
                  className="nobody-range w-full"
                  aria-label={t("fxSpeed")}
                />
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {speedChips.map((r) => (
                    <button
                      key={r}
                      onClick={() => engine.setRate(r)}
                      className={cn(
                        "tnum rounded-full border px-3 py-1 text-[11px] transition-all",
                        Math.abs(speed - r) < 0.01 ? "bg-accent font-semibold" : "t-mut hover:text-[var(--fg)]"
                      )}
                      style={{ borderColor: Math.abs(speed - r) < 0.01 ? "transparent" : "var(--line2)" }}
                    >
                      {r}×
                    </button>
                  ))}
                  {Math.abs(speed - 1) > 0.01 && (
                    <button
                      onClick={() => engine.setRate(1)}
                      className="t-faint rounded-full border px-3 py-1 text-[11px] transition-colors hover:text-[var(--fg)]"
                      style={{ borderColor: "var(--line2)" }}
                    >
                      {t("fxReset")}
                    </button>
                  )}
                </div>
              </section>

              {/* ── sleep timer ── */}
              <section className="mt-6 pb-1">
                <div className="mb-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[12.5px] font-semibold">
                    <Timer size={14} className="t-accent" /> {t("fxSleep")}
                  </div>
                  {sleepActive && (
                    <span className="t-accent tnum flex items-center gap-1.5 text-[11.5px]">
                      <span className="blink inline-block h-1.5 w-1.5 rounded-full" style={{ background: "var(--accent)" }} />
                      {engine.sleepMode === "track" ? t("fxSleepTrack") : remainLabel}
                      <button
                        onClick={() => engine.cancelSleepTimer()}
                        className="t-faint ms-1 rounded-full p-1 transition-colors hover:text-[var(--fg)]"
                        aria-label={t("fxSleepCancel")}
                      >
                        <Power size={11} />
                      </button>
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {SLEEP_OPTIONS.map((m) => (
                    <button
                      key={m}
                      onClick={() => engine.startSleepTimer(m)}
                      className={cn(
                        "tnum rounded-full border px-3.5 py-1.5 text-[11.5px] transition-all",
                        (m === 0 && engine.sleepMode === "track") || (m > 0 && engine.sleepMode === "timed" && engine.sleepMinutes === m)
                          ? "bg-accent font-semibold"
                          : "t-mut hover:text-[var(--fg)]"
                      )}
                      style={{ borderColor: "var(--line2)" }}
                    >
                      {m === 0 ? t("fxSleepTrack") : `${m} ${t("fxMin")}`}
                    </button>
                  ))}
                </div>
                <p className="t-faint mt-2.5 text-[11px] leading-relaxed">{t("fxSleepHint")}</p>
              </section>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/** Label + horizontal dB slider + value (ReplayGain boost / fallback). */
function RangeRow({ label, value, min, max, disabled, onChange }: {
  label: string; value: number; min: number; max: number; disabled?: boolean; onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-[11.5px]">
        <span>{label}</span>
        <span className="tnum t-mut">{fmtDb(value)} dB</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={0.5}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(Number(e.target.value))}
        onDoubleClick={() => onChange(0)}
        className="nobody-range w-full"
        aria-label={label}
      />
    </div>
  );
}
