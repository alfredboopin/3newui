import type { ReplayGainInfo } from "./shared/replayGain";

export type Language = "fa" | "en" | "tr" | "ru";

export type Page = "focus" | "library" | "lyrics" | "downloads" | "contact" | "donate" | "settings";

export type LyricLine = {
  time: number;
  text: string;
  translations?: Partial<Record<Language, string>>;
};

export type AudioMetadata = {
  format: string;
  bitrate: string;
  sampleRate: string;
  channels: string;
  fileSize: string;
  /** 1.7.0: exact size in bytes (fileSize is a rounded "x.y MB" label). Absent on
   *  libraries saved before 1.7.0; the bridge then falls back to sourceStamp. */
  bytes?: number;
  codec: string;
  bitDepth: string;
  path: string;
  composer?: string;
  genre?: string;
  /** V1.6.1 (P3): ReplayGain / R128 loudness tags */
  replayGain?: ReplayGainInfo;
};

export type Track = {
  id: number;
  title: string;
  artist: string;
  album: string;
  year: string;
  cover: string;
  accent: string;
  secondary: string;
  duration: number;
  durationLabel: string;
  bpm: number;
  key: string;
  lyrics: LyricLine[];
  metadata: AudioMetadata;
  sourceUrl?: string;
  sourcePath?: string;
  folderPath?: string;
  lrcSource?: string;
  isFallbackLyric?: boolean;
  isFallbackCover?: boolean;
  /** 1.7.0-dev.5 (P4 · 4): "size:mtime" of the file when it was last read;
   *  a rescan re-reads the file only when this changes. */
  sourceStamp?: string;
  /** 1.7.0-dev.5: where the current cover came from. A file changed outside
   *  the app may replace an embedded / placeholder cover, never one the user
   *  picked or Smart Fetch found. */
  coverOrigin?: "embedded" | "sidecar" | "fetched" | "user" | "fallback";
  /** 1.7.0-dev.5: cheap signature of the embedded cover (skip a palette
   *  recompute when a rescan finds the same picture). */
  coverSig?: string;
  /** 1.7.0-dev.5: a library-only tag edit is laid over the file's tags. */
  tagOverride?: boolean;
};

export type Playlist = {
  id: string;
  name: string;
  trackIds: number[];
  createdAt: number;
  system?: "liked";
  emoji?: string;
  color?: string;
};

export type PersistedState = {
  trackId?: number;
  elapsed?: number;
  volume?: number;
  lang?: Language;
  likedIds?: number[];
  playlists?: Playlist[];
  urQueueIds?: number[];
  showTranslation?: boolean;
  lyricSize?: number;
  lyricStyle?: "classic" | "karaoke" | "minimal";
  idleEqualizerStyle?: "bars" | "wave" | "orbit" | "random";
  compactStyle?: "classic" | "cover" | "minimal";
  ambientMotion?: boolean;
  autoColor?: boolean;
  highContrast?: boolean;
  themeMode?: "dark" | "light";
  folderPaths?: string[];
  /** 1.7.0-dev.9: single files outside the managed folders that must come back
   *  after a restart (songs added by an M3U import). */
  looseFiles?: string[];
  recentlyPlayedIds?: number[];
  /** V1.6.3 (P3): Classic repeat off / all / one */
  repeatMode?: "off" | "all" | "one";
  savedAt?: number;
};

export type QuoteItem = {
  id: number;
  fa: string;
  en: string;
  tr: string;
  /** Task 40-i18n-ru: ready Russian quote text + author. Consumers should
   *  render `lang === "ru" ? (q.ru ?? q.en) : ...` — always fall back to en. */
  ru?: string;
  authorRu?: string;
  /** RU subject words used by the generator (pairs). Kept on every quote so a
   *  `q.ruX ?? q.en`-style lookup also lands on Russian text when present. */
  ruX?: string;
  ruY?: string;
  authorFa: string;
  authorEn: string;
  authorTr: string;
};
