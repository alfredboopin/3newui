// ── NOBODY · Performance mode (V1.5.4 · Phase 2) ─────────────────────────────
// One global switch shared by all four faces. When on, <html> carries
// data-nb-perf="lite" and src/perf.css drops the expensive always-on eye
// candy (backdrop blur, drifting aurora blobs, stardust, orbit spins); the
// shared frame loop also throttles decorative canvases to ~30 fps.
// Independently of the switch, <html data-nb-hidden> is set while the
// window is hidden so every CSS animation pauses (no compositor work while
// minimized).

import { useSyncExternalStore } from "react";

const KEY = "nobody-perf-mode";
type Listener = (on: boolean) => void;
const listeners = new Set<Listener>();

let lite = read();

function read(): boolean {
  try {
    return localStorage.getItem(KEY) === "lite";
  } catch {
    return false;
  }
}

function apply() {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  if (lite) root.setAttribute("data-nb-perf", "lite");
  else root.removeAttribute("data-nb-perf");
}

export function isPerfLite(): boolean {
  return lite;
}

export function setPerfLite(on: boolean): void {
  if (on === lite) return;
  lite = on;
  try {
    if (on) localStorage.setItem(KEY, "lite");
    else localStorage.removeItem(KEY);
  } catch {
    /* storage unavailable — the switch still works for this session */
  }
  apply();
  for (const l of listeners) l(on);
}

export function onPerfModeChange(fn: Listener): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

/** React hook: `[on, setOn]`. */
export function usePerfLite(): [boolean, (on: boolean) => void] {
  const on = useSyncExternalStore(
    (cb) => onPerfModeChange(cb),
    isPerfLite,
    isPerfLite
  );
  return [on, setPerfLite];
}

let installed = false;
/** Called once from main.tsx before the first render. */
export function installPerfMode(): void {
  if (installed || typeof document === "undefined") return;
  installed = true;
  apply();
  const syncHidden = () => {
    if (document.hidden) document.documentElement.setAttribute("data-nb-hidden", "");
    else document.documentElement.removeAttribute("data-nb-hidden");
  };
  syncHidden();
  document.addEventListener("visibilitychange", syncHidden);
  // another window of the app flipped the switch
  window.addEventListener("storage", (e) => {
    if (e.key !== KEY) return;
    const next = read();
    if (next !== lite) { lite = next; apply(); for (const l of listeners) l(next); }
  });
}
