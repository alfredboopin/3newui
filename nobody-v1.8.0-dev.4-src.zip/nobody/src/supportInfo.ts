// ── NOBODY · central support & contact data (V1.4.0) ─────────────────────────
// ONE source of truth for every face (classic / cinema / EELA / ALOK):
// donation wallets + direct-support portal + creator contact points.
// The data mirrors the CLASSIC donate/contact sections (user request #11:
// "اطلاعات بخش دونیت رو از classic ui بگیر"). When the donation info is
// updated later, THIS file is the only place that needs touching.

export interface SupportWallet {
  code: string;
  network: string;
  name: string;
  address: string;
  color: string;
  mono: string;
}

/** Crypto wallets — the creator's REAL addresses (V1.5.2 user request,
 *  «اطلاعات بخش دونیت همه ui ها») — listed in the user's own order:
 *  Tron, USDT (TRC-20), BTC. USDT-TRC20 shares the Tron address by design
 *  (USDT on the Tron chain lives on the same wallet address). */
export const DONATE_WALLETS: SupportWallet[] = [
  { code: "TRX", network: "Tron", name: "Tron", address: "TWdqYu5H6emRHd6jFfkHjfG8Yg2285DFmT", color: "#ef0027", mono: "T" },
  { code: "USDT", network: "TRC-20", name: "Tether", address: "TWdqYu5H6emRHd6jFfkHjfG8Yg2285DFmT", color: "#26a17b", mono: "₮" },
  { code: "BTC", network: "Bitcoin", name: "Bitcoin", address: "bc1qq2xlwehtzwugn9w987n9phyglzlclmnl5z6y0r", color: "#f7931a", mono: "₿" },
];

/** Direct-support portal (classic's Reymit card). */
export const DONATE_DIRECT = {
  label: "Reymit",
  href: "https://reymit.ir/epodonios",
};

/** Creator contact points (user request #7). Instagram has no real page yet —
 *  it renders as a disabled "coming soon" row everywhere. */
export const CONTACT = {
  email: "Epodonios@gmail.com",
  telegramHandle: "@nowheremans",
  telegramHref: "https://t.me/nowheremans",
  githubHandle: "Epodonios/NOBODY-player",
  githubHref: "https://github.com/Epodonios/NOBODY-player",
  instagramHandle: "@epodonios",
  instagramHref: "", // not launched yet → "coming soon"
};

/** Copy an address to the clipboard with the legacy textarea fallback
 *  (the classic UI's proven approach — clipboard API can be blocked). */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
      return true;
    } catch {
      return false;
    }
  }
}
