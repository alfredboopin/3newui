// NOBODY 1.8.0-dev.4 · Phase 5 installer hardening, node run (no Electron / Windows needed)
//   I   setup-app/electron/installerCore.ts on a fake payload: junction (symlink) guard,
//       hardlink trap, elevated in-place refusal, async copy (event loop stays live),
//       cancel + rollback, upgrade, in-place uninstall that never deletes through a link
//   II  winproc (player .cjs + setup .ts twin): path-verified PIDs, graceful quit, PowerShell quoting
//   III elevation hand-over argument (resume.ts)
//   IV  player uninstall.cjs: in-place delete lines never go through a link
// run: node docs/tests/installer-run.cjs   (TS bundled on the fly with esbuild; ORIG_CORE=<old installerCore.ts> adds the stall comparison)
'use strict';
const path = require('path'); const fs = require('fs'); const os = require('os'); const Module = require('module');
const ROOT = path.resolve(__dirname, '../..');
const { buildSync } = require(process.env.ESBUILD || '/opt/sd-artifact/node_modules/esbuild');
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, x) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, x !== undefined ? JSON.stringify(x).slice(0, 400) : ''); } };
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const OUT = fs.mkdtempSync(path.join(os.tmpdir(), 'nobody-inst-build-'));
function bundle(entry, name) {
  const outfile = path.join(OUT, name + '.cjs');
  buildSync({ entryPoints: [entry], bundle: true, platform: 'node', format: 'cjs', outfile, logLevel: 'error', target: 'node20' });
  return require(outfile);
}
const core = bundle(path.join(ROOT, 'setup-app/electron/installerCore.ts'), 'core');
const wpTs = bundle(path.join(ROOT, 'setup-app/electron/winproc.ts'), 'winproc');
const resume = bundle(path.join(ROOT, 'setup-app/electron/resume.ts'), 'resume');
const wpCjs = require(path.join(ROOT, 'electron/winproc.cjs'));
const ORIG = process.env.ORIG_CORE;
const coreOld = ORIG && fs.existsSync(ORIG) ? bundle(ORIG, 'core-old') : null;

const T = fs.mkdtempSync(path.join(os.tmpdir(), 'nobody-inst-'));
const rnd = (n, seed) => { const b = Buffer.alloc(n); let x = seed >>> 0 || 1; for (let i = 0; i < n; i += 4) { x = (x * 1103515245 + 12345) >>> 0; b.writeUInt32LE(x, Math.min(i, n - 4)); } return b; };
const sha = (b) => require('crypto').createHash('sha256').update(b).digest('hex');

function makeFixture(name, { big = 0, small = 6 } = {}) {
  const base = path.join(T, name); const payload = path.join(base, 'payload'); const runtime = path.join(base, 'runtime');
  fs.mkdirSync(path.join(payload, 'resources'), { recursive: true }); fs.mkdirSync(path.join(runtime, 'locales'), { recursive: true });
  const files = [];
  const put = (rel, buf) => { const p = path.join(payload, ...rel.split('/')); fs.mkdirSync(path.dirname(p), { recursive: true }); fs.writeFileSync(p, buf); files.push({ rel, bytes: buf.length, sha256: sha(buf) }); };
  put('resources/app.asar', rnd(big || 200_000, 7));
  put('icon.png', rnd(3000, 9));
  for (let i = 0; i < small; i++) put(`resources/fonts/f${i}.woff2`, rnd(4000 + i * 4, 100 + i));
  const rt = [];
  const rput = (rel, buf) => { fs.writeFileSync(path.join(runtime, ...rel.split('/')), buf); rt.push({ rel, bytes: buf.length }); };
  rput('ffmpeg.dll', rnd(50_000, 3)); rput('locales/en-US.pak', rnd(20_000, 4));
  const exe = path.join(runtime, 'electron-exe'); fs.writeFileSync(exe, rnd(90_000, 5));
  const manifest = { files, totalBytes: files.reduce((a, f) => a + f.bytes, 0), totalFiles: files.length };
  return { base, payload, runtime, exe, manifest, rt };
}
function makeDeps(fx, over = {}) {
  const events = []; const shortcuts = []; const regs = []; const closed = [];
  const deps = {
    isWin: false, appVersion: '1.8.0-dev.4', payloadDir: fx.payload, manifest: fx.manifest,
    desktopDir: (scope) => path.join(fx.base, scope === 'all' ? 'public-desktop' : 'desktop'),
    startMenuDir: (scope) => path.join(fx.base, scope === 'all' ? 'common-start' : 'start'),
    writeShortcut: (lnk, exe, args) => { try { fs.mkdirSync(path.dirname(lnk), { recursive: true }); fs.writeFileSync(lnk, `${exe} ${args || ''}`); shortcuts.push(lnk); return 'created'; } catch { return 'failed'; } },
    writeUninstallRegistration: (info) => { regs.push(info); },
    removeUninstallRegistration: () => {},
    closeRunningApp: async (dir) => { closed.push(dir); return false; },
    onEvent: (ev) => events.push(ev),
    cancelled: () => false,
    runtimeDir: () => fx.runtime, runtimeFiles: () => fx.rt, runtimeExePath: () => fx.exe,
    ...over,
  };
  return { deps, events, shortcuts, regs, closed };
}
const errCode = (events) => (events.find((e) => e.type === 'error') || {}).code;
const exists = (p) => fs.existsSync(p);
const O = (destDir, scope = 'me', desktop = false) => ({ destDir, scope, desktop, launchAfter: false, openFolder: false });

(async () => {
  console.log('\n■ I1 · fresh per-user install');
  let fx = makeFixture('fresh'); let dest = path.join(fx.base, 'Programs', 'NOBODY');
  let d = makeDeps(fx);
  let r = await core.runInstall(O(dest, 'me', true), d.deps);
  ok(r.ok, 'installs', r.error);
  ok(fx.manifest.files.every((f) => sha(fs.readFileSync(path.join(dest, ...f.rel.split('/')))) === f.sha256), 'every payload file lands byte-exact');
  ok(exists(path.join(dest, 'NOBODY')) && exists(path.join(dest, 'ffmpeg.dll')) && exists(path.join(dest, core.UNINSTALL_SENTINEL)), 'runtime exe + dlls + uninstall marker');
  ok(d.shortcuts.length === 3 && d.shortcuts.every((s) => s.startsWith(path.join(fx.base, 'start')) || s.startsWith(path.join(fx.base, 'desktop'))), 'per-user shortcuts → the user Start Menu / Desktop', d.shortcuts);
  ok(eq(d.closed, [dest]), 'closeRunningApp asked for THIS folder only', d.closed);

  console.log('\n■ I2 · junction planted inside a foreign folder (in-place install)');
  fx = makeFixture('junction'); dest = path.join(fx.base, 'Games');
  const victim = path.join(fx.base, 'victim'); fs.mkdirSync(victim); fs.writeFileSync(path.join(victim, 'app.asar'), 'SYSTEM FILE');
  fs.mkdirSync(dest); fs.writeFileSync(path.join(dest, 'their-save.dat'), 'theirs');
  fs.symlinkSync(victim, path.join(dest, 'resources'), 'junction');
  d = makeDeps(fx);
  r = await core.runInstall(O(dest), d.deps);
  ok(!r.ok && errCode(d.events) === 'E-REPARSE', 'install refused with E-REPARSE', [r.error, errCode(d.events)]);
  ok(fs.readFileSync(path.join(victim, 'app.asar'), 'utf8') === 'SYSTEM FILE' && fs.readdirSync(victim).length === 1, 'nothing written through the junction (target untouched)', fs.readdirSync(victim));
  ok(fs.readFileSync(path.join(dest, 'their-save.dat'), 'utf8') === 'theirs' && fs.lstatSync(path.join(dest, 'resources')).isSymbolicLink(), 'rollback deleted nothing of theirs, nothing through the link');
  ok(!exists(path.join(dest, 'NOBODY')), 'files written before the junction were rolled back');

  console.log('\n■ I3 · the destination itself is a link');
  fx = makeFixture('destlink'); const realT = path.join(fx.base, 'elsewhere'); fs.mkdirSync(realT);
  dest = path.join(fx.base, 'NOBODY'); fs.symlinkSync(realT, dest, 'junction');
  d = makeDeps(fx);
  r = await core.runInstall(O(dest), d.deps);
  ok(!r.ok && errCode(d.events) === 'E-REPARSE' && fs.readdirSync(realT).length === 0, 'refused, link target stays empty', [errCode(d.events), fs.readdirSync(realT)]);

  console.log('\n■ I4 · all users (elevated): linked ancestor, foreign non-empty folder');
  fx = makeFixture('elev'); const realP = path.join(fx.base, 'realParent'); fs.mkdirSync(realP);
  fs.symlinkSync(realP, path.join(fx.base, 'Program Files'), 'junction');
  dest = path.join(fx.base, 'Program Files', 'NOBODY');
  d = makeDeps(fx, { elevated: true });
  r = await core.runInstall(O(dest, 'all'), d.deps);
  ok(!r.ok && errCode(d.events) === 'E-REPARSE' && fs.readdirSync(realP).length === 0, 'a junction ABOVE the destination is refused', errCode(d.events));
  dest = path.join(fx.base, 'Shared'); fs.mkdirSync(dest); fs.writeFileSync(path.join(dest, 'x.txt'), 'x');
  d = makeDeps(fx, { elevated: true });
  r = await core.runInstall(O(dest, 'all'), d.deps);
  ok(!r.ok && errCode(d.events) === 'E-INPLACE-ELEVATED' && fs.readdirSync(dest).length === 1, 'into a foreign non-empty folder → refused, untouched', errCode(d.events));
  dest = path.join(fx.base, 'Empty'); fs.mkdirSync(dest);
  d = makeDeps(fx, { elevated: true });
  r = await core.runInstall(O(dest, 'all', true), d.deps);
  ok(r.ok, 'into an empty folder → fine', r.error);
  ok(d.shortcuts.length === 3 && d.shortcuts.every((s) => s.includes('common-start') || s.includes('public-desktop')), 'common Start Menu + Public Desktop', d.shortcuts);
  ok(JSON.parse(fs.readFileSync(path.join(dest, core.UNINSTALL_SENTINEL), 'utf8')).scope === 'all', 'marker records scope "all"');

  console.log("\n■ I5 · hardlink trap: an existing file shares its data with someone else's");
  fx = makeFixture('hardlink'); dest = path.join(fx.base, 'Mine'); fs.mkdirSync(path.join(dest, 'resources'), { recursive: true });
  const precious = path.join(fx.base, 'precious.bin'); fs.writeFileSync(precious, 'PRECIOUS');
  fs.linkSync(precious, path.join(dest, 'resources', 'app.asar'));
  d = makeDeps(fx);
  r = await core.runInstall(O(dest), d.deps);
  ok(r.ok && fs.readFileSync(precious, 'utf8') === 'PRECIOUS', 'install ok, the hardlinked file elsewhere is untouched', r.error);
  ok(sha(fs.readFileSync(path.join(dest, 'resources', 'app.asar'))) === fx.manifest.files[0].sha256, 'and ours is the real payload');

  console.log('\n■ I6 · async copy: the event loop stays live during a big install');
  fx = makeFixture('big', { big: 96 * 1024 * 1024, small: 300 });
  const measure = async (impl, destName) => {
    const dd = makeDeps(fx);
    if (impl === coreOld) { dd.deps.closeRunningApp = () => false; }
    let last = Date.now(); let maxGap = 0; const iv = setInterval(() => { const n = Date.now(); maxGap = Math.max(maxGap, n - last); last = n; }, 5);
    const t0 = Date.now();
    const res = await impl.runInstall(O(path.join(fx.base, destName)), dd.deps);
    clearInterval(iv); const n = Date.now(); maxGap = Math.max(maxGap, n - last);
    return { ok: res.ok, err: res.error, maxGap, ms: n - t0 };
  };
  const nw = await measure(core, 'BigNew');
  ok(nw.ok, `96 MB + 300 files installed (${nw.ms} ms)`, nw.err);
  ok(nw.maxGap < 150, `longest main-thread stall ${nw.maxGap} ms (< 150 ms)`, nw);
  if (coreOld) {
    const old = await measure(coreOld, 'BigOld');
    console.log(`    (1.8.0-dev.3 sync copy: longest stall ${old.maxGap} ms, ${old.ms} ms total)`);
    ok(old.maxGap > nw.maxGap * 2, `the old sync copy froze ${old.maxGap} ms at a time, now ${nw.maxGap} ms`);
  }

  console.log('\n■ I7 · cancel mid-copy → prompt, full rollback');
  let cancel = false; let cancelAt = 0;
  d = makeDeps(fx, { cancelled: () => cancel, onEvent: (ev) => { if (ev.type === 'progress' && ev.frac > 0.03 && !cancel) { cancel = true; cancelAt = Date.now(); } } });
  dest = path.join(fx.base, 'Cancelled');
  r = await core.runInstall(O(dest), d.deps);
  const lag = Date.now() - cancelAt;
  ok(r.cancelled && !exists(dest), 'cancelled, fresh folder removed (leave no trace)', [r, exists(dest)]);
  ok(cancelAt > 0 && lag < 3000, `cancel honoured ${lag} ms after the click`);

  console.log('\n■ I8 · upgrade over a previous NOBODY');
  fx = makeFixture('upgrade'); dest = path.join(fx.base, 'NOBODY');
  d = makeDeps(fx); await core.runInstall(O(dest), d.deps);
  fs.writeFileSync(path.join(dest, 'stale-from-old.dll'), 'old');
  d = makeDeps(fx); r = await core.runInstall(O(dest), d.deps);
  ok(r.ok && !exists(path.join(dest, 'stale-from-old.dll')) && fs.readdirSync(fx.base).every((n) => !n.includes('.bak-')), 'old install staged aside, replaced, backup removed', r.error);

  console.log('\n■ I9 · Setup uninstall of an IN-PLACE install keeps the foreign folder');
  fx = makeFixture('inplace-un'); dest = path.join(fx.base, 'Tools'); fs.mkdirSync(path.join(dest, 'resources'), { recursive: true });
  fs.writeFileSync(path.join(dest, 'theirs.txt'), 'theirs'); fs.writeFileSync(path.join(dest, 'resources', 'their.cfg'), 'cfg');
  d = makeDeps(fx); r = await core.runInstall(O(dest), d.deps);
  ok(r.ok, 'installed in place', r.error);
  const sent = JSON.parse(fs.readFileSync(path.join(dest, core.UNINSTALL_SENTINEL), 'utf8'));
  ok(sent.inPlace === true && sent.files.includes('resources/app.asar'), 'marker lists exactly our files');
  const v2 = path.join(fx.base, 'victim2'); fs.mkdirSync(v2); fs.writeFileSync(path.join(v2, 'f0.woff2'), 'KEEP');
  fs.rmSync(path.join(dest, 'resources', 'fonts'), { recursive: true }); fs.symlinkSync(v2, path.join(dest, 'resources', 'fonts'), 'junction');
  const plan = core.buildUninstallPlan({ installDir: dest, scope: 'me', version: '1.8.0-dev.4', keepData: true, isWin: false, desktopDir: path.join(fx.base, 'desktop'), startMenuDir: path.join(fx.base, 'start'), userDataDir: path.join(fx.base, 'ud'), runningImage: '/nowhere', inPlaceFiles: sent.files });
  const closedU = [];
  const ur = await core.runUninstall(plan, { isWin: false, onEvent: () => {}, cancelled: () => false, closeRunningApp: async (dd) => { closedU.push(dd); return false; }, removeUninstallRegistration: () => {} });
  ok(ur.ok && !exists(path.join(dest, 'resources', 'app.asar')) && !exists(path.join(dest, 'NOBODY')), 'our files removed');
  ok(exists(dest) && fs.readFileSync(path.join(dest, 'theirs.txt'), 'utf8') === 'theirs' && fs.readFileSync(path.join(dest, 'resources', 'their.cfg'), 'utf8') === 'cfg', 'their files + folder survive (was: the whole folder removed)');
  ok(fs.readFileSync(path.join(v2, 'f0.woff2'), 'utf8') === 'KEEP', 'nothing deleted through the junction planted later');
  ok(eq(closedU, [dest]), "uninstall closes only this folder's NOBODY");
  const tr = core.buildUninstallPlan({ installDir: dest, scope: 'me', version: 'x', keepData: true, isWin: false, desktopDir: '/d', startMenuDir: '/s', userDataDir: '/u', runningImage: '/r', inPlaceFiles: ['ok.txt', '../escape.txt', '/abs/x'] });
  ok(eq(tr.inPlaceFiles, ['ok.txt']), 'marker entries escaping the folder are dropped', tr.inPlaceFiles);
  fx = makeFixture('owned-un'); dest = path.join(fx.base, 'NOBODY');
  d = makeDeps(fx); await core.runInstall(O(dest), d.deps);
  const p2 = core.buildUninstallPlan({ installDir: dest, scope: 'me', version: 'x', keepData: true, isWin: false, desktopDir: '/d', startMenuDir: path.join(fx.base, 'start'), userDataDir: '/u', runningImage: '/r' });
  await core.runUninstall(p2, { isWin: false, onEvent: () => {}, cancelled: () => false, closeRunningApp: async () => false, removeUninstallRegistration: () => {} });
  ok(!exists(dest) && p2.inPlaceFiles === null, 'an owned install is still removed completely');

  console.log('\n■ II1 · process list parsing + "only our install" (player cjs + setup ts)');
  for (const [name, W] of [['player', wpCjs], ['setup', wpTs]]) {
    const one = W.parseProcessJson('{"ProcessId":4242,"ExecutablePath":"C:\\\\P\\\\NOBODY\\\\NOBODY.exe"}');
    const many = W.parseProcessJson(JSON.stringify([
      { ProcessId: 10, ExecutablePath: 'C:\\Users\\a\\AppData\\Local\\Programs\\NOBODY\\NOBODY.exe' },
      { ProcessId: 11, ExecutablePath: 'c:\\users\\A\\appdata\\local\\programs\\nobody\\NOBODY.EXE' },
      { ProcessId: 12, ExecutablePath: 'C:\\Users\\a\\AppData\\Local\\Programs\\NOBODY2\\NOBODY.exe' },
      { ProcessId: 13, ExecutablePath: 'D:\\Portable\\NOBODY\\NOBODY.exe' },
      { ProcessId: 14, ExecutablePath: null },
      { ProcessId: 99, ExecutablePath: 'C:\\Users\\a\\AppData\\Local\\Programs\\NOBODY\\NOBODY.exe' },
      { ProcessId: 'x' }, null,
    ]));
    ok(one.length === 1 && one[0].pid === 4242 && W.parseProcessJson('').length === 0 && W.parseProcessJson('garbage').length === 0, `${name}: one object / empty / junk`);
    const pids = W.ownInstallPids({ list: many, installDir: 'C:\\Users\\a\\AppData\\Local\\Programs\\NOBODY', ownPid: 99, isWin: true });
    ok(eq(pids, [10, 11]), `${name}: only this folder (any case); the NOBODY2 sibling, a portable copy, an unreadable path and ourselves are spared`, pids);
  }

  console.log('\n■ II2 · graceful quit first, force only the stubborn verified PIDs');
  for (const [name, W] of [['player', wpCjs], ['setup', wpTs]]) {
    let alive = [{ pid: 10, path: 'C:\\A\\NOBODY\\NOBODY.exe' }, { pid: 20, path: 'D:\\Portable\\NOBODY.exe' }];
    const quits = []; const kills = [];
    let res = await W.closeInstall({ installDir: 'C:\\A\\NOBODY', exeName: 'NOBODY.exe', ownPid: 1, isWin: true },
      { list: () => alive, quit: (exe) => { quits.push(exe); alive = alive.filter((p) => p.pid !== 10); }, kill: (pid) => kills.push(pid), sleep: async () => {} });
    ok(eq(quits, ['C:\\A\\NOBODY\\NOBODY.exe']) && kills.length === 0 && res.graceful === 1 && alive.some((p) => p.pid === 20), `${name}: asked via its own exe, nothing force-killed, portable copy untouched`, res);
    alive = [{ pid: 10, path: 'C:\\A\\NOBODY\\NOBODY.exe' }, { pid: 20, path: 'D:\\Portable\\NOBODY.exe' }]; quits.length = 0;
    res = await W.closeInstall({ installDir: 'C:\\A\\NOBODY', exeName: 'NOBODY.exe', ownPid: 1, isWin: true, waitMs: 1000 },
      { list: () => alive, quit: (exe) => quits.push(exe), kill: (pid) => kills.push(pid), sleep: async () => {} });
    ok(eq(kills, [10]) && res.killed === 1, `${name}: ignores the request → only PID 10 force-closed`, kills);
    kills.length = 0; quits.length = 0;
    await W.closeInstall({ installDir: 'C:\\A\\NOBODY', exeName: 'NOBODY.exe', ownPid: 1, isWin: true, graceful: false }, { list: () => [{ pid: 10, path: 'C:\\A\\NOBODY\\NOBODY.exe' }], quit: (e) => quits.push(e), kill: (p) => kills.push(p), sleep: async () => {} });
    ok(quits.length === 0 && eq(kills, [10]), `${name}: graceful off (old player) → no exe launched, just its PID`);
    kills.length = 0;
    res = await W.closeInstall({ installDir: 'C:\\A\\NOBODY', exeName: 'NOBODY.exe', ownPid: 1, isWin: true }, { list: () => [{ pid: 20, path: 'D:\\Portable\\NOBODY.exe' }], quit: (e) => quits.push(e), kill: (p) => kills.push(p), sleep: async () => {} });
    ok(res.found === 0 && quits.length === 0 && kills.length === 0, `${name}: nothing of ours running → nothing launched (it would open a player)`);
  }
  ok(wpTs.supportsQuitFlag('1.8.0-dev.4') && wpTs.supportsQuitFlag('1.8.0') && wpTs.supportsQuitFlag('1.9.2') && wpTs.supportsQuitFlag('2.0.0') && !wpTs.supportsQuitFlag('1.8.0-dev.3') && !wpTs.supportsQuitFlag('1.7.0') && !wpTs.supportsQuitFlag(undefined), 'only 1.8.0-dev.4+ players are sent --nobody-quit');

  console.log("\n■ II3 · PowerShell scripts can't be broken by a path");
  for (const [name, W] of [['player', wpCjs], ['setup', wpTs]]) {
    const exe = "C:\\Users\\O'Brien\\Downloads\\NOBODY-Setup.exe";
    const sc = W.elevateScript(exe, ['--nobody-elevated', "--x='; Remove-Item C:\\ -Recurse; '"]);
    ok(sc.includes("-FilePath 'C:\\Users\\O''Brien\\Downloads\\NOBODY-Setup.exe'") && sc.includes("'--x=''; Remove-Item C:\\ -Recurse; '''") && sc.includes('-Verb RunAs') && /exit 1223/.test(sc), `${name}: quotes doubled inside literals, UAC refusal → 1223`, sc);
    ok(Buffer.from(W.psEncode(sc), 'base64').toString('utf16le') === sc, `${name}: -EncodedCommand round trip (UTF-16LE)`);
    ok(W.listScript('NOBODY.exe').includes("Name='NOBODY.exe'") && W.listScript("a'b").includes("Name='a''b'"), `${name}: process query quoted`);
  }
  const cases = [['{"ProcessId":5,"ExecutablePath":"C:\\\\X\\\\NOBODY.exe"}', 'C:\\X'], ['[{"ProcessId":5,"ExecutablePath":"C:\\\\X\\\\sub\\\\NOBODY.exe"},{"ProcessId":6,"ExecutablePath":"C:\\\\XY\\\\NOBODY.exe"}]', 'C:\\X']];
  ok(cases.every(([o, dir]) => eq(wpCjs.ownInstallPids({ list: wpCjs.parseProcessJson(o), installDir: dir, ownPid: 0, isWin: true }), wpTs.ownInstallPids({ list: wpTs.parseProcessJson(o), installDir: dir, ownPid: 0, isWin: true }))), 'player and setup twins agree');

  console.log('\n■ III · elevation hand-over argument');
  const opts = { destDir: 'C:\\Program Files\\NOBODY', scope: 'all', desktop: true, launchAfter: true, openFolder: false, lang: 'fa' };
  const arg = resume.RESUME_PREFIX + resume.encodeResume(opts);
  ok(/^--nobody-resume=[A-Za-z0-9_-]+$/.test(arg), 'one argv item, base64url only (nothing to quote)');
  ok(eq(resume.decodeResume(['setup.exe', resume.ELEVATED_FLAG, arg]), opts), 'decodes to the same choices');
  ok(resume.decodeResume(['x', resume.RESUME_PREFIX + 'not-json']) === null && resume.decodeResume(['x']) === null, 'junk / absent → null');
  const evil = resume.decodeResume(['x', resume.RESUME_PREFIX + Buffer.from(JSON.stringify({ destDir: 'C:\\X', scope: 'root', desktop: 'yes', lang: '../../etc' })).toString('base64url')]);
  ok(evil && evil.scope === 'me' && evil.desktop === true && evil.lang === undefined, 'fields re-normalized (scope, booleans, lang)', evil);
  ok(resume.decodeResume(['x', resume.RESUME_PREFIX + Buffer.from(JSON.stringify({ destDir: 'C:\\' + 'a'.repeat(300) })).toString('base64url')]) === null, 'over-long path refused');

  console.log('\n■ IV · player uninstaller (uninstall.cjs)');
  const origLoad = Module._load; Module._load = function (req) { if (req === 'electron') return { app: {}, dialog: {} }; return origLoad.apply(this, arguments); };
  const U = require(path.join(ROOT, 'electron/uninstall.cjs')); Module._load = origLoad;
  const ip = path.join(T, 'player-inplace'); fs.mkdirSync(path.join(ip, 'resources'), { recursive: true }); fs.writeFileSync(path.join(ip, 'resources', 'app.asar'), 'x');
  const v3 = path.join(T, 'victim3'); fs.mkdirSync(v3); fs.writeFileSync(path.join(v3, 'a.dll'), 'KEEP'); fs.symlinkSync(v3, path.join(ip, 'locales'), 'junction');
  const lines = U.inPlaceDeleteLines(ip, ['resources/app.asar', 'locales/a.dll', '../outside.txt']);
  ok(lines.some((l) => l.includes(path.join('resources', 'app.asar'))) && !lines.some((l) => l.includes('a.dll')) && !lines.some((l) => l.includes('outside')), 'delete lines: ours yes, through a junction no, escaping no', lines);
  ok(U.linkOnPath(ip, 'locales/a.dll') === true && U.linkOnPath(ip, 'resources/app.asar') === false, 'linkOnPath');

  console.log(`\n${pass}/${pass + fail} passed`);
  if (fails.length) { console.log('FAILED:\n - ' + fails.join('\n - ')); process.exitCode = 1; }
  fs.rmSync(T, { recursive: true, force: true }); fs.rmSync(OUT, { recursive: true, force: true });
})().catch((e) => { console.error(e); process.exitCode = 1; });
