import { ListenTracker, isFullListen } from "/home/user/work/src/src/shared/stats/listenTracker";
import { computeStats, playsToCsv } from "/home/user/work/src/src/shared/stats/stats";
let pass=0, fail=0; const ok=(c:any,m:string)=>{ if(c){pass++;} else {fail++; console.log('FAIL',m);} };
const recs:any[]=[]; let now=1_700_000_000_000; const mem=new Map<string,string>();
const store={getItem:(k:string)=>mem.get(k)??null,setItem:(k:string,v:string)=>{mem.set(k,v)},removeItem:(k:string)=>{mem.delete(k)}};
const tr=new ListenTracker((r)=>{recs.push(r)},()=>now,store);
const meta=()=>({title:'A',artist:'X',album:'Al',duration:200});
for(let p=0;p<=120;p+=0.25){ tr.sample('engine','a',p,200,true,meta); now+=250; }
tr.sample('engine','b',0,100,true,()=>({title:'B',artist:'Y',album:'',duration:100}));
ok(recs.length===1 && recs[0].full && !recs[0].skip && Math.abs(recs[0].ms-120000)<300,'a full 120/200');
for(let p=0;p<=20;p+=0.25) tr.sample('engine','b',p,100,true);
tr.sample('engine','b',80,100,true); // seek forward ignored
for(let p=80;p<=85;p+=0.25) tr.sample('engine','b',p,100,true);
tr.sample('classic','c',0,50,true,meta);
ok(recs.length===2 && recs[1].skip && Math.abs(recs[1].ms-25000)<600,'b skipped, seek excluded '+recs[1]?.ms);
for(let p=0;p<=3;p+=0.25) tr.sample('classic','c',p,50,false); // paused adds nothing
tr.sample('classic','d',0,50,true);
ok(recs.length===2,'paused/short not stored');
for(let p=0;p<=49;p+=0.5) tr.sample('classic','d',p,50,true);
tr.sample('classic','d',0.3,50,true); // repeat-one loop
ok(recs.length===3 && recs[2].full,'loop closes listen');
for(let p=0.3;p<=10;p+=0.5){ tr.sample('classic','d',p,50,true); now+=500; }
ok(mem.size===1,'open listen mirrored');
const tr2=new ListenTracker((r)=>{recs.push(r)},()=>now,store); tr2.recover();
ok(recs.length===4 && recs[3].id==='d','recover after crash');
ok(!isFullListen(20000,25) && isFullListen(240000,1000),'full rule');
const st=computeStats(recs,{range:'all',now});
ok(st.plays===4 && st.topTracks[0].id==='d' && st.skips===1 && st.streak.current===1,'stats '+JSON.stringify([st.plays,st.topTracks[0]?.id,st.skips,st.streak]));
ok(playsToCsv([{...recs[0],title:'=cmd'}]).includes("'=cmd"),'csv formula guard');
// 1.7.0-dev.11: library placeholders group with "unknown", and the resolver fills them
const ph=[{at:now-5000,id:'p1',ms:60000,dur:200,title:'S',artist:'Unknown Artist',album:'Unknown Album',full:true,skip:false,src:'engine'},{at:now-4000,id:'p2',ms:60000,dur:200,title:'T',artist:'Unknown Artist',album:'Unknown Album',full:true,skip:false,src:'engine'}] as any[];
const st2=computeStats(ph,{range:'all',now,resolve:(id)=>id==='p1'?{title:'S',artist:'Real',album:'Rec'}:null});
ok(st2.uniqueArtists===1 && st2.topArtists.some(a=>a.name==='Real') && st2.topArtists.some(a=>a.key===''&&a.name==='Unknown artist') && st2.topAlbums.some(a=>a.name==='Rec'),'placeholders → unknown / resolved '+JSON.stringify(st2.topArtists.map(a=>[a.key,a.name])));
// discard(): the open listen is forgotten, the same song keeps counting from zero
const recs3:any[]=[]; const mem3=new Map<string,string>(); const st3={getItem:(k:string)=>mem3.get(k)??null,setItem:(k:string,v:string)=>{mem3.set(k,v)},removeItem:(k:string)=>{mem3.delete(k)}};
let n3=now; const tr3=new ListenTracker((r)=>{recs3.push(r)},()=>n3,st3); let genu=0; tr3.onGenuine(()=>genu++);
for(let p=0;p<=60;p+=0.5){ tr3.sample('engine','z',p,200,true,meta); n3+=500; }
tr3.discard(); ok(mem3.size===0,'discard drops the mirror');
for(let p=60.5;p<=70;p+=0.5){ tr3.sample('engine','z',p,200,true); n3+=500; }
tr3.close('change');
ok(recs3.length===1 && Math.abs(recs3[0].ms-10000)<600 && genu===1,'discard: only time after it is stored, Most played not double-counted '+JSON.stringify([recs3[0]?.ms,genu]));
console.log(`${pass} passed, ${fail} failed`);
