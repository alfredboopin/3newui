// Runs docs/tests/m3u.spec.ts: esbuild bundle → plain node.
import { build } from "esbuild";
import { execFileSync } from "child_process";
import path from "path";
import { fileURLToPath } from "url";
const here = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(here, ".m3u-spec.cjs");
await build({ entryPoints: [path.join(here, "m3u.spec.ts")], bundle: true, platform: "node", format: "cjs", outfile: out, logLevel: "error" });
execFileSync(process.execPath, [out], { stdio: "inherit" });
