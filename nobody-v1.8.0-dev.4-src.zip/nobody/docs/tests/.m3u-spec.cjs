"use strict";

// src/cinema/lib/trackSort.ts
var collator = new Intl.Collator(void 0, { numeric: true, sensitivity: "base" });

// src/cinema/lib/smartPlaylist.ts
var ARABIC_TO_PERSIAN = { "\u064A": "\u06CC", "\u0649": "\u06CC", "\u0643": "\u06A9", "\u0629": "\u0647" };
function fold(s) {
  if (!s) return "";
  return s.normalize("NFKD").replace(/[\u0300-\u036f\u064B-\u065F\u0670]/g, "").replace(/[\u064A\u0649\u0643\u0629]/g, (c) => ARABIC_TO_PERSIAN[c] || c).replace(/\u200C/g, " ").replace(/\s+/g, " ").trim().toLocaleLowerCase();
}
var DAY = 864e5;
var UNIT_MS = { days: DAY, weeks: 7 * DAY, months: 30 * DAY };

// src/shared/m3u/m3u.ts
var DRIVE_RE = /^[a-zA-Z]:[\\/]/;
var UNC_RE = /^(?:\\\\|\/\/)[^\\/]+[\\/][^\\/]+/;
var isWinPath = (p2) => DRIVE_RE.test(p2) || UNC_RE.test(p2);
var isAbsolutePath = (p2) => isWinPath(p2) || p2.startsWith("/");
function normalizePath(p2, win = isWinPath(p2)) {
  if (!p2) return "";
  let root = "";
  let rest = p2.replace(/\\/g, "/");
  if (/^[a-zA-Z]:\//.test(rest)) {
    root = rest.slice(0, 2).toUpperCase() + "/";
    rest = rest.slice(3);
  } else if (/^\/\/[^/]+\/[^/]+/.test(rest)) {
    const m2 = /^\/\/([^/]+)\/([^/]+)\/?/.exec(rest);
    root = `//${m2[1]}/${m2[2]}/`;
    rest = rest.slice(m2[0].length);
  } else if (rest.startsWith("/")) {
    root = "/";
    rest = rest.slice(1);
  }
  const out2 = [];
  for (const seg of rest.split("/")) {
    if (!seg || seg === ".") continue;
    if (seg === "..") {
      if (out2.length) out2.pop();
      continue;
    }
    out2.push(seg);
  }
  let joined = root + out2.join("/");
  if (root.startsWith("//") && !out2.length) joined = root.slice(0, -1);
  return win ? joined.replace(/\//g, "\\") : joined;
}
function dirnameOf(p2) {
  const i = Math.max(p2.lastIndexOf("/"), p2.lastIndexOf("\\"));
  return i <= 0 ? i === 0 ? p2.slice(0, 1) : "" : p2.slice(0, i);
}
var basenameOf = (p2) => p2.split(/[\\/]/).pop() || p2;
function pathKey(p2) {
  if (!p2) return "";
  return normalizePath(p2, false).normalize("NFC").toLocaleLowerCase();
}
function decodeFileUrl(u) {
  const m2 = /^file:\/\/([^/]*)(\/.*)?$/i.exec(u);
  if (!m2) return null;
  let host = m2[1];
  let rest = m2[2] || "";
  try {
    rest = decodeURIComponent(rest);
    host = decodeURIComponent(host);
  } catch {
  }
  if (host && host.toLowerCase() !== "localhost") return `//${host}${rest}`;
  if (/^\/[a-zA-Z]:[\\/]/.test(rest) || /^\/[a-zA-Z]\|/.test(rest)) return rest.slice(1).replace("|", ":");
  return rest;
}
function resolveEntryPath(line, baseDir) {
  let p2 = line.trim();
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(p2)) {
    if (!/^file:/i.test(p2)) return null;
    const f = decodeFileUrl(p2);
    if (f === null) return "";
    p2 = f;
  }
  const baseWin = isWinPath(baseDir);
  if (DRIVE_RE.test(p2) || UNC_RE.test(p2)) return normalizePath(p2, true);
  if (/^[\\/]/.test(p2)) {
    if (baseWin) {
      const drive = /^[a-zA-Z]:/.exec(baseDir)?.[0];
      const unc = UNC_RE.exec(baseDir)?.[0];
      if (drive) return normalizePath(drive + p2, true);
      if (unc) return normalizePath(unc + p2, true);
    }
    if (p2.startsWith("\\")) return "";
    return normalizePath(p2, false);
  }
  if (/^[a-zA-Z]:[^\\/]/.test(p2)) return "";
  if (!baseDir) return "";
  return normalizePath(`${baseDir}/${p2}`, baseWin);
}
function parseExtinf(body) {
  let i = 0;
  let inQ = false;
  for (; i < body.length; i++) {
    const c = body[i];
    if (c === '"') inQ = !inQ;
    else if (c === "," && !inQ) break;
  }
  const head = body.slice(0, i).trim();
  const display = i < body.length ? body.slice(i + 1).trim() : "";
  const durRaw = /^-?\d+(?:\.\d+)?/.exec(head)?.[0];
  const dur = durRaw !== void 0 ? Number(durRaw) : NaN;
  const out2 = {};
  if (isFinite(dur) && dur > 0) out2.duration = dur;
  if (display) {
    const sep = display.indexOf(" - ");
    if (sep > 0) {
      out2.artist = display.slice(0, sep).trim();
      out2.title = display.slice(sep + 3).trim();
    } else out2.title = display;
  }
  return out2;
}
function parseM3U(text, baseDir = "") {
  const res = { extended: false, entries: [], remote: 0, unresolved: 0 };
  const lines = text.replace(/^\uFEFF/, "").split(/\r\n|\r|\n/);
  let pending = null;
  let pendingArtist;
  lines.forEach((rawLine, idx2) => {
    const line = rawLine.replace(/\x00/g, "").trim();
    if (!line) return;
    if (line.startsWith("#")) {
      const up = line.toUpperCase();
      if (up.startsWith("#EXTM3U")) res.extended = true;
      else if (up.startsWith("#PLAYLIST:")) {
        const n = line.slice(10).trim();
        if (n) res.name = n;
      } else if (up.startsWith("#EXTINF:")) pending = parseExtinf(line.slice(8));
      else if (up.startsWith("#EXTART:")) pendingArtist = line.slice(8).trim() || void 0;
      return;
    }
    const path = resolveEntryPath(line, baseDir);
    const meta = pending;
    pending = null;
    const art = pendingArtist;
    pendingArtist = void 0;
    if (path === null) {
      res.remote++;
      return;
    }
    if (!path) {
      res.unresolved++;
      return;
    }
    const e = { path, raw: line, line: idx2 + 1 };
    if (meta) Object.assign(e, meta);
    if (art && !e.artist) e.artist = art;
    res.entries.push(e);
  });
  return res;
}
var LEGACY_BY_LANG = {
  fa: ["windows-1256", "windows-1252", "windows-1251", "windows-1254"],
  ru: ["windows-1251", "windows-1252", "windows-1256", "windows-1254"],
  tr: ["windows-1254", "windows-1252", "windows-1256", "windows-1251"],
  en: ["windows-1252", "windows-1256", "windows-1251", "windows-1254"]
};
function decodeM3U(bytes, lang = "en", score) {
  if (bytes.length >= 3 && bytes[0] === 239 && bytes[1] === 187 && bytes[2] === 191)
    return { text: new TextDecoder("utf-8").decode(bytes.subarray(3)), encoding: "utf-8" };
  if (bytes.length >= 2 && bytes[0] === 255 && bytes[1] === 254)
    return { text: new TextDecoder("utf-16le").decode(bytes.subarray(2)), encoding: "utf-16le" };
  if (bytes.length >= 2 && bytes[0] === 254 && bytes[1] === 255)
    return { text: new TextDecoder("utf-16be").decode(bytes.subarray(2)), encoding: "utf-16be" };
  try {
    return { text: new TextDecoder("utf-8", { fatal: true }).decode(bytes), encoding: "utf-8" };
  } catch {
  }
  const order = LEGACY_BY_LANG[lang] || LEGACY_BY_LANG.en;
  let best = null;
  let bestScore = -1;
  for (const enc of order) {
    let text;
    try {
      text = new TextDecoder(enc).decode(bytes);
    } catch {
      continue;
    }
    const s = score ? score(text) : 0;
    if (s > bestScore) {
      best = { text, encoding: enc };
      bestScore = s;
    }
    if (!score) break;
  }
  return best ?? { text: new TextDecoder("utf-8").decode(bytes), encoding: "utf-8" };
}
var tagKey = (artist, title) => `${fold(artist)}${fold(title)}`;
function indexLibrary(tracks) {
  const idx2 = { byPath: /* @__PURE__ */ new Map(), byName: /* @__PURE__ */ new Map(), byTags: /* @__PURE__ */ new Map() };
  for (const t of tracks) {
    if (t.filePath) idx2.byPath.set(pathKey(t.filePath), t.id);
    const nm = t.filePath ? basenameOf(t.filePath) : t.fileName;
    if (nm) {
      const k = fold(nm);
      idx2.byName.set(k, idx2.byName.has(k) && idx2.byName.get(k) !== t.id ? null : t.id);
    }
    if (t.title) {
      const k = tagKey(t.artist, t.title);
      const arr = idx2.byTags.get(k);
      if (arr) arr.push(t);
      else idx2.byTags.set(k, [t]);
    }
  }
  return idx2;
}
function matchEntry(e, idx2) {
  const byPath = idx2.byPath.get(pathKey(e.path));
  if (byPath) return { entry: e, id: byPath, kind: "path" };
  const byName = idx2.byName.get(fold(basenameOf(e.path)));
  if (byName) return { entry: e, id: byName, kind: "name" };
  if (e.title) {
    const cands = idx2.byTags.get(tagKey(e.artist, e.title));
    if (cands && cands.length) {
      if (e.duration && e.duration > 0) {
        const close = cands.filter((c) => !c.duration || Math.abs(c.duration - e.duration) <= 3);
        if (close.length) {
          close.sort((a, b) => Math.abs((a.duration || 1e9) - e.duration) - Math.abs((b.duration || 1e9) - e.duration));
          return { entry: e, id: close[0].id, kind: "tags" };
        }
      } else if (cands.length === 1) return { entry: e, id: cands[0].id, kind: "tags" };
    }
  }
  return { entry: e, id: null, kind: null };
}
var matchAll = (entries, idx2) => entries.map((e) => matchEntry(e, idx2));
function libraryScorer(idx2, baseDir) {
  return (text) => {
    const p2 = parseM3U(text, baseDir);
    let n = 0;
    for (const e of p2.entries) if (idx2.byPath.has(pathKey(e.path)) || idx2.byName.get(fold(basenameOf(e.path)))) n++;
    return n;
  };
}
var oneLine = (s) => (s || "").replace(/[\r\n\x00]+/g, " ").trim();
function rootOf(p2) {
  const n = normalizePath(p2, false);
  if (/^[A-Za-z]:\//.test(n)) return n.slice(0, 3).toLowerCase();
  const unc = /^\/\/[^/]+\/[^/]+/.exec(n);
  if (unc) return unc[0].toLowerCase() + "/";
  return n.startsWith("/") ? "/" : "";
}
function relativePath(dir, file) {
  const win = isWinPath(dir) || isWinPath(file);
  const rd = rootOf(dir);
  const rf = rootOf(file);
  if (!rd || rd !== rf) return null;
  const a = normalizePath(dir, false).slice(rd.length).split("/").filter(Boolean);
  const b = normalizePath(file, false).slice(rf.length).split("/").filter(Boolean);
  const eq2 = (x, y) => win ? x.toLowerCase() === y.toLowerCase() : x === y;
  let i = 0;
  while (i < a.length && i < b.length - 1 && eq2(a[i], b[i])) i++;
  const parts = [...Array(a.length - i).fill(".."), ...b.slice(i)];
  let rel = parts.join(win ? "\\" : "/");
  if (rel.startsWith("#")) rel = (win ? ".\\" : "./") + rel;
  return rel;
}
function buildM3U(items, opts = {}) {
  const dir = opts.targetPath ? dirnameOf(opts.targetPath) : "";
  const out2 = ["#EXTM3U"];
  if (opts.name) out2.push(`#PLAYLIST:${oneLine(opts.name)}`);
  for (const it of items) {
    const abs = it.path && isAbsolutePath(it.path) ? normalizePath(it.path) : "";
    let line = abs;
    if (abs && dir && opts.relative !== false) line = relativePath(dir, abs) ?? abs;
    if (!line) line = oneLine(it.fileName || it.path);
    if (!line) continue;
    const dur = it.duration && it.duration > 0 ? Math.round(it.duration) : -1;
    const artist = oneLine(it.artist);
    const title = oneLine(it.title) || basenameOf(line);
    out2.push(`#EXTINF:${dur},${artist ? `${artist} - ` : ""}${title}`);
    out2.push(line);
  }
  return out2.join("\r\n") + "\r\n";
}
function encodeM3U(text, targetPath) {
  const body = new TextEncoder().encode(text);
  if (!/\.m3u$/i.test(targetPath)) return body;
  const out2 = new Uint8Array(body.length + 3);
  out2.set([239, 187, 191]);
  out2.set(body, 3);
  return out2;
}
var playlistNameFromFile = (p2) => basenameOf(p2).replace(/\.m3u8?$/i, "").trim() || "Playlist";

// docs/tests/m3u.spec.ts
var pass = 0;
var fail = 0;
var eq = (name, a, b) => {
  const ok = JSON.stringify(a) === JSON.stringify(b);
  ok ? pass++ : fail++;
  if (!ok) console.log("FAIL", name, "\n  got ", JSON.stringify(a), "\n  want", JSON.stringify(b));
};
eq("norm win", normalizePath("c:/Music/./a/../b//x.mp3"), "C:\\Music\\b\\x.mp3");
eq("norm unc", normalizePath("\\\\nas\\music\\a\\..\\x.flac"), "\\\\nas\\music\\x.flac");
eq("norm posix", normalizePath("/home/u/../v/x.mp3"), "/home/v/x.mp3");
eq("norm .. above root", normalizePath("C:\\..\\..\\x.mp3"), "C:\\x.mp3");
eq("key equal", pathKey("C:\\Music\\\xC4.mp3"), pathKey("c:/music/A\u0308.MP3".normalize("NFD")));
eq("rel", resolveEntryPath("sub\\x.mp3", "D:\\Lists"), "D:\\Lists\\sub\\x.mp3");
eq("rel ..", resolveEntryPath("..\\Music\\x.mp3", "D:\\Lists"), "D:\\Music\\x.mp3");
eq("rel fwd on win", resolveEntryPath("../Music/x.mp3", "D:\\Lists"), "D:\\Music\\x.mp3");
eq("root-rel", resolveEntryPath("\\Music\\x.mp3", "E:\\Lists\\a"), "E:\\Music\\x.mp3");
eq("abs other drive", resolveEntryPath("C:\\x.mp3", "E:\\Lists"), "C:\\x.mp3");
eq("unc abs", resolveEntryPath("\\\\nas\\m\\x.mp3", "E:\\L"), "\\\\nas\\m\\x.mp3");
eq("posix rel", resolveEntryPath("a/b.mp3", "/home/u/lists"), "/home/u/lists/a/b.mp3");
eq("posix abs", resolveEntryPath("/srv/m/b.mp3", "/home/u"), "/srv/m/b.mp3");
eq("file url win", resolveEntryPath("file:///C:/My%20Music/%D8%B3%D9%84%D8%A7%D9%85.mp3", ""), "C:\\My Music\\\u0633\u0644\u0627\u0645.mp3");
eq("file url localhost", resolveEntryPath("file://localhost/C:/a.mp3", ""), "C:\\a.mp3");
eq("file url unc", resolveEntryPath("file://nas/music/a.mp3", ""), "\\\\nas\\music\\a.mp3");
eq("file url posix", resolveEntryPath("file:///home/u/a%23b.mp3", ""), "/home/u/a#b.mp3");
eq("http remote", resolveEntryPath("http://radio/x", "C:\\"), null);
eq("rel no base", resolveEntryPath("x.mp3", ""), "");
eq("drive-relative", resolveEntryPath("C:x.mp3", "D:\\"), "");
var txt = `\uFEFF#EXTM3U\r
#PLAYLIST:Road trip\r
#EXTINF:215 tvg-name="a, b" group-title="x",Queen - Don't Stop Me Now\r
Queen\\01 Don't Stop.mp3\r
\r
# comment\r
#EXTINF:-1,Live stream\r
https://radio.example/live\r
#EXTINF:0,Just A Title\r
C:\\Music\\t.flac\r
#EXTART:Googoosh
file:///C:/M/x.mp3\rplain.ogg`;
var p = parseM3U(txt, "D:\\Lists");
eq("name", p.name, "Road trip");
eq("extended", p.extended, true);
eq("remote", p.remote, 1);
eq("count", p.entries.length, 4);
eq("e0", [p.entries[0].path, p.entries[0].artist, p.entries[0].title, p.entries[0].duration], ["D:\\Lists\\Queen\\01 Don't Stop.mp3", "Queen", "Don't Stop Me Now", 215]);
eq("e1 no dur, no artist", [p.entries[1].duration, p.entries[1].artist, p.entries[1].title], [void 0, void 0, "Just A Title"]);
eq("extart", p.entries[2].artist, "Googoosh");
eq("plain no meta", [p.entries[3].path, p.entries[3].title], ["D:\\Lists\\plain.ogg", void 0]);
eq("extinf not leaking after remote", p.entries[1].line, 10);
eq("plain m3u", parseM3U("a.mp3\nb.mp3\n", "/m").entries.map((e) => e.path), ["/m/a.mp3", "/m/b.mp3"]);
var fa = "C:\\\u0645\u0648\u0633\u06CC\u0642\u06CC\\\u06AF\u0648\u06AF\u0648\u0634 - \u0645\u0646 \u0622\u0645\u062F\u0647\u200C\u0627\u0645.mp3";
var enc1256 = new Uint8Array([...Buffer.from("#EXTM3U\r\n")].concat([67, 58, 92]));
eq("utf8 bom", decodeM3U(new Uint8Array([239, 187, 191, 97])).encoding, "utf-8");
eq("utf16le", decodeM3U(new Uint8Array([255, 254, 97, 0, 98, 0])).text, "ab");
eq("utf8 plain", decodeM3U(new TextEncoder().encode(fa)).text, fa);
var legacy = new Uint8Array([67, 58, 92, 211, 225, 199, 227, 46, 109, 112, 51]);
eq("1256 by lang", decodeM3U(legacy, "fa").text, "C:\\\u0633\u0644\u0627\u0645.mp3");
eq("1256 by library score (en ui)", decodeM3U(legacy, "en", libraryScorer(indexLibrary([{ id: "1", filePath: "C:\\\u0633\u0644\u0627\u0645.mp3", title: "x", artist: "y", duration: 1 }]), "")).encoding, "windows-1256");
var cyr = new Uint8Array([47, 207, 240, 232, 226, 229, 242, 46, 109, 112, 51]);
eq("1251 by lang", decodeM3U(cyr, "ru").text, "/\u041F\u0440\u0438\u0432\u0435\u0442.mp3");
eq("1251 by score", decodeM3U(cyr, "fa", libraryScorer(indexLibrary([{ id: "1", filePath: "/\u041F\u0440\u0438\u0432\u0435\u0442.mp3", title: "x", artist: "y", duration: 1 }]), "/")).encoding, "windows-1251");
var lib = [
  { id: "a", filePath: "C:\\Music\\Queen\\01 Don't Stop.mp3", title: "Don't Stop Me Now", artist: "Queen", duration: 211 },
  { id: "b", filePath: "D:\\Other\\01 Intro.mp3", title: "Intro", artist: "X", duration: 60 },
  { id: "c", filePath: "E:\\Other\\01 Intro.mp3", title: "Intro", artist: "Y", duration: 61 },
  { id: "d", filePath: "E:\\Fa\\track.mp3", title: "\u0645\u0646 \u0622\u0645\u062F\u0647\u200C\u0627\u0645", artist: "\u06AF\u0648\u06AF\u0648\u0634", duration: 300 },
  { id: "e", filePath: "E:\\Dup\\x1.mp3", title: "Same", artist: "Twin", duration: 100 },
  { id: "f", filePath: "E:\\Dup\\x2.mp3", title: "Same", artist: "Twin", duration: 200 }
];
var idx = indexLibrary(lib);
var m = (e) => {
  const r = matchEntry({ raw: "", line: 1, path: "", ...e }, idx);
  return [r.id, r.kind];
};
eq("path exact case-insens", m({ path: "c:\\music\\queen\\01 DON'T STOP.mp3" }), ["a", "path"]);
eq("moved file \u2192 unique name", m({ path: "Z:\\Backup\\01 Don't Stop.mp3" }), ["a", "name"]);
eq("ambiguous name \u2192 no", m({ path: "Z:\\01 Intro.mp3" }), [null, null]);
eq("ambiguous name + tags", m({ path: "Z:\\01 Intro.mp3", artist: "y", title: "intro" }), ["c", "tags"]);
eq("tags fold arabic \u064A/\u0643 + ZWNJ", m({ path: "Z:\\q.mp3", artist: "\u06AF\u0648\u06AF\u0648\u0634", title: "\u0645\u0646 \u0622\u0645\u062F\u0647 \u0627\u0645" }), ["d", "tags"]);
eq("tags fold \u064A", m({ path: "Z:\\q.mp3", artist: "\u06AF\u0648\u06AF\u0648\u0634", title: "\u0645\u0646 \u0622\u0645\u062F\u0647\u200C\u0627\u0645" }), ["d", "tags"]);
eq("tags duration picks", m({ path: "Z:\\q.mp3", artist: "Twin", title: "Same", duration: 199 }), ["f", "tags"]);
eq("tags duration too far", m({ path: "Z:\\q.mp3", artist: "Twin", title: "Same", duration: 150 }), [null, null]);
eq("tags ambiguous no dur", m({ path: "Z:\\q.mp3", artist: "Twin", title: "Same" }), [null, null]);
eq("tags with \xB13s", m({ path: "Z:\\q.mp3", artist: "Queen", title: "don't stop me now", duration: 214 }), ["a", "tags"]);
var out = buildM3U([
  { path: "D:\\Lists\\Queen\\a.mp3", title: "A", artist: "Queen", duration: 210.6 },
  { path: "D:\\Music\\b.flac", title: "B\r\nhack", duration: 0 },
  { path: "C:\\x\\c.mp3", title: "C", artist: "Z" },
  { path: "d:\\lists\\#weird.mp3", title: "W" },
  { fileName: "web-only.mp3", title: "Web" }
], { targetPath: "D:\\Lists\\road.m3u8", name: "Road\ntrip" });
eq("build", out.split("\r\n"), ["#EXTM3U", "#PLAYLIST:Road trip", "#EXTINF:211,Queen - A", "Queen\\a.mp3", "#EXTINF:-1,B hack", "..\\Music\\b.flac", "#EXTINF:-1,Z - C", "C:\\x\\c.mp3", "#EXTINF:-1,W", ".\\#weird.mp3", "#EXTINF:-1,Web", "web-only.mp3", ""]);
eq("build posix", buildM3U([{ path: "/home/u/m/a.mp3", title: "A" }], { targetPath: "/home/u/lists/x.m3u" }).split("\r\n")[2], "../m/a.mp3");
eq("build unc same share", relativePath("\\\\nas\\m\\lists", "\\\\NAS\\m\\a\\x.mp3"), "..\\a\\x.mp3");
eq("build unc other share", relativePath("\\\\nas\\m\\lists", "\\\\nas\\n\\x.mp3"), null);
var rt = parseM3U(buildM3U(lib.map((t) => ({ path: t.filePath, title: t.title, artist: t.artist, duration: t.duration })), { targetPath: "E:\\Lists\\all.m3u8" }), "E:\\Lists");
eq("round trip", matchAll(rt.entries, idx).map((r) => r.id), ["a", "b", "c", "d", "e", "f"]);
eq("bom only for .m3u", [encodeM3U("x", "a.m3u")[0], encodeM3U("x", "a.m3u8")[0]], [239, 120]);
eq("name from file", playlistNameFromFile("C:\\L\\Road Trip.M3U8"), "Road Trip");
var big = Array.from({ length: 2e4 }, (_, i) => ({ id: String(i), filePath: `C:\\Music\\A${i % 300}\\${i} song.mp3`, title: `Song ${i}`, artist: `A${i % 300}`, duration: 200 }));
var t0 = performance.now();
var bidx = indexLibrary(big);
var bigList = buildM3U(big.map((t) => ({ path: t.filePath, title: t.title, artist: t.artist, duration: t.duration })), { targetPath: "C:\\Lists\\big.m3u8" });
var bp = parseM3U(bigList, "C:\\Lists");
var hits = matchAll(bp.entries, bidx).filter((r) => r.kind === "path").length;
var ms = performance.now() - t0;
eq("20k round trip all path hits", hits, 2e4);
console.log(`20k index+build+parse+match: ${ms.toFixed(0)} ms`);
console.log(`${pass}/${pass + fail} passed`);
if (fail) process.exit(1);
