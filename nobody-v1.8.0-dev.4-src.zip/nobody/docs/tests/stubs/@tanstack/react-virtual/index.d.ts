export interface VirtualItem { index: number; key: any; start: number; end: number; size: number; lane: number }
export interface Virtualizer<S = any, I = any> { getVirtualItems(): VirtualItem[]; getTotalSize(): number; measureElement: (el: I | null) => void; scrollToIndex(i: number, o?: any): void; scrollToOffset(o: number, opt?: any): void; measure(): void; options: any; scrollElement: S | null }
export function useVirtualizer<S = any, I = any>(o: any): Virtualizer<S, I>;
export function useWindowVirtualizer<I = any>(o: any): Virtualizer<Window, I>;
