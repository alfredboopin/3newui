declare module "path" { const p: any; export default p; export function resolve(...a: string[]): string; export function join(...a: string[]): string; export function dirname(p: string): string; }
declare module "node:path" { const p: any; export default p; export function resolve(...a: string[]): string; }
declare module "url" { export function fileURLToPath(u: any): string; }
declare module "node:url" { export function fileURLToPath(u: any): string; }
declare var process: any; declare var __dirname: string;
declare namespace NodeJS { type Timeout = ReturnType<typeof setTimeout>; }
