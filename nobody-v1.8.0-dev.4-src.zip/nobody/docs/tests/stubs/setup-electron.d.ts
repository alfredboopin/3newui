// minimal ambient stubs for a sandbox type-check of setup-app/electron (no @types/node / electron here)
declare namespace NodeJS { interface Process { [k: string]: any; platform: string; env: Record<string, string | undefined>; argv: string[]; pid: number; execPath: string; getuid?: () => number } }
declare var process: NodeJS.Process;
declare var __dirname: string;
declare var require: any;
declare class Buffer extends Uint8Array { static from(a: any, enc?: string): Buffer; toString(enc?: string): string; static concat(a: any[]): Buffer }
declare function setTimeout(fn: (...a: any[]) => void, ms?: number): any;
declare function clearTimeout(t: any): void;
declare function setInterval(fn: (...a: any[]) => void, ms?: number): any;
declare function clearInterval(t: any): void;
declare function setImmediate(fn: (...a: any[]) => void): any;
declare var console: any;
declare module "fs" { namespace fs { type Stats = any; type Dirent = any } const fs: any; export = fs; }
declare module "fs/promises" { const fsp: any; export = fsp; }
declare module "path" { const path: any; export = path; }
declare module "crypto" { const c: any; export = c; }
declare module "os" { const c: any; export = c; }
declare module "child_process" { export const execFile: any; export const execFileSync: any; export const spawn: any; }
declare namespace Electron { type IpcMainInvokeEvent = any; type BrowserWindow = any }
declare module "electron" { export const app: any; export const dialog: any; export const ipcMain: any; export const shell: any; export const contextBridge: any; export const ipcRenderer: any; export type IpcRendererEvent = any; export class BrowserWindow { constructor(o: any); [k: string]: any; static getAllWindows(): any[] } }
