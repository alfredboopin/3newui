// NOBODY 1.7.0 · duplicate finder core (grouping, keeper, merge plan, memory, excluded paths)
// run: node docs/tests/run-ts.mjs docs/tests/dupes-run.ts
const mem: Record<string, string> = {};
(globalThis as any).localStorage = { getItem: (k: string) => (k in mem ? mem[k] : null), setItem: (k: string, v: string) => { mem[k] = String(v); }, removeItem: (k: string) => { delete mem[k]; } };
import {
  songTitleKey, artistKey, findDuplicates, planMerge, qualityScore, groupSig, loadIgnored, saveIgnored, IGNORED_KEY,
  dupeTracksFrom, fmtBytes, isLossless, type DupeTrack,
} from "/home/user/work/src/src/shared/dupes/dupes";
import { excludePaths, unexcludePaths, isExcludedPath, excludedCount, clearExcluded, __resetExcluded, normPath } from "/home/user/work/src/src/shared/dupes/excludedPaths";

let pass = 0, fail = 0;
const ok = (c: any, m: string, extra?: any) => { if (c) pass++; else { fail++; console.log("FAIL", m, extra !== undefined ? JSON.stringify(extra) : ""); } };
const eq = (a: any, b: any) => JSON.stringify(a) === JSON.stringify(b);

// ── title / artist keys ──
ok(songTitleKey("Kooch") === songTitleKey("kooch"), "title: case");
ok(songTitleKey("Café del Mar") === songTitleKey("Cafe Del Mar"), "title: accents");
ok(songTitleKey("01 - Kooch") === songTitleKey("Kooch") && songTitleKey("3. Kooch") === songTitleKey("Kooch") && songTitleKey("03) Kooch") === songTitleKey("Kooch"), "title: leading track numbers");
ok(songTitleKey("Glass (feat. Sohrab)") === songTitleKey("Glass") && songTitleKey("Glass ft. X") === songTitleKey("Glass") && songTitleKey("Glass [with Y]") === songTitleKey("Glass"), "title: feat. / ft. / with");
ok(songTitleKey("Glass (Remastered 2011)") === songTitleKey("Glass") && songTitleKey("Glass - 2011 Remaster") === songTitleKey("Glass") && songTitleKey("Glass [Explicit]") === songTitleKey("Glass"), "title: remaster / explicit");
ok(songTitleKey("Glass (Live)") !== songTitleKey("Glass"), "title: (Live) is a different version", [songTitleKey("Glass (Live)")]);
ok(songTitleKey("Glass (Acoustic)") !== songTitleKey("Glass"), "title: (Acoustic) kept");
ok(songTitleKey("كوچ") === songTitleKey("کوچ") && songTitleKey("يار") === songTitleKey("یار"), "title: Arabic ك/ي → Persian ک/ی");
ok(songTitleKey("می‌روم") === songTitleKey("میروم"), "title: ZWNJ folded");
ok(songTitleKey("", "07 Saffron.flac") === songTitleKey("Saffron"), "title: empty → file name (number + ext stripped)");
ok(songTitleKey("Don't Stop!") === songTitleKey("Dont Stop"), "title: punctuation", [songTitleKey("Don't Stop!"), songTitleKey("Dont Stop")]);
ok(artistKey("Sohrab feat. Darya") === artistKey("Sohrab") && artistKey("Sohrab & Darya") === artistKey("Sohrab") && artistKey("Sohrab, Darya") === artistKey("Sohrab") && artistKey("Sohrab x Darya") === artistKey("Sohrab"), "artist: primary artist");
ok(artistKey("Unknown Artist") === "" && artistKey("") === "", "artist: placeholder → empty");
ok(artistKey("Beyoncé") === artistKey("BEYONCE"), "artist: case + accents");

// ── fixtures ──
let n = 0;
const tr = (o: Partial<DupeTrack>): DupeTrack => ({ id: o.id || `t${++n}`, title: "Song", artist: "Artist", duration: 200, format: "mp3", bitrate: 192, fileSize: 5_000_000, fileName: `${o.id || n}.mp3`, filePath: `/m/${o.id || n}.mp3`, ...o });
const lib: DupeTrack[] = [
  tr({ id: "k-mp3", title: "Kooch", artist: "Sohrab", duration: 241, format: "mp3", bitrate: 320, fileSize: 9_600_000 }),
  tr({ id: "k-flac", title: "Kooch", artist: "Sohrab", duration: 240, format: "flac", bitrate: 900, fileSize: 27_000_000, filePath: "/music/lossless/Sohrab/Kooch.flac" }),
  tr({ id: "k-128", title: "01 - Kooch (Remastered 2019)", artist: "Sohrab feat. Darya", duration: 242.5, format: "mp3", bitrate: 128, fileSize: 3_800_000 }),
  tr({ id: "k-live", title: "Kooch (Live)", artist: "Sohrab", duration: 310, format: "mp3", bitrate: 320 }),
  tr({ id: "k-edit", title: "Kooch", artist: "Sohrab", duration: 200, format: "mp3", bitrate: 320 }),
  tr({ id: "g1", title: "Glass", artist: "Mirror Band", duration: 180, format: "m4a", bitrate: 256, hasCover: true }),
  tr({ id: "g2", title: "glass", artist: "MIRROR BAND", duration: 181, format: "m4a", bitrate: 256 }),
  tr({ id: "u1", title: "Intro", artist: "Unknown Artist", duration: 60 }),
  tr({ id: "u2", title: "Intro", artist: "", duration: 60.4 }),
  tr({ id: "u3", title: "Intro", artist: "", duration: 95 }),
  tr({ id: "f1", title: "Track A", artist: "X", duration: 100, format: "flac", fileSize: 12_345_678 }),
  tr({ id: "f2", title: "Totally different tags", artist: "Y", duration: 100.2, format: "flac", fileSize: 12_345_678, filePath: "/backup/f2.flac" }),
  tr({ id: "f3", title: "Other", artist: "Z", duration: 140, format: "flac", fileSize: 12_345_678 }),
  tr({ id: "solo", title: "Saffron", artist: "Darya" }),
];

// ── mode: song ──
const song = findDuplicates(lib, "song");
const gK = song.find((g) => g.ids.includes("k-flac"))!;
ok(!!gK && eq([...gK.ids].sort(), ["k-128", "k-flac", "k-mp3"]), "song: 3 copies of Kooch within 3 s (feat./remaster/number folded)", gK?.ids);
ok(gK.keep === "k-flac" && gK.ids[0] === "k-flac", "song: lossless FLAC is the keeper");
ok(gK.ids[1] === "k-mp3" && gK.ids[2] === "k-128", "song: then 320 before 128", gK.ids);
ok(!song.some((g) => g.ids.includes("k-live")) && !song.some((g) => g.ids.includes("k-edit")), "song: live take (310 s, different title) and radio edit (200 s) stay apart");
ok(song.some((g) => eq([...g.ids].sort(), ["g1", "g2"])), "song: Glass ×2 (case-insensitive)");
const gG = song.find((g) => g.ids.includes("g1"))!;
ok(gG.keep === "g1", "song: equal quality → the copy with a cover wins");
ok(song.some((g) => eq([...g.ids].sort(), ["u1", "u2"])) && !song.some((g) => g.ids.includes("u3")), "song: no artist → only ±1 s copies group", song.filter((g) => g.ids.some((x) => x.startsWith("u"))).map((g) => g.ids));
ok(!song.some((g) => g.ids.includes("solo")), "song: unique song not listed");
ok(gK.extraBytes === 9_600_000 + 3_800_000, "song: extraBytes = the copies that go", gK.extraBytes);
ok(gK.sig === groupSig(gK.ids) && gK.sig === ["k-128", "k-flac", "k-mp3"].join("|"), "sig = sorted ids");
ok(song[0].ids.length >= song[song.length - 1].ids.length, "biggest groups first");

// ── mode: tags ──
const tags = findDuplicates(lib, "tags");
const tK = tags.find((g) => g.ids.includes("k-flac"))!;
ok(eq([...tK.ids].sort(), ["k-128", "k-edit", "k-flac", "k-mp3"]), "tags: any length → radio edit joins, (Live) stays apart (different title)", tK.ids);
ok(!tags.some((g) => g.ids.some((x) => x.startsWith("u"))), "tags: no-artist songs never grouped");

// ── mode: file ──
const file = findDuplicates(lib, "file");
ok(file.length >= 1 && file.some((g) => eq([...g.ids].sort(), ["f1", "f2"])), "file: same size + format + length ±0.5 s regardless of tags", file.map((g) => g.ids));
ok(!file.some((g) => g.ids.includes("f3")), "file: same size but 40 s longer → not a copy");
const fG = file.find((g) => g.ids.includes("f1"))!;
ok(fG.keep === "f1", "file: shorter path wins a quality tie", fG.ids);
ok(findDuplicates([tr({ id: "z1", fileSize: 0 }), tr({ id: "z2", fileSize: 0 })], "file").length === 0, "file: unknown size never matches");

// ── ignored ──
const ign = new Set([gK.sig]);
ok(!findDuplicates(lib, "song", { ignored: ign }).some((g) => g.sig === gK.sig), "ignored group hidden");
const lib2 = [...lib, tr({ id: "k-4", title: "Kooch", artist: "Sohrab", duration: 240.5, format: "ogg", bitrate: 160 })];
ok(findDuplicates(lib2, "song", { ignored: ign }).some((g) => g.ids.includes("k-4") && g.ids.includes("k-flac")), "a new copy makes a NEW group (signature changes) → shown again");
saveIgnored(new Set(["a|b", "c|d"]));
ok(eq([...loadIgnored()].sort(), ["a|b", "c|d"]), "ignored memory round trip");
mem[IGNORED_KEY] = "{bad";
ok(loadIgnored().size === 0, "corrupt ignored memory → empty");
mem[IGNORED_KEY] = JSON.stringify(["x", 3, null, "y"]);
ok(eq([...loadIgnored()], ["x", "y"]), "non-strings dropped");

// ── quality ──
ok(isLossless("FLAC") && isLossless("wav") && !isLossless("mp3") && !isLossless(undefined), "isLossless");
ok(qualityScore(tr({ format: "flac", bitrate: 0 })) > qualityScore(tr({ format: "mp3", bitrate: 320, hasCover: true, hasLyrics: true, rating: 5, plays: 100 })), "lossless beats everything");
ok(qualityScore(tr({ bitrate: 320 })) > qualityScore(tr({ bitrate: 256, hasCover: true, hasLyrics: true })), "bitrate beats cover/lyrics");
ok(qualityScore(tr({ rating: 4 })) > qualityScore(tr({ hasCover: true })), "rating counts");
ok(qualityScore(tr({ plays: 1000 })) - qualityScore(tr({ plays: 0 })) <= 60, "plays capped");

// ── merge plan ──
const plan = planMerge({
  playlists: [
    { id: "p1", trackIds: ["a", "gone", "b", "keep"] },
    { id: "p2", trackIds: ["x", "y"] },
    { id: "smart", trackIds: ["gone"], smart: { rules: [] } },
    { id: "liked", trackIds: ["gone"] },
  ],
  ratings: { gone: 5, keep: 3 },
  playCounts: { gone: 4, keep: 6 },
  lastPlayed: { gone: 2000, keep: 1000 },
}, { gone: "keep" });
ok(eq(plan.playlists, [{ id: "p1", trackIds: ["a", "keep", "b"] }, { id: "liked", trackIds: ["keep"] }]), "merge: removed id → kept id, first position wins, no doubles, untouched/smart lists skipped", plan.playlists);
ok(plan.ratings.keep === 5 && !("gone" in plan.ratings), "merge: best rating");
ok(plan.playCounts.keep === 10 && !("gone" in plan.playCounts), "merge: plays summed");
ok(plan.lastPlayed.keep === 2000 && !("gone" in plan.lastPlayed), "merge: latest last-played");
const plan2 = planMerge({ playlists: [], ratings: { gone: 2 }, playCounts: {}, lastPlayed: {} }, { gone: "k" });
ok(plan2.ratings.k === 2, "merge: rating moves to an unrated keeper");

// ── library rows → finder input ──
const rows = dupeTracksFrom([
  { id: "a", title: "A", artist: "B", duration: 10, format: "mp3", bitrate: "320 kbps", hasCover: true, isPlaceholderCover: true, syncedLyrics: [{ t: 0 }] },
  { id: "d", title: "Demo", artist: "B", duration: 10, demo: true },
  undefined,
  { id: "c", title: "C", artist: "B", duration: 10, hasCover: true, plainLyrics: "  " },
], { a: 4 }, { a: 7 });
ok(rows.length === 2, "rows: demo + missing rows skipped");
ok(rows[0].bitrate === 320, "rows: \"320 kbps\" string bitrate parsed");
ok(rows[0].hasCover === false && rows[0].hasLyrics === true && rows[0].rating === 4 && rows[0].plays === 7, "rows: placeholder cover isn't a cover; synced lyrics count; rating/plays attached", rows[0]);
ok(rows[1].hasCover === true && rows[1].hasLyrics === false, "rows: blank plain lyrics don't count");

// ── sizes ──
ok(fmtBytes(0) === "0 B" && fmtBytes(1536) === "2 KB" && fmtBytes(13_400_000) === "12.8 MB" && fmtBytes(3 * 1024 ** 3) === "3 GB", "fmtBytes", [fmtBytes(1536), fmtBytes(13_400_000), fmtBytes(3 * 1024 ** 3)]);
ok(/[۰-۹]/.test(fmtBytes(13_400_000, "fa-IR")), "fmtBytes: Persian digits", fmtBytes(13_400_000, "fa-IR"));

// ── excluded paths ──
__resetExcluded();
clearExcluded();
excludePaths(["C:\\Music\\Album\\01 Kooch.mp3", "/home/u/Music/Glass.flac", ""]);
ok(excludedCount() === 2, "excluded: two paths stored");
ok(isExcludedPath("c:/music/album/01 kooch.mp3") && isExcludedPath("C:\\MUSIC\\Album\\01 Kooch.mp3"), "excluded: case-insensitive, / and \\ unified");
__resetExcluded();
ok(isExcludedPath("/home/u/Music/Glass.flac"), "excluded: survives a restart (localStorage)");
unexcludePaths(["C:/Music/Album/01 Kooch.mp3"]);
ok(!isExcludedPath("C:\\Music\\Album\\01 Kooch.mp3") && excludedCount() === 1, "excluded: re-adding a file forgets it");
ok(normPath("C:\\a\\b\\") === "c:/a/b", "normPath trailing slash");

// ── scale ──
const big: DupeTrack[] = [];
for (let i = 0; i < 20_000; i++) big.push(tr({ id: `b${i}`, title: `Song ${i % 15000}`, artist: `Artist ${(i % 15000) % 900}`, duration: 180 + (i % 3), fileSize: 4_000_000 + (i % 15000) }));
const t0 = Date.now();
const bg = findDuplicates(big, "song");
const ms = Date.now() - t0;
ok(bg.length > 0 && ms < 1500, `20k tracks grouped in ${ms} ms`, { groups: bg.length, ms });

console.log(`${pass}/${pass + fail} passed`);
if (fail) process.exit(1);
