// NOBODY 1.7.0 · scrobbling core (md5, Last.fm signing + client, ListenBrainz client, offline queue)
// run: node docs/tests/run-ts.mjs docs/tests/scrobble-run.ts
import { md5 } from "/home/user/work/src/src/shared/scrobble/md5";
import { lastfmSign, formEncode, LastfmClient, ListenBrainzClient, lbPayload, LASTFM_MAX_AGE_S } from "/home/user/work/src/src/shared/scrobble/services";
import { Scrobbler, itemFromListen, QUEUE_KEY, STATE_KEY, BACKOFF_MIN_MS } from "/home/user/work/src/src/shared/scrobble/scrobbler";
import { ListenTracker } from "/home/user/work/src/src/shared/stats/listenTracker";
import crypto from "crypto";

let pass = 0, fail = 0;
const ok = (c: any, m: string, extra?: any) => { if (c) pass++; else { fail++; console.log("FAIL", m, extra !== undefined ? JSON.stringify(extra) : ""); } };

// ── md5 ──
for (const s of ["", "abc", "x".repeat(56), "سلام", "y".repeat(200)]) ok(md5(s) === crypto.createHash("md5").update(s, "utf8").digest("hex"), `md5 ${s.length}`);

// ── signature: Last.fm docs example shape ──
const sig = lastfmSign({ method: "auth.getSession", api_key: "k", token: "t", format: "json" }, "S");
ok(sig === md5("api_keykmethodauth.getSessiontokentS"), "api_sig sorted, format excluded");
ok(lastfmSign({ "artist[0]": "سهراب", "track[0]": "Kooch" }, "s") === md5("artist[0]سهرابtrack[0]Koochs"), "api_sig UTF-8 + array keys");
ok(formEncode({ a: "x y", "b[0]": "ک" }) === "a=x%20y&b%5B0%5D=%DA%A9", "form encode");

// ── fake services ──
type Call = { url: string; method: string; headers?: Record<string, string>; body?: string };
const calls: Call[] = [];
let mode: Record<string, string> = { lastfm: "ok", lb: "ok" };
const SECRET = "0123456789abcdef0123456789abcdef", KEY = "fedcba9876543210fedcba9876543210";
const res = (status: number, body: unknown, headers: Record<string, string> = {}) => ({ status, text: async () => (typeof body === "string" ? body : JSON.stringify(body)), headers: { get: (n: string) => headers[n.toLowerCase()] ?? null } });
let sessionPolls = 0;
const fetcher = async (url: string, init: any) => {
  calls.push({ url, method: init.method, headers: init.headers, body: init.body });
  if (url.startsWith("https://ws.audioscrobbler.com/2.0/")) {
    const q = new URLSearchParams(init.method === "GET" ? url.split("?")[1] : init.body);
    const p: Record<string, string> = {}; q.forEach((v, k) => { p[k] = v; });
    const { api_sig, format, ...rest } = p;
    if (api_sig !== lastfmSign(rest, SECRET)) return res(403, { error: 13, message: "Invalid method signature supplied" });
    if (mode.lastfm === "offline") throw new Error("net::ERR_INTERNET_DISCONNECTED");
    if (mode.lastfm === "500") return res(503, "busy");
    if (mode.lastfm === "badsk" && p.method !== "auth.getToken" && p.method !== "auth.getSession") return res(403, { error: 9, message: "Invalid session key" });
    if (p.method === "auth.getToken") return res(200, { token: "TOK" });
    if (p.method === "auth.getSession") { sessionPolls++; return sessionPolls < 3 ? res(403, { error: 14, message: "Unauthorized Token" }) : res(200, { session: { name: "mrvirus", key: "SK1", subscriber: 0 } }); }
    if (p.method === "track.updateNowPlaying") return res(200, { nowplaying: {} });
    if (p.method === "track.scrobble") {
      const n = Object.keys(p).filter((k) => k.startsWith("artist[")).length;
      const list = Array.from({ length: n }, (_, i) => ({ ignoredMessage: { code: p[`artist[${i}]`] === "Ignored Guy" ? "1" : "0", "#text": "" } }));
      return res(200, { scrobbles: { "@attr": { accepted: n, ignored: 0 }, scrobble: n === 1 ? list[0] : list } });
    }
    return res(400, { error: 3, message: "Invalid Method" });
  }
  if (url.startsWith("https://api.listenbrainz.org/1/")) {
    if (mode.lb === "offline") throw new Error("offline");
    if (init.headers?.Authorization !== "Token good-token-123") return res(401, { code: 401, error: "Invalid authorization token." });
    if (url.endsWith("/validate-token")) return res(200, { code: 200, message: "Token valid.", valid: true, user_name: "virus_lb" });
    if (mode.lb === "429") { mode.lb = "ok"; return res(429, { error: "rate" }, { "x-ratelimit-reset-in": "2" }); }
    const body = JSON.parse(init.body);
    if (body.payload.some((x: any) => x.track_metadata.track_name === "Bad")) return res(400, { code: 400, error: "bad listen" });
    return res(200, { status: "ok" });
  }
  return res(404, "");
};

// ── clients ──
{
  const c = new LastfmClient({ apiKey: KEY, secret: SECRET }, fetcher as any);
  const t = await c.getToken(); ok(t.token === "TOK", "getToken");
  ok(c.authUrl("TOK") === `https://www.last.fm/api/auth/?api_key=${KEY}&token=TOK`, "auth url");
  sessionPolls = 0;
  ok((await c.getSession("TOK")).kind === "pending", "getSession pending (14)");
  const items = [{ k: "a@1", ts: 1700000000, artist: "Sohrab", track: "Kooch", album: "Fx", dur: 241 }, { k: "b@2", ts: 1700000300, artist: "Ignored Guy", track: "X" }];
  const r = await c.scrobble("SK1", items);
  ok(r.kind === "ok" && r.accepted?.join() === "a@1" && r.ignored?.[0]?.k === "b@2" && r.ignored?.[0]?.why === "artist", "scrobble: accepted + ignored per item", r);
  const body = new URLSearchParams(calls[calls.length - 1].body);
  ok(body.get("timestamp[0]") === "1700000000" && body.get("duration[0]") === "241" && body.get("album[0]") === "Fx" && !body.get("album[1]") && body.get("sk") === "SK1" && body.get("format") === "json", "scrobble body");
  const bad = new LastfmClient({ apiKey: KEY, secret: "f".repeat(32) }, fetcher as any);
  ok((await bad.getToken()).kind === "config", "wrong secret → config (13)");
  const lb = new ListenBrainzClient(fetcher as any, { version: "1.7.0" });
  ok((await lb.validate("good-token-123")).name === "virus_lb", "LB validate");
  ok((await lb.validate("nope-nope-nope")).kind === "auth", "LB bad token → auth");
  const pl = lbPayload("import", items, { version: "1.7.0" }) as any;
  ok(pl.listen_type === "import" && pl.payload[0].listened_at === 1700000000 && pl.payload[0].track_metadata.release_name === "Fx" && pl.payload[0].track_metadata.additional_info.duration_ms === 241000 && pl.payload[0].track_metadata.additional_info.media_player === "NOBODY", "LB import payload");
  const np = lbPayload("playing_now", [{ artist: "a", track: "b" }], { version: "1" }) as any;
  ok(np.payload[0].listened_at === undefined, "LB playing_now has no listened_at");
}

// ── itemFromListen ──
const rec = (o: any = {}) => ({ at: 1_700_000_000_000, id: "t1", ms: 200000, dur: 240, title: "Kooch", artist: "Sohrab", album: "Fx", full: true, skip: false, src: "engine", ...o });
ok((itemFromListen(rec() as any) as any)?.k === "t1@1700000000000", "item key id@start");
ok(itemFromListen(rec({ full: false }) as any) === null, "not full → nothing");
ok(itemFromListen(rec({ artist: "Unknown Artist" }) as any) === "notags", "placeholder artist → notags");
ok((itemFromListen(rec({ artist: "Unknown Artist" }) as any, () => ({ title: "Kooch", artist: "Sohrab", album: "" })) as any)?.artist === "Sohrab", "placeholder → library tag");

// ── scrobbler: fake clock + timers ──
let now = 1_700_000_000_000;
let timers: { at: number; fn: () => void; id: number }[] = []; let tid = 0;
const setTimer = (fn: () => void, ms: number) => { const id = ++tid; timers.push({ at: now + ms, fn, id }); return id; };
const clearTimer = (h: any) => { timers = timers.filter((t) => t.id !== h); };
const settle = async () => { for (let i = 0; i < 6; i++) await new Promise((r) => setImmediate(r)); };
const advance = async (ms: number) => {
  const end = now + ms;
  for (;;) {
    await settle();
    timers.sort((a, b) => a.at - b.at);
    const t = timers[0];
    if (!t || t.at > end) break;
    timers.shift(); now = Math.max(now, t.at); t.fn();
  }
  now = end;
  await settle();
};
const mem = new Map<string, string>();
const kv = { getItem: (k: string) => mem.get(k) ?? null, setItem: (k: string, v: string) => { mem.set(k, v); }, removeItem: (k: string) => { mem.delete(k); } };
const vault = new Map<string, string>();
const secrets = { get: async (n: string) => vault.get(n) ?? null, set: async (n: string, v: string) => { vault.set(n, v); }, del: async (n: string) => { vault.delete(n); } };
const mk = (builtin = { apiKey: "", secret: "" }) => new Scrobbler({ fetcher: fetcher as any, secrets, storage: kv, version: "1.7.0", builtinLastfm: builtin, now: () => now, setTimer, clearTimer });

let s = mk();
await s.whenReady();
ok(!s.lastfmReady(), "no built-in key → Last.fm needs the user's own API account");
ok(!(await s.setLastfmKeys("short", "x")), "invalid key format rejected");
ok(await s.setLastfmKeys(KEY, SECRET), "own API key saved");
ok(vault.get("scrobble.lastfm.secret") === SECRET && !mem.get(STATE_KEY)!.includes(SECRET), "secret only in the secret store, never in localStorage");
// listens before connecting are not queued
s.onListenClosed(rec({ at: now - 600_000 }) as any);
ok(s.pending("lastfm") === 0, "not connected → nothing queued");
// connect Last.fm via browser flow (3 polls)
sessionPolls = 0;
let opened = "";
const cp = s.connectLastfm((u) => { opened = u; }, { pollMs: 3000 });
await advance(12_000);
const cr = await cp;
ok(cr.ok && cr.name === "mrvirus" && opened.includes("token=TOK"), "Last.fm connected after the browser approval", cr);
ok(vault.get("scrobble.lastfm.session") === "SK1" && s.connected("lastfm"), "session key stored");
// LB connect
ok(!(await s.connectListenBrainz("nope-nope-nope")).ok, "LB wrong token refused");
const lbc = await s.connectListenBrainz(" good-token-123 ");
ok(lbc.ok && s.state.listenbrainz.user === "virus_lb", "LB connected (trimmed token)");
await advance(5000);

// now playing → both
calls.length = 0;
s.onNowPlaying("t1", { title: "Kooch", artist: "Sohrab", album: "Fx", duration: 240 });
await advance(10);
ok(calls.some((c) => c.body?.includes("track.updateNowPlaying")) && calls.some((c) => c.body?.includes('"playing_now"')), "now playing sent to both");
s.setPref("lastfm", { nowPlaying: false });
calls.length = 0;
s.onNowPlaying("t1", { title: "Kooch", artist: "Sohrab", album: "Fx", duration: 240 });
await advance(10);
ok(!calls.some((c) => c.url.includes("audioscrobbler")) && calls.some((c) => c.url.includes("listenbrainz")), "now playing pref off for Last.fm only");

// offline: queue survives, backoff, then online
mode = { lastfm: "offline", lb: "offline" };
calls.length = 0;
const T0 = now - 300_000;
for (let i = 0; i < 3; i++) s.onListenClosed(rec({ id: "o" + i, at: T0 + i * 1000 }) as any);
ok(s.pending("lastfm") === 3 && s.pending("listenbrainz") === 3, "3 listens queued per service");
ok(JSON.parse(mem.get(QUEUE_KEY)!).lastfm.length === 3, "queue persisted before any network call");
await advance(2000);
ok(s.state.lastfm.lastError === "offline" && s.retryAt("lastfm") - now >= BACKOFF_MIN_MS - 2000, "offline → backoff ~30 s", s.retryAt("lastfm") - now);
await advance(31_000);
ok(s.retryAt("lastfm") - now > 50_000, "second failure → backoff doubles", s.retryAt("lastfm") - now);
// restart while offline: a new instance reads the queue
s = mk();
await s.whenReady();
ok(s.pending("lastfm") === 3 && s.connected("lastfm") && s.connected("listenbrainz"), "restart: queue + connections restored");
// duplicate listen (recovered after a crash) is not queued twice
s.onListenClosed(rec({ id: "o1", at: T0 + 1000 }) as any);
ok(s.pending("lastfm") === 3, "same listen (id@start) never queued twice");
mode = { lastfm: "ok", lb: "ok" };
calls.length = 0;
s.retryNow();
await advance(100);
ok(s.pending("lastfm") === 0 && s.pending("listenbrainz") === 0, "online → both queues flushed");
const lfBatch = calls.filter((c) => c.body?.includes("track.scrobble"));
ok(lfBatch.length === 1 && /artist%5B2%5D/.test(lfBatch[0].body!), "Last.fm: one batch of 3");
const lbB = calls.filter((c) => c.url.endsWith("submit-listens"));
ok(lbB.length === 1 && JSON.parse(lbB[0].body!).listen_type === "import" && JSON.parse(lbB[0].body!).payload.length === 3, "ListenBrainz: one import of 3");
ok(s.state.lastfm.sent === 3 && s.state.listenbrainz.sent === 3, "sent counters");

// 120 queued → Last.fm 50+50+20, LB 100+20
calls.length = 0;
mode = { lastfm: "offline", lb: "offline" };
for (let i = 0; i < 120; i++) s.onListenClosed(rec({ id: "m" + i, at: now - 3_600_000 + i * 1000 }) as any);
await advance(2000);
mode = { lastfm: "ok", lb: "ok" }; calls.length = 0; s.retryNow(); await advance(100);
ok(calls.filter((c) => c.body?.includes("track.scrobble")).length === 3 && calls.filter((c) => c.url.endsWith("submit-listens")).length === 2, "batching 50 / 100");

// Last.fm: older than 14 days dropped locally, LB keeps it
calls.length = 0;
mode = { lastfm: "offline", lb: "offline" };
s.onListenClosed(rec({ id: "old", at: now - (LASTFM_MAX_AGE_S + 3600) * 1000 }) as any);
mode = { lastfm: "ok", lb: "ok" }; s.retryNow(); await advance(2000);
ok(!calls.some((c) => c.body?.includes("track.scrobble")) && calls.some((c) => c.url.endsWith("submit-listens")), "15-day-old listen: not sent to Last.fm, sent to ListenBrainz");

// LB 429 honours X-RateLimit-Reset-In
mode.lb = "429";
s.onListenClosed(rec({ id: "rl", at: now - 1000 }) as any);
await advance(1600);
ok(s.pending("listenbrainz") === 1 && s.retryAt("listenbrainz") - now <= 2500, "429 → retry after reset-in (2 s)", s.retryAt("listenbrainz") - now);
await advance(3000);
ok(s.pending("listenbrainz") === 0, "sent after the rate-limit window");

// LB 400 on a batch → one by one, bad item dropped, others sent
mode = { lastfm: "offline", lb: "offline" };
s.onListenClosed(rec({ id: "g1", at: now - 5000 }) as any);
s.onListenClosed(rec({ id: "bad", title: "Bad", at: now - 4000 }) as any);
s.onListenClosed(rec({ id: "g2", at: now - 3000 }) as any);
await advance(2000);
mode = { lastfm: "ok", lb: "ok" }; calls.length = 0; const ign = s.state.listenbrainz.ignored; s.retryNow(); await advance(200);
ok(s.pending("listenbrainz") === 0 && s.state.listenbrainz.ignored === ign + 1, "400 batch bisected: bad listen dropped, the rest sent");

// revoked session → needsAuth, queue kept, reconnect flushes
mode.lastfm = "badsk";
s.onListenClosed(rec({ id: "x1", at: now - 1000 }) as any);
await advance(2000);
ok(s.state.lastfm.needsAuth && s.pending("lastfm") === 1, "invalid session → reconnect needed, queue kept");
s.onListenClosed(rec({ id: "x2", at: now - 500 }) as any);
ok(s.pending("lastfm") === 2, "still queues while waiting for reconnect");
mode.lastfm = "ok"; sessionPolls = 0;
const re = s.connectLastfm(() => {}, { pollMs: 3000 }); await advance(12_000); await re;
await advance(500);
ok(!s.state.lastfm.needsAuth && s.pending("lastfm") === 0, "reconnect → queue flushed");

// disconnect: secrets + queue gone
mode.lastfm = "offline";
s.onListenClosed(rec({ id: "y1", at: now - 1000 }) as any);
await s.disconnect("lastfm");
ok(!vault.has("scrobble.lastfm.session") && s.pending("lastfm") === 0 && !s.connected("lastfm"), "disconnect drops session + queue");
// auth cancel
mode.lastfm = "ok";
const c2 = s.connectLastfm(() => {}, { pollMs: 3000 }); await advance(10); s.cancelLastfmAuth(); await advance(4000);
ok((await c2).why === "cancelled", "auth flow can be cancelled");

// tracker → scrobbler end to end (history OFF still scrobbles)
{
  mode = { lastfm: "ok", lb: "ok" };
  const stored: any[] = [];
  const tr = new ListenTracker((r) => { stored.push(r); }, () => now, null);
  tr.setEnabledGetter(() => false);
  tr.onClosed((r) => s.onListenClosed(r));
  calls.length = 0;
  for (let p = 0; p <= 130; p += 0.5) { tr.sample("classic", "e2e", p, 240, true, () => ({ title: "Saffron", artist: "Darya", album: "Fx", duration: 240 })); now += 500; }
  tr.ended("classic", "e2e", 130);
  await advance(2000);
  ok(stored.length === 0, "history off: nothing stored");
  ok(calls.some((c) => c.url.endsWith("submit-listens") && c.body!.includes("Saffron")), "history off: the Classic listen is still scrobbled");
}

console.log(`${pass}/${pass + fail} passed`);
if (fail) process.exit(1);
