// bundle a .ts test with esbuild (same toolchain as the UI harness) and run it in node
import { build } from '/opt/sd-artifact/node_modules/esbuild/lib/main.js';
import { pathToFileURL } from 'url';
const src = process.argv[2]; const out = '/tmp/nobody-test-' + Date.now() + '.mjs';
await build({ entryPoints: [src], bundle: true, platform: 'node', format: 'esm', outfile: out, logLevel: 'error', define: { 'import.meta.env': '{}' }, external: ['crypto', 'fs', 'path'] });
await import(pathToFileURL(out).href);
