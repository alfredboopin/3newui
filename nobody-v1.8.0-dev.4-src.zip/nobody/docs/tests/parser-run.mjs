globalThis.window = globalThis;
import fs from 'fs';
const { parseAudioFileMetadata } = await import(process.env.AP || '../../src/audioParser.ts');
const H=3*1024*1024, TL=1024*1024;
for (const f of process.argv.slice(2)) {
  const b = fs.readFileSync(f);
  const show=(k,m)=>{const { cover, ...rest } = m; console.log((k+' '+f).padEnd(34), JSON.stringify({ ...rest, cover: cover ? cover.length : 0 }));};
  // cinema: full File, no options
  show('cin', await parseAudioFileMetadata(new File([b], f)));
  // desktop: head + tail
  const head = b.subarray(0, Math.min(H, b.length));
  const tail = b.length > H && /m4a|ogg|opus/.test(f) ? b.subarray(b.length - Math.min(TL, b.length - H)) : undefined;
  show('dsk', await parseAudioFileMetadata(new File([head], f), { tail: tail ? new File([tail], f) : undefined, realSize: b.length }));
  show('dsR', await parseAudioFileMetadata(new File([head], f), { tail: tail ? new File([tail], f) : undefined, realSize: b.length, readRange: async (s,l)=>{ if(s+l>b.length) throw 0; return b.subarray(s,s+l);} }));
}
