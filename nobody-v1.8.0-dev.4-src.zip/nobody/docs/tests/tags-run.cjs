const fs = require('fs'); const path = require('path'); const { execFileSync } = require('child_process');
const T = require('../../electron/tags/index.cjs');
const { oggCrc } = require('../../electron/tags/ogg.cjs');
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FAIL', m); } };
const md5 = (f) => execFileSync('ffmpeg', ['-v', 'error', '-i', f, '-map', '0:a', '-f', 'md5', '-'], { encoding: 'utf8' }).trim();
const probe = (f) => { const j = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', f], { encoding: 'utf8' })); const tags = {}; for (const [k, v] of Object.entries(j.format.tags || {})) tags[k.toLowerCase()] = v; for (const s of j.streams) for (const [k, v] of Object.entries(s.tags || {})) if (s.codec_type === 'audio') tags[k.toLowerCase()] ??= v; return { tags, pics: j.streams.filter((s) => s.disposition && s.disposition.attached_pic).length }; };
const decodeErrors = (f) => execFileSync('ffmpeg', ['-v', 'error', '-i', f, '-map', '0:a', '-f', 'null', '-'], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
function checkOggPages(f) { const b = fs.readFileSync(f); let pos = 0, seq = -1, n = 0; while (pos < b.length) { if (b.toString('latin1', pos, pos + 4) !== 'OggS') return 'no OggS at ' + pos; const ns = b[pos + 26]; let dl = 0; for (let i = 0; i < ns; i++) dl += b[pos + 27 + i]; const len = 27 + ns + dl; const pg = Buffer.from(b.subarray(pos, pos + len)); const crc = pg.readUInt32LE(22); pg.writeUInt32LE(0, 22); if (oggCrc(pg) !== crc) return 'bad crc page ' + n; const s = pg.readUInt32LE(18); if (s !== seq + 1) return `seq gap ${seq}->${s}`; seq = s; pos += len; n++; } return 'ok:' + n; }
const cover = new Uint8Array(fs.readFileSync('cover.jpg')); const coverPng = new Uint8Array(fs.readFileSync('cover.png'));
const FA = { title: 'آهنگ تست — Ünïcødé', artist: 'هنرمند; Second', album: 'آلبوم', albumArtist: 'Various', year: '2019-05-01', genre: 'Rock; Pop', track: '3/12', disc: '1/2', composer: 'کامپوزر', comment: 'line one\nخط دو' };
(async () => {
  for (const name of ['mp3_v23.mp3', 'mp3_v24.mp3', 'mp3_none.mp3', 'flac_cov.flac', 'flac_plain.flac', 'vorbis.ogg', 'opus.opus', 'm4a_end.m4a', 'm4a_fast.m4a', 'alac.m4a']) {
    console.log('==', name);
    const f = path.resolve('w_' + name); fs.copyFileSync(name, f);
    const a0 = md5(f);
    const r0 = await T.readTags(f);
    if (name !== 'mp3_none.mp3') { ok(r0.fields.title === 'Orig', 'read title ' + r0.fields.title); ok(r0.fields.artist === 'OrigArtist', 'read artist'); ok(/^2001/.test(r0.fields.year), 'read year ' + r0.fields.year); ok(r0.fields.genre === 'Rock', 'read genre ' + r0.fields.genre); ok(r0.fields.track.startsWith('2'), 'read track ' + r0.fields.track); if (!name.startsWith('mp3')) ok(r0.fields.comment === 'hello', 'read comment ' + JSON.stringify(r0.fields.comment)); }
    console.log('  read:', r0.tagType, r0.hasCover ? 'cover' : 'no cover');
    // 1: full write + cover
    const w1 = await T.writeTags(f, { fields: FA, cover: { action: 'set', data: cover } });
    console.log('  w1', w1.mode, w1.size);
    ok(w1.fields.title === FA.title && w1.fields.album === FA.album && w1.fields.composer === FA.composer, 'w1 fields ' + JSON.stringify(w1.fields));
    ok(w1.fields.genre === 'Rock; Pop', 'w1 genre ' + w1.fields.genre);
    ok(w1.fields.track === '3/12' && w1.fields.disc === '1/2', 'w1 track/disc');
    ok(w1.fields.comment === FA.comment, 'w1 comment ' + JSON.stringify(w1.fields.comment));
    ok(w1.hasCover, 'w1 cover');
    ok(md5(f) === a0, 'audio unchanged after w1');
    const p1 = probe(f); ok((p1.tags.title || '') === FA.title, 'ffprobe title ' + p1.tags.title); ok((p1.tags.album || '') === FA.album, 'ffprobe album');
    ok(/Rock/.test(p1.tags.genre || ''), 'ffprobe genre ' + p1.tags.genre);
    ok(p1.pics >= 1 || /ogg|opus/.test(name), 'ffprobe sees cover ' + p1.pics);
    if (/ogg|opus/.test(name)) ok(checkOggPages(f).startsWith('ok'), 'ogg pages ' + checkOggPages(f));
    ok(decodeErrors(f) === '', 'decodes cleanly');
    // 2: small edit → should be in place now
    const w2 = await T.writeTags(f, { fields: { title: 'Short' } });
    console.log('  w2', w2.mode);
    ok(w2.fields.title === 'Short' && w2.fields.album === FA.album && w2.hasCover, 'w2 keeps others');
    if (!/ogg|opus/.test(name)) ok(w2.mode === 'inplace', 'w2 in place');
    ok(md5(f) === a0, 'audio unchanged after w2');
    // 3: remove cover + clear fields
    const w3 = await T.writeTags(f, { fields: { comment: '', composer: '', genre: '' }, cover: { action: 'remove' } });
    console.log('  w3', w3.mode, w3.size);
    ok(!w3.hasCover && !w3.fields.comment && !w3.fields.composer && !w3.fields.genre && w3.fields.title === 'Short', 'w3 cleared ' + JSON.stringify(w3.fields));
    ok(probe(f).pics === 0, 'ffprobe no cover');
    ok(md5(f) === a0, 'audio unchanged after w3');
    if (/ogg|opus/.test(name)) ok(checkOggPages(f).startsWith('ok'), 'ogg pages w3 ' + checkOggPages(f));
    // 4: png cover
    const w4 = await T.writeTags(f, { fields: {}, cover: { action: 'set', data: coverPng } });
    ok(w4.hasCover && md5(f) === a0 && decodeErrors(f) === '', 'w4 png cover');
    const leftovers = fs.readdirSync('.').filter((x) => x.includes('.nobody-'));
    ok(leftovers.length === 0, 'no temp leftovers');
  }
  // errors
  const bad = async (p, patch, code) => { try { await T.writeTags(p, patch); ok(false, 'expected ' + code); } catch (e) { ok(T.errorCode(e) === code, `got ${T.errorCode(e)} want ${code} (${e.message})`); } };
  await bad(path.resolve('src.wav'), { fields: { title: 'x' } }, 'E_UNSUPPORTED');
  await bad(path.resolve('w_mp3_v23.mp3'), { fields: { year: 'soon' } }, 'E_INVALID');
  await bad(path.resolve('w_mp3_v23.mp3'), { fields: { track: 'abc' } }, 'E_INVALID');
  await bad(path.resolve('w_mp3_v23.mp3'), { fields: {}, cover: { action: 'set', data: new Uint8Array([1, 2, 3, 4]) } }, 'E_INVALID');
  await bad('relative.mp3', { fields: {} }, 'E_INVALID');
  await bad(path.resolve('missing.mp3'), { fields: {} }, 'E_NOT_FOUND');
  fs.copyFileSync('mp3_v24.mp3', 'ro.mp3'); fs.chmodSync('ro.mp3', 0o444);
  if (process.getuid && process.getuid() !== 0) await bad(path.resolve('ro.mp3'), { fields: { title: 'x' } }, 'E_READONLY');
  // concurrency: 5 parallel writes on one file → all serialized, last wins, file valid
  const cf = path.resolve('w_flac_plain.flac');
  await Promise.all([1, 2, 3, 4, 5].map((i) => T.writeTags(cf, { fields: { title: 'T' + i } })));
  ok((await T.readTags(cf)).fields.title === 'T5', 'serialized writes');
  console.log(`\n${pass} passed, ${fail} failed`);
})().catch((e) => { console.error('CRASH', e); process.exit(1); });
