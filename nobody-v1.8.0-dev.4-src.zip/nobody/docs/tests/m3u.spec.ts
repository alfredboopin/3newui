// node docs/tests/m3u-run.mjs → bundles this with esbuild and runs it in plain node
import * as M from "../../src/shared/m3u/m3u";
let pass = 0, fail = 0;
const eq = (name: string, a: unknown, b: unknown) => {
  const ok = JSON.stringify(a) === JSON.stringify(b);
  ok ? pass++ : fail++;
  if (!ok) console.log("FAIL", name, "\n  got ", JSON.stringify(a), "\n  want", JSON.stringify(b));
};
// paths
eq("norm win", M.normalizePath("c:/Music/./a/../b//x.mp3"), "C:\\Music\\b\\x.mp3");
eq("norm unc", M.normalizePath("\\\\nas\\music\\a\\..\\x.flac"), "\\\\nas\\music\\x.flac");
eq("norm posix", M.normalizePath("/home/u/../v/x.mp3"), "/home/v/x.mp3");
eq("norm .. above root", M.normalizePath("C:\\..\\..\\x.mp3"), "C:\\x.mp3");
eq("key equal", M.pathKey("C:\\Music\\Ä.mp3"), M.pathKey("c:/music/A\u0308.MP3".normalize("NFD")));
eq("rel", M.resolveEntryPath("sub\\x.mp3", "D:\\Lists"), "D:\\Lists\\sub\\x.mp3");
eq("rel ..", M.resolveEntryPath("..\\Music\\x.mp3", "D:\\Lists"), "D:\\Music\\x.mp3");
eq("rel fwd on win", M.resolveEntryPath("../Music/x.mp3", "D:\\Lists"), "D:\\Music\\x.mp3");
eq("root-rel", M.resolveEntryPath("\\Music\\x.mp3", "E:\\Lists\\a"), "E:\\Music\\x.mp3");
eq("abs other drive", M.resolveEntryPath("C:\\x.mp3", "E:\\Lists"), "C:\\x.mp3");
eq("unc abs", M.resolveEntryPath("\\\\nas\\m\\x.mp3", "E:\\L"), "\\\\nas\\m\\x.mp3");
eq("posix rel", M.resolveEntryPath("a/b.mp3", "/home/u/lists"), "/home/u/lists/a/b.mp3");
eq("posix abs", M.resolveEntryPath("/srv/m/b.mp3", "/home/u"), "/srv/m/b.mp3");
eq("file url win", M.resolveEntryPath("file:///C:/My%20Music/%D8%B3%D9%84%D8%A7%D9%85.mp3", ""), "C:\\My Music\\سلام.mp3");
eq("file url localhost", M.resolveEntryPath("file://localhost/C:/a.mp3", ""), "C:\\a.mp3");
eq("file url unc", M.resolveEntryPath("file://nas/music/a.mp3", ""), "\\\\nas\\music\\a.mp3");
eq("file url posix", M.resolveEntryPath("file:///home/u/a%23b.mp3", ""), "/home/u/a#b.mp3");
eq("http remote", M.resolveEntryPath("http://radio/x", "C:\\"), null);
eq("rel no base", M.resolveEntryPath("x.mp3", ""), "");
eq("drive-relative", M.resolveEntryPath("C:x.mp3", "D:\\"), "");
// parse
const txt = "\uFEFF#EXTM3U\r\n#PLAYLIST:Road trip\r\n#EXTINF:215 tvg-name=\"a, b\" group-title=\"x\",Queen - Don't Stop Me Now\r\nQueen\\01 Don't Stop.mp3\r\n\r\n# comment\r\n#EXTINF:-1,Live stream\r\nhttps://radio.example/live\r\n#EXTINF:0,Just A Title\r\nC:\\Music\\t.flac\r\n#EXTART:Googoosh\nfile:///C:/M/x.mp3\rplain.ogg";
const p = M.parseM3U(txt, "D:\\Lists");
eq("name", p.name, "Road trip");
eq("extended", p.extended, true);
eq("remote", p.remote, 1);
eq("count", p.entries.length, 4);
eq("e0", [p.entries[0].path, p.entries[0].artist, p.entries[0].title, p.entries[0].duration], ["D:\\Lists\\Queen\\01 Don't Stop.mp3", "Queen", "Don't Stop Me Now", 215]);
eq("e1 no dur, no artist", [p.entries[1].duration, p.entries[1].artist, p.entries[1].title], [undefined, undefined, "Just A Title"]);
eq("extart", p.entries[2].artist, "Googoosh");
eq("plain no meta", [p.entries[3].path, p.entries[3].title], ["D:\\Lists\\plain.ogg", undefined]);
eq("extinf not leaking after remote", p.entries[1].line, 10);
eq("plain m3u", M.parseM3U("a.mp3\nb.mp3\n", "/m").entries.map((e) => e.path), ["/m/a.mp3", "/m/b.mp3"]);
// decode
const fa = "C:\\موسیقی\\گوگوش - من آمده‌ام.mp3";
const enc1256 = new Uint8Array([...Buffer.from("#EXTM3U\r\n")].concat([0x43,0x3a,0x5c]));
eq("utf8 bom", M.decodeM3U(new Uint8Array([0xef, 0xbb, 0xbf, 0x61])).encoding, "utf-8");
eq("utf16le", M.decodeM3U(new Uint8Array([0xff, 0xfe, 0x61, 0, 0x62, 0])).text, "ab");
eq("utf8 plain", M.decodeM3U(new TextEncoder().encode(fa)).text, fa);
// build a real windows-1256 byte string for "سلام" = D3 E1 C7 E3
const legacy = new Uint8Array([0x43, 0x3a, 0x5c, 0xd3, 0xe1, 0xc7, 0xe3, 0x2e, 0x6d, 0x70, 0x33]);
eq("1256 by lang", M.decodeM3U(legacy, "fa").text, "C:\\سلام.mp3");
eq("1256 by library score (en ui)", M.decodeM3U(legacy, "en", M.libraryScorer(M.indexLibrary([{ id: "1", filePath: "C:\\سلام.mp3", title: "x", artist: "y", duration: 1 }]), "")).encoding, "windows-1256");
const cyr = new Uint8Array([0x2f, 0xcf, 0xf0, 0xe8, 0xe2, 0xe5, 0xf2, 0x2e, 0x6d, 0x70, 0x33]); // "/Привет.mp3" in 1251
eq("1251 by lang", M.decodeM3U(cyr, "ru").text, "/Привет.mp3");
eq("1251 by score", M.decodeM3U(cyr, "fa", M.libraryScorer(M.indexLibrary([{ id: "1", filePath: "/Привет.mp3", title: "x", artist: "y", duration: 1 }]), "/")).encoding, "windows-1251");
// match
const lib: M.MatchTrack[] = [
  { id: "a", filePath: "C:\\Music\\Queen\\01 Don't Stop.mp3", title: "Don't Stop Me Now", artist: "Queen", duration: 211 },
  { id: "b", filePath: "D:\\Other\\01 Intro.mp3", title: "Intro", artist: "X", duration: 60 },
  { id: "c", filePath: "E:\\Other\\01 Intro.mp3", title: "Intro", artist: "Y", duration: 61 },
  { id: "d", filePath: "E:\\Fa\\track.mp3", title: "من آمده‌ام", artist: "گوگوش", duration: 300 },
  { id: "e", filePath: "E:\\Dup\\x1.mp3", title: "Same", artist: "Twin", duration: 100 },
  { id: "f", filePath: "E:\\Dup\\x2.mp3", title: "Same", artist: "Twin", duration: 200 },
];
const idx = M.indexLibrary(lib);
const m = (e: Partial<M.M3UEntry>) => { const r = M.matchEntry({ raw: "", line: 1, path: "", ...e } as M.M3UEntry, idx); return [r.id, r.kind]; };
eq("path exact case-insens", m({ path: "c:\\music\\queen\\01 DON'T STOP.mp3" }), ["a", "path"]);
eq("moved file → unique name", m({ path: "Z:\\Backup\\01 Don't Stop.mp3" }), ["a", "name"]);
eq("ambiguous name → no", m({ path: "Z:\\01 Intro.mp3" }), [null, null]);
eq("ambiguous name + tags", m({ path: "Z:\\01 Intro.mp3", artist: "y", title: "intro" }), ["c", "tags"]);
eq("tags fold arabic ي/ك + ZWNJ", m({ path: "Z:\\q.mp3", artist: "گوگوش", title: "من آمده ام" }), ["d", "tags"]);
eq("tags fold ي", m({ path: "Z:\\q.mp3", artist: "گوگوش", title: "من آمده\u200Cام" }), ["d", "tags"]);
eq("tags duration picks", m({ path: "Z:\\q.mp3", artist: "Twin", title: "Same", duration: 199 }), ["f", "tags"]);
eq("tags duration too far", m({ path: "Z:\\q.mp3", artist: "Twin", title: "Same", duration: 150 }), [null, null]);
eq("tags ambiguous no dur", m({ path: "Z:\\q.mp3", artist: "Twin", title: "Same" }), [null, null]);
eq("tags with ±3s", m({ path: "Z:\\q.mp3", artist: "Queen", title: "don't stop me now", duration: 214 }), ["a", "tags"]);
// build
const out = M.buildM3U([
  { path: "D:\\Lists\\Queen\\a.mp3", title: "A", artist: "Queen", duration: 210.6 },
  { path: "D:\\Music\\b.flac", title: "B\r\nhack", duration: 0 },
  { path: "C:\\x\\c.mp3", title: "C", artist: "Z" },
  { path: "d:\\lists\\#weird.mp3", title: "W" },
  { fileName: "web-only.mp3", title: "Web" },
], { targetPath: "D:\\Lists\\road.m3u8", name: "Road\ntrip" });
eq("build", out.split("\r\n"), ["#EXTM3U", "#PLAYLIST:Road trip", "#EXTINF:211,Queen - A", "Queen\\a.mp3", "#EXTINF:-1,B hack", "..\\Music\\b.flac", "#EXTINF:-1,Z - C", "C:\\x\\c.mp3", "#EXTINF:-1,W", ".\\#weird.mp3", "#EXTINF:-1,Web", "web-only.mp3", ""]);
eq("build posix", M.buildM3U([{ path: "/home/u/m/a.mp3", title: "A" }], { targetPath: "/home/u/lists/x.m3u" }).split("\r\n")[2], "../m/a.mp3");
eq("build unc same share", M.relativePath("\\\\nas\\m\\lists", "\\\\NAS\\m\\a\\x.mp3"), "..\\a\\x.mp3");
eq("build unc other share", M.relativePath("\\\\nas\\m\\lists", "\\\\nas\\n\\x.mp3"), null);
// round trip: build → parse → match
const rt = M.parseM3U(M.buildM3U(lib.map((t) => ({ path: t.filePath, title: t.title, artist: t.artist, duration: t.duration })), { targetPath: "E:\\Lists\\all.m3u8" }), "E:\\Lists");
eq("round trip", M.matchAll(rt.entries, idx).map((r) => r.id), ["a", "b", "c", "d", "e", "f"]);
eq("bom only for .m3u", [M.encodeM3U("x", "a.m3u")[0], M.encodeM3U("x", "a.m3u8")[0]], [0xef, 0x78]);
eq("name from file", M.playlistNameFromFile("C:\\L\\Road Trip.M3U8"), "Road Trip");
// perf
const big: M.MatchTrack[] = Array.from({ length: 20000 }, (_, i) => ({ id: String(i), filePath: `C:\\Music\\A${i % 300}\\${i} song.mp3`, title: `Song ${i}`, artist: `A${i % 300}`, duration: 200 }));
const t0 = performance.now();
const bidx = M.indexLibrary(big);
const bigList = M.buildM3U(big.map((t) => ({ path: t.filePath, title: t.title, artist: t.artist, duration: t.duration })), { targetPath: "C:\\Lists\\big.m3u8" });
const bp = M.parseM3U(bigList, "C:\\Lists");
const hits = M.matchAll(bp.entries, bidx).filter((r) => r.kind === "path").length;
const ms = performance.now() - t0;
eq("20k round trip all path hits", hits, 20000);
console.log(`20k index+build+parse+match: ${ms.toFixed(0)} ms`);
console.log(`${pass}/${pass + fail} passed`);
if (fail) process.exit(1);
