// NOBODY 1.8.0-dev.3 · global shortcuts Settings UI, Chromium run (Classic / Cinema / EELA / ALOK × EN / FA)
// desk:*-hotkeys is mocked in mock.ts (state in sessionStorage, survives reloads). Fixtures: fixtures-m3u.sh.
import { chromium } from '/opt/sd-artifact/node_modules/playwright/index.mjs';
const T = '/home/user/work/t-m3u'; const LIB = T + '/lib/Album';
const ROOT = { classic: '[data-ui-pane="classic"]', cinema: '#nc-root', eela: '#ne-root', alok: '#na-root' };
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, x) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, x !== undefined ? JSON.stringify(x) : ''); } };
const browser = await chromium.launch({ executablePath: '/ms-playwright/chromium-1208/chrome-linux64/chrome', args: ['--autoplay-policy=no-user-gesture-required'] });
const faces = (process.env.FACES || 'classic,cinema,eela,alok').split(','); const langs = (process.env.LANGS || 'en,fa').split(',');
const PERSIAN = /[\u0600-\u06FF]/; const RAW = /\b(hk|dk)[A-Z]\w+\b|\{\{\w+\}\}/;
const waitFor = async (page, fn, arg, ms = 6000) => { try { await page.waitForFunction(fn, arg, { timeout: ms }); return true; } catch { return false; } };
const desk = (page) => page.evaluate(() => window.__desk());
const hkS = (page) => page.evaluate(() => { const s = window.__T.useHotkeys.getState(); return { enabled: s.enabled, map: s.map, status: s.status, busy: s.busy, recording: s.recording, note: s.note }; });
const goSettings = async (page, face) => {
  if (face === 'classic') { await page.click('.settings-nav'); return; }
  await page.evaluate((face) => { const T = window.__T; if (face === 'cinema') T.useUi.getState().setView('settings'); else if (face === 'eela') T.useEelaUi.getState().setView('settings'); else { const s = T.useAlokUi.getState(); if (s.view !== 'settings') s.toggleView('settings'); } }, face);
};
const boot = async (page) => { await page.waitForFunction(() => { const T = window.__T; if (!T) return false; const b = T.getBridge(); return Math.max(Object.keys(T.useLibrary.getState().tracks).length, b ? b.listTracks().length : 0) >= 7; }, null, { timeout: 25000 }); };
const row = (face) => `${ROOT[face]} [data-desk-row="hotkeys"]`;
const sw = (face) => `${row(face)} [role="switch"]`;
const list = (face) => `${ROOT[face]} [data-hotkey-list]`;
const keysBtn = (face, a) => `${list(face)} [data-hk="${a}"] .ndh-keys`;
const caps = (page, face, a) => page.$eval(keysBtn(face, a), (e) => e.innerText.replace(/\s+/g, ' ').trim()).catch(() => null);
const noteOf = (page, face, a) => page.$eval(`${list(face)} [data-hk="${a}"] .ndh-note`, (e) => e.innerText).catch(() => '');
/** one keydown as the OS would send it, aimed at whatever has focus (capture listener must eat it) */
const press = (page, ev) => page.evaluate((ev) => { const t = document.activeElement || document.body; t.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, ...ev })); t.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, cancelable: true, ...ev })); }, ev);
const idle = (page) => waitFor(page, () => !window.__T.useHotkeys.getState().busy, null, 3000);

for (const face of faces) for (const lang of langs) {
  console.log(`\n■ ${face} · ${lang}`);
  const rtl = lang === 'fa';
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(String(e).slice(0, 300)));
  await page.addInitScript(([lib, face, lang]) => {
    if (sessionStorage.getItem('seeded')) return;
    localStorage.clear();
    localStorage.setItem('nobody-player-state-v2', JSON.stringify({ folderPaths: [lib], lang })); localStorage.setItem('nobody-ui-mode', face);
    sessionStorage.setItem('seeded', '1');
  }, [LIB, face, lang]);
  await page.goto('http://127.0.0.1:8787/');
  await boot(page);
  await page.evaluate((lang) => window.__T.useSettings.getState().set('lang', lang), lang);
  await goSettings(page, face);
  await page.waitForSelector(row(face), { timeout: 8000 }).catch(() => {});

  // ── 1. the row itself
  const rtxt = await page.$eval(row(face), (e) => e.innerText).catch(() => '');
  ok(rtl ? /میان‌برهای سراسری/.test(rtxt) : /Global shortcuts/.test(rtxt), 'row title = "Global shortcuts" (not "Open with")', rtxt.slice(0, 100));
  ok(!/Open with|Open with»/.test(rtxt.split('\n')[0]) && !RAW.test(rtxt) && (!rtl || PERSIAN.test(rtxt)), 'row localized, no raw keys', rtxt.slice(0, 100));
  if (face === 'cinema' || face === 'eela') ok(await page.$(`${row(face)} svg.lucide-keyboard`) !== null && await page.$(`${row(face)} svg.lucide-folder-open`) === null, 'row icon = keyboard');
  ok(await page.$eval(sw(face), (e) => e.getAttribute('aria-checked')).catch(() => null) === 'false', 'off by default');
  ok(await page.$(list(face)) === null, 'list hidden while off');

  // ── 2. switch on → saved in main, list with the 7 actions + defaults
  await page.click(sw(face));
  ok(await waitFor(page, () => window.__desk().hk.enabled === true, null, 3000) && await idle(page), 'switch on → main enables the hotkeys', (await desk(page)).hk.calls);
  ok(await waitFor(page, (s) => document.querySelectorAll(s + ' [data-hk]').length === 7, list(face), 3000), 'list shows 7 actions');
  const ltxt = await page.$eval(list(face), (e) => e.innerText).catch(() => '');
  ok(!RAW.test(ltxt) && (!rtl || PERSIAN.test(ltxt)), 'list localized', ltxt.slice(0, 120));
  ok((await caps(page, face, 'play-pause')) === 'Ctrl Alt Space' && (await caps(page, face, 'next')) === 'Ctrl Alt →', 'defaults shown as key caps (Ctrl Alt Space, Ctrl Alt →)', [await caps(page, face, 'play-pause'), await caps(page, face, 'next')]);
  ok(await page.$eval(`${list(face)} [data-hk="play-pause"] bdi`, (e) => e.getAttribute('dir')).catch(() => null) === 'ltr', 'key caps stay LTR');
  ok(await page.$eval(`${list(face)} [data-hk="next"]`, (e) => e.getAttribute('data-status')) === 'ok', 'registered → status ok');

  // ── 3. record a new combo; Persian layout: key = "ح", code = KeyP → still Ctrl+Alt+P
  const playing0 = await page.evaluate((face) => face === 'classic' ? window.__T.getBridge().captureHandoff().isPlaying : window.__T.useUi.getState().isPlaying, face);
  await page.click(keysBtn(face, 'play-pause'));
  ok(await waitFor(page, () => window.__desk().hk.suspended === true, null, 2000), 'recording → main suspends our shortcuts');
  ok(rtl ? PERSIAN.test(await caps(page, face, 'play-pause')) : /Press keys/i.test(await caps(page, face, 'play-pause')), 'button says "press keys"', await caps(page, face, 'play-pause'));
  await press(page, { code: 'Space', key: ' ' });
  ok((await hkS(page)).note?.why === 'mods' && (await noteOf(page, face, 'play-pause')).length > 0, 'plain Space → "needs Ctrl/Alt/Win" note', [await hkS(page), await noteOf(page, face, 'play-pause')]);
  const playing1 = await page.evaluate((face) => face === 'classic' ? window.__T.getBridge().captureHandoff().isPlaying : window.__T.useUi.getState().isPlaying, face);
  ok(playing1 === playing0, "…and the face's own Space (play/pause) never fired", [playing0, playing1]);
  await press(page, { code: 'Delete', key: 'Delete', ctrlKey: true, altKey: true });
  ok((await hkS(page)).note?.why === 'reserved', 'Ctrl+Alt+Delete → reserved note', (await hkS(page)).note);
  await press(page, { code: 'ControlLeft', key: 'Control', ctrlKey: true });
  ok((await hkS(page)).recording === 'play-pause', 'a lone modifier keeps waiting');
  await press(page, rtl ? { code: 'KeyP', key: 'ح', ctrlKey: true, altKey: true } : { code: 'KeyP', key: 'p', ctrlKey: true, altKey: true });
  await idle(page);
  const d1 = await desk(page);
  ok(d1.hk.map['play-pause'] === 'Ctrl+Alt+P', rtl ? 'Persian layout ("ح") → saved as Ctrl+Alt+P (physical key)' : 'Ctrl+Alt+P saved in main', d1.hk.map);
  ok(d1.hk.suspended === false && (await hkS(page)).recording === null, 'recording over → shortcuts live again');
  ok((await caps(page, face, 'play-pause')) === 'Ctrl Alt P', 'list shows Ctrl Alt P', await caps(page, face, 'play-pause'));
  ok(await page.evaluate(() => document.activeElement?.classList.contains('ndh-keys') && document.activeElement.closest('[data-hk]')?.getAttribute('data-hk') === 'play-pause'), 'focus back on the same button');

  // ── 4. Esc cancels, nothing saved
  const nCalls = (await desk(page)).hk.calls.length;
  await page.click(keysBtn(face, 'stop')); await press(page, { code: 'Escape', key: 'Escape' });
  ok((await hkS(page)).recording === null && (await desk(page)).hk.calls.length === nCalls, 'Esc cancels, nothing saved');

  // ── 5. reuse a combo → it moves, the other action is cleared, note says so
  await page.click(keysBtn(face, 'next')); await press(page, { code: 'KeyP', key: 'p', ctrlKey: true, altKey: true }); await idle(page);
  const d2 = await desk(page);
  ok(d2.hk.map.next === 'Ctrl+Alt+P' && d2.hk.map['play-pause'] === '', 'Ctrl+Alt+P moved to Next, Play/Pause cleared', d2.hk.map);
  const mv = await noteOf(page, face, 'next');
  ok(mv.length > 0 && !RAW.test(mv) && (!rtl || PERSIAN.test(mv)), 'moved note shown (localized)', mv);
  ok((await page.$eval(keysBtn(face, 'play-pause'), (e) => e.innerText)).trim().length > 0 && (await caps(page, face, 'play-pause')) !== 'Ctrl Alt P', 'Play/Pause shows "none"');

  // ── 6. Backspace while recording clears; ✕ clears
  await page.click(keysBtn(face, 'vol-up')); await press(page, { code: 'Backspace', key: 'Backspace' }); await idle(page);
  ok((await desk(page)).hk.map['vol-up'] === '', 'Backspace while recording → cleared');
  await page.click(`${list(face)} [data-hk="vol-down"] .ndh-clear`); await idle(page);
  ok((await desk(page)).hk.map['vol-down'] === '', '✕ button → cleared');

  // ── 7. another app owns a combo → "taken" after restart
  await page.evaluate(() => window.__deskPatch({ hk: { taken: ['Ctrl+Alt+N'] } }));
  await page.reload(); await boot(page); await goSettings(page, face);
  await page.waitForSelector(list(face), { timeout: 8000 }).catch(() => {});
  ok(await page.$eval(sw(face), (e) => e.getAttribute('aria-checked')).catch(() => null) === 'true', 'after restart: still on, list visible');
  const d3 = await desk(page);
  ok((await caps(page, face, 'next')) === 'Ctrl Alt P' && d3.hk.map.next === 'Ctrl+Alt+P', 'after restart: custom combo kept');
  ok(await page.$eval(`${list(face)} [data-hk="show-hide"]`, (e) => e.getAttribute('data-status')).catch(() => null) === 'taken' && (await noteOf(page, face, 'show-hide')).length > 0, 'Ctrl+Alt+N owned by another app → "taken" warning');

  // ── 8. save fails → note, nothing changes
  await page.evaluate(() => window.__deskPatch({ hk: { saveFail: true } }));
  await page.click(keysBtn(face, 'stop')); await press(page, { code: 'KeyS', key: 's', ctrlKey: true, altKey: true }); await idle(page);
  ok((await desk(page)).hk.map.stop === '' && (await noteOf(page, face, 'stop')).length > 0, 'save fails → error note, combo not kept', [(await desk(page)).hk.map.stop, await noteOf(page, face, 'stop')]);
  await page.evaluate(() => window.__deskPatch({ hk: { saveFail: false } }));

  // ── 9. reset → defaults
  await page.click(`${list(face)} [data-hk-reset]`); await idle(page);
  const d4 = await desk(page);
  ok(d4.hk.map['play-pause'] === 'Ctrl+Alt+Space' && d4.hk.map.next === 'Ctrl+Alt+Right' && d4.hk.map['vol-up'] === 'Ctrl+Alt+Up', 'Reset → defaults back', d4.hk.map);
  ok(await page.$eval(`${list(face)} [data-hk-reset]`, (e) => e.disabled), 'Reset disabled when already default');

  // ── 10. off → list gone, main disabled
  await page.click(sw(face)); await idle(page);
  ok((await desk(page)).hk.enabled === false && await waitFor(page, (s) => !document.querySelector(s), list(face), 2000), 'switch off → main disables, list hidden');

  // ── 11. older main without hotkeys support → row disabled, says why
  await page.evaluate(() => window.__deskPatch({ hk: { supported: false } }));
  await page.reload(); await boot(page); await goSettings(page, face);
  await page.waitForSelector(row(face), { timeout: 8000 }).catch(() => {});
  const naTxt = await page.$eval(row(face), (e) => e.innerText).catch(() => '');
  ok(await page.$eval(row(face), (e) => e.hasAttribute('data-disabled')).catch(() => false) && (rtl ? /نسخه/.test(naTxt) : /updated desktop app/.test(naTxt)), 'unsupported main → row disabled, says why', naTxt.slice(0, 120));
  ok(errs.length === 0, 'no page errors', errs);
  await ctx.close();
}
await browser.close();
console.log(`\n${pass}/${pass + fail} passed`);
if (fails.length) console.log('FAILED:\n - ' + fails.join('\n - '));
