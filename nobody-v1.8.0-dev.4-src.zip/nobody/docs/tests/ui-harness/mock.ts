// mocked electronAPI over the test server's /rpc
const rpc = async (fn: string, ...args: any[]) => { const r = await (await fetch('/rpc', { method: 'POST', body: JSON.stringify({ fn, args }) })).json(); if (r.err) throw new Error(r.err); return r.r; };
const unb = (x: any) => x && x.__b64 ? Uint8Array.from(atob(x.__b64), c => c.charCodeAt(0)) : x;
const b64 = (u: Uint8Array) => { let s = ''; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode(...u.subarray(i, i + 0x8000)); return { __b64: btoa(s) }; };
(window as any).__keys = []; (window as any).__opened = []; (window as any).__trashCalls = []; (window as any).__calls = [];
// ── fake Last.fm + ListenBrainz behind the http:fetch proxy contract ({ ok, status, headers, bodyBase64 })
// __net: { offline?: bool, lfmApproved?: bool, lfmRevoked?: bool, lbRevoked?: bool, lfmIgnoreFirst?: bool }
(window as any).__net = {};
const enc = (o: any) => { const u = new TextEncoder().encode(typeof o === 'string' ? o : JSON.stringify(o)); let s = ''; for (const c of u) s += String.fromCharCode(c); return btoa(s); };
const reply = (status: number, body: any, headers: Record<string, string> = {}) => ({ ok: status >= 200 && status < 300, status, headers: { 'content-type': 'application/json', ...headers }, bodyBase64: enc(body) });
async function fakeNet(url: string, init: any) {
  const net = (window as any).__net; const u = new URL(url);
  const params = new URLSearchParams(init.method === 'POST' && u.host === 'ws.audioscrobbler.com' ? init.body || '' : u.search);
  const call = { host: u.host, path: u.pathname, method: init.method || 'GET', m: params.get('method'), body: init.body || '', auth: init.headers?.Authorization || '' };
  (window as any).__calls.push(call);
  await new Promise((r) => setTimeout(r, 40));
  if (net.offline) throw new Error('net::ERR_INTERNET_DISCONNECTED');
  if (u.host === 'ws.audioscrobbler.com') {
    const m = call.m;
    if (m === 'auth.getToken') return reply(200, { token: 'tok-' + Date.now() });
    if (m === 'auth.getSession') return net.lfmApproved ? reply(200, { session: { name: 'nobody_fan', key: 'sk-123', subscriber: 0 } }) : reply(403, { error: 14, message: 'Unauthorized Token - This token has not been authorized' });
    if (net.lfmRevoked) return reply(403, { error: 9, message: 'Invalid session key - Please re-authenticate' });
    if (m === 'track.updateNowPlaying') return reply(200, { nowplaying: { ignoredMessage: { code: '0' } } });
    if (m === 'track.scrobble') {
      const n = [...params.keys()].filter((k) => k.startsWith('artist[')).length; const list = [];
      for (let i = 0; i < n; i++) list.push({ ignoredMessage: { code: net.lfmIgnoreFirst && i === 0 ? '1' : '0', '#text': '' } });
      return reply(200, { scrobbles: { scrobble: n === 1 ? list[0] : list, '@attr': { accepted: n, ignored: 0 } } });
    }
    return reply(400, { error: 3, message: 'Invalid Method' });
  }
  if (u.host === 'api.listenbrainz.org') {
    const tok = String(call.auth).replace(/^Token /, '');
    if (u.pathname === '/1/validate-token') return tok === 'good-lb-token-1234' && !net.lbRevoked ? reply(200, { code: 200, message: 'Token valid.', valid: true, user_name: 'lb_listener' }) : reply(200, { code: 200, message: 'Token invalid.', valid: false });
    if (u.pathname === '/1/submit-listens') return net.lbRevoked ? reply(401, { code: 401, error: 'Invalid authorization token.' }) : reply(200, { status: 'ok' }, { 'X-RateLimit-Remaining': '30', 'X-RateLimit-Reset-In': '10' });
    return reply(404, { error: 'not found' });
  }
  return reply(403, { error: 'host not allowed' });
}
window.addEventListener('keydown', (e) => (window as any).__keys.push(e.key));
(window as any).electronAPI = {
  minimize() {}, maximize() {}, close() {}, toggleFullscreen: async () => false, getState: async () => ({ maximized: false, fullscreen: false }), onWindowState: () => () => {},
  enterCompact: async () => false, exitCompact: async () => false, pickFolders: async () => (window as any).__pick || [], pickFiles: async () => (window as any).__pickFiles || [],
  getPathForFile: (f: any) => f.path || '', stat: (p: string) => rpc('stat', p), readSlice: async (p: string, s: number, l: number) => unb(await rpc('readSlice', p, s, l)),
  readFile: async (p: string) => unb(await rpc('readFile', p)), writeTextFile: (p: string, t: string) => rpc('writeTextFile', p, t),
  writeBinaryFile: (p: string, b: Uint8Array) => rpc('writeBinaryFile', p, b64(b)), walk: (r: string, e: string[]) => rpc('walk', r, e),
  readTags: (p: string) => rpc('readTags', p), writeTags: (p: string, patch: any) => { if (patch?.cover?.data) patch = { ...patch, cover: { ...patch.cover, data: b64(patch.cover.data) } }; return rpc('writeTags', p, patch); },
  httpFetch: (url: string, init: any) => fakeNet(url, init || {}), openExternal: async (u: string) => { (window as any).__opened.push(u); return true; },
  // 1.7.0 scrobbling secrets (safeStorage in main) → server memory, survives reloads
  secretGet: (n: string) => rpc('secretGet', n), secretSet: (n: string, v: string) => rpc('secretSet', n, v), secretDelete: (n: string) => rpc('secretDelete', n),
  // 1.7.0 duplicate finder: fs:trash contract; paths in __trashFail answer E_BUSY
  trashFiles: async (paths: string[]) => { (window as any).__trashCalls.push(paths); const fail = new Set((window as any).__trashFail || []); const ok = paths.filter((p) => !fail.has(p)); const r: any[] = ok.length ? await rpc('trash', ok) : []; return paths.map((p) => fail.has(p) ? { path: p, ok: false, code: 'E_BUSY' } : r.find((x) => x.path === p)); },
  // 1.7.0-dev.9 M3U: same contract as electron/main.cjs playlist:* handlers
  pickPlaylistImport: async () => ((await rpc('pickPlaylistImport', (window as any).__pickM3U || [])) as any[]).map((x) => (x.bytes ? { ...x, bytes: unb(x.bytes) } : x)),
  pickPlaylistExport: async (name: string) => { (window as any).__exportName = name; return (window as any).__exportPath ?? null; },
  writePlaylist: (p: string, t: string) => rpc('writePlaylist', p, t),
  // 1.8.0 desktop integration: same contract as electron/main.cjs desk:* (state survives reloads via sessionStorage)
  deskReady: async () => { const d = deskState(); const out = d.pending || { files: [], playlists: [] }; for (const p of out.playlists || []) d.granted.push(p); d.pending = null; d.readyCalls++; saveDesk(d); return out; },
  onDeskOpen: (cb: any) => { (window as any).__deskOpen = (payload: any) => { const d = deskState(); for (const p of payload.playlists || []) d.granted.push(p); saveDesk(d); cb(payload); }; return () => {}; },
  deskReadPlaylist: async (p: string) => { if (!deskState().granted.includes(p)) return { path: p, error: 'E_DENIED' }; try { return { path: p, bytes: unb(await rpc('readFile', p)) }; } catch { return { path: p, error: 'E_READ' }; } },
  deskGetPrefs: async () => { const d = deskState(); return { ...d.prefs }; },
  deskSetPref: async (k: string, v: any) => { let d = deskState(); d.setCalls.push([k, v, Date.now()]); saveDesk(d); if (typeof v !== 'boolean') return { ok: false }; if (k === 'openWith' && !d.prefs.openWithSupported) return { ok: false, code: 'E_UNSUPPORTED', value: false }; await new Promise((r) => setTimeout(r, 120)); d = deskState(); if (k === 'openWith' && d.regFail) return { ok: false, value: d.prefs.openWith }; d.prefs[k] = v; saveDesk(d); return { ok: true, value: v }; },
  deskSetLabels: (l: any) => { const d = deskState(); d.labels.push(l); saveDesk(d); },
  deskNowPlaying: (np: any) => { const d = deskState(); d.np.push(np); if (d.np.length > 60) d.np = d.np.slice(-60); saveDesk(d); },
  // 1.8.0-dev.2 global hotkeys: same contract as main.cjs desk:get-hotkeys / set-hotkeys / hotkeys-suspend.
  // d.hk.taken = combos "another app" owns (register() → false); d.hk.supported=false = older main.
  deskGetHotkeys: async () => hkPayload(deskState().hk),
  deskSetHotkeys: async (patch: any) => {
    let d = deskState(); d.hk.calls.push(patch); saveDesk(d);
    if (!d.hk.supported) return { ok: false, code: 'E_UNSUPPORTED', ...hkPayload(d.hk) };
    if (!patch || typeof patch !== 'object') return { ok: false, code: 'E_INVALID', ...hkPayload(d.hk) };
    const next = { enabled: d.hk.enabled, map: { ...d.hk.map } };
    if ('enabled' in patch) { if (typeof patch.enabled !== 'boolean') return { ok: false, code: 'E_INVALID', ...hkPayload(d.hk) }; next.enabled = patch.enabled; }
    if ('map' in patch) for (const [a, v] of Object.entries(patch.map || {})) {
      if (!HK_ACTIONS.includes(a)) return { ok: false, code: 'E_INVALID', action: a, ...hkPayload(d.hk) };
      if (typeof v !== 'string' || (v && !HK_OK.test(v))) return { ok: false, code: 'E_INVALID', action: a, ...hkPayload(d.hk) };
      next.map[a] = v;
    }
    const seen = new Map(); for (const a of HK_ACTIONS) { const v = next.map[a]; if (!v) continue; if (seen.has(v)) return { ok: false, code: 'E_DUPLICATE', action: a, other: seen.get(v), ...hkPayload(d.hk) }; seen.set(v, a); }
    await new Promise((r) => setTimeout(r, 120));
    d = deskState(); if (d.hk.saveFail) return { ok: false, ...hkPayload(d.hk) };
    d.hk.enabled = next.enabled; d.hk.map = next.map; d.hk.suspended = false; saveDesk(d); return { ok: true, ...hkPayload(d.hk) };
  },
  deskHotkeysSuspend: async (on: any) => { const d = deskState(); d.hk.suspended = on === true; d.hk.suspendCalls.push(on === true); saveDesk(d); return hkPayload(d.hk); },
};
const HK_ACTIONS = ['play-pause', 'next', 'prev', 'stop', 'vol-up', 'vol-down', 'show-hide'];
const HK_DEFAULTS: any = { 'play-pause': 'Ctrl+Alt+Space', next: 'Ctrl+Alt+Right', prev: 'Ctrl+Alt+Left', stop: '', 'vol-up': 'Ctrl+Alt+Up', 'vol-down': 'Ctrl+Alt+Down', 'show-hide': 'Ctrl+Alt+N' };
const HK_OK = /^(?:(?:Ctrl|Alt|Shift|Super)\+)*[^+]+$/;
function hkDefault() { return { supported: true, enabled: false, map: { ...HK_DEFAULTS }, taken: [], suspended: false, saveFail: false, calls: [], suspendCalls: [] }; }
function hkPayload(h: any) {
  h = { ...hkDefault(), ...(h || {}) };
  const status: any = {};
  for (const a of HK_ACTIONS) { const v = h.map[a]; status[a] = !v ? 'unset' : (!h.enabled || h.suspended) ? 'off' : h.taken.includes(v) ? 'taken' : 'ok'; }
  return { enabled: h.enabled, map: { ...h.map }, status: h.supported ? status : {}, defaults: { ...HK_DEFAULTS }, actions: [...HK_ACTIONS], supported: !!h.supported };
}
function deskState() { try { const o = JSON.parse(sessionStorage.getItem('__desk') || 'null'); if (o) { if (!o.hk) o.hk = hkDefault(); return o; } } catch { /* fresh */ } return { pending: null, granted: [], prefs: { closeToTray: false, openWith: false, platform: 'win32', trayAvailable: true, openWithSupported: false }, setCalls: [], labels: [], np: [], readyCalls: 0, regFail: false, hk: hkDefault() }; }
function saveDesk(d: any) { sessionStorage.setItem('__desk', JSON.stringify(d)); }
(window as any).__desk = () => deskState(); (window as any).__deskPatch = (p: any) => { const d = deskState(); Object.assign(d, p); if (p.prefs) d.prefs = { ...deskState().prefs, ...p.prefs }; if (p.hk) d.hk = { ...(deskState().hk || hkDefault()), ...p.hk }; saveDesk(d); };
