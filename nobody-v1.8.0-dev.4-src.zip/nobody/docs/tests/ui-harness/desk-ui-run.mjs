// NOBODY 1.8.0 · desktop integration, Chromium UI run (Classic / Cinema / EELA / ALOK, EN + FA)
// The desk:* main-process contract is mocked in mock.ts (state in sessionStorage, survives reloads).
// Fixtures: fixtures-m3u.sh (t-m3u: 7 songs in lib/Album, 2 outside the library, lists/road.m3u8).
import { chromium } from '/opt/sd-artifact/node_modules/playwright/index.mjs';
const T = '/home/user/work/t-m3u'; const LIB = T + '/lib/Album';
const ROOT = { classic: '[data-ui-pane="classic"]', cinema: '#nc-root', eela: '#ne-root', alok: '#na-root' };
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, x) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, x !== undefined ? JSON.stringify(x) : ''); } };
const browser = await chromium.launch({ executablePath: '/ms-playwright/chromium-1208/chrome-linux64/chrome', args: ['--autoplay-policy=no-user-gesture-required'] });
const faces = (process.env.FACES || 'classic,cinema,eela,alok').split(','); const langs = (process.env.LANGS || 'en,fa').split(',');
const PERSIAN = /[\u0600-\u06FF]/; const RAW = /\bdk[A-Z]\w+\b|\{\{\w+\}\}/;
const waitFor = async (page, fn, arg, ms = 8000) => { try { await page.waitForFunction(fn, arg, { timeout: ms }); return true; } catch { return false; } };
const desk = (page) => page.evaluate(() => window.__desk());
// Classic's own library is the truth there (the mirror only fills when something hydrates it)
const count = (page) => page.evaluate(() => { const T = window.__T; return localStorage.getItem('nobody-ui-mode') === 'classic' ? (T.getBridge()?.listTracks().length ?? 0) : Object.keys(T.useLibrary.getState().tracks).length; });
/** what is playing: Classic through the bridge, the engine faces through the engine */
const now = (page, face) => page.evaluate((face) => {
  const T = window.__T; const L = T.useLibrary.getState().tracks;
  if (face === 'classic') { const h = T.getBridge().captureHandoff(); return { title: L[h.trackId]?.title || null, playing: h.isPlaying, engine: T.engine.currentId }; }
  return { title: L[T.engine.currentId]?.title || null, playing: T.useUi.getState().isPlaying, queue: T.engine.queue.map((id) => L[id]?.title) };
}, face);
const toasts = (page) => page.evaluate(() => window.__T.useUi.getState().toasts.map((t) => [t.msg, t.kind]));
const clearToasts = (page) => page.evaluate(() => window.__T.useUi.setState({ toasts: [] }));
const goSettings = async (page, face) => {
  if (face === 'classic') { await page.click('.settings-nav'); return; }
  await page.evaluate((face) => { const T = window.__T; if (face === 'cinema') T.useUi.getState().setView('settings'); else if (face === 'eela') T.useEelaUi.getState().setView('settings'); else { const s = T.useAlokUi.getState(); if (s.view !== 'settings') s.toggleView('settings'); } }, face);
};
const row = (face, id) => `${ROOT[face]} [data-desk-row="${id}"]`;
const sw = (face, id) => `${row(face, id)} [role="switch"]`;
const checked = (page, face, id) => page.$eval(sw(face, id), (e) => e.getAttribute('aria-checked') === 'true').catch(() => null);
const boot = async (page) => { await page.waitForFunction(() => { const T = window.__T; if (!T) return false; const b = T.getBridge(); return Math.max(Object.keys(T.useLibrary.getState().tracks).length, b ? b.listTracks().length : 0) >= 7; }, null, { timeout: 25000 }); };

for (const face of faces) for (const lang of langs) {
  console.log(`\n■ ${face} · ${lang}`);
  const rtl = lang === 'fa';
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 820 } }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(String(e).slice(0, 300)));
  await page.addInitScript(([lib, face, lang, T]) => {
    if (sessionStorage.getItem('seeded')) return;
    localStorage.clear(); indexedDB.deleteDatabase('nobody-stats');
    localStorage.setItem('nobody-player-state-v2', JSON.stringify({ folderPaths: [lib], lang })); localStorage.setItem('nobody-ui-mode', face);
    // launched by double-clicking two songs: one outside the library, one inside
    sessionStorage.setItem('__desk', JSON.stringify({ pending: { files: [T + '/outside/Outside A.mp3', T + '/lib/Album/03 Three.mp3'], playlists: [] }, granted: [], prefs: { closeToTray: false, openWith: false, platform: 'win32', trayAvailable: true, openWithSupported: false }, setCalls: [], labels: [], np: [], readyCalls: 0, regFail: false }));
    sessionStorage.setItem('seeded', '1');
  }, [LIB, face, lang, T]);
  await page.goto('http://127.0.0.1:8787/');
  await boot(page);
  await page.evaluate((lang) => window.__T.useSettings.getState().set('lang', lang), lang);

  // ── 1. files opened before the UI existed
  ok(await waitFor(page, () => Object.keys(window.__T.useLibrary.getState().tracks).length === 8, null, 12000), 'launch files: the outside song joined the library (7 → 8)', await count(page));
  ok(await waitFor(page, (face) => { const T = window.__T; const L = T.useLibrary.getState().tracks; const id = face === 'classic' ? T.getBridge().captureHandoff().trackId : T.engine.currentId; return L[id]?.title === 'Outside A'; }, face, 8000), 'first opened song plays (Outside A)', await now(page, face));
  let n = await now(page, face);
  if (face === 'classic') ok(n.engine === null, 'Classic plays it itself (engine stays silent)', n);
  else ok(n.queue?.join() === 'Outside A,Three', 'queue = the opened songs in order', n.queue);
  const d0 = await desk(page);
  ok(d0.readyCalls === 1 && d0.pending === null, 'desk:ready asked once, pending handed over');
  if (face !== 'classic') { const ts = await toasts(page); ok(ts.some(([m, k]) => k === 'success' && /2|۲/.test(m) && (!rtl || PERSIAN.test(m)) && !RAW.test(m)), 'toast: playing 2 opened songs', ts); }

  // ── 2. labels + now playing for the tray / thumbar / taskbar
  ok(await waitFor(page, (rtl) => { const l = window.__desk().labels.at(-1); return !!l && (rtl ? l.play === 'پخش' && l.quit === 'خروج از NOBODY' : l.play === 'Play' && l.quit === 'Quit NOBODY'); }, rtl, 3000), `tray labels sent in ${lang}`, (await desk(page)).labels.at(-1));
  ok(await waitFor(page, () => { const np = window.__desk().np.at(-1); return np && np.title === 'Outside A' && np.artist === 'Delta' && np.playing === true; }, null, 4000), 'now playing → main (Outside A — Delta, playing)', (await desk(page)).np.at(-1));
  await page.evaluate((face) => face === 'classic' ? window.__T.getBridge().pause() : window.__T.engine.pause(), face);
  ok(await waitFor(page, () => window.__desk().np.at(-1)?.playing === false, null, 4000), 'pause → playing false (⏯ shows Play)', (await desk(page)).np.at(-1));

  // ── 3. a playlist opened while running
  await clearToasts(page);
  await page.evaluate((T) => window.__deskOpen({ files: [], playlists: [T + '/lists/road.m3u8'] }), T);
  ok(await waitFor(page, () => window.__T.useLibrary.getState().playlists.some((p) => p.name === 'Road trip'), null, 10000), 'road.m3u8 → playlist "Road trip"');
  ok(await waitFor(page, (face) => { const T = window.__T; const L = T.useLibrary.getState().tracks; const id = face === 'classic' ? T.getBridge().captureHandoff().trackId : T.engine.currentId; return L[id]?.title === 'One'; }, face, 6000), 'its first song plays (One)', await now(page, face));
  const nAfterList = await count(page);
  ok(nAfterList === 9, 'its outside song (Outside B) joined the library too', nAfterList);
  ok((await toasts(page)).some(([m, k]) => k === 'success' && /Road trip/.test(m)), 'toast: playlist imported');
  const denied = await page.evaluate((T) => window.electronAPI.deskReadPlaylist(T + '/lists/fa.m3u'), T);
  ok(denied.error === 'E_DENIED', 'a playlist that was not opened can\'t be read');

  // ── 4. a song already in the library / a missing file
  await page.evaluate((T) => window.__deskOpen({ files: [T + '/lib/Album/05 Five.mp3'], playlists: [] }), T);
  ok(await waitFor(page, (face) => { const T = window.__T; const L = T.useLibrary.getState().tracks; const id = face === 'classic' ? T.getBridge().captureHandoff().trackId : T.engine.currentId; return L[id]?.title === 'Five'; }, face, 6000) && await count(page) === nAfterList, 'song already in the library → plays it, no duplicate row', [await now(page, face), await count(page)]);
  await clearToasts(page);
  await page.evaluate(() => window.__deskOpen({ files: ['/nowhere/ghost.mp3'], playlists: [] }));
  ok(await waitFor(page, () => window.__T.useUi.getState().toasts.some((t) => t.kind === 'error'), null, 6000), 'missing file → error toast, nothing else changes');
  n = await now(page, face); ok(n.title === 'Five', 'still on Five', n);

  // ── 5. Settings rows
  await goSettings(page, face); await page.waitForSelector(row(face, 'openwith'), { timeout: 8000 }).catch(() => {});
  ok(!!(await page.$(row(face, 'tray'))) && !!(await page.$(row(face, 'openwith'))), 'Settings: tray + "Open with" rows');
  const txt = await page.$eval(row(face, 'tray'), (e) => e.innerText).catch(() => '');
  ok(!RAW.test(txt) && (!rtl || PERSIAN.test(txt)), 'rows localized', txt.slice(0, 80));
  ok(await checked(page, face, 'tray') === false, 'tray: off by default');
  await page.click(sw(face, 'tray'));
  ok(await waitFor(page, () => window.__desk().setCalls.some((c) => c[0] === 'closeToTray' && c[1] === true), null, 3000) && await waitFor(page, (s) => document.querySelector(s)?.getAttribute('aria-checked') === 'true', sw(face, 'tray'), 3000), 'tray on → saved in main, switch on');
  const owTxt = await page.$eval(row(face, 'openwith'), (e) => e.innerText).catch(() => '');
  ok(await page.$eval(row(face, 'openwith'), (e) => e.hasAttribute('data-disabled')) && (rtl ? /نسخه/.test(owTxt) : /installed Windows app/.test(owTxt)), '"Open with": not available in a dev run (says why)', owTxt.slice(0, 120));
  await page.$eval(sw(face, 'openwith'), (e) => e.click()); await page.waitForTimeout(250); // DOM click: a disabled <button> must simply ignore it
  ok(!(await desk(page)).setCalls.some((c) => c[0] === 'openWith'), '…and its switch does nothing');

  // ── 6. restart: opened songs stay, nothing re-opened, prefs back
  await page.evaluate(() => window.__deskPatch({ prefs: { openWithSupported: true }, regFail: true }));
  await page.reload(); await boot(page); await page.waitForFunction((n) => { const T = window.__T; return Math.max(Object.keys(T.useLibrary.getState().tracks).length, T.getBridge()?.listTracks().length ?? 0) >= n; }, nAfterList, { timeout: 8000 }).catch(() => {}); await page.waitForTimeout(1200);
  ok(await count(page) === nAfterList, 'after restart: opened songs are still in the library, nothing imported twice', await count(page));
  ok((await desk(page)).readyCalls === 2, 'desk:ready asked again (nothing pending)');
  await goSettings(page, face); await page.waitForSelector(row(face, 'openwith'), { timeout: 8000 }).catch(() => {});
  await waitFor(page, () => window.__T.useDesktopPrefs.getState().loaded, null, 3000);
  ok(await checked(page, face, 'tray') === true, 'after restart: tray switch still on');
  await page.click(sw(face, 'openwith'));
  ok(await waitFor(page, (s) => document.querySelector(s)?.getAttribute('aria-checked') === 'false', sw(face, 'openwith'), 3000) && await waitFor(page, ([s, rtl]) => (rtl ? /به‌روز نشد/ : /Couldn’t update/).test(document.querySelector(s)?.innerText || ''), [row(face, 'openwith'), rtl], 3000), 'registry write fails → switch back off, error shown');
  await page.evaluate(() => window.__deskPatch({ regFail: false }));
  await page.click(sw(face, 'openwith'));
  // the switch flips optimistically; wait for main's answer (busy → null) before reading the mock state
  ok(await waitFor(page, (s) => document.querySelector(s)?.getAttribute('aria-checked') === 'true', sw(face, 'openwith'), 3000) && await waitFor(page, () => window.__T.useDesktopPrefs.getState().busy === null && window.__desk().prefs.openWith === true, null, 3000) && await checked(page, face, 'openwith') === true, 'registry write ok → "Open with" on', [await desk(page).then(d => [d.setCalls, d.prefs, d.regFail]), await checked(page, face, 'openwith'), await page.evaluate(() => { const s = window.__T.useDesktopPrefs.getState(); return [s.openWith, s.busy, s.error]; })]);
  ok(errs.length === 0, 'no page errors', errs);
  await ctx.close();
}
await browser.close();
console.log(`\n${pass}/${pass + fail} passed`);
if (fails.length) console.log('FAILED:\n - ' + fails.join('\n - '));
