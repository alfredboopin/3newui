// NOBODY 1.7.0 · Scrobbling sheet, Chromium UI run (Cinema / EELA / ALOK, EN + FA/RTL)
// Fake Last.fm + ListenBrainz behind the http:fetch proxy (mock.ts fakeNet), secrets in the
// server (safeStorage stand-in). Listens are fed straight into the scrobbler (the >30 s / 50 %
// rule itself is covered by scrobble-run.ts + stats-run.ts).
import { chromium } from '/opt/sd-artifact/node_modules/playwright/index.mjs';
const LIB = process.env.LIB || '/home/user/work/t/lib/Album';
const ROOT = { cinema: '#nc-root', eela: '#ne-root', alok: '#na-root' };
const SH = '[data-scrobble-sheet]';
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, extra) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, extra !== undefined ? JSON.stringify(extra) : ''); } };
const browser = await chromium.launch({ executablePath: '/ms-playwright/chromium-1208/chrome-linux64/chrome', args: ['--autoplay-policy=no-user-gesture-required'] });
const faces = (process.env.FACES || 'cinema,eela,alok').split(','); const langs = (process.env.LANGS || 'en,fa').split(',');
const latin = (s) => String(s || '').replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[٬,\s]/g, '');
const rpc = (page, fn, ...args) => page.evaluate(async ([fn, args]) => (await (await fetch('/rpc', { method: 'POST', body: JSON.stringify({ fn, args }) })).json()).r, [fn, args]);
const RAW_KEY = /\b(sc|dp|ls|st|m3u)[A-Z][A-Za-z_]+\b|\{\{\w+\}\}/;
const PERSIAN = /[\u0600-\u06FF]/;
const HEX = (c) => c.repeat(32);

const goSettings = (page, face) => page.evaluate((face) => {
  const T = window.__T; if (face === 'cinema') T.useUi.getState().setView('settings'); else if (face === 'eela') T.useEelaUi.getState().setView('settings'); else { const s = T.useAlokUi.getState(); if (s.view !== 'settings') s.toggleView('settings'); }
}, face);
const goPlaylists = (page, face) => page.evaluate((face) => {
  const T = window.__T; if (face === 'cinema') T.useUi.getState().setView('playlists'); else if (face === 'eela') T.useEelaUi.getState().setView('playlists'); else { const s = T.useAlokUi.getState(); if (s.view !== 'playlists') s.toggleView('playlists'); }
}, face);
const card = (id) => `${SH} [data-sc-service="${id}"]`;
const status = (page, id) => page.$eval(card(id), (e) => e.getAttribute('data-sc-status')).catch(() => null);
const stat = (page, id, k) => page.$eval(`${card(id)} [data-sc-stat="${k}"] dd`, (e) => e.textContent).then(latin).catch(() => null);
const S = (page) => page.evaluate(() => { const s = window.__T.getScrobbler(); return { lf: { ...s.state.lastfm, pending: s.pending('lastfm'), c: s.connected('lastfm') }, lb: { ...s.state.listenbrainz, pending: s.pending('listenbrainz'), c: s.connected('listenbrainz') } }; });
const waitFor = async (page, fn, arg, ms = 8000) => { try { await page.waitForFunction(fn, arg, { timeout: ms }); return true; } catch { return false; } };
const toasts = (page) => page.evaluate(() => window.__T.useUi.getState().toasts.map(t => [t.msg, t.sub || '', t.kind]));
const clearToasts = (page) => page.evaluate(() => window.__T.useUi.setState({ toasts: [] }));
let nListen = 0;
const listen = (page, title) => page.evaluate(([title, n]) => {
  const T = window.__T; const tr = Object.values(T.useLibrary.getState().tracks).find((x) => x.title === title);
  T.getScrobbler().onListenClosed({ at: Date.now() - 300000 + n * 1000, id: tr.id, ms: 200000, dur: 240, title: tr.title, artist: tr.artist, album: tr.album, full: true, skip: false, src: 'engine' });
}, [title, nListen++]);
const calls = (page, pred) => page.evaluate((p) => window.__calls.filter(new Function('c', `return ${p}`)).length, pred);
const net = (page, patch) => page.evaluate((p) => Object.assign(window.__net, p), patch);
const inSheet = (page) => page.evaluate((s) => !!document.querySelector(s)?.contains(document.activeElement), SH);
const overflow = (page) => page.$eval(SH, (el) => { const b = el.querySelector('.nte-body'); const r = el.getBoundingClientRect(); return { sw: b.scrollWidth, cw: b.clientWidth, l: r.left, r: r.right, vw: innerWidth }; });
const openFromSettings = async (page, root) => { await page.click(`${root} [data-scrobble-open]`); return !!(await page.waitForSelector(SH, { timeout: 4000 }).catch(() => null)); };

for (const face of faces) for (const lang of langs) {
  console.log(`\n■ ${face} · ${lang}`);
  const rtl = lang === 'fa'; const root = ROOT[face];
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 820 }, permissions: ['clipboard-read', 'clipboard-write'] }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 300)));
  await page.addInitScript(([lib, face, lang]) => { if (!sessionStorage.getItem('seeded')) { localStorage.clear(); indexedDB.deleteDatabase('nobody-stats'); localStorage.setItem('nobody-player-state-v2', JSON.stringify({ folderPaths: [lib], lang })); localStorage.setItem('nobody-ui-mode', face); sessionStorage.setItem('seeded', '1'); } }, [LIB, face, lang]);
  await page.goto('http://127.0.0.1:8787/');
  await rpc(page, '__secretReset');
  await page.waitForFunction(() => window.__T && Object.keys(window.__T.useLibrary.getState().tracks).length >= 6, null, { timeout: 25000 });
  await page.evaluate((lang) => window.__T.useSettings.getState().set('lang', lang), lang);
  await page.waitForTimeout(500);

  // ── 1. entry in Settings, live summary
  await goSettings(page, face); await page.waitForTimeout(500);
  ok(!!(await page.waitForSelector(`${root} [data-scrobble-open]`, { timeout: 4000 }).catch(() => null)), 'Scrobbling entry in Settings');
  const row0 = await page.evaluate((r) => document.querySelector(`${r} [data-scrobble-open]`)?.closest('[data-scrobble-row], .ne-row, div')?.parentElement?.innerText || '', root);
  ok(!RAW_KEY.test(row0) && (!rtl || PERSIAN.test(row0)), 'Settings row localized', row0.slice(0, 120));

  // ── 2. open, focus, direction, no raw keys
  ok(await openFromSettings(page, root), 'sheet opens from Settings');
  ok(await page.evaluate(([r, s]) => !!document.querySelector(r)?.contains(document.querySelector(s)), [root, SH]), 'sheet mounted inside the face root');
  ok((await page.$eval(SH, e => getComputedStyle(e).direction)) === (rtl ? 'rtl' : 'ltr'), `direction ${rtl ? 'rtl' : 'ltr'}`);
  const txt0 = await page.$eval(SH, e => e.innerText);
  ok(!RAW_KEY.test(txt0), 'no raw i18n keys / {{placeholders}}', (txt0.match(RAW_KEY) || [])[0]);
  ok(!rtl || PERSIAN.test(await page.$eval(`${SH} .nte-title`, e => e.textContent)), 'title in Persian (fa)');
  ok(await status(page, 'lastfm') === 'off' && await status(page, 'listenbrainz') === 'off', 'both services: not connected');
  ok(!!(await page.$(`${SH} [data-sc-keys]`)), 'no build key → Last.fm asks for your own API account');
  ok(await page.evaluate(() => document.activeElement?.hasAttribute('data-sc-apikey')), 'focus on the API key field');

  // ── 3. own API key: keys never reach the face; invalid → error; valid → Connect
  await page.evaluate(() => { window.__keys = []; });
  await page.fill(`${SH} [data-sc-apikey]`, 'not-a-key'); await page.fill(`${SH} [data-sc-secret]`, 'nope');
  await page.keyboard.type(' x');
  ok((await page.evaluate(() => window.__keys.length)) === 0, 'typing in the sheet never reaches the face shortcuts');
  await page.click(`${SH} [data-sc-savekeys]`); await page.waitForTimeout(150);
  ok(!!(await page.$(`${SH} [data-sc-key-err]`)), 'invalid key → error shown');
  await page.click(`${SH} [data-sc-create-api]`); await page.waitForTimeout(100);
  ok((await page.evaluate(() => window.__opened.at(-1))) === 'https://www.last.fm/api/account/create', '"Create an API account" opens last.fm');
  await page.fill(`${SH} [data-sc-apikey]`, HEX('a')); await page.fill(`${SH} [data-sc-secret]`, HEX('b'));
  await page.press(`${SH} [data-sc-secret]`, 'Enter'); await page.waitForTimeout(250);
  ok(!!(await page.$(`${SH} [data-sc-connect="lastfm"]`)) && !!(await page.$(`${SH} [data-sc-removekeys]`)), 'Enter saves the key → Connect + Remove key');
  const sec = await rpc(page, '__secrets');
  ok(sec['scrobble.lastfm.secret'] === HEX('b') && !JSON.stringify(await page.evaluate(() => ({ ...localStorage }))).includes(HEX('b')), 'secret goes to the OS store, never localStorage');

  // ── 4. Last.fm browser auth: waiting UI, open again, copy, cancel, approve
  await page.click(`${SH} [data-sc-connect="lastfm"]`);
  ok(!!(await page.waitForSelector(`${SH} [data-sc-authorizing]`, { timeout: 3000 }).catch(() => null)), 'waiting-for-approval panel');
  const authUrl = await page.evaluate(() => window.__opened.at(-1));
  ok(/^https:\/\/www\.last\.fm\/api\/auth\/\?api_key=a{32}&token=tok-\d+$/.test(authUrl || ''), 'browser opened on the Last.fm auth page', authUrl);
  await page.click(`${SH} [data-sc-reopen]`); await page.waitForTimeout(100);
  ok((await page.evaluate(() => window.__opened.at(-1))) === authUrl, '"Open again" reopens the same page');
  await clearToasts(page);
  await page.click(`${SH} [data-sc-copy]`); await page.waitForTimeout(200);
  const clip = await page.evaluate(() => navigator.clipboard.readText().catch(() => ''));
  ok(clip === authUrl && (await toasts(page)).some(t => t[2] === 'success'), '"Copy link" copies the URL + toast', clip);
  await page.click(`${SH} [data-sc-cancel-auth]`); await page.waitForTimeout(200);
  ok(!(await page.$(`${SH} [data-sc-authorizing]`)) && !!(await page.$(`${SH} [data-sc-connect="lastfm"]`)), 'Cancel → back to Connect');
  await page.waitForTimeout(3300);
  ok((await S(page)).lf.c === false && !(await page.$(`${SH} [data-sc-msg]`)), 'cancelled run never connects, no error shown');
  await clearToasts(page);
  await page.click(`${SH} [data-sc-connect="lastfm"]`);
  await page.waitForSelector(`${SH} [data-sc-authorizing]`, { timeout: 3000 }).catch(() => {});
  await page.waitForTimeout(3400);
  ok((await S(page)).lf.c === false && !!(await page.$(`${SH} [data-sc-authorizing]`)), 'not approved yet → keeps waiting (polls)');
  await net(page, { lfmApproved: true });
  ok(await waitFor(page, (c) => document.querySelector(c)?.getAttribute('data-sc-status') === 'on', card('lastfm'), 6000), 'approved → Connected');
  ok((await page.$eval(`${card('lastfm')} [data-sc-user]`, e => e.textContent)) === 'nobody_fan', 'account name shown');
  ok(!!(await page.$(`${card('lastfm')} [data-sc-own]`)), '"own API key" badge');
  ok((await toasts(page)).some(t => t[2] === 'success' && /nobody_fan/.test(t[0]) && !RAW_KEY.test(t[0])), 'connected toast', await toasts(page));
  ok((await rpc(page, '__secrets'))['scrobble.lastfm.session'] === 'sk-123', 'session key stored in the OS store');

  // ── 5. ListenBrainz: token page, bad token, good token
  await page.click(`${SH} [data-sc-lb-page]`); await page.waitForTimeout(100);
  ok((await page.evaluate(() => window.__opened.at(-1))) === 'https://listenbrainz.org/settings/', '"Get your token" opens ListenBrainz settings');
  ok(await page.$eval(`${SH} [data-sc-connect="listenbrainz"]`, e => e.disabled), 'Connect disabled with an empty token');
  await page.fill(`${SH} [data-sc-token]`, 'wrong-token-0000'); await page.press(`${SH} [data-sc-token]`, 'Enter');
  ok(!!(await page.waitForSelector(`${card('listenbrainz')} [data-sc-msg]`, { timeout: 3000 }).catch(() => null)), 'bad token → error message');
  const lbErr = await page.$eval(`${card('listenbrainz')} [data-sc-msg]`, e => e.textContent);
  ok(!RAW_KEY.test(lbErr) && /ListenBrainz/.test(lbErr) && (!rtl || PERSIAN.test(lbErr)), 'error text localized', lbErr);
  await page.fill(`${SH} [data-sc-token]`, 'good-lb-token-1234');
  ok(!(await page.$(`${card('listenbrainz')} [data-sc-msg]`)), 'error clears while typing');
  await page.click(`${SH} [data-sc-connect="listenbrainz"]`);
  ok(await waitFor(page, (c) => document.querySelector(c)?.getAttribute('data-sc-status') === 'on', card('listenbrainz'), 4000), 'good token → Connected');
  ok((await page.$eval(`${card('listenbrainz')} [data-sc-user]`, e => e.textContent)) === 'lb_listener', 'LB user name shown');

  // ── 6. a listen → sent to both
  await page.evaluate(() => { window.__calls = []; });
  await listen(page, 'Glass');
  ok(await waitFor(page, () => { const s = window.__T.getScrobbler(); return s.state.lastfm.sent === 1 && s.state.listenbrainz.sent === 1; }, null, 6000), 'listen scrobbled to Last.fm and ListenBrainz');
  ok(await calls(page, "c.m === 'track.scrobble' && c.method === 'POST' && /api_sig=[0-9a-f]{32}/.test(c.body)") === 1 && await calls(page, "c.path === '/1/submit-listens' && /\"single\"/.test(c.body) && /Glass/.test(c.body)") === 1, 'one signed Last.fm batch + one LB "single"');
  await page.waitForTimeout(200);
  ok(await stat(page, 'lastfm', 'sent') === '1' && await stat(page, 'listenbrainz', 'sent') === '1' && await stat(page, 'lastfm', 'pending') === '0', 'cards: sent 1, pending 0');
  ok((await stat(page, 'lastfm', 'last')) !== '—', 'last sent time shown');
  ok(await page.$eval(`${card('lastfm')} [data-sc-send]`, e => e.disabled), '"Send now" disabled with nothing pending');

  // ── 7. offline: queued, note with next retry time, Send now after reconnecting
  await net(page, { offline: true });
  await listen(page, 'Kooch');
  ok(await waitFor(page, (c) => document.querySelector(c)?.getAttribute('data-sc-status') === 'offline', card('lastfm'), 6000), 'offline → status Offline');
  const off = await page.$eval(`${card('lastfm')} [data-sc-offline-note]`, e => e.textContent).catch(() => '');
  ok(/\d|[۰-۹]/.test(off) && !RAW_KEY.test(off) && (!rtl || PERSIAN.test(off)), 'offline note says when it retries', off);
  ok(await stat(page, 'lastfm', 'pending') === '1' && await stat(page, 'listenbrainz', 'pending') === '1', 'listen kept in both queues');
  ok(!(await page.$eval(`${card('lastfm')} [data-sc-send]`, e => e.disabled)), '"Send now" enabled');
  await net(page, { offline: false });
  await page.click(`${card('lastfm')} [data-sc-send]`);
  ok(await waitFor(page, () => window.__T.getScrobbler().state.lastfm.sent === 2, null, 4000), 'Send now → delivered');
  ok(await waitFor(page, (c) => document.querySelector(c)?.getAttribute('data-sc-status') === 'on', card('lastfm'), 3000), 'status back to Connected');
  await page.click(`${card('listenbrainz')} [data-sc-send]`);
  ok(await waitFor(page, () => window.__T.getScrobbler().pending('listenbrainz') === 0, null, 4000), 'LB queue drained too');

  // ── 8. switches: scrobbling off → paused, now-playing disabled, not queued
  await page.click(`${SH} [data-sc-switch="lastfm-enabled"]`); await page.waitForTimeout(150);
  ok(await status(page, 'lastfm') === 'paused' && await page.$eval(`${SH} [data-sc-switch="lastfm-np"]`, e => e.disabled) && (await page.$eval(`${SH} [data-sc-switch="lastfm-enabled"]`, e => e.getAttribute('aria-checked'))) === 'false', 'scrobbling off → Paused, now-playing switch disabled');
  await listen(page, 'Old Tape'); await page.waitForTimeout(300);
  let st = await S(page);
  ok(st.lf.pending === 0 && (st.lb.pending === 1 || st.lb.sent === 3), 'paused service does not queue; the other one does', st);
  await page.click(`${SH} [data-sc-switch="lastfm-np"]`, { force: true }).catch(() => {});
  await page.click(`${SH} [data-sc-switch="lastfm-enabled"]`); await page.waitForTimeout(150);
  ok(await status(page, 'lastfm') === 'on', 'back on');
  await page.click(`${SH} [data-sc-switch="lastfm-np"]`); await page.waitForTimeout(100);
  ok((await S(page)).lf.nowPlaying === false, 'now-playing switch off');
  await page.click(`${SH} [data-sc-switch="lastfm-np"]`);
  // now playing goes out when a song really plays
  await page.evaluate(() => { window.__calls = []; const T = window.__T; const tr = Object.values(T.useLibrary.getState().tracks)[0]; T.getScrobbler().onNowPlaying(tr.id, { title: tr.title, artist: tr.artist, album: tr.album, duration: 6 }); });
  await page.waitForTimeout(300);
  ok(await calls(page, "c.m === 'track.updateNowPlaying'") === 1 && await calls(page, "/playing_now/.test(c.body)") === 1, '"now playing" sent to both');

  // ── 9. access revoked: reconnect note, queue kept, reconnect with a token
  await waitFor(page, () => window.__T.getScrobbler().pending('listenbrainz') === 0, null, 4000);
  await net(page, { lbRevoked: true });
  await listen(page, 'Night Bus');
  ok(await waitFor(page, (c) => document.querySelector(c)?.getAttribute('data-sc-status') === 'auth', card('listenbrainz'), 5000), 'revoked token → "Reconnect" status');
  ok(!!(await page.$(`${card('listenbrainz')} [data-sc-auth-note]`)) && !!(await page.$(`${card('listenbrainz')} [data-sc-reconnect]`)), 'auth note + Reconnect button');
  ok(await stat(page, 'listenbrainz', 'pending') === '1', 'queue kept (not cleared)');
  await goSettings(page, face);
  ok(await page.evaluate(() => !!document.querySelector('[data-scrobble-sheet]')), 'sheet stays open over the view');
  await page.click(`${card('listenbrainz')} [data-sc-reconnect]`);
  ok(!!(await page.waitForSelector(`${card('listenbrainz')} [data-sc-token]`, { timeout: 2000 }).catch(() => null)), 'Reconnect → token form');
  await net(page, { lbRevoked: false });
  await page.fill(`${card('listenbrainz')} [data-sc-token]`, 'good-lb-token-1234'); await page.press(`${card('listenbrainz')} [data-sc-token]`, 'Enter');
  ok(await waitFor(page, () => { const s = window.__T.getScrobbler(); return !s.state.listenbrainz.needsAuth && s.pending('listenbrainz') === 0; }, null, 5000), 'reconnected → the kept listen is sent');

  // ── 10. disconnect: confirm warns about unsent plays, Esc backs out
  await net(page, { offline: true });
  await listen(page, 'Paper Moon');
  await waitFor(page, () => window.__T.getScrobbler().pending('lastfm') === 1, null, 4000);
  await page.click(`${card('lastfm')} [data-sc-disconnect]`); await page.waitForTimeout(120);
  const ask = await page.$eval(`${card('lastfm')} [data-sc-ask]`, e => e.innerText).catch(() => '');
  ok(/1|۱/.test(ask) && !RAW_KEY.test(ask) && (!rtl || PERSIAN.test(ask)), 'confirm warns about 1 unsent play', ask);
  ok(await page.evaluate(() => document.activeElement?.closest('[data-sc-ask]') != null), 'focus on Cancel inside the confirm', await page.evaluate(() => [document.activeElement?.outerHTML.slice(0, 90), !!document.querySelector('[data-sc-ask]'), !!document.querySelector('[data-scrobble-sheet]')]));
  await page.keyboard.press('Escape'); await page.waitForTimeout(150);
  ok(!(await page.$(`${card('lastfm')} [data-sc-ask]`)) && !!(await page.$(SH)), 'Esc backs out of the confirm, sheet stays', [!!(await page.$(`${card('lastfm')} [data-sc-ask]`)), !!(await page.$(SH))]);
  await page.click(`${card('lastfm')} [data-sc-disconnect]`);
  await page.click(`${card('lastfm')} [data-sc-disconnect-yes]`); await page.waitForTimeout(250);
  st = await S(page);
  ok(!st.lf.c && st.lf.pending === 0 && await status(page, 'lastfm') === 'off', 'disconnected, Last.fm queue dropped');
  ok(!('scrobble.lastfm.session' in (await rpc(page, '__secrets'))), 'session key deleted');
  ok(st.lb.c && st.lb.pending === 1, 'ListenBrainz untouched (still connected, its queue kept)');
  ok(!!(await page.$(`${SH} [data-sc-connect="lastfm"]`)), 'Connect shown again (own key kept)');
  await page.click(`${SH} [data-sc-removekeys]`); await page.waitForTimeout(200);
  ok(!!(await page.$(`${SH} [data-sc-keys]`)) && !('scrobble.lastfm.secret' in (await rpc(page, '__secrets'))), 'Remove key → back to the key form, secret deleted');
  await net(page, { offline: false });

  // ── 11. layout + keyboard
  const o1 = await overflow(page);
  ok(o1.sw <= o1.cw + 1 && o1.l >= -1 && o1.r <= o1.vw + 1, 'no horizontal overflow at 1280 px', o1);
  await page.setViewportSize({ width: 520, height: 820 }); await page.waitForTimeout(250);
  const o2 = await overflow(page);
  ok(o2.sw <= o2.cw + 1 && o2.l >= -1 && o2.r <= o2.vw + 1, 'no horizontal overflow at 520 px', o2);
  await page.setViewportSize({ width: 1280, height: 820 });
  await page.focus(`${SH} [data-sc-close]`);
  await page.keyboard.press('Tab'); ok(await inSheet(page), 'Tab stays inside the sheet');
  await page.keyboard.down('Shift'); await page.keyboard.press('Tab'); await page.keyboard.press('Tab'); await page.keyboard.up('Shift');
  ok(await inSheet(page), 'Shift+Tab stays inside the sheet');
  await page.keyboard.press('Escape');
  ok(!!(await page.waitForSelector(SH, { state: 'detached', timeout: 2000 }).then(() => true).catch(() => false)), 'Esc closes');
  ok(await page.evaluate((r) => document.activeElement?.matches(`${r} [data-scrobble-open]`), root), 'focus back on the Settings button');
  await page.waitForTimeout(200);
  const row1 = await page.evaluate((r) => document.querySelector(`${r} [data-scrobble-open]`)?.closest('[data-scrobble-row]')?.innerText || document.querySelector(`${r} [data-scrobble-open]`)?.parentElement?.parentElement?.innerText || '', root);
  ok(/ListenBrainz/.test(row1) && /lb_listener/.test(row1) && !/Last\.fm · /.test(row1), 'Settings summary is live (ListenBrainz · lb_listener)', row1.slice(0, 160));

  // ── 12. restart: still connected, pending listen goes out at boot
  await page.waitForTimeout(400);
  await page.reload();
  await page.waitForFunction(() => window.__T && Object.keys(window.__T.useLibrary.getState().tracks).length >= 6, null, { timeout: 25000 });
  ok(await waitFor(page, () => { const s = window.__T.getScrobbler(); return s.connected('listenbrainz') && s.state.listenbrainz.user === 'lb_listener'; }, null, 5000), 'after restart: ListenBrainz still connected (token from the OS store)');
  ok(await waitFor(page, () => window.__T.getScrobbler().pending('listenbrainz') === 0 && window.__T.getScrobbler().state.listenbrainz.sent >= 5, null, 9000), 'after restart: the unsent listen is delivered', await S(page));

  // ── 13. other entry points: stats footer, command palette
  await goPlaylists(page, face); await page.waitForTimeout(400);
  await page.click(`${root} [data-stats-open]`); await page.waitForSelector('[data-stats-sheet]', { timeout: 3000 }).catch(() => {});
  await page.click('[data-stats-sheet] [data-stats-scrobble]').catch(() => {});
  ok(!!(await page.waitForSelector(SH, { timeout: 2000 }).catch(() => null)) && !(await page.$('[data-stats-sheet]')), 'stats footer → Scrobbling (stats sheet closes)');
  await page.keyboard.press('Escape'); await page.waitForTimeout(250);
  if (face !== 'eela') {
    await page.evaluate((face) => face === 'cinema' ? window.__T.useUi.getState().setShowPalette(true) : window.__T.useAlokUi.getState().setShowCmd(true), face);
    await page.waitForTimeout(400);
    await page.keyboard.type(rtl ? 'اسکراب' : 'scrobbl'); await page.waitForTimeout(250);
    let got = await page.evaluate(() => document.activeElement?.tagName === 'INPUT');
    await page.keyboard.press('Enter');
    let opened = !!(await page.waitForSelector(`${root} ${SH}`, { timeout: 2000 }).catch(() => null));
    if (!opened && rtl) { // FA label may not contain the transliteration: search by the localized label instead
      await page.evaluate((face) => face === 'cinema' ? window.__T.useUi.getState().setShowPalette(true) : window.__T.useAlokUi.getState().setShowCmd(true), face); await page.waitForTimeout(300);
      await page.keyboard.press('Control+a'); await page.keyboard.type('Last'); await page.waitForTimeout(200); await page.keyboard.press('Enter');
      opened = !!(await page.waitForSelector(`${root} ${SH}`, { timeout: 2000 }).catch(() => null));
    }
    ok(got && opened, 'command palette → Scrobbling (inside this face)');
    await page.keyboard.press('Escape'); await page.waitForTimeout(200);
  }
  ok(errs.length === 0, 'no page errors', errs);
  await ctx.close();
}
await browser.close();
console.log(`\n${pass}/${pass + fail} passed`);
if (fail) { console.log('FAILED:', fails); process.exit(1); }
