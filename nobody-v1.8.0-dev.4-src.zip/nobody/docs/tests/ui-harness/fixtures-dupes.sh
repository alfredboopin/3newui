#!/usr/bin/env bash
# Fixtures for dupes-ui-run.mjs, own dir (never mixed with t/ or t-m3u/). Rebuilt before every face/lang
# because the run moves files to /home/user/work/trash-bin.
#  song : Kooch FLAC ↔ MP3 320 (feat.), Glass 128 ↔ "Glass (Remastered 2011)" 256 (+1 s), یاد/کاوه ↔ ياد/كاوه (Arabic ي/ك)
#  tags : + Night Bus 6 s ↔ 16 s (live take, kept apart in song mode)
#  file : Paper Moon ↔ Paper Noon (same bytes length, different title) + the یاد pair
#  Saffron: unique
set -e; R=/home/user/work/t-dupes/lib; rm -rf /home/user/work/t-dupes /home/user/work/trash-bin; mkdir -p "$R/A" "$R/B"
mk(){ ffmpeg -loglevel error -y -f lavfi -i "sine=frequency=$1:duration=$2" -ac 2 -ar 44100 -metadata title="$3" -metadata artist="$4" -metadata album="Dupes" ${@:6} "$5"; }
mk 440 6 "Kooch" "Sohrab" "$R/A/01 Kooch.flac" -c:a flac
mk 440 6 "Kooch" "Sohrab feat. Mina" "$R/B/Kooch.mp3" -c:a libmp3lame -b:a 320k
mk 523 6 "Glass" "Mirror Band" "$R/A/Glass.mp3" -c:a libmp3lame -b:a 128k
mk 523 7 "Glass (Remastered 2011)" "Mirror Band" "$R/B/Glass (Remastered).mp3" -c:a libmp3lame -b:a 256k
mk 600 6 "یاد" "کاوه" "$R/A/یاد.mp3" -c:a libmp3lame -b:a 192k
mk 600 6 "ياد" "كاوه" "$R/B/ياد.mp3" -c:a libmp3lame -b:a 192k
mk 392 6 "Night Bus" "Lumen" "$R/A/Night Bus.mp3" -c:a libmp3lame -b:a 160k
mk 392 16 "Night Bus" "Lumen" "$R/B/Night Bus (Live).mp3" -c:a libmp3lame -b:a 160k
mk 294 6 "Paper Moon" "Ivy Lane" "$R/A/Paper Moon.flac" -c:a flac
mk 294 6 "Paper Noon" "Ivy Lane" "$R/B/Paper Noon.flac" -c:a flac
mk 349 6 "Saffron" "Darya" "$R/A/Saffron.flac" -c:a flac
