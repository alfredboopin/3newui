// NOBODY 1.7.0-dev.8 · smart playlists + ratings, Chromium UI run (Cinema / EELA / ALOK, EN + FA/RTL)
// 1.7.0-dev.10: fixtures from fixtures.sh smart; wait for the Cinema panel cross-fade before checking the badge
import { chromium } from '/opt/sd-artifact/node_modules/playwright/index.mjs';
const LIB = '/home/user/work/t/lib/Album';
const ROOT = { cinema: '#nc-root', eela: '#ne-root', alok: '#na-root' };
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, extra) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, extra !== undefined ? JSON.stringify(extra) : ''); } };
const browser = await chromium.launch({ executablePath: '/ms-playwright/chromium-1208/chrome-linux64/chrome', args: ['--autoplay-policy=no-user-gesture-required'] });
const faces = (process.env.FACES || 'cinema,eela,alok').split(','); const langs = (process.env.LANGS || 'en,fa').split(',');

async function session(face, lang) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 820 } }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 300)));
  await page.addInitScript(([lib, face, lang]) => { if (!sessionStorage.getItem('seeded')) { localStorage.clear(); localStorage.setItem('nobody-player-state-v2', JSON.stringify({ folderPaths: [lib], lang })); localStorage.setItem('nobody-ui-mode', face); sessionStorage.setItem('seeded', '1'); } }, [LIB, face, lang]);
  await page.goto('http://127.0.0.1:8787/');
  await page.waitForFunction(() => window.__T && Object.keys(window.__T.useLibrary.getState().tracks).length >= 6, null, { timeout: 25000 });
  await page.evaluate((lang) => window.__T.useSettings.getState().set('lang', lang), lang);
  await page.waitForTimeout(700);
  return { ctx, page, errs };
}
const goPlaylists = (page, face) => page.evaluate((face) => {
  const T = window.__T; if (face === 'cinema') T.useUi.getState().setView('playlists'); else if (face === 'eela') T.useEelaUi.getState().setView('playlists'); else { const s = T.useAlokUi.getState(); if (s.view !== 'playlists') s.toggleView('playlists'); }
}, face);
const dlg = '.nsp-dialog';
const smartIds = (page) => page.evaluate(() => window.__T.useLibrary.getState().playlists.filter(p => p.smart).map(p => ({ id: p.id, name: p.name, def: p.smart })));
const trackIdBy = (page, title) => page.evaluate((title) => Object.values(window.__T.useLibrary.getState().tracks).find(t => t.title === title)?.id, title);
const keysReset = (page) => page.evaluate(() => { window.__keys = []; });
const keysSeen = (page) => page.evaluate(() => window.__keys.slice());
const overflow = (page, sel) => page.$eval(sel, (el) => { const r = el.getBoundingClientRect(); const bad = [...el.querySelectorAll('*')].filter(n => { const b = n.getBoundingClientRect(); return b.width > 0 && (b.right > r.right + 1 || b.left < r.left - 1) && getComputedStyle(n).position !== 'fixed' && !n.closest('datalist,option'); }).map(n => n.className && String(n.className).slice(0, 40)); return { sw: el.scrollWidth, cw: el.clientWidth, bad: bad.slice(0, 4), right: r.right, left: r.left, vw: innerWidth }; });

for (const face of faces) for (const lang of langs) {
  console.log(`\n■ ${face} · ${lang}`);
  const { ctx, page, errs } = await session(face, lang);
  const rtl = lang === 'fa';
  await goPlaylists(page, face); await page.waitForTimeout(600);
  const root = ROOT[face];
  ok(await page.$(`${root} [data-smart-new]`), 'New smart playlist button present');
  ok((await page.$eval('html', h => h.dir || getComputedStyle(document.body).direction)) !== undefined, 'page booted');

  // T1 create from template
  await page.click(`${root} [data-smart-new]`);
  await page.waitForSelector(dlg, { timeout: 4000 });
  ok(await page.evaluate(([r, d]) => !!document.querySelector(r)?.contains(document.querySelector(d)), [root, dlg]), 'dialog mounted inside the face root');
  ok((await page.$eval(dlg, e => getComputedStyle(e).direction)) === (rtl ? 'rtl' : 'ltr'), `dialog direction ${rtl ? 'rtl' : 'ltr'}`);
  ok(await page.evaluate((d) => document.querySelector(d).contains(document.activeElement), dlg), 'focus moved into the dialog');
  const chips = await page.$$(`${dlg} .nsp-chip`);
  ok(chips.length === 6, '6 template chips', chips.length);
  await keysReset(page);
  await page.click(`${dlg} #nsp-name`); await page.keyboard.type('nkpm ');
  ok((await keysSeen(page)).length === 0, 'typing in the dialog never reaches window shortcuts (n/k/p/m/space)', await keysSeen(page));
  ok(await page.evaluate(() => window.__T.engine.audio.paused), 'space in the name field did not start playback');
  await page.fill(`${dlg} #nsp-name`, '');
  await chips[0].click(); // top rated
  await page.waitForTimeout(150);
  const tplName = await page.$eval(`${dlg} #nsp-name`, e => e.value);
  ok(tplName.length > 0, 'template fills the name', tplName);
  const cnt0 = await page.$eval(`${dlg} .nsp-preview-count`, e => e.textContent);
  ok(/(^|\D)0(\D|$)|۰/.test(cnt0), 'top rated preview = 0 before any rating', cnt0);
  // Tab trap
  for (let i = 0; i < 45; i++) await page.keyboard.press('Tab');
  ok(await page.evaluate((d) => document.querySelector(d).contains(document.activeElement), dlg), 'Tab ×45 stays inside the dialog');
  for (let i = 0; i < 7; i++) await page.keyboard.press('Shift+Tab');
  ok(await page.evaluate((d) => document.querySelector(d).contains(document.activeElement), dlg), 'Shift+Tab stays inside');
  // overflow
  const ov = await overflow(page, dlg);
  ok(ov.sw <= ov.cw + 1 && ov.bad.length === 0 && ov.right <= ov.vw && ov.left >= 0, 'no horizontal overflow at 1280 px', ov);
  await page.setViewportSize({ width: 520, height: 820 }); await page.waitForTimeout(250);
  const ov2 = await overflow(page, dlg);
  ok(ov2.sw <= ov2.cw + 1 && ov2.right <= ov2.vw + 0.5 && ov2.left >= -0.5, 'no horizontal overflow at 520 px', ov2);
  if (rtl) {
    const pos = await page.evaluate((d) => { const n = document.querySelector(`${d} #nsp-name`).getBoundingClientRect(); const lab = document.querySelector(`${d} .nte-label`).getBoundingClientRect(); const x = document.querySelector(`${d} .nte-head .nte-icon`).getBoundingClientRect(); const t = document.querySelector(`${d} .nte-title`).getBoundingClientRect(); return { labRight: lab.right, nameRight: n.right, closeX: x.left, titleX: t.left }; }, dlg);
    ok(Math.abs(pos.labRight - pos.nameRight) < 4 && pos.closeX < pos.titleX, 'RTL: labels start on the right, close button on the left', pos);
  }
  await page.setViewportSize({ width: 1280, height: 820 }); await page.waitForTimeout(150);
  await keysReset(page);
  await page.focus(`${dlg} #nsp-name`);
  await page.keyboard.press('Control+s');
  await page.waitForSelector(dlg, { state: 'detached', timeout: 3000 }).catch(() => {});
  ok(!(await page.$(dlg)), 'Ctrl+S creates and closes');
  ok((await keysSeen(page)).length === 0, 'Ctrl+S did not reach window', await keysSeen(page));
  let sm = await smartIds(page);
  ok(sm.length === 1 && sm[0].name === tplName, 'smart playlist stored with the template name', sm.map(s => s.name));
  await page.waitForTimeout(300);
  await page.waitForSelector(`${root} [data-smart-badge]`, { timeout: 2000 }).catch(() => {}); ok(await page.$(`${root} [data-smart-badge]`), 'created list is selected/open (Smart badge visible)');
  ok(await page.$(`${root} [data-smart-edit]`), 'Edit rules button visible');

  // T2 rating → live count
  const kooch = await trackIdBy(page, 'Kooch'), glass = await trackIdBy(page, 'Glass');
  const headTxt = () => page.evaluate((r) => document.querySelector(r).innerText, root);
  await page.evaluate(([a, b]) => { const L = window.__T.useLibrary.getState(); L.setRating(a, 5); L.setRating(b, 4); }, [kooch, glass]);
  await page.waitForTimeout(400);
  let txt = await headTxt();
  ok(txt.includes('Kooch') && txt.includes('Glass') && !txt.includes('Old Tape'), 'list updates live after rating (Kooch 5★, Glass 4★ shown)');
  const order = txt.indexOf('Kooch') < txt.indexOf('Glass');
  ok(order, 'highest rated first');
  // smart rows: no remove buttons
  const rmCount = await page.evaluate(([r, face]) => {
    const el = document.querySelector(r);
    if (face === 'alok') return [...el.querySelectorAll('.na-row .na-icon-btn')].filter(b => /remove|حذف/i.test(b.getAttribute('aria-label') || b.title || '')).length;
    return [...el.querySelectorAll('button')].filter(b => /remove from playlist|از فهرست|حذف از/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.title || ''))).length;
  }, [root, face]);
  ok(rmCount === 0, 'no remove button on smart rows', rmCount);
  // star keyboard on a row: rate Old Tape is not listed; rate Kooch down via keys
  const stars = await page.$$(`${root} .nrt[role=slider]`);
  if (face !== 'alok') {
    ok(stars.length >= 2, 'stars rendered on smart rows', stars.length);
    const s0 = stars[0];
    const before = await s0.getAttribute('aria-valuenow');
    await keysReset(page);
    const pos0 = await page.evaluate(() => ({ p: window.__T.engine.audio.paused, id: window.__T.useUi.getState().currentId }));
    await s0.focus(); await page.keyboard.press(rtl ? 'ArrowRight' : 'ArrowLeft');
    await page.keyboard.press('Enter'); await page.keyboard.press(' ');
    await page.waitForTimeout(250);
    const pos1 = await page.evaluate(() => ({ p: window.__T.engine.audio.paused, id: window.__T.useUi.getState().currentId }));
    ok(before === '5' && (await page.evaluate((id) => window.__T.useLibrary.getState().ratings[id], kooch)) === 4, `${rtl ? '→' : '←'} lowers the rating (RTL-aware)`, { before, now: await page.evaluate((id) => window.__T.useLibrary.getState().ratings[id], kooch) });
    ok((await keysSeen(page)).length === 0 && pos0.p === pos1.p && pos0.id === pos1.id, 'star keys (arrows / Enter / Space) never hit transport or the row', { keys: await keysSeen(page), pos0, pos1 });
  }
  // T3 Edit rules: Esc when dirty asks, Esc again keeps editing, change rule, save
  await page.click(`${root} [data-smart-edit]`);
  await page.waitForSelector(dlg);
  ok((await page.$$(`${dlg} .nsp-chip`)).length === 0, 'edit mode has no template chips');
  await page.selectOption(`${dlg} .nsp-sort select, ${dlg} .nsp-order select`, 'title').catch(async () => {});
  // add a rule: genre contains rock
  await page.click(`${dlg} .nsp-add`);
  const rules = await page.$$(`${dlg} .nsp-rule`);
  const last = rules[rules.length - 1];
  const sel = await last.$$('select');
  await sel[0].selectOption('genre'); await page.waitForTimeout(80);
  const ops = await (await last.$$('select'))[1].evaluate(s => [...s.options].map(o => o.value));
  await (await last.$$('select'))[1].selectOption(ops.includes('contains') ? 'contains' : ops[0]);
  await (await last.$('.nsp-val input')).fill('rock');
  await page.waitForTimeout(150);
  const pc = await page.$eval(`${dlg} .nsp-preview-count`, e => e.textContent);
  ok(/(^|\D)1(\D|$)|۱/.test(pc), 'preview live: rating ≥ … AND genre contains rock → 1 (Glass)', pc);
  await page.keyboard.press('Escape');
  ok(await page.$(`${dlg} .nte-btn-danger`), 'Esc on a dirty dialog asks to discard');
  await page.keyboard.press('Escape');
  ok(!(await page.$(`${dlg} .nte-btn-danger`)) && await page.$(dlg), 'second Esc = keep editing');
  await page.click(`${dlg} .nte-btn-primary`);
  await page.waitForSelector(dlg, { state: 'detached', timeout: 3000 }).catch(() => {});
  sm = await smartIds(page);
  ok(!(await page.$(dlg)) && sm[0].def.rules.length === 2, 'Save stores 2 rules', sm[0]?.def?.rules?.length);
  await page.waitForTimeout(300);
  txt = await headTxt();
  ok(txt.includes('Glass') && !txt.includes('Kooch'), 'list re-resolved after Edit rules (only Glass)');
  // Esc on clean dialog closes immediately
  await page.click(`${root} [data-smart-edit]`); await page.waitForSelector(dlg);
  await page.keyboard.press('Escape'); await page.waitForTimeout(200);
  ok(!(await page.$(dlg)), 'Esc on a clean dialog closes at once');
  ok(await page.evaluate((r) => !!document.activeElement && document.querySelector(r).contains(document.activeElement) && document.activeElement !== document.body, root), 'focus returned into the face after close');

  // T4 manual list: add/remove still offered; smart lists hidden from "add to playlist"
  await page.evaluate(() => window.__T.useLibrary.getState().createPlaylist('Manual One'));
  await page.waitForTimeout(200);
  if (face === 'alok') {
    await page.evaluate(() => { const s = window.__T.useAlokUi.getState(); s.toggleView('library'); });
    await page.waitForTimeout(500);
    const addBtn = await page.$(`#na-root .na-row [aria-label^="${lang === 'fa' ? '' : 'Add to playlist'}"]`);
    const btns = await page.$$('#na-root .na-row .na-pop-wrap > button');
    await btns[0].click(); await page.waitForSelector('#na-root .na-pop');
    const popTxt = await page.$eval('#na-root .na-pop', e => e.innerText);
    ok(popTxt.includes('Manual One') && !popTxt.includes(tplName), 'ALOK "Add to playlist" popover lists manual lists only', popTxt);
    await page.keyboard.press('Escape');
    // InfoCard stars
    await page.evaluate((id) => { window.__T.engine.setQueue([id], id, false); }, kooch);
    await page.waitForTimeout(400);
    await page.evaluate(() => { const s = window.__T.useAlokUi.getState(); s.closePanel(); s.setShowInfo(true); });
    await page.waitForTimeout(500);
    const ir = await page.$('#na-root [data-info-rating] .nrt');
    ok(!!ir && (await ir.getAttribute('aria-valuenow')) === '5', 'ALOK InfoCard shows the rating row (5★)', ir && await ir.getAttribute('aria-valuenow'));
    if (ir) {
      await keysReset(page);
      await ir.focus(); await page.keyboard.press('Home'); await page.waitForTimeout(100);
      const cleared = await page.evaluate((id) => window.__T.useLibrary.getState().ratings[id] || 0, kooch);
      await page.keyboard.press('End'); await page.waitForTimeout(150);
      ok(cleared === 0 && (await page.evaluate((id) => window.__T.useLibrary.getState().ratings[id], kooch)) === 5 && (await keysSeen(page)).length === 0, 'InfoCard: Home clears, End → 5★, keys stay local');
      await page.keyboard.press('Escape'); await page.waitForTimeout(400);
      ok(!(await page.evaluate(() => window.__T.useAlokUi.getState().showInfo)), 'Esc from the star still closes the InfoCard');
    }
    // detail: smart list hides Add current
    await page.evaluate(() => { window.__T.useAlokUi.getState().toggleView('playlists'); }); await page.waitForTimeout(400);
    const card = (await page.$$('#na-root .na-face-card')).length;
    ok(card === 2, 'ALOK cards: smart + manual', card);
    const cardsTxt = await page.$eval('#na-root .na-panel', e => e.innerText);
    ok(/Smart|هوشمند/.test(cardsTxt), 'Smart label on the card');
    await page.click(`#na-root .na-face-card[aria-label="${tplName}"]`); await page.waitForTimeout(300);
    const detail = await page.$eval('#na-root .na-panel', e => e.innerText);
    ok(!/Add current|افزودن آهنگ فعلی/.test(detail) && await page.$('#na-root [data-smart-edit]'), 'smart detail: no "Add current", Edit rules shown', detail.slice(0, 200));
  } else {
    // manual list shows remove buttons (contrast check)
    if (face === 'cinema') {
      // Enter on a playlist row plays (row focus only)
      await page.evaluate(() => window.__T.engine.pause());
      const row = await page.$('#nc-root .nc-row[tabindex]') || await page.$('#nc-root .nc-row');
      if (row) { await row.focus(); await keysReset(page); await page.keyboard.press('Enter'); await page.waitForTimeout(500); }
      ok(!!row && (await page.evaluate((id) => window.__T.useUi.getState().currentId, null)) === glass, 'Cinema: Enter on a playlist row plays it', await page.evaluate(() => window.__T.useUi.getState().currentId));
    }
    if (face === 'eela') {
      const row = await page.$('#ne-root [role=button][tabindex="0"].group, #ne-root .group[tabindex="0"]');
      if (row) { await row.focus(); await page.keyboard.press('Enter'); await page.waitForTimeout(500); }
      ok(!!row && (await page.evaluate(() => window.__T.useUi.getState().currentId)) === glass, 'EELA: Enter on a playlist row plays it');
      // NowPlaying stars + library row stars
      await page.evaluate(() => window.__T.useEelaUi.getState().setView('library')); await page.waitForTimeout(300);
      const libStars = await page.$$('#ne-root .ne-track-album-txt ~ .nrt, #ne-root .nrt[data-quiet]');
      ok(libStars.length >= 0, 'EELA library view renders');
    }
  }
  // T5 delete via store → no crash, view falls back
  await page.evaluate((id) => window.__T.useLibrary.getState().deletePlaylist(id), sm[0].id);
  await page.waitForTimeout(300);
  ok((await smartIds(page)).length === 0, 'smart list deleted');
  ok(errs.length === 0, 'no page errors', errs);
  await page.screenshot({ path: `/home/user/work/h/ui-${face}-${lang}.png` });
  await ctx.close();
}
console.log(`\n${pass} passed, ${fail} failed`); if (fails.length) console.log(fails);
await browser.close(); process.exit(fail ? 1 : 0);
