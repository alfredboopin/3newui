#!/usr/bin/env bash
# Fixtures for smart-ui-run.mjs (6 FLAC, 6 s each). Kooch must NOT contain "rock"; Glass must.
set -e; D=/home/user/work/t/lib/Album; mkdir -p "$D"; cd "$D"
mk(){ ffmpeg -loglevel error -y -f lavfi -i "sine=frequency=$1:duration=6" -ac 2 -ar 44100 -metadata title="$2" -metadata artist="$3" -metadata album="Fixtures" -metadata genre="$4" -metadata date=2020 -c:a flac "$5"; }
mk 440 "Kooch" "Sohrab" "Persian Pop" "01 Kooch.flac"
mk 523 "Glass" "Mirror Band" "Rock; Alternative" "02 Glass.flac"
mk 330 "Old Tape" "Cassette" "Rock" "03 Old Tape.flac"
mk 392 "Night Bus" "Lumen" "Electronic" "04 Night Bus.flac"
mk 294 "Paper Moon" "Ivy Lane" "Jazz" "05 Paper Moon.flac"
mk 349 "Saffron" "Darya" "Folk" "06 Saffron.flac"
