import { build } from '/opt/sd-artifact/node_modules/esbuild/lib/main.js';
import fs from 'fs'; import { createRequire } from 'module';
const require = createRequire('/opt/sd-artifact/node_modules/');
const NM = '/opt/sd-artifact/node_modules';
const SRC = '/home/user/work/src';
// Tailwind v3 approximation of the v4 `@import "tailwindcss"` (test harness only)
const postcss = require('postcss'); const tw = require('tailwindcss');
const twCss = await postcss([tw({ content: [SRC + '/src/**/*.{ts,tsx}'], corePlugins: {} })]).process('@tailwind base;@tailwind components;@tailwind utilities;', { from: undefined });
fs.writeFileSync('dist/tw.css', twCss.css);
const alias = { react: NM + '/react', 'react-dom': NM + '/react-dom', zustand: NM + '/zustand', 'framer-motion': NM + '/framer-motion', 'lucide-react': NM + '/lucide-react', clsx: NM + '/clsx', 'tailwind-merge': NM + '/tailwind-merge' };
const plug = { name: 'h', setup(b) {
  b.onResolve({ filter: /^@tanstack\/react-virtual$/ }, () => ({ path: '/home/user/work/h/shims/virtual.ts' }));
  b.onResolve({ filter: /^@tauri-apps\// }, () => ({ path: '/home/user/work/h/shims/tauri.ts' }));
  b.onResolve({ filter: /^@\// }, (a) => ({ path: require.resolve ? SRC + '/src/' + a.path.slice(2) : '' }));
  b.onLoad({ filter: /\.css$/ }, (a) => ({ contents: fs.readFileSync(a.path, 'utf8').replace(/@import\s+"tailwindcss";?/g, ''), loader: 'css' }));
  b.onLoad({ filter: /desktopLibrary\.ts$/ }, (a) => ({ contents: fs.readFileSync(a.path, 'utf8').replace('return `app://${encodeURIComponent(path)}`;', 'return `app://${encodeURIComponent(path)}`.replace("app://", location.origin + "/app/");'), loader: 'ts' }));
} };
const r = await build({ entryPoints: ['entry.tsx'], bundle: true, outdir: 'dist', format: 'esm', alias, plugins: [plug], loader: { '.woff2': 'file', '.woff': 'file', '.ttf': 'file', '.svg': 'file', '.png': 'file', '.jpg': 'file' }, jsx: 'automatic', define: { 'process.env.NODE_ENV': '"development"', 'import.meta.env.DEV': 'true', 'import.meta.env.PROD': 'false', 'import.meta.env.MODE': '"development"', 'import.meta.env.BASE_URL': '"/"' }, logLevel: 'error', sourcemap: 'inline', external: ['/fonts/*'] });
fs.writeFileSync('dist/index.html', `<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/tw.css"><link rel="stylesheet" href="/entry.css"></head><body><div id="root"></div><script type="module" src="/entry.js"></script></body></html>`);
console.log('built', fs.statSync('dist/entry.js').size);
