#!/usr/bin/env bash
# Fixtures for m3u-ui-run.mjs (1.7.0). Own dir so they never mix with the smart/stats FLAC fixtures.
#   lib/Album: 7 mp3 (4 s) incl. "07 سلام.mp3" · outside/: Outside A + B (not in the library)
#   lists/road.m3u8 (relative, file://, absolute, moved→name, tags-only, 2 outside, missing, stream, dupe)
#   lists/fa.m3u (windows-1256, no BOM) · lists/big.m3u8 (> 8 MB → E_TOO_LARGE)
set -e; T="${T:-/home/user/work/t-m3u}"; rm -rf "$T"; mkdir -p "$T/lib/Album" "$T/outside" "$T/lists"
mk(){ ffmpeg -loglevel error -y -f lavfi -i "sine=frequency=$1:duration=4" -ac 2 -ar 44100 -c:a libmp3lame -b:a 128k -id3v2_version 3 -metadata title="$2" -metadata artist="$3" -metadata album="$4" "$5"; }
A="$T/lib/Album"
mk 440 "One"   "Alpha"   "Fixtures" "$A/01 One.mp3"
mk 494 "Two"   "Bravo"   "Fixtures" "$A/02 Two.mp3"
mk 523 "Three" "Charlie" "Fixtures" "$A/03 Three.mp3"
mk 587 "Four"  "Alpha"   "Fixtures" "$A/04 Four.mp3"
mk 659 "Five"  "Echo"    "Fixtures" "$A/05 Five.mp3"
mk 698 "Six"   "Foxtrot" "Fixtures" "$A/06 Six.mp3"
mk 784 "سلام"  "داریا"   "Fixtures" "$A/07 سلام.mp3"
mk 330 "Outside A" "Delta" "Elsewhere" "$T/outside/Outside A.mp3"
mk 349 "Outside B" "Delta" "Elsewhere" "$T/outside/Outside B.mp3"
python3 - "$T" <<'PY'
import sys, urllib.parse
T = sys.argv[1]; L = T + "/lists"
road = [
  "#EXTM3U", "#PLAYLIST:Road trip",
  "#EXTINF:4,Alpha - One", "../lib/Album/01 One.mp3",                                  # relative
  "file://" + urllib.parse.quote(T + "/lib/Album/02 Two.mp3"),                          # file:// URL
  T + "/lib/Album/03 Three.mp3",                                                        # absolute
  "/old/music/04 Four.mp3",                                                             # moved → file name
  "#EXTINF:4,Echo - Five", "/old/renamed/track five.mp3",                               # tags only
  "../outside/Outside A.mp3",                                                           # outside, relative
  T + "/outside/Outside B.mp3",                                                         # outside, absolute
  "#EXTINF:200,Nobody - Ghost", "/nowhere/ghost.mp3",                                   # missing
  "#EXTINF:-1,Radio", "http://radio.example/stream",                                    # stream
  "../lib/Album/01 One.mp3",                                                            # duplicate
]
open(L + "/road.m3u8", "w", encoding="utf-8", newline="\r\n").write("\n".join(road) + "\n")
fa = ["#EXTM3U", "#EXTINF:4,سلام", "..\\lib\\Album\\07 سلام.mp3", "../lib/Album/06 Six.mp3"]
open(L + "/fa.m3u", "wb").write(("\r\n".join(fa) + "\r\n").encode("cp1256"))
line = "#EXTINF:4,Filler - Filler\r\n/nowhere/filler-%06d.mp3\r\n"
with open(L + "/big.m3u8", "w", encoding="utf-8", newline="") as f:
  f.write("#EXTM3U\r\n"); i = 0
  while f.tell() < 8 * 1024 * 1024 + 4096: f.write(line % i); i += 1
PY
ls -la "$T/lib/Album" "$T/outside" "$T/lists"
