// NOBODY 1.7.0-dev.9 · M3U/M3U8 import + export, Chromium UI run (Cinema / EELA / ALOK, EN + FA/RTL)
import { chromium } from '/opt/sd-artifact/node_modules/playwright/index.mjs';
import fs from 'fs';
const T = process.env.T || '/home/user/work/t-m3u';
const LIB = `${T}/lib/Album`;
const OUT = `${T}/out`; fs.mkdirSync(OUT, { recursive: true });
const ROOT = { cinema: '#nc-root', eela: '#ne-root', alok: '#na-root' };
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, extra) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, extra !== undefined ? JSON.stringify(extra) : ''); } };
const browser = await chromium.launch({ executablePath: '/ms-playwright/chromium-1208/chrome-linux64/chrome', args: ['--autoplay-policy=no-user-gesture-required'] });
const faces = (process.env.FACES || 'cinema,eela,alok').split(','); const langs = (process.env.LANGS || 'en,fa').split(',');
const rpc = (page, fn, ...args) => page.evaluate(async ([fn, args]) => (await (await fetch('/rpc', { method: 'POST', body: JSON.stringify({ fn, args }) })).json()).r, [fn, args]);

const goPlaylists = (page, face) => page.evaluate((face) => {
  const T = window.__T; if (face === 'cinema') T.useUi.getState().setView('playlists'); else if (face === 'eela') T.useEelaUi.getState().setView('playlists'); else { const s = T.useAlokUi.getState(); if (s.view !== 'playlists') s.toggleView('playlists'); }
}, face);
const lib = (page) => page.evaluate(() => { const s = window.__T.useLibrary.getState(); return { n: Object.keys(s.tracks).length, titles: Object.values(s.tracks).map(t => t.title) }; });
const plByName = (page, name) => page.evaluate((name) => { const s = window.__T.useLibrary.getState(); const p = s.playlists.find(p => p.name === name); return p ? { id: p.id, titles: p.trackIds.map(id => s.tracks[id]?.title) } : null; }, name);
const toasts = (page) => page.evaluate(() => window.__T.useUi.getState().toasts.map(t => [t.msg, t.sub || '', t.kind]));
const clearToasts = (page) => page.evaluate(() => window.__T.useUi.setState({ toasts: [] }));
const clickImport = async (page, root) => {
  // ALOK opens the imported playlist's detail; Import lives on the list → go back first
  if (!(await page.$(`${root} [data-m3u-import]`))) {
    await page.evaluate((root) => [...document.querySelectorAll(`${root} button`)].find(b => b.textContent.trim().startsWith('←'))?.click(), root);
    await page.waitForTimeout(250);
  }
  await page.click(`${root} [data-m3u-import]`);
};
const persisted = (page) => page.evaluate(() => JSON.parse(localStorage.getItem('nobody-player-state-v2') || '{}'));

for (const face of faces) for (const lang of langs) {
  console.log(`\n■ ${face} · ${lang}`);
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 820 } }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 300)));
  await page.addInitScript(([lib, face, lang]) => { if (!sessionStorage.getItem('seeded')) { localStorage.clear(); localStorage.setItem('nobody-player-state-v2', JSON.stringify({ folderPaths: [lib], lang })); localStorage.setItem('nobody-ui-mode', face); sessionStorage.setItem('seeded', '1'); } }, [LIB, face, lang]);
  await page.goto('http://127.0.0.1:8787/');
  await page.waitForFunction(() => window.__T && Object.keys(window.__T.useLibrary.getState().tracks).length >= 7, null, { timeout: 25000 });
  await page.evaluate((lang) => window.__T.useSettings.getState().set('lang', lang), lang);
  await page.waitForTimeout(600);
  const root = ROOT[face];
  await goPlaylists(page, face); await page.waitForTimeout(500);
  const imp = `${root} [data-m3u-import]`;
  ok(!!(await page.$(imp)), 'Import button inside the face root');
  const label = await page.$eval(imp, (e) => (e.getAttribute('aria-label') || e.textContent || '').trim());
  ok(lang === 'fa' ? /وارد کردن/.test(label) : /Import/.test(label), 'Import button localized', label);

  // ── 1. road trip: path / file:// / relative / name / tags / outside / missing / stream / dupe
  ok((await lib(page)).n === 7, 'library starts with 7 songs');
  await page.evaluate((p) => { window.__pickM3U = [p]; }, `${T}/lists/road.m3u8`);
  await clearToasts(page);
  await clickImport(page, root);
  await page.waitForFunction(() => window.__T.useLibrary.getState().playlists.some(p => p.name === 'Road trip'), null, { timeout: 8000 }).catch(() => {});
  const road = await plByName(page, 'Road trip');
  ok(!!road, '#PLAYLIST name used');
  ok(JSON.stringify(road?.titles) === JSON.stringify(['One', 'Two', 'Three', 'Four', 'Five', 'Outside A', 'Outside B']), 'songs in file order (relative, file://, absolute, moved → name, tags-only, 2 outside files)', road?.titles);
  const after = await lib(page);
  ok(after.n === 9 && after.titles.includes('Outside A') && after.titles.includes('Outside B'), 'the 2 on-disk files outside the library were imported', after.n);
  const ts = await toasts(page);
  const sum = ts.find(t => t[2] !== 'progress');
  ok(!!sum && /7/.test(sum[0]) && (lang === 'fa' ? /Road trip/.test(sum[0]) : /“Road trip”: 7 songs/.test(sum[0])), 'summary toast', ts);
  ok(!!sum && /2/.test(sum[1]) && /1/.test(sum[1]) && sum[1].split('·').length === 4, 'toast sub: added 2 · not found 1 · stream 1 · duplicate 1', sum?.[1]);
  ok(!ts.some(t => t[2] === 'progress'), 'progress toast dismissed');
  await page.waitForTimeout(400);
  // the view selected the new playlist
  const shown = await page.evaluate(([root]) => document.querySelector(root).innerText.includes('Road trip'), [root]);
  ok(shown, 'new playlist shown in the view');
  const exp = `${root} [data-m3u-export]`;
  ok(!!(await page.$(exp)) && !(await page.$eval(exp, e => e.disabled)), 'Export button enabled on the opened playlist');
  await page.waitForTimeout(500);
  const st = await persisted(page);
  ok(Array.isArray(st.looseFiles) && st.looseFiles.length === 2 && st.looseFiles.every(f => f.startsWith(`${T}/outside/`)), 'outside files remembered (looseFiles)', st.looseFiles);

  // ── 2. export (.m3u8 relative, CRLF, EXTINF) + round trip
  const target = `${OUT}/${face}-${lang}.m3u8`;
  await page.evaluate((p) => { window.__exportPath = p; }, target);
  await clearToasts(page);
  await page.click(exp);
  await page.waitForTimeout(500);
  const txt = fs.existsSync(target) ? fs.readFileSync(target, 'utf8') : '';
  const lines = txt.split('\r\n');
  ok(lines[0] === '#EXTM3U' && lines[1] === '#PLAYLIST:Road trip', 'export header + name', lines.slice(0, 2));
  ok(lines.includes('../lib/Album/01 One.mp3') && lines.includes('../outside/Outside B.mp3'), 'export paths relative to the playlist folder', lines.filter(l => !l.startsWith('#')));
  ok(lines.includes('#EXTINF:4,Alpha - One') && lines.includes('#EXTINF:4,Delta - Outside A'), 'EXTINF duration + Artist - Title', lines.filter(l => l.startsWith('#EXTINF')).slice(0, 2));
  ok(!/[^\r]\n/.test(txt) && txt.endsWith('\r\n'), 'CRLF line endings');
  ok(lines.filter(l => l && !l.startsWith('#')).length === 7, '7 songs exported');
  ok((await toasts(page)).some(t => t[2] === 'success' && /7/.test(t[0])), 'export toast');
  ok(await page.evaluate(() => window.__exportName) === 'Road trip', 'save dialog got the playlist name');
  // round trip
  await page.evaluate((p) => { window.__pickM3U = [p]; }, target);
  await clickImport(page, root);
  await page.waitForFunction(() => window.__T.useLibrary.getState().playlists.some(p => p.name === 'Road trip (2)'), null, { timeout: 8000 }).catch(() => {});
  const rt = await plByName(page, 'Road trip (2)');
  ok(JSON.stringify(rt?.titles) === JSON.stringify(road?.titles), 'round trip: same songs, same order, unique name', rt?.titles);
  ok((await lib(page)).n === 9, 'round trip imports nothing new');

  // ── 3. legacy windows-1256 .m3u (Persian path) + .m3u export with BOM
  await page.evaluate((p) => { window.__pickM3U = [p]; }, `${T}/lists/fa.m3u`);
  await clearToasts(page);
  await clickImport(page, root);
  await page.waitForFunction(() => window.__T.useLibrary.getState().playlists.some(p => p.name === 'fa'), null, { timeout: 8000 }).catch(() => {});
  const fa = await plByName(page, 'fa');
  ok(JSON.stringify(fa?.titles) === JSON.stringify(['سلام', 'Six']), `windows-1256 file decoded (UI ${lang}), name from file name`, fa?.titles);
  const faT = `${OUT}/${face}-${lang}-fa.m3u`;
  await page.evaluate((p) => { window.__exportPath = p; }, faT);
  await page.waitForTimeout(300);
  await page.click(exp);
  await page.waitForTimeout(500);
  const hex = await rpc(page, 'readHex', faT, 3);
  ok(hex === 'efbbbf', '.m3u export starts with a UTF-8 BOM', hex);
  ok(fs.existsSync(faT) && fs.readFileSync(faT, 'utf8').includes('07 سلام.mp3'), '.m3u export keeps the Persian file name');

  // ── 4. errors: too large / cancel / nothing found
  await clearToasts(page);
  await page.evaluate((p) => { window.__pickM3U = [p]; }, `${T}/lists/big.m3u8`);
  await clickImport(page, root); await page.waitForTimeout(600);
  ok((await toasts(page)).some(t => t[2] === 'error' && /big\.m3u8/.test(t[0])), 'too-large playlist → error toast', await toasts(page));
  const nBefore = (await page.evaluate(() => window.__T.useLibrary.getState().playlists.length));
  await page.evaluate(() => { window.__pickM3U = []; });
  await clickImport(page, root); await page.waitForTimeout(300);
  ok((await page.evaluate(() => window.__T.useLibrary.getState().playlists.length)) === nBefore, 'cancelled picker changes nothing');
  fs.writeFileSync(`${T}/lists/ghosts.m3u8`, '#EXTM3U\n/nope/a.mp3\nhttp://x/y\n');
  await clearToasts(page);
  await page.evaluate((p) => { window.__pickM3U = [p]; }, `${T}/lists/ghosts.m3u8`);
  await clickImport(page, root); await page.waitForTimeout(600);
  ok((await page.evaluate(() => window.__T.useLibrary.getState().playlists.length)) === nBefore && (await toasts(page)).some(t => t[2] === 'error'), 'no songs found → no empty playlist, error toast');
  // export cancelled
  await page.evaluate(() => { window.__exportPath = null; });
  if (!(await page.$(exp))) { await page.click(`${root} .na-face-card[aria-label="Road trip"]`); await page.waitForTimeout(300); }
  await clearToasts(page);
  await page.click(exp); await page.waitForTimeout(300);
  ok((await toasts(page)).length === 0, 'cancelled save dialog → silent');

  // ── 5. layout: no horizontal overflow at 1280 / 520, RTL placement
  for (const w of [1280, 520]) {
    await page.setViewportSize({ width: w, height: 820 }); await page.waitForTimeout(300);
    const r = await page.evaluate(([imp, exp]) => [imp, exp].map(s => { const b = document.querySelector(s)?.getBoundingClientRect(); return b ? [Math.round(b.left), Math.round(b.right)] : null; }), [imp, exp]);
    ok(r.every(b => !b || (b[0] >= -1 && b[1] <= w + 1)), `buttons inside the viewport at ${w} px`, r);
  }
  await page.setViewportSize({ width: 1280, height: 820 });
  if (lang === 'fa') {
    const dir = await page.$eval(exp, e => getComputedStyle(e).direction);
    ok(dir === 'rtl', 'RTL direction on export button');
  }

  // ── 6. restart: outside files + playlist survive
  await page.waitForTimeout(800);
  await page.reload();
  await page.waitForFunction(() => window.__T && Object.keys(window.__T.useLibrary.getState().tracks).length >= 9, null, { timeout: 25000 }).catch(() => {});
  await page.waitForTimeout(800);
  const re = await lib(page);
  ok(re.n === 9, 'after restart: library still has the 2 outside files', re.n);
  const road2 = await plByName(page, 'Road trip');
  ok(JSON.stringify(road2?.titles) === JSON.stringify(road?.titles), 'after restart: playlist intact (7 songs)', road2?.titles);
  ok(errs.length === 0, 'no page errors', errs);
  await ctx.close();
}
await browser.close();
console.log(`\n${pass}/${pass + fail} passed`);
if (fail) { console.log('FAILED:', fails); process.exit(1); }
