#!/usr/bin/env bash
[ -f /tmp/srv.pid ] && kill $(cat /tmp/srv.pid) 2>/dev/null; sleep 0.3
cd /home/user/work/h && setsid nohup node server.cjs > /tmp/server.log 2>&1 < /dev/null & echo $! > /tmp/srv.pid; sleep 0.8; cat /tmp/server.log
