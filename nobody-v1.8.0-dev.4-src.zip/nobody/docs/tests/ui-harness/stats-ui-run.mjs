// NOBODY 1.7.0-dev.11 · listening stats sheet, Chromium UI run (Cinema / EELA / ALOK, EN + FA/RTL)
import { chromium } from '/opt/sd-artifact/node_modules/playwright/index.mjs';
import fs from 'fs';
const LIB = '/home/user/work/t/lib/Album';
const ROOT = { cinema: '#nc-root', eela: '#ne-root', alok: '#na-root' };
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, extra) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, extra !== undefined ? JSON.stringify(extra) : ''); } };
const browser = await chromium.launch({ executablePath: '/ms-playwright/chromium-1208/chrome-linux64/chrome', args: ['--autoplay-policy=no-user-gesture-required'] });
const faces = (process.env.FACES || 'cinema,eela,alok').split(','); const langs = (process.env.LANGS || 'en,fa').split(',');
const latin = (s) => String(s || '').replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[٬,\s]/g, '');
const SH = '[data-stats-sheet]';

async function session(face, lang) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 820 }, acceptDownloads: true }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 300)));
  await page.addInitScript(([lib, face, lang]) => { if (!sessionStorage.getItem('seeded')) { localStorage.clear(); indexedDB.deleteDatabase('nobody-stats'); localStorage.setItem('nobody-player-state-v2', JSON.stringify({ folderPaths: [lib], lang })); localStorage.setItem('nobody-ui-mode', face); sessionStorage.setItem('seeded', '1'); } }, [LIB, face, lang]);
  await page.goto('http://127.0.0.1:8787/');
  await page.waitForFunction(() => window.__T && Object.keys(window.__T.useLibrary.getState().tracks).length >= 6, null, { timeout: 25000 });
  await page.evaluate((lang) => window.__T.useSettings.getState().set('lang', lang), lang);
  await page.waitForTimeout(600);
  return { ctx, page, errs };
}
const goPlaylists = (page, face) => page.evaluate((face) => {
  const T = window.__T; if (face === 'cinema') T.useUi.getState().setView('playlists'); else if (face === 'eela') T.useEelaUi.getState().setView('playlists'); else { const s = T.useAlokUi.getState(); if (s.view !== 'playlists') s.toggleView('playlists'); }
}, face);
const overflow = (page, sel) => page.$eval(sel, (el) => { const r = el.getBoundingClientRect(); const bad = [...el.querySelectorAll('*')].filter(n => { const b = n.getBoundingClientRect(); return b.width > 0 && (b.right > r.right + 1 || b.left < r.left - 1) && getComputedStyle(n).position !== 'fixed'; }).map(n => n.className && String(n.className).slice(0, 40)); const body = el.querySelector('.nte-body'); return { sw: body.scrollWidth, cw: body.clientWidth, bad: bad.slice(0, 4), right: r.right, left: r.left, vw: innerWidth }; });
const card = async (page, k) => latin(await page.$eval(`${SH} [data-stat="${k}"] .nls-card-value`, e => e.textContent));
const inSheet = (page) => page.evaluate((s) => !!document.querySelector(s)?.contains(document.activeElement), SH);

// history: Glass ×5 (today, -1, -2, -10, -40), Kooch ×3 (today, -1, -200), Old Tape ×1 skip today,
// Night Bus ×1 with "Unknown Artist" snapshot today, a song no longer in the library ×1 (-3)
const seed = (page) => page.evaluate(async () => {
  const T = window.__T; const tracks = Object.values(T.useLibrary.getState().tracks); const by = (t) => tracks.find(x => x.title === t);
  const day = (n, h = 21) => { const d = new Date(); d.setDate(d.getDate() - n); d.setHours(h, 10, 0, 0); return Math.min(d.getTime(), Date.now() - 60000); };
  const row = (tr, n, o = {}) => ({ at: day(n, o.h), id: tr ? tr.id : 'gone-1', ms: o.ms ?? 200000, dur: 240, title: tr ? tr.title : 'Ghost Song', artist: o.artist ?? (tr ? tr.artist : 'Old Artist'), album: tr ? tr.album : 'Lost', genre: tr ? tr.genre : 'Rock', full: o.skip ? false : true, skip: !!o.skip, src: 'engine' });
  const G = by('Glass'), K = by('Kooch'), O = by('Old Tape'), N = by('Night Bus');
  const rows = [row(K, 200), row(G, 40), row(G, 10), row(null, 3), row(G, 2, { h: 8 }), row(G, 1), row(K, 1), row(G, 0, { h: 9 }), row(K, 0, { h: 10 }), row(O, 0, { ms: 20000, skip: true, h: 11 }), row(N, 0, { artist: 'Unknown Artist', h: 12 })];
  rows.sort((a, b) => a.at - b.at);
  for (const r of rows) await T.LOG.appendPlay(r);
  return { n: rows.length, glass: G.id, kooch: K.id };
});

for (const face of faces) for (const lang of langs) {
  console.log(`\n■ ${face} · ${lang}`);
  const { ctx, page, errs } = await session(face, lang);
  const rtl = lang === 'fa'; const root = ROOT[face];
  await goPlaylists(page, face); await page.waitForTimeout(500);
  ok(await page.waitForSelector(`${root} [data-stats-open]`, { timeout: 3000 }).catch(() => null), 'Listening stats button present');

  // empty
  await page.click(`${root} [data-stats-open]`);
  await page.waitForSelector(SH, { timeout: 4000 });
  ok(await page.evaluate(([r, d]) => !!document.querySelector(r)?.contains(document.querySelector(d)), [root, SH]), 'sheet mounted inside the face root');
  ok((await page.$eval(SH, e => getComputedStyle(e).direction)) === (rtl ? 'rtl' : 'ltr'), `sheet direction ${rtl ? 'rtl' : 'ltr'}`);
  ok(await page.evaluate((s) => document.activeElement?.matches(`${s} [data-range="30d"]`), SH), 'focus on the active period (30 days default)');
  await page.waitForSelector(`${SH} [data-stats-empty]`, { timeout: 3000 }).catch(() => {});
  ok(await page.$(`${SH} [data-stats-empty]`), 'empty state with no history');
  ok(await page.$eval(`${SH} [data-stats-export]`, e => e.disabled) && await page.$eval(`${SH} [data-stats-clear]`, e => e.disabled), 'Export / Clear disabled while empty');
  await page.keyboard.press('Escape');
  await page.waitForSelector(SH, { state: 'detached', timeout: 2000 }).catch(() => {});
  ok(!(await page.$(SH)), 'Esc closes');
  ok(await page.evaluate((s) => document.activeElement?.matches(s), `${root} [data-stats-open]`), 'focus returns to the opener');

  const sd = await seed(page);
  await page.click(`${root} [data-stats-open]`); await page.waitForSelector(`${SH} [data-stat="plays"]`, { timeout: 4000 });
  // 30 d: everything but -40 and -200 → 9
  ok(await card(page, 'plays') === '9', '30 days: 9 plays', await card(page, 'plays'));
  ok(await card(page, 'songs') === '5', '30 days: 5 songs (incl. one gone from the library)', await card(page, 'songs'));
  ok(await card(page, 'artists') === '5', '30 days: 5 artists ("Unknown Artist" snapshot falls back to the library tag)', await card(page, 'artists'));
  ok(/^\d+%$|^\d+٪$/.test(await card(page, 'skip')) && (await card(page, 'skip')).startsWith('11'), 'skip rate 1/9 = 11 %', await card(page, 'skip'));
  ok((await card(page, 'streak')).startsWith('4'), 'streak 4 days (today … -3)', await card(page, 'streak'));
  ok((await page.$$(`${SH} .nls-day`)).length === 30, '30 day bars', (await page.$$(`${SH} .nls-day`)).length);
  ok((await page.$$(`${SH} [data-kind="hours"] .nls-hist-col`)).length === 24, '24 hour columns');
  const wd = await page.$$eval(`${SH} [data-weekday]`, ns => ns.map(n => +n.dataset.weekday));
  ok(wd.length === 7 && wd[0] === (rtl ? 6 : 0), `week starts on ${rtl ? 'Saturday' : 'Sunday'}`, wd);

  // top songs
  const top = await page.$$eval(`${SH} [data-top-list="tracks"] [data-top-row]`, ns => ns.map(n => ({ k: n.dataset.topRow, d: n.disabled, t: n.querySelector('.nls-row-name').textContent })));
  ok(top[0]?.k === sd.glass, 'top song = Glass', top.slice(0, 3));
  const ghost = top.find(x => x.k === 'gone-1');
  ok(ghost && ghost.d, 'song gone from the library is listed but not playable', ghost);
  await page.click(`${SH} [data-top-row="${sd.glass}"]`);
  await page.waitForFunction((id) => window.__T.engine.currentId === id, sd.glass, { timeout: 4000 }).catch(() => {});
  const q = await page.evaluate(() => ({ cur: window.__T.engine.currentId, q: window.__T.useUi.getState().queue?.length ?? null }));
  ok(q.cur === sd.glass, 'click on a top song plays it', q);
  await page.evaluate(() => window.__T.engine.pause());

  // keyboard tabs (RTL aware)
  await page.focus(`${SH} [data-top="tracks"]`);
  await page.evaluate(() => { window.__keys = []; });
  await page.keyboard.press(rtl ? 'ArrowLeft' : 'ArrowRight');
  await page.waitForTimeout(120);
  ok(await page.$eval(`${SH} [data-top="artists"]`, e => e.getAttribute('aria-selected') === 'true' && document.activeElement === e), `${rtl ? '←' : '→'} moves to Artists (focus follows)`);
  const arts = await page.$$eval(`${SH} [data-top-list="artists"] .nls-row-name`, ns => ns.map(n => n.textContent));
  ok(arts[0] === 'Mirror Band' && !arts.some(a => /unknown/i.test(a)), 'top artist Mirror Band, no "Unknown Artist" row', arts);
  await page.keyboard.press('k'); await page.keyboard.press('n'); await page.keyboard.press(' ');
  ok((await page.evaluate(() => window.__keys.length)) === 0, 'keys inside the sheet never reach window shortcuts');
  ok(await page.evaluate(() => window.__T.engine.audio.paused), 'Space on a tab did not start playback');
  await page.keyboard.press('End'); await page.waitForTimeout(100);
  const genres = await page.$$eval(`${SH} [data-top-list="genres"] .nls-row-name`, ns => ns.map(n => n.textContent));
  ok(genres[0] === 'Rock' && genres.includes('Alternative'), 'End → Genres; Rock first ("Rock; Alternative" split)', genres);
  await page.click(`${SH} [data-top="albums"]`);
  const albums = await page.$$eval(`${SH} [data-top-list="albums"] .nls-row-name`, ns => ns.map(n => n.textContent));
  ok(albums.length >= 1 && albums[0] === 'Fixtures', 'albums: Fixtures first', albums);

  // ranges
  await page.click(`${SH} [data-range="7d"]`); await page.waitForTimeout(120);
  ok(await card(page, 'plays') === '8' && (await page.$$(`${SH} .nls-day`)).length === 7, '7 days: 8 plays, 7 bars', await card(page, 'plays'));
  await page.focus(`${SH} [data-range="7d"]`); await page.keyboard.press('Home'); await page.waitForTimeout(80);
  await page.click(`${SH} [data-range="all"]`); await page.waitForTimeout(120);
  ok(await card(page, 'plays') === '11', 'all time: 11 plays', await card(page, 'plays'));
  ok(await card(page, 'new') === '5', 'all time: 5 discoveries', await card(page, 'new'));
  ok(await page.evaluate(() => localStorage.getItem('nobody-stats-range')) === 'all', 'period remembered');
  const days = (await page.$$(`${SH} .nls-day`)).length;
  ok(days >= 200 && days <= 202, 'all-time day series from the first listen', days);

  // live update
  await page.evaluate(async (id) => { await window.__T.LOG.appendPlay({ at: Date.now() - 1000, id, ms: 60000, dur: 240, title: 'Kooch', artist: 'Sohrab', album: 'Fixtures', full: false, skip: false, src: 'classic' }); }, sd.kooch);
  await page.waitForTimeout(150);
  ok(await card(page, 'plays') === '12', 'a new listen shows up live', await card(page, 'plays'));

  // trap + overflow
  for (let i = 0; i < 40; i++) await page.keyboard.press('Tab');
  ok(await inSheet(page), 'Tab ×40 stays inside');
  for (let i = 0; i < 9; i++) await page.keyboard.press('Shift+Tab');
  ok(await inSheet(page), 'Shift+Tab stays inside');
  const ov = await overflow(page, SH);
  ok(ov.sw <= ov.cw + 1 && ov.bad.length === 0 && ov.right <= ov.vw, 'no horizontal overflow at 1280 px', ov);
  await page.setViewportSize({ width: 520, height: 820 }); await page.waitForTimeout(200);
  const ov2 = await overflow(page, SH);
  ok(ov2.sw <= ov2.cw + 1 && ov2.bad.length === 0 && ov2.right <= ov2.vw + 0.5 && ov2.left >= -0.5, 'no horizontal overflow at 520 px', ov2);
  await page.setViewportSize({ width: 1280, height: 820 }); await page.waitForTimeout(150);
  if (rtl) {
    const pos = await page.evaluate((s) => { const x = document.querySelector(`${s} .nte-head .nte-icon`).getBoundingClientRect(); const t = document.querySelector(`${s} .nte-title`).getBoundingClientRect(); const a = document.querySelector(`${s} [data-range="7d"]`).getBoundingClientRect(); const b = document.querySelector(`${s} [data-range="all"]`).getBoundingClientRect(); return { closeX: x.left, titleX: t.left, a: a.left, b: b.left }; }, SH);
    ok(pos.closeX < pos.titleX && pos.a > pos.b, 'RTL: close on the left, periods run right → left', pos);
  }
  if (face === 'cinema') await page.screenshot({ path: `/home/user/work/shot-${face}-${lang}.png` });
  else await page.screenshot({ path: `/home/user/work/shot-${face}-${lang}.png` });

  // keep history toggle
  await page.click(`${SH} [data-stats-keep]`);
  ok(await page.evaluate(() => window.__T.useSettings.getState().statsEnabled === false) && await page.$(`${SH} [data-stats-off]`), 'toggle off → setting off + note');
  await page.click(`${SH} [data-stats-keep]`);
  ok(await page.evaluate(() => window.__T.useSettings.getState().statsEnabled !== false) && !(await page.$(`${SH} [data-stats-off]`)), 'toggle back on');

  // CSV
  const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 4000 }).catch(() => null), page.click(`${SH} [data-stats-export]`)]);
  let csv = ''; if (dl) { const p = await dl.path(); csv = fs.readFileSync(p, 'utf8'); }
  const lines = csv.replace(/^\ufeff/, '').trim().split('\r\n');
  ok(dl && /^nobody-listening-\d{4}-\d\d-\d\d\.csv$/.test(dl.suggestedFilename()), 'CSV download name', dl && dl.suggestedFilename());
  ok(csv.startsWith('\ufeff') && lines[0].startsWith('started_utc,artist,title') && lines.length === 13 && csv.includes('Ghost Song'), 'CSV: BOM, header + 12 rows', lines.length);

  // clear
  await page.click(`${SH} [data-stats-clear]`);
  ok(await page.$(`${SH} [data-stats-ask]`), 'Clear asks first');
  await page.keyboard.press('Escape'); await page.waitForTimeout(80);
  ok(await page.$(SH) && !(await page.$(`${SH} [data-stats-ask]`)), 'Esc backs out of the prompt, sheet stays');
  await page.click(`${SH} [data-stats-clear]`); await page.click(`${SH} [data-stats-clear-yes]`);
  await page.waitForSelector(`${SH} [data-stats-empty]`, { timeout: 3000 }).catch(() => {});
  ok(await page.$(`${SH} [data-stats-empty]`) && (await page.evaluate(async () => (await window.__T.LOG.getPlays()).length)) === 0, 'Delete → empty, log cleared');
  const hit = await page.evaluate(() => { const e = document.elementFromPoint(5, 5); return e && (e.className + '|' + e.tagName); });
  ok(String(hit).startsWith('nte-backdrop'), 'backdrop is what sits around the sheet', hit);
  await page.mouse.click(5, 5);
  await page.waitForTimeout(150);
  ok(!(await page.$(SH)), 'backdrop click closes');
  ok(errs.length === 0, 'no page errors', errs);
  await ctx.close();
}
await browser.close();
console.log(`\n${pass}/${pass + fail} passed`); if (fail) { console.log('FAILED:', fails); process.exit(1); }
