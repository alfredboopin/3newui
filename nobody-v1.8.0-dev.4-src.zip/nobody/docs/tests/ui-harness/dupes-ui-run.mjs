// NOBODY 1.7.0 · Duplicate finder sheet, Chromium UI run (Cinema / EELA / ALOK, EN + FA/RTL)
// Fixtures: fixtures-dupes.sh (own dir t-dupes, rebuilt for every face/lang because files really
// move to /home/user/work/trash-bin through the fs:trash stand-in). Grouping rules themselves are
// covered by dupes-run.ts; this run checks the sheet, the keep/remove flow and what survives a restart.
import { chromium } from '/opt/sd-artifact/node_modules/playwright/index.mjs';
import { execSync } from 'child_process'; import fs from 'fs';
const LIB = '/home/user/work/t-dupes/lib'; const BIN = '/home/user/work/trash-bin';
const ROOT = { cinema: '#nc-root', eela: '#ne-root', alok: '#na-root' };
const SH = '[data-dupes-sheet]';
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, extra) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, extra !== undefined ? JSON.stringify(extra) : ''); } };
const browser = await chromium.launch({ executablePath: '/ms-playwright/chromium-1208/chrome-linux64/chrome', args: ['--autoplay-policy=no-user-gesture-required'] });
const faces = (process.env.FACES || 'cinema,eela,alok').split(','); const langs = (process.env.LANGS || 'en,fa').split(',');
const latin = (s) => String(s || '').replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
const RAW_KEY = /\b(sc|dp|ls|st|m3u)[A-Z][A-Za-z_]+\b|\{\{\w+\}\}/;
const PERSIAN = /[\u0600-\u06FF]/;
const N_ALL = 11;
const goPlaylists = (page, face) => page.evaluate((face) => {
  const T = window.__T; if (face === 'cinema') T.useUi.getState().setView('playlists'); else if (face === 'eela') T.useEelaUi.getState().setView('playlists'); else { const s = T.useAlokUi.getState(); if (s.view !== 'playlists') s.toggleView('playlists'); }
}, face);
const waitFor = async (page, fn, arg, ms = 8000) => { try { await page.waitForFunction(fn, arg, { timeout: ms }); return true; } catch { return false; } };
const idOf = (page, rel) => page.evaluate((rel) => Object.values(window.__T.useLibrary.getState().tracks).find((t) => (t.filePath || '').replace(/\\/g, '/').endsWith('/' + rel))?.id || null, rel);
const nameOf = (page, id) => page.evaluate((id) => { const p = window.__T.useLibrary.getState().tracks[id]?.filePath || ''; return p.split('/').slice(-2).join('/'); }, id);
/** groups as sorted "A/x|B/y" strings, keep marked with * */
const groups = (page) => page.evaluate((SH) => [...document.querySelectorAll(`${SH} [data-dp-group]`)].map((g) => [...g.querySelectorAll('[data-dp-copy]')].map((c) => {
  const p = (window.__T.useLibrary.getState().tracks[c.getAttribute('data-dp-copy')]?.filePath || '').split('/').slice(-2).join('/');
  return (c.hasAttribute('data-keep') ? '*' : '') + p; }).sort((a, b) => a.replace('*', '').localeCompare(b.replace('*', ''))).join('|')).sort(), SH);
const groupWith = (page, rel) => page.evaluate(([SH, rel]) => { for (const g of document.querySelectorAll(`${SH} [data-dp-group]`)) for (const c of g.querySelectorAll('[data-dp-copy]')) { if ((window.__T.useLibrary.getState().tracks[c.getAttribute('data-dp-copy')]?.filePath || '').endsWith('/' + rel)) return g.getAttribute('data-dp-group'); } return null; }, [SH, rel]);
const G = (sig) => `${SH} [data-dp-group="${sig}"]`;
const summary = (page) => page.$eval(`${SH} [data-dp-summary]`, (e) => e.textContent).then(latin).catch(() => '');
const toasts = (page) => page.evaluate(() => window.__T.useUi.getState().toasts.map(t => [t.msg, t.sub || '', t.kind]));
const clearToasts = (page) => page.evaluate(() => window.__T.useUi.setState({ toasts: [] }));
const exists = (p) => fs.existsSync(p);
const inSheet = (page) => page.evaluate((s) => !!document.querySelector(s)?.contains(document.activeElement), SH);
const overflow = (page) => page.$eval(SH, (el) => { const b = el.querySelector('.nte-body'); const f = el.querySelector('.nte-foot'); const r = el.getBoundingClientRect(); return { sw: b.scrollWidth, cw: b.clientWidth, fw: f.scrollWidth, fc: f.clientWidth, l: r.left, r: r.right, vw: innerWidth }; });
const mode = (page) => page.$eval(`${SH} [data-dp-mode][aria-checked="true"]`, (e) => e.getAttribute('data-dp-mode')).catch(() => null);
const openSheet = async (page, root) => { await page.click(`${root} [data-dupes-open]`); return !!(await page.waitForSelector(SH, { timeout: 4000 }).catch(() => null)); };
const boot = async (page, n) => page.waitForFunction((n) => window.__T && Object.keys(window.__T.useLibrary.getState().tracks).length >= n, n, { timeout: 25000 });

for (const face of faces) for (const lang of langs) {
  console.log(`\n■ ${face} · ${lang}`);
  execSync('bash /home/user/work/h/fixtures-dupes.sh');
  const rtl = lang === 'fa'; const root = ROOT[face];
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 820 } }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', e => errs.push(String(e).slice(0, 300)));
  await page.addInitScript(([lib, face, lang]) => { if (!sessionStorage.getItem('seeded')) { localStorage.clear(); indexedDB.deleteDatabase('nobody-stats'); localStorage.setItem('nobody-player-state-v2', JSON.stringify({ folderPaths: [lib], lang })); localStorage.setItem('nobody-ui-mode', face); sessionStorage.setItem('seeded', '1'); } }, [LIB, face, lang]);
  await page.goto('http://127.0.0.1:8787/');
  await boot(page, N_ALL);
  await page.evaluate((lang) => window.__T.useSettings.getState().set('lang', lang), lang);
  await page.waitForTimeout(500);
  const id = {}; for (const r of ['A/01 Kooch.flac', 'B/Kooch.mp3', 'A/Glass.mp3', 'B/Glass (Remastered).mp3', 'A/یاد.mp3', 'B/ياد.mp3', 'A/Saffron.flac']) id[r] = await idOf(page, r);
  ok(Object.values(id).every(Boolean) && (await page.evaluate(() => Object.keys(window.__T.useLibrary.getState().tracks).length)) === N_ALL, `library: ${N_ALL} fixture songs`);

  // listening data on the copy that will go: it must move to the kept FLAC
  await page.evaluate((m) => { const L = window.__T.useLibrary.getState(); L.setRating(m, 4); L.recordPlay(m); L.recordPlay(m); L.toggleLike(m); L.createPlaylistFrom('Road', [m]); }, id['B/Kooch.mp3']);

  // ── 1. entry, open, direction, focus
  await goPlaylists(page, face); await page.waitForTimeout(400);
  ok(!!(await page.waitForSelector(`${root} [data-dupes-open]`, { timeout: 4000 }).catch(() => null)), 'Find duplicates entry in Playlists');
  ok(await openSheet(page, root), 'sheet opens');
  ok(await page.evaluate(([r, s]) => !!document.querySelector(r)?.contains(document.querySelector(s)), [root, SH]), 'sheet mounted inside the face root');
  ok((await page.$eval(SH, e => getComputedStyle(e).direction)) === (rtl ? 'rtl' : 'ltr'), `direction ${rtl ? 'rtl' : 'ltr'}`);
  const txt0 = await page.$eval(SH, e => e.innerText);
  ok(!RAW_KEY.test(txt0), 'no raw i18n keys / {{placeholders}}', (txt0.match(RAW_KEY) || [])[0]);
  ok(!rtl || PERSIAN.test(await page.$eval(`${SH} .nte-title`, e => e.textContent)), 'title in Persian (fa)');
  ok(await page.evaluate(() => document.activeElement?.getAttribute('data-dp-mode') === 'song'), 'focus on the active mode (Same song)');

  // ── 2. song mode
  let g = await groups(page);
  ok(g.length === 3, 'song mode: 3 groups', g);
  ok(g.includes('*A/01 Kooch.flac|B/Kooch.mp3'), 'Kooch FLAC ↔ MP3 "feat." grouped, FLAC suggested', g);
  ok(g.includes('A/Glass.mp3|*B/Glass (Remastered).mp3'), 'Glass ↔ "Glass (Remastered 2011)" grouped, 256 kbps suggested', g);
  ok(g.some((x) => x.includes('A/یاد.mp3') && x.includes('B/ياد.mp3')), 'Persian ی/ک ↔ Arabic ي/ك grouped', g);
  ok(!g.some((x) => /Night Bus|Paper|Saffron/.test(x)), 'live take, other titles, unique song: not grouped');
  let sm = await summary(page);
  ok(/3\D+3\D/.test(sm), 'summary: 3 groups · 3 extra copies', sm);
  const kooch = await groupWith(page, 'B/Kooch.mp3');
  ok(!!(await page.$(`${G(kooch)} [data-dp-copy="${id['A/01 Kooch.flac']}"] [data-flag="best"]`)) && !!(await page.$(`${G(kooch)} [data-dp-copy="${id['B/Kooch.mp3']}"] [data-flag="remove"]`)), 'flags: Suggested + Keep / Will be removed');
  const chips = await page.$eval(`${G(kooch)} [data-dp-copy="${id['B/Kooch.mp3']}"]`, (e) => e.innerText).then(latin);
  ok(/MP3/.test(chips) && !/MPEG/.test(chips) && /320/.test(chips) && /KB|MB|کیلو|مگا/i.test(chips) && /2/.test(chips) && !!(await page.$(`${G(kooch)} [data-dp-copy="${id['B/Kooch.mp3']}"] .lucide-star`)), 'copy chips: MP3 (not MPEG), kbps, size, rating, plays', chips);

  // ── 3. mode switch by keyboard (RTL-aware arrows), remembered
  await page.focus(`${SH} [data-dp-mode="song"]`);
  await page.keyboard.press(rtl ? 'ArrowLeft' : 'ArrowRight'); await page.waitForTimeout(200);
  ok(await mode(page) === 'tags' && await page.evaluate(() => document.activeElement?.getAttribute('data-dp-mode') === 'tags'), `${rtl ? '←' : '→'} → "Same tags", focus follows`);
  g = await groups(page);
  ok(g.length === 4 && g.some((x) => x.includes('A/Night Bus.mp3') && x.includes('B/Night Bus (Live).mp3')), 'tags mode: + Night Bus 6 s ↔ 16 s (4 groups)', g);
  ok(PERSIAN.test(await page.$eval(`${SH} [data-dp-hint]`, e => e.textContent)) === rtl, 'mode hint localized');
  await page.keyboard.press(rtl ? 'ArrowLeft' : 'ArrowRight'); await page.waitForTimeout(200);
  g = await groups(page);
  ok(await mode(page) === 'file' && g.length === 2 && g.some((x) => /Paper Moon/.test(x) && /Paper Noon/.test(x)) && g.some((x) => /یاد/.test(x) && /ياد/.test(x)), 'file mode: Paper Moon ↔ Paper Noon (same bytes, other tags) + the یاد pair', g);
  ok(await page.evaluate(() => localStorage.getItem('nobody-dupes-mode')) === 'file', 'mode remembered');
  await page.keyboard.press('Home'); await page.waitForTimeout(200);
  ok(await mode(page) === 'song', 'Home → back to "Same song"');

  // ── 4. Not duplicates → hidden, survives reopen, Show hidden brings it back
  const yad = await groupWith(page, 'A/یاد.mp3');
  await page.click(`${G(yad)} [data-dp-ignore]`); await page.waitForTimeout(200);
  ok((await groups(page)).length === 2 && !(await page.$(G(yad))), 'Not duplicates → group hidden');
  ok(await inSheet(page), 'focus stays in the sheet after the group went (Esc / Tab keep working)', await page.evaluate(() => document.activeElement?.tagName));
  ok(/1/.test(latin(await page.$eval(`${SH} [data-dp-unhide]`, e => e.textContent).catch(() => ''))), '"Show hidden (1)" in the footer');
  await page.keyboard.press('Escape'); await page.waitForTimeout(250); await openSheet(page, root); await page.waitForTimeout(200);
  ok((await groups(page)).length === 2, 'hidden group stays hidden after reopening');
  await page.click(`${SH} [data-dp-unhide]`); await page.waitForTimeout(200);
  ok((await groups(page)).length === 3 && !(await page.$(`${SH} [data-dp-unhide]`)), 'Show hidden → back (3 groups)');
  ok(await inSheet(page), 'focus stays in the sheet after "Show hidden" went away');

  // ── 5. pick another keeper → flags + summary size follow
  sm = await summary(page);
  await page.click(`${G(kooch)} [data-dp-keep="${id['B/Kooch.mp3']}"]`); await page.waitForTimeout(150);
  const sm2 = await summary(page);
  ok(!!(await page.$(`${G(kooch)} [data-dp-copy="${id['B/Kooch.mp3']}"][data-keep]`)) && !(await page.$(`${G(kooch)} [data-dp-copy="${id['A/01 Kooch.flac']}"][data-keep]`)), 'keep radio moves the Keep flag');
  ok(sm2 !== sm, 'summary "to free" follows the pick', [sm, sm2]);
  await page.focus(`${G(kooch)} [data-dp-keep="${id['B/Kooch.mp3']}"]`); await page.keyboard.press('ArrowUp'); await page.waitForTimeout(150);
  ok(!!(await page.$(`${G(kooch)} [data-dp-copy="${id['A/01 Kooch.flac']}"][data-keep]`)) && await summary(page) === sm, '↑ inside the group (native radios) → FLAC kept again');

  // ── 6. preview one copy: queue = the group's copies; flagged as playing
  await page.click(`${G(await groupWith(page, 'A/Glass.mp3'))} [data-dp-play="${id['A/Glass.mp3']}"]`); await page.waitForTimeout(300);
  const eq = await page.evaluate(() => ({ cur: window.__T.engine.currentId, q: [...window.__T.engine.queue] }));
  ok(eq.cur === id['A/Glass.mp3'] && eq.q.length === 2 && eq.q.includes(id['B/Glass (Remastered).mp3']), 'play this copy → it plays, queue = the 2 copies', eq);
  ok(await waitFor(page, ([s, i]) => !!document.querySelector(`${s} [data-dp-copy="${i}"] [data-flag="remove"]`)?.textContent && window.__T.useUi.getState().currentId === i, [SH, id['A/Glass.mp3']], 3000), 'playing copy flagged "Playing · kept"');

  // ── 7. Recycle Bin + one group: confirm, focus, Esc, remove
  const tr = await page.$(`${SH} [data-dp-trash]`);
  ok(!!tr, 'Recycle Bin option shown (desktop)');
  await page.check(`${SH} [data-dp-trash]`);
  ok(await page.evaluate(() => localStorage.getItem('nobody-dupes-trash')) === '1', 'Recycle Bin choice remembered');
  await page.click(`${G(kooch)} [data-dp-resolve]`);
  ok(await page.evaluate(() => !!document.activeElement?.closest('[data-dp-ask]')), 'focus on Cancel inside the confirm (right away)', await page.evaluate(() => document.activeElement?.outerHTML.slice(0, 80)));
  const ask = latin(await page.$eval(`${SH} [data-dp-ask]`, e => e.innerText).catch(() => ''));
  ok(/1/.test(ask) && (rtl ? /سطل/.test(ask) : /Recycle Bin/.test(ask)) && !RAW_KEY.test(ask), 'confirm: 1 copy, goes to the Recycle Bin', ask);
  await page.keyboard.press('Escape'); await page.waitForTimeout(150);
  ok(!(await page.$(`${SH} [data-dp-ask]`)) && !!(await page.$(SH)), 'Esc backs out of the confirm, sheet stays');
  await page.click(`${G(kooch)} [data-dp-resolve]`); await clearToasts(page);
  await page.click(`${SH} [data-dp-ask-yes]`);
  ok(await waitFor(page, (i) => !window.__T.useLibrary.getState().tracks[i], id['B/Kooch.mp3'], 5000), 'MP3 copy left the library');
  ok(!exists(`${LIB}/B/Kooch.mp3`) && exists(`${BIN}/Kooch.mp3`) && exists(`${LIB}/A/01 Kooch.flac`), 'file moved to the Recycle Bin, FLAC untouched');
  const kept = await page.evaluate((k) => { const L = window.__T.useLibrary.getState(); return { r: L.ratings[k], p: L.playCounts[k], liked: L.isLiked(k), road: L.playlists.find((p) => p.name === 'Road')?.trackIds.includes(k) }; }, id['A/01 Kooch.flac']);
  ok(kept.r === 4 && kept.p >= 2 && kept.liked && kept.road, 'kept FLAC inherits rating, plays, Liked, playlist', kept);
  let ts = await toasts(page);
  ok(ts.some(([m, s, k]) => /1/.test(latin(m)) && /1/.test(latin(s)) && k === 'success' && (!rtl || PERSIAN.test(m))), 'toast: removed 1 · 1 to the Recycle Bin', ts);
  ok((await groups(page)).length === 2 && !(await page.$(G(kooch))), 'group gone from the list');

  // ── 8. a copy that can't be trashed stays (E_BUSY)
  const yad2 = await groupWith(page, 'A/یاد.mp3');
  const yadOut = await page.$eval(`${G(yad2)} [data-dp-copy]:not([data-keep])`, (e) => e.getAttribute('data-dp-copy'));
  const yadOutPath = await page.evaluate((i) => window.__T.useLibrary.getState().tracks[i].filePath, yadOut);
  await page.evaluate((p) => { window.__trashFail = [p]; }, yadOutPath); await clearToasts(page);
  await page.click(`${G(yad2)} [data-dp-resolve]`); await page.click(`${SH} [data-dp-ask-yes]`); await page.waitForTimeout(700);
  ts = await toasts(page);
  ok(ts.some(([m, s, k]) => k === 'error' && /1/.test(latin(s))) && exists(yadOutPath) && !!(await page.evaluate((i) => window.__T.useLibrary.getState().tracks[i], yadOut)), 'Recycle Bin refused → file + row stay, error toast says 1 stayed', ts);
  ok(!!(await page.$(G(yad2))), 'that group is still listed');

  // ── 9. Remove all with the playing copy inside
  await page.evaluate(() => { window.__trashFail = []; }); await clearToasts(page);
  await page.click(`${SH} [data-dp-resolve-all]`);
  const ask2 = latin(await page.$eval(`${SH} [data-dp-ask]`, e => e.innerText).catch(() => ''));
  ok(/\b1\b|1 /.test(ask2) && (rtl ? PERSIAN.test(ask2) : /playing/i.test(ask2)), 'Remove all: confirm counts 1 (playing copy excluded) and says it stays', ask2);
  await page.click(`${SH} [data-dp-ask-yes]`); await page.waitForTimeout(800);
  ts = await toasts(page);
  ok(!exists(yadOutPath) && exists(`${LIB}/A/Glass.mp3`) && !!(await page.evaluate((i) => window.__T.useLibrary.getState().tracks[i], id['A/Glass.mp3'])), 'یاد copy trashed, the playing Glass stays (file + row)');
  ok(ts.some(([m, s, k]) => k === 'success' && /1/.test(latin(m)) && /1/.test(latin(s))), 'toast: removed 1 · 1 playing, kept', ts);
  ok(await page.evaluate(() => window.__T.engine.currentId) === id['A/Glass.mp3'], 'playback not interrupted');

  // ── 10. library only (no Recycle Bin): file stays, never imported again
  await page.evaluate(() => window.__T.engine.stopAndClear()); await page.waitForTimeout(200);
  await page.uncheck(`${SH} [data-dp-trash]`); await clearToasts(page);
  const glass = await groupWith(page, 'A/Glass.mp3');
  await page.click(`${G(glass)} [data-dp-resolve]`);
  const ask3 = await page.$eval(`${SH} [data-dp-ask]`, e => e.innerText).catch(() => '');
  ok(!(rtl ? /سطل/.test(ask3) : /Recycle Bin/.test(ask3)), 'confirm says library only (no Recycle Bin)', ask3);
  await page.click(`${SH} [data-dp-ask-yes]`);
  ok(await waitFor(page, (i) => !window.__T.useLibrary.getState().tracks[i], id['A/Glass.mp3'], 5000) && exists(`${LIB}/A/Glass.mp3`), 'Glass 128 left the library, file still on disk');
  ok((await page.$$(`${SH} [data-dp-group]`)).length === 0 && !!(await page.$(`${SH} [data-dp-empty]`)), 'no duplicates left → empty state');
  await page.click(`${SH} [data-dp-mode="file"]`); await page.waitForTimeout(150);

  // ── 11. Tab trap, Esc, focus back
  for (let i = 0; i < 14; i++) await page.keyboard.press('Tab');
  ok(await inSheet(page), 'Tab stays inside the sheet');
  for (let i = 0; i < 14; i++) await page.keyboard.press('Shift+Tab');
  ok(await inSheet(page), 'Shift+Tab stays inside the sheet');
  await page.evaluate(() => { window.__keys = []; }); await page.keyboard.press('Space');
  await page.keyboard.press('Escape'); await page.waitForTimeout(250);
  ok(!(await page.$(SH)), 'Esc closes');
  ok(await page.evaluate(() => document.activeElement?.hasAttribute('data-dupes-open')), 'focus back on the Find duplicates button');

  // ── 12. restart: removed copies stay out, inherited data + mode kept
  await page.waitForTimeout(400);
  await page.reload();
  await boot(page, N_ALL - 3); await page.waitForTimeout(1500);
  const after = await page.evaluate(() => Object.values(window.__T.useLibrary.getState().tracks).map((t) => (t.filePath || '').split('/').slice(-2).join('/')));
  ok(after.length === N_ALL - 3 && !after.includes('A/Glass.mp3'), `after restart: ${N_ALL - 3} songs, Glass 128 (still on disk) not imported again`, after);
  const kept2 = await page.evaluate(() => { const L = window.__T.useLibrary.getState(); const k = Object.values(L.tracks).find((t) => /01 Kooch\.flac$/.test(t.filePath || ''))?.id; return { r: L.ratings[k], liked: L.isLiked(k), road: L.playlists.find((p) => p.name === 'Road')?.trackIds.includes(k) }; });
  ok(kept2.r === 4 && kept2.liked && kept2.road, 'after restart: kept FLAC still has rating, Liked, playlist', kept2);
  await goPlaylists(page, face); await page.waitForTimeout(400); await openSheet(page, root); await page.waitForTimeout(200);
  ok(await mode(page) === 'file' && (await groups(page)).length === 1, 'after restart: last mode (file) + Paper pair');

  // ── 13. layout
  for (const w of [1280, 520]) { await page.setViewportSize({ width: w, height: 820 }); await page.waitForTimeout(250); const o = await overflow(page); ok(o.sw <= o.cw + 1 && o.fw <= o.fc + 1 && o.l >= -1 && o.r <= o.vw + 1, `no horizontal overflow at ${w} px`, o); }
  await page.setViewportSize({ width: 1280, height: 820 });
  await page.keyboard.press('Escape'); await page.waitForTimeout(250);

  // ── 14. command palette (Cinema + ALOK; EELA has none)
  if (face !== 'eela') {
    await page.evaluate((face) => face === 'cinema' ? window.__T.useUi.getState().setShowPalette(true) : window.__T.useAlokUi.getState().setShowCmd(true), face);
    await page.waitForTimeout(400);
    await page.keyboard.type(rtl ? 'تکراری' : 'duplic'); await page.waitForTimeout(250);
    const got = await page.evaluate(() => document.activeElement?.tagName === 'INPUT');
    await page.keyboard.press('Enter');
    ok(got && !!(await page.waitForSelector(`${root} ${SH}`, { timeout: 2000 }).catch(() => null)), 'command palette → Find duplicates (inside this face)');
    await page.keyboard.press('Escape'); await page.waitForTimeout(200);
  }
  ok(errs.length === 0, 'no page errors', errs);
  await ctx.close();
}
await browser.close();
console.log(`\n${pass}/${pass + fail} passed`);
if (fails.length) console.log('FAILED:\n - ' + fails.join('\n - '));
