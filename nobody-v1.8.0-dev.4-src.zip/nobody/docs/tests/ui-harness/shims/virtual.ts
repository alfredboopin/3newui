// test shim: render every row (no windowing), deterministic offsets
export function useVirtualizer(o: any) {
  const n = o.count || 0, m = o.scrollMargin || 0, g = o.gap || 0;
  const items: any[] = []; let s = m;
  for (let i = 0; i < n; i++) { const sz = o.estimateSize(i); items.push({ index: i, key: o.getItemKey ? o.getItemKey(i) : i, start: s, end: s + sz, size: sz, lane: 0 }); s += sz + g; }
  return { getVirtualItems: () => items, getTotalSize: () => s - m + m, measureElement: () => {}, scrollToIndex: () => {}, scrollToOffset: () => {}, measure: () => {}, options: o };
}
