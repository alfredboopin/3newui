export const convertFileSrc = (p: string) => p; export const readFile = async () => new Uint8Array(); export const stat = async () => ({ size: 0 });
export const open = async () => null; export const SeekMode = {}; export const writeTextFile = async () => {}; export const writeFile = async () => {};
export const readDir = async () => []; export const join = async (...a: string[]) => a.join('/'); export const invoke = async () => null;
