const http = require('http'), fs = require('fs'), fsp = fs.promises, path = require('path');
const tags = require('/home/user/work/src/electron/tags/index.cjs');
const log = { readSlice: {}, stat: 0 }; const secrets = new Map();
const ROOT = '/home/user/work/h/dist'; const PUB = '/home/user/work/src/public';
function b64(u8) { return Buffer.from(u8).toString('base64'); }
async function walk(root, exts) {
  const out = []; const st = [root];
  while (st.length) { const d = st.pop(); let es; try { es = await fsp.readdir(d, { withFileTypes: true }); } catch { continue; }
    for (const e of es) { const f = path.join(d, e.name); if (e.isDirectory()) st.push(f); else if (exts.has(path.extname(e.name).toLowerCase())) out.push(f); } }
  return out;
}
const fns = {
  async stat(p) { log.stat++; const i = await fsp.stat(p); return { size: i.size, isFile: i.isFile(), mtimeMs: i.mtimeMs }; },
  async readSlice(p, start, len) { log.readSlice[p] = (log.readSlice[p] || 0) + 1; const fh = await fsp.open(p, 'r'); try { const b = Buffer.alloc(len); const { bytesRead } = await fh.read(b, 0, len, start); return { __b64: b64(b.subarray(0, bytesRead)) }; } finally { await fh.close(); } },
  async readFile(p) { return { __b64: b64(await fsp.readFile(p)) }; },
  async walk(root, exts) { return walk(root, new Set(exts.map(e => '.' + e))); },
  async writeBinaryFile(p, data) { await fsp.writeFile(p, Buffer.from(data.__b64, 'base64')); return true; },
  async writeTextFile(p, t) { await fsp.writeFile(p, t); return true; },
  async readTags(p) { try { return { ok: true, ...(await tags.readTags(p)) }; } catch (e) { return { ok: false, code: tags.errorCode(e) }; } },
  async writeTags(p, patch) { if (patch.cover && patch.cover.data) patch.cover.data = new Uint8Array(Buffer.from(patch.cover.data.__b64, 'base64'));
    try { return { ok: true, ...(await tags.writeTags(p, patch)) }; } catch (e) { return { ok: false, code: tags.errorCode(e) }; } },
  async pickPlaylistImport(paths) { const out = []; for (const p of paths) { try { const st = await fsp.stat(p); if (st.size > 8 * 1024 * 1024) { out.push({ path: p, error: 'E_TOO_LARGE' }); continue; } out.push({ path: p, bytes: { __b64: b64(await fsp.readFile(p)) } }); } catch { out.push({ path: p, error: 'E_READ' }); } } return out; },
  async writePlaylist(p, text) { if (!/\.m3u8?$/i.test(p)) throw new Error('Blocked file type'); const body = Buffer.from(String(text), 'utf-8'); await fsp.writeFile(p, /\.m3u$/i.test(p) ? Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), body]) : body); return true; },
  async readText(p) { return (await fsp.readFile(p)).toString('utf-8'); },
  async readHex(p, n) { return (await fsp.readFile(p)).subarray(0, n).toString('hex'); },
  async secretGet(n) { return secrets.has(n) ? secrets.get(n) : null; }, async secretSet(n, v) { if (!/^scrobble\./.test(n)) throw new Error('Blocked secret name'); secrets.set(n, String(v)); return true; },
  async secretDelete(n) { secrets.delete(n); return true; }, async __secrets() { return Object.fromEntries(secrets); }, async __secretReset() { secrets.clear(); return true; },
  // fs:trash stand-in: moves the file into /home/user/work/trash-bin (outside every library) (never a hard delete), same result shape as main.cjs
  async trash(paths) { const out = []; for (const p of paths) { try { const st = await fsp.lstat(p); if (!st.isFile()) { out.push({ path: p, ok: false, code: 'E_TYPE' }); continue; } const d = '/home/user/work/trash-bin'; await fsp.mkdir(d, { recursive: true }); await fsp.rename(p, path.join(d, path.basename(p))); out.push({ path: p, ok: true }); } catch (e) { out.push({ path: p, ok: false, code: e && e.code === 'ENOENT' ? 'E_NOT_FOUND' : 'E_BUSY' }); } } return out; },
  async exists(p) { return fs.existsSync(p); },
  async __log() { return log; }, async __resetLog() { log.readSlice = {}; log.stat = 0; return true; },
};
http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/rpc') { let body = ''; req.on('data', c => body += c); req.on('end', async () => {
      try { const { fn, args } = JSON.parse(body); const r = await fns[fn](...args); res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ r })); }
      catch (e) { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ err: String(e && e.message || e) })); } }); return; }
  if (u.pathname.startsWith('/app/')) {
    const p = decodeURIComponent(u.pathname.slice(5)); let st; try { st = await fsp.stat(p); } catch { res.writeHead(404); return res.end(); }
    const size = st.size; const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || ''); const ext = path.extname(p).slice(1);
    const type = { flac: 'audio/flac', mp3: 'audio/mpeg', wav: 'audio/wav' }[ext] || 'application/octet-stream';
    if (m) { const s = m[1] ? +m[1] : 0; const e = m[2] ? +m[2] : size - 1;
      res.writeHead(206, { 'content-type': type, 'accept-ranges': 'bytes', 'content-range': `bytes ${s}-${e}/${size}`, 'content-length': e - s + 1, 'access-control-allow-origin': '*' });
      fs.createReadStream(p, { start: s, end: e }).pipe(res); }
    else { res.writeHead(200, { 'content-type': type, 'accept-ranges': 'bytes', 'content-length': size, 'access-control-allow-origin': '*' }); fs.createReadStream(p).pipe(res); }
    return; }
  let f = path.join(ROOT, u.pathname === '/' ? 'index.html' : u.pathname); if (!fs.existsSync(f)) f = path.join(PUB, u.pathname);
  try { const d = await fsp.readFile(f); res.writeHead(200, { 'content-type': f.endsWith('.js') ? 'text/javascript' : f.endsWith('.css') ? 'text/css' : f.endsWith('.html') ? 'text/html' : 'application/octet-stream' }); res.end(d); } catch { res.writeHead(404); res.end(); }
}).listen(8787, () => console.log('up'));
