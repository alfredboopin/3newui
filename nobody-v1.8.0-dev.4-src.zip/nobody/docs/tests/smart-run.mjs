// NOBODY · smart playlist rule engine + rating sort — node test (1.7.0-dev.7)
// Run: node docs/tests/smart-run.mjs   (needs esbuild; bundles smart.spec.ts)
import { build } from "esbuild";
import { fileURLToPath, pathToFileURL } from "node:url";
import { dirname, join } from "node:path";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";

const here = dirname(fileURLToPath(import.meta.url));
const out = mkdtempSync(join(tmpdir(), "nobody-smart-"));
const file = join(out, "spec.mjs");
await build({ entryPoints: [join(here, "smart.spec.ts")], bundle: true, platform: "node", format: "esm", outfile: file, logLevel: "error" });
try {
  const { run } = await import(pathToFileURL(file).href);
  const { pass, fail } = await run();
  console.log(`\n${pass}/${pass + fail} passed`);
  process.exitCode = fail ? 1 : 0;
} finally {
  rmSync(out, { recursive: true, force: true });
}
