// NOBODY 1.8.0 · Phase 5 part 1: desktop integration, node run (no Electron needed)
//   part A: electron/desktop.cjs pure helpers + the tray/thumbar/jump-list shell on a fake Electron
//   part B: electron/main.cjs booted against a fake Electron (app lifecycle, IPC, windows):
//           open-with queue, second instance, jump-list commands, close to tray, window state,
//           global hotkeys IPC (1.8.0-dev.3), --nobody-quit (1.8.0-dev.4)
// run: node docs/tests/desktop-run.cjs
const path = require('path'); const fs = require('fs'); const os = require('os'); const Module = require('module');
const ROOT = path.resolve(__dirname, '../..');
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, x) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, x !== undefined ? JSON.stringify(x) : ''); } };
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const D = require(path.join(ROOT, 'electron/desktop.cjs'));
const P = (...a) => path.resolve(...a);

console.log('\n■ A1 · command line');
let r = D.parseOpenArgs(['C:/NOBODY/NOBODY.exe', '/music/a.mp3', '--flag', '-x', 'rel/b.FLAC', '"/q/c.ogg"', '/music/a.mp3', '/x/list.m3u8', '/x/readme.txt', '.'], '/home/u');
ok(eq(r.files, [P('/music/a.mp3'), P('/home/u/rel/b.FLAC'), P('/q/c.ogg')]), 'audio files: absolute, relative → cwd, quoted, de-duplicated, case-insensitive ext', r.files);
ok(eq(r.playlists, [P('/x/list.m3u8')]) && r.cmd === null, 'playlists apart; switches, "." and non-audio ignored', r);
r = D.parseOpenArgs(['exe', '--nobody-cmd=next'], '/'); ok(r.cmd === 'next' && !r.files.length, 'jump-list command parsed');
r = D.parseOpenArgs(['exe', '--nobody-cmd=rm-rf'], '/'); ok(r.cmd === null, 'unknown command ignored');
r = D.parseOpenArgs(['exe', 'file:///music/%D8%B3%D9%84%D8%A7%D9%85.mp3'], '/'); ok(eq(r.files, [P('/music/سلام.mp3')]), 'file:// URL with Persian name decoded', r.files);
r = D.parseOpenArgs(['exe', ...Array.from({ length: 900 }, (_, i) => `/m/${i}.mp3`)], '/'); ok(r.files.length === 500, 'bounded to 500 files');
ok(eq(D.parseOpenArgs(null, '/'), { files: [], playlists: [], cmd: null }), 'bad argv → empty');

console.log('\n■ A2 · window state');
const opt = { defW: 1360, defH: 860, minW: 720, minH: 520 };
const prim = { workArea: { x: 0, y: 0, width: 1920, height: 1040 } };
const left = { workArea: { x: -1600, y: 100, width: 1600, height: 860 } };
ok(eq(D.fitWindowState(null, [prim], opt), { width: 1360, height: 860, maximized: false, center: true }), 'first run: default size, centred');
ok(eq(D.fitWindowState(null, [{ workArea: { x: 0, y: 0, width: 1280, height: 680 } }], opt), { width: 1280, height: 680, maximized: false, center: true }), 'first run on a small screen: fits the work area');
let f = D.fitWindowState({ x: 200, y: 120, width: 1000, height: 700, maximized: false }, [prim], opt);
ok(f.x === 200 && f.y === 120 && f.width === 1000 && f.height === 700 && !f.center, 'saved spot restored', f);
f = D.fitWindowState({ x: -1400, y: 200, width: 1100, height: 700, maximized: true }, [prim, left], opt);
ok(f.x === -1400 && !f.center && f.maximized, 'second monitor (negative x) kept, maximized kept', f);
f = D.fitWindowState({ x: -1400, y: 200, width: 1100, height: 700, maximized: false }, [prim], opt);
ok(f.center && f.x === undefined && f.width === 1100, 'that monitor unplugged → centred on the primary, size kept', f);
f = D.fitWindowState({ x: 1880, y: 300, width: 1000, height: 700, maximized: false }, [prim], opt);
ok(f.center, 'only 40 px on screen → centred', f);
f = D.fitWindowState({ x: 1500, y: -300, width: 1000, height: 700, maximized: false }, [prim], opt);
ok(!f.center && f.y === 0 && f.x === 1500, 'title bar above the screen → pulled down onto it', f);
f = D.fitWindowState({ x: 0, y: 0, width: 5000, height: 3000, maximized: false }, [prim], opt);
ok(f.width === 1920 && f.height === 1040, 'bigger than the screen → clamped', f);
f = D.fitWindowState({ x: 10, y: 10, width: 100, height: 50, maximized: false }, [prim], opt);
ok(f.width === 720 && f.height === 520, 'below the minimum → min size', f);
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nobody-desk-')); const wsf = path.join(tmp, 'sub', 'window-state.json');
ok(D.writeWindowState(wsf, { x: 5, y: 6, width: 900, height: 600, maximized: true }) && eq(D.readWindowState(wsf), { x: 5, y: 6, width: 900, height: 600, maximized: true }), 'write → read round trip (dir created)');
fs.writeFileSync(wsf, '{oops'); ok(D.readWindowState(wsf) === null, 'corrupt file → null');
fs.writeFileSync(wsf, JSON.stringify({ x: 'a', width: 0, height: 9 })); ok(D.readWindowState(wsf) === null, 'nonsense size → null');

console.log('\n■ A3 · "Open with" registry');
const exe = 'C:\\Users\\me\\AppData\\Local\\Programs\\NOBODY\\NOBODY.exe';
const add = D.openWithRegCommands(exe, true); const del = D.openWithRegCommands(exe, false);
ok(add.every((a) => a[0] === 'add' && a[1].startsWith('HKCU\\Software\\Classes') && a.includes('/f')), 'register: HKCU only (no UAC), every add forced');
ok(add.some((a) => a.includes(`"${exe}" "%1"`)) && add.some((a) => a.includes(`"${exe}",0`)), 'open command quotes exe and %1, icon from the exe');
ok(D.AUDIO_EXTS.every((e) => add.some((a) => a[1] === `HKCU\\Software\\Classes\\.${e}\\OpenWithProgids` && a.includes('REG_NONE') && a.includes(D.PROG_AUDIO))), 'every audio type gets an OpenWithProgids entry (REG_NONE)');
ok(['m3u', 'm3u8'].every((e) => add.some((a) => a[1].endsWith(`.${e}\\OpenWithProgids`) && a.includes(D.PROG_LIST))), 'playlists → NOBODY.Playlist');
ok(add.some((a) => a[1] === 'HKCU\\Software\\Classes\\Applications\\NOBODY.exe' && a.includes('FriendlyAppName')), 'Applications\\NOBODY.exe with a friendly name');
ok(!add.some((a) => /UserChoice|\\shell\\open\\command$/.test(a[1]) && /\\\.mp3\\/.test(a[1])), 'never touches UserChoice / the default app of a type');
ok(del.every((a) => a[0] === 'delete') && del.some((a) => a[1].endsWith('\\.mp3\\OpenWithProgids') && a[3] === D.PROG_AUDIO) && del.some((a) => a[1].endsWith('NOBODY.AudioFile')), 'unregister: only our values / keys');

console.log('\n■ A4 · labels / now playing text');
ok(D.cleanLabels({ play: '  پخش ', quit: 5, next: '' }).play === 'پخش' && D.cleanLabels({ quit: 5 }).quit === 'Quit NOBODY' && D.cleanLabels({ next: '' }).next === 'Next', 'labels: trimmed, bad values fall back');
ok(D.nowPlayingText({ title: 'Kooch', artist: 'Sohrab' }) === 'Kooch — Sohrab' && D.nowPlayingText({ title: '' }) === '', 'Title — Artist / empty');
ok(D.nowPlayingText({ title: 'x'.repeat(300), artist: 'y' }).length === 127, 'tooltip bounded to 127');
ok(D.cleanNowPlaying({ title: 'a\nb', artist: 7, playing: 1 }).title === 'a b' && D.cleanNowPlaying({ artist: 7 }).artist === '', 'now playing sanitised');
ok(D.windowTitle({ title: 'Glass', artist: 'Mirror Band' }) === 'Glass — Mirror Band · NOBODY' && D.windowTitle(null) === 'NOBODY', 'taskbar window title');

console.log('\n■ A5 · tray / thumbar / jump list on a fake Electron');
function fakeElectron(opts = {}) {
  const log = { tray: [], thumbar: [], tasks: null, balloons: [] };
  class Tray { constructor(img) { if (opts.noTray) throw new Error('no tray'); this.img = img; this.h = {}; log.tray.push(this); } setToolTip(t) { this.tip = t; } setContextMenu(m) { this.menu = m; } on(e, f) { this.h[e] = f; } displayBalloon(b) { log.balloons.push(b); } destroy() { this.dead = true; } }
  const img = (p) => ({ p, isEmpty: () => !fs.existsSync(p), resize(o) { return { ...this, o }; } });
  const nativeImage = { createFromPath: img, createEmpty: () => ({ isEmpty: () => true }) };
  const Menu = { buildFromTemplate: (t) => ({ items: t }) };
  const app = { isPackaged: !!opts.packaged, getAppPath: () => '/dev/app', setUserTasks: (t) => { log.tasks = t; return true; } };
  return { log, electron: { Tray, Menu, nativeImage, app } };
}
const fe = fakeElectron();
const sent = []; let toggled = 0, quit = 0;
const win = { visible: true, isDestroyed: () => false, isVisible() { return this.visible; }, isMinimized: () => false, setThumbarButtons(b) { fe.log.thumbar.push(b); return true; }, setTitle(t) { this.title = t; } };
const sh = D.createDesktopShell({ electron: fe.electron, getWindow: () => win, send: (c) => sent.push(c), iconPath: path.join(ROOT, 'public/icon.png'), assetsDir: path.join(ROOT, 'electron/assets'), isWin: true, toggleWindow: () => toggled++, onQuit: () => quit++ });
sh.start();
const tray = fe.log.tray[0];
ok(!!tray && sh.hasTray && tray.tip === 'NOBODY', 'tray created, tooltip "NOBODY" when idle');
const labelsOf = () => tray.menu.items.filter((i) => i.label).map((i) => i.label);
ok(eq(labelsOf(), ['Nothing playing', 'Play', 'Next', 'Previous', 'Hide NOBODY', 'Quit NOBODY']), 'menu: now playing, Play, Next, Previous, Hide, Quit', labelsOf());
ok(tray.menu.items[0].enabled === false, 'now-playing line is not clickable');
tray.menu.items.find((i) => i.label === 'Next').click(); tray.menu.items.find((i) => i.label === 'Play').click(); tray.menu.items.find((i) => i.label === 'Previous').click();
ok(eq(sent, ['next', 'play-pause', 'prev']), 'menu items send media-key commands', sent);
tray.h.click(); tray.menu.items.find((i) => i.label === 'Hide NOBODY').click(); tray.menu.items.find((i) => i.label === 'Quit NOBODY').click();
ok(toggled === 2 && quit === 1, 'tray click + Show/Hide toggle the window, Quit quits');
ok(fe.log.tasks?.length === 3 && fe.log.tasks.every((t) => t.arguments.startsWith('"/dev/app" --nobody-cmd=')) && fe.log.tasks.map((t) => t.arguments.split('=')[1]).join() === 'play-pause,next,prev', 'jump list: 3 tasks, dev run passes the app path', fe.log.tasks?.map((t) => t.arguments));
sh.attachWindow();
let tb = fe.log.thumbar.at(-1);
ok(tb?.length === 3 && tb[1].tooltip === 'Play' && /thumb-play\.png$/.test(tb[1].icon.p), 'thumbar: ⏮ ⏯ ⏭, Play icon while paused');
tb[0].click(); tb[2].click(); tb[1].click(); ok(eq(sent.slice(-3), ['prev', 'next', 'play-pause']), 'thumbar buttons send commands');
ok(sh.setNowPlaying({ title: 'Kooch', artist: 'Sohrab', playing: true }) === true, 'now playing accepted');
tb = fe.log.thumbar.at(-1);
ok(tb[1].tooltip === 'Pause' && /thumb-pause\.png$/.test(tb[1].icon.p), 'thumbar ⏯ switches to Pause while playing');
ok(tray.tip === 'Kooch — Sohrab · NOBODY' && labelsOf()[0] === 'Kooch — Sohrab' && labelsOf()[1] === 'Pause', 'tooltip + menu follow the song', [tray.tip, labelsOf()]);
ok(win.title === 'Kooch — Sohrab · NOBODY', 'taskbar window title follows');
const nThumb = fe.log.thumbar.length;
ok(sh.setNowPlaying({ title: 'Kooch', artist: 'Sohrab', playing: true }) === false && fe.log.thumbar.length === nThumb, 'same state again → no redraw');
sh.setLabels({ play: 'پخش', pause: 'مکث', next: 'بعدی', prev: 'قبلی', show: 'نمایش NOBODY', hide: 'پنهان کردن NOBODY', quit: 'خروج از NOBODY', nothing: 'چیزی پخش نمی‌شود' });
ok(labelsOf().includes('مکث') && labelsOf().includes('خروج از NOBODY') && fe.log.thumbar.at(-1)[0].tooltip === 'قبلی' && fe.log.tasks[1].title === 'بعدی', 'Persian labels: menu, thumbar, jump list');
win.visible = false; sh.refresh(); ok(labelsOf().includes('نمایش NOBODY'), 'hidden window → menu says Show');
sh.balloon(); ok(fe.log.balloons.length === 1 && /NOBODY/.test(fe.log.balloons[0].content), 'tray note balloon');
sh.destroy(); ok(tray.dead && !sh.hasTray, 'destroy removes the tray');
const fe2 = fakeElectron({ noTray: true, packaged: true });
const sh2 = D.createDesktopShell({ electron: fe2.electron, getWindow: () => null, send() {}, iconPath: '/nope.png', assetsDir: '/nope', isWin: true, toggleWindow() {}, onQuit() {} });
sh2.start(); sh2.attachWindow(); sh2.setNowPlaying({ title: 'x', playing: true });
ok(!sh2.hasTray && fe2.log.tasks?.[0].arguments === '--nobody-cmd=play-pause', 'no tray on this desktop → no crash; packaged jump list has no app path');

/* ─────────────────────────── part B: main.cjs ─────────────────────────── */
/** fake globalShortcut: `taken` = combos another app owns; `fire(acc)` = the user presses it */
function fakeGS(taken = []) {
  const reg = new Map(); const own = new Set(taken); const log = [];
  return { reg, log, own,
    register(acc, cb) { log.push(['reg', acc]); if (own.has(acc) || reg.has(acc)) return false; reg.set(acc, cb); return true; },
    unregister(acc) { log.push(['unreg', acc]); reg.delete(acc); },
    unregisterAll() { reg.clear(); },
    isRegistered: (acc) => reg.has(acc),
    fire(acc) { const cb = reg.get(acc); if (cb) cb(); return !!cb; } };
}

console.log('\n■ A6 · global hotkeys: accelerator rules');
const N = D.normalizeAccelerator;
ok(N('ctrl + alt + right') === 'Ctrl+Alt+Right' && N('Alt+Ctrl+arrowright') === 'Ctrl+Alt+Right', 'canonical order + aliases (ctrl/alt, arrowright → Right)');
ok(N('Win+Shift+p') === 'Shift+Super+P' && N('CmdOrCtrl+K') === 'Ctrl+K', 'Win/Cmd → Super, CmdOrCtrl → Ctrl, letters upper-cased');
ok(N('Ctrl++') === 'Ctrl+Plus' && N('Ctrl+Alt+num5') === 'Ctrl+Alt+num5', '"Ctrl++" → Ctrl+Plus, numpad keys kept');
ok(N('') === '' && N(null) === '' && N(undefined) === '', 'empty → "" (cleared)');
ok(N('Shift+A') === null && N('P') === null && N('Space') === null, 'needs Ctrl, Alt or Win (Shift+letter would eat typing)');
ok(N('F13') === 'F13' && N('Shift+F24') === 'Shift+F24' && N('F12') === null, 'F13–F24 alone are fine, F12 alone is not');
ok(N('Ctrl+Alt+Delete') === null && N('alt+f4') === null && N('Win+L') === null && N('Alt+Space') === null, 'OS-reserved combos refused');
ok(N('Ctrl+Ctrl+A') === null && N('Ctrl+A+B') === null && N('Ctrl+Alt') === null && N('AltGr+Q') === null, 'repeated modifier, two keys, no key, AltGr → refused');
ok(N('Ctrl+Alt+ش') === null && N('Ctrl+' + 'x'.repeat(80)) === null && N(42) === null, 'layout characters, over-long, non-string → refused');

console.log('\n■ A7 · global hotkeys: stored config');
let c = D.cleanHotkeys(null);
ok(c.enabled === false && c.map['play-pause'] === 'Ctrl+Alt+Space' && c.map.stop === '' && Object.keys(c.map).length === 7, 'nothing stored → off, defaults, 7 actions', c);
c = D.cleanHotkeys({ enabled: true, map: { next: 'alt+ctrl+n', prev: 'Ctrl+Alt+N', 'show-hide': 'bogus', evil: 'Ctrl+Alt+E' } });
ok(c.enabled === true && c.map.next === 'Ctrl+Alt+N' && c.map.prev === '' , 'normalized on read; a repeated combo is cleared on the later action', c.map);
ok(c.map['show-hide'] === '' && !('evil' in c.map) && c.map['play-pause'] === 'Ctrl+Alt+Space', 'bad combo → cleared, unknown action dropped, missing → default');
ok(D.cleanHotkeys({ enabled: 'yes' }).enabled === false, 'enabled must be a real boolean');

console.log('\n■ A8 · global hotkeys: registration');
let gs = fakeGS(['Ctrl+Alt+N']); const fired = [];
let hk = D.createHotkeys({ globalShortcut: gs, onAction: (a) => fired.push(a) });
let st0 = hk.set(null);
ok(gs.reg.size === 0 && st0['play-pause'] === 'off' && st0.stop === 'unset', 'off by default: nothing registered (status off / unset)', st0);
let st1 = hk.set({ enabled: true });
ok(gs.reg.size === 5 && st1['play-pause'] === 'ok' && st1['show-hide'] === 'taken' && st1.stop === 'unset', 'on: 5 registered, Ctrl+Alt+N owned by another app → taken', st1);
gs.fire('Ctrl+Alt+Right'); gs.fire('Ctrl+Alt+Up'); gs.fire('Ctrl+Alt+Space');
ok(eq(fired, ['next', 'vol-up', 'play-pause']), 'pressing them → the right actions', fired);
hk.suspend(true);
ok(gs.reg.size === 0 && hk.status.next === 'off' && !gs.fire('Ctrl+Alt+Right'), 'suspended (recording) → all released, nothing fires');
hk.suspend(false);
ok(gs.reg.size === 5 && hk.status.next === 'ok', 'resumed → registered again');
hk.set({ enabled: true, map: { ...hk.config.map, next: 'Ctrl+Shift+F9' } });
ok(!gs.reg.has('Ctrl+Alt+Right') && gs.reg.has('Ctrl+Shift+F9'), 'changing a combo releases the old one');
const media = fakeGS(); media.register('MediaNextTrack', () => {});
const hk2 = D.createHotkeys({ globalShortcut: media, onAction() {} }); hk2.set({ enabled: true }); hk2.set({ enabled: false });
ok(media.reg.has('MediaNextTrack') && media.reg.size === 1, 'turning off releases only OUR combos (hardware media keys stay)', [...media.reg.keys()]);
hk.release(); ok(gs.reg.size === 0, 'release() frees everything we own');

function bootMain({ argv = ['NOBODY.exe'], userData, displays, lock = true, platform, gs } = {}) {
  const ev = new (require('events'))();
  const handles = {}, ons = {};
  const W = [];
  const sentTo = [];
  class BrowserWindow {
    static getAllWindows() { return W.filter((w) => !w.destroyed); }
    constructor(o) { this.o = o; this.h = {}; this.visible = false; this.min = false; this.max = false; this.full = false; this.focused = false; this.destroyed = false; this.bounds = { x: o.x ?? 100, y: o.y ?? 100, width: o.width, height: o.height }; this.title = o.title; this.thumbar = null;
      const self = this; this.webContents = { h: {}, on(e, f) { (this.h[e] = this.h[e] || []).push(f); }, send(ch, ...a) { sentTo.push([ch, ...a]); }, setWindowOpenHandler() {}, session: {} };
      W.push(this); }
    on(e, f) { (this.h[e] = this.h[e] || []).push(f); return this; }
    once(e, f) { const g = (...a) => { this.h[e] = this.h[e].filter((x) => x !== g); f(...a); }; return this.on(e, g); }
    emit(e, ...a) { for (const f of [...(this.h[e] || [])]) f(...a); }
    loadFile() {} loadURL() {}
    show() { this.visible = true; this.emit('show'); } hide() { this.visible = false; this.emit('hide'); }
    focus() { this.focused = true; } isFocused() { return this.focused; }
    isVisible() { return this.visible; } isMinimized() { return this.min; } restore() { this.min = false; }
    minimize() { this.min = true; } maximize() { this.max = true; this.emit('maximize'); } unmaximize() { this.max = false; this.emit('unmaximize'); } isMaximized() { return this.max; }
    isFullScreen() { return this.full; } setFullScreen(v) { this.full = v; }
    getBounds() { return { ...this.bounds }; } getNormalBounds() { return { ...this.bounds }; } setBounds(b) { this.bounds = { ...this.bounds, ...b }; this.emit('resize'); } setPosition(x, y) { this.bounds.x = x; this.bounds.y = y; this.emit('move'); }
    setAlwaysOnTop() {} setResizable() {} center() {}
    isDestroyed() { return this.destroyed; }
    close() { const e = { defaultPrevented: false, preventDefault() { this.defaultPrevented = true; } }; this.emit('close', e); if (!e.defaultPrevented) { this.destroyed = true; this.emit('closed'); if (!BrowserWindow.getAllWindows().length) ev.emit('window-all-closed'); } }
    setThumbarButtons(b) { this.thumbar = b; return true; } setTitle(t) { this.title = t; }
  }
  let readyResolve; const ready = new Promise((r) => (readyResolve = r));
  const trays = [];
  const fakeE = {
    app: { on: (e, f) => ev.on(e, f), whenReady: () => ready, isReady: () => isReady, requestSingleInstanceLock: () => lock, releaseSingleInstanceLock() {}, quit: () => { quitCalls++; }, exit: (c) => { exitCodes.push(c); }, commandLine: { appendSwitch() {} }, getPath: () => userData, isPackaged: false, getAppPath: () => '/dev/app', setUserTasks: (t) => { tasks = t; return true; } },
    BrowserWindow, Menu: { setApplicationMenu() {}, buildFromTemplate: (t) => ({ items: t }) },
    ipcMain: { handle: (c, f) => { handles[c] = f; }, on: (c, f) => { ons[c] = f; } },
    protocol: { registerSchemesAsPrivileged() {}, handle() {} }, net: {},
    screen: { getPrimaryDisplay: () => displays[0], getAllDisplays: () => displays, getCursorScreenPoint: () => ({ x: 0, y: 0 }) },
    shell: { openExternal() {} },
    nativeImage: { createFromPath: (p) => ({ p, isEmpty: () => false, resize() { return this; } }), createEmpty: () => ({ isEmpty: () => true }) },
    globalShortcut: gs || { register: () => true, unregister() {}, unregisterAll() {} },
    Tray: class { constructor() { this.h = {}; trays.push(this); } setToolTip(t) { this.tip = t; } setContextMenu(m) { this.menu = m; } on(e, f) { this.h[e] = f; } displayBalloon(b) { this.balloon = b; } destroy() {} },
    safeStorage: { isEncryptionAvailable: () => false }, dialog: {}, webUtils: {},
  };
  let isReady = false, quitCalls = 0, tasks = null; const exitCodes = [];
  const origLoad = Module._load; const origArgv = process.argv;
  Module._load = function (req, parent, isMain) { if (req === 'electron') return fakeE; return origLoad.apply(this, arguments); };
  process.argv = argv;
  const mainPath = path.join(ROOT, 'electron/main.cjs');
  delete require.cache[mainPath];
  require(mainPath);
  process.argv = origArgv; // Module._load stays hooked: main.cjs requires electron lazily too
  const api = {
    ev, handles, ons, W, sentTo, trays, exitCodes, get quitCalls() { return quitCalls; }, get tasks() { return tasks; },
    async ready() { isReady = true; readyResolve(); await new Promise((r) => setImmediate(r)); },
    win: () => W.filter((w) => !w.destroyed).at(-1),
    invoke: (c, ...a) => handles[c]({}, ...a), send: (c, ...a) => ons[c]({}, ...a),
  };
  return api;
}
(async () => {
  // part B runs main.cjs as on Windows (thumbar, jump list, case-insensitive paths)
  Object.defineProperty(process, 'platform', { value: 'win32' });
  const ud = fs.mkdtempSync(path.join(os.tmpdir(), 'nobody-main-'));
  const PRIMARY = { id: 1, workArea: { x: 0, y: 0, width: 1920, height: 1040 } };
  console.log('\n■ B1 · first launch with files ("Open with" a song + a playlist)');
  let m = bootMain({ argv: ['NOBODY.exe', '/m/07 سلام.mp3', '/m/road.m3u8', '/m/notes.txt'], userData: ud, displays: [PRIMARY] });
  await m.ready();
  let w = m.win();
  ok(!!w && w.o.width === 1360 && w.o.center === true, 'no saved state → default size, centred');
  w.emit('ready-to-show');
  ok(w.visible, 'window shown');
  ok(!!m.trays[0] && m.trays[0].tip === 'NOBODY', 'tray up');
  ok(Array.isArray(m.tasks) && m.tasks.length === 3, 'jump list set');
  ok(!!w.thumbar && w.thumbar.length === 3, 'thumbar buttons attached on show');
  let got = await m.invoke('desk:ready');
  ok(eq(got.files, [P('/m/07 سلام.mp3')]) && eq(got.playlists, [P('/m/road.m3u8')]), 'desk:ready hands over the command-line files', got);
  ok(eq((await m.invoke('desk:ready')).files, []), 'handed over once');
  const pl = path.join(ud, 'road.m3u8'); fs.writeFileSync(pl, '#EXTM3U\n/m/a.mp3\n');
  let rp = await m.invoke('desk:read-playlist', pl);
  ok(rp.error === 'E_DENIED', 'desk:read-playlist refuses a playlist that was not opened with NOBODY');
  rp = await m.invoke('desk:read-playlist', '/etc/passwd'); ok(rp.error === 'E_DENIED', 'and anything that is not .m3u/.m3u8');

  console.log('\n■ B2 · second launch: files forwarded, commands do not steal focus');
  w.focused = false; w.hide();
  m.ev.emit('second-instance', {}, ['NOBODY.exe', 'b.flac', pl], ud);
  const op = m.sentTo.filter((x) => x[0] === 'desk:open').at(-1);
  ok(op && eq(op[1].files, [path.join(ud, 'b.flac')]) && eq(op[1].playlists, [pl]), 'renderer ready → desk:open right away (relative path → its cwd)', op);
  ok(w.visible && w.focused, 'window shown + focused (it was in the tray)');
  rp = await m.invoke('desk:read-playlist', pl); ok(rp.bytes && Buffer.from(rp.bytes).toString().startsWith('#EXTM3U'), 'now that playlist can be read');
  w.focused = false; const nSent = m.sentTo.length;
  m.ev.emit('second-instance', {}, ['NOBODY.exe', '--nobody-cmd=next'], ud);
  ok(eq(m.sentTo.slice(nSent), [['media:key', 'next']]) && !w.focused, 'jump list "Next" → media:key next, focus untouched');
  w.webContents.h['did-start-loading'].forEach((f) => f());
  m.ev.emit('second-instance', {}, ['NOBODY.exe', '/m/c.mp3'], ud);
  ok(!m.sentTo.some((x) => x[0] === 'desk:open' && x[1].files.includes(P('/m/c.mp3'))), 'renderer reloading → queued, not sent');
  got = await m.invoke('desk:ready'); ok(eq(got.files, [P('/m/c.mp3')]), '…and handed over at the next desk:ready');
  m.ev.emit('open-file', { preventDefault() {} }, '/m/d.opus');
  ok(m.sentTo.filter((x) => x[0] === 'desk:open').at(-1)[1].files[0] === P('/m/d.opus'), 'macOS open-file → same path');

  console.log('\n■ B3 · tray menu + now playing');
  m.send('desk:now-playing', { title: 'Kooch', artist: 'Sohrab', playing: true });
  ok(m.trays[0].tip === 'Kooch — Sohrab · NOBODY' && w.title === 'Kooch — Sohrab · NOBODY', 'tooltip + taskbar title');
  ok(w.thumbar[1].tooltip === 'Pause', 'thumbar shows Pause');
  m.send('desk:labels', { pause: 'مکث', play: 'پخش' }); ok(w.thumbar[1].tooltip === 'مکث', 'labels from the renderer');
  const nS = m.sentTo.length; m.trays[0].menu.items.find((i) => i.label === 'Next').click();
  ok(eq(m.sentTo.slice(nS), [['media:key', 'next']]), 'tray Next → media:key');

  console.log('\n■ B4 · close to tray');
  let prefs = await m.invoke('desk:get-prefs');
  ok(prefs.closeToTray === false && prefs.trayAvailable === true && prefs.openWithSupported === false, 'defaults: close quits, tray available, "Open with" only in the packaged Windows app', prefs);
  w.focused = true; w.close();
  ok(!w.destroyed && m.sentTo.at(-1)[0] === 'app:close-requested', 'off: close plays the veil (app:close-requested)');
  m.send('win:close-confirmed');
  ok(w.destroyed, 'confirmed → window closes');
  ok(fs.existsSync(path.join(ud, 'window-state.json')), 'window state written on close');
  m.ev.emit('second-instance', {}, ['NOBODY.exe'], ud); w = m.win(); w.emit('ready-to-show');
  ok(!!w && w.visible, 'second launch after the window closed → a new window');
  let rset = await m.invoke('desk:set-pref', 'closeToTray', true);
  ok(rset.ok && JSON.parse(fs.readFileSync(path.join(ud, 'desktop.json'), 'utf8')).closeToTray === true, 'closeToTray saved to desktop.json');
  ok((await m.invoke('desk:set-pref', 'closeToTray', 'yes')).ok === false, 'non-boolean refused');
  ok((await m.invoke('desk:set-pref', 'openWith', true)).ok === false, '"Open with" refused in a dev / non-Windows run');
  const nS2 = m.sentTo.length;
  m.send('win:close');
  ok(!w.visible && !w.destroyed && !m.sentTo.slice(nS2).some((x) => x[0] === 'app:close-requested'), '✕ → hidden in the tray, no veil, still alive');
  ok(!!m.trays[0].balloon, 'first time: tray note balloon');
  w.show(); w.close(); ok(!w.visible && !w.destroyed, 'Alt+F4 / taskbar close → tray too');
  ok(m.trays[0].menu.items.some((i) => i.label === 'Show NOBODY'), 'menu offers Show NOBODY');
  m.trays[0].menu.items.find((i) => i.label === 'Show NOBODY').click(); ok(w.visible && w.focused, 'Show → back');
  m.trays[0].menu.items.find((i) => i.label === 'Quit NOBODY').click();
  ok(m.sentTo.at(-1)[0] === 'app:close-requested' && !w.destroyed, 'tray Quit with the window on screen → veil first');
  m.send('win:close-confirmed'); ok(w.destroyed, 'then really closes (not hidden)');

  console.log('\n■ B5 · window state on the next launch');
  const ud2 = fs.mkdtempSync(path.join(os.tmpdir(), 'nobody-main2-'));
  m = bootMain({ userData: ud2, displays: [PRIMARY] }); await m.ready(); w = m.win(); w.emit('ready-to-show');
  w.setBounds({ x: 300, y: 200, width: 1100, height: 720 }); w.maximize(); m.send('win:close'); m.send('win:close-confirmed');
  let st = JSON.parse(fs.readFileSync(path.join(ud2, 'window-state.json'), 'utf8'));
  ok(st.x === 300 && st.width === 1100 && st.maximized === true, 'saved: normal bounds + maximized', st);
  m = bootMain({ userData: ud2, displays: [PRIMARY] }); await m.ready(); w = m.win();
  ok(w.o.x === 300 && w.o.y === 200 && w.o.width === 1100 && w.o.center === false, 'restored at the same spot', w.o);
  w.emit('ready-to-show'); ok(w.max, 'and maximized again');
  w.unmaximize(); await m.invoke('win:enter-compact'); m.send('win:close'); m.send('win:close-confirmed');
  st = JSON.parse(fs.readFileSync(path.join(ud2, 'window-state.json'), 'utf8'));
  ok(st.width === 1100 && st.maximized === false, 'closed in the mini-player → the full window size is remembered, not 440×260', st);
  fs.writeFileSync(path.join(ud2, 'window-state.json'), JSON.stringify({ x: -1500, y: 100, width: 1000, height: 700, maximized: false }));
  m = bootMain({ userData: ud2, displays: [PRIMARY] }); await m.ready(); w = m.win();
  ok(w.o.center === true && w.o.x === undefined && w.o.width === 1000, 'monitor gone → centred, size kept', w.o);
  m = bootMain({ userData: ud2, displays: [PRIMARY], lock: false });
  ok(m.quitCalls === 1, 'no single-instance lock → this launch quits (the running one gets the files)');

  console.log('\n■ B6 · global hotkeys through main.cjs');
  const ud3 = fs.mkdtempSync(path.join(os.tmpdir(), 'nobody-hk-'));
  let g = fakeGS(['Ctrl+Alt+N']);
  m = bootMain({ userData: ud3, displays: [PRIMARY], gs: g }); await m.ready(); w = m.win(); w.emit('ready-to-show');
  let h = await m.invoke('desk:get-hotkeys');
  ok(h.supported === true && h.enabled === false && h.map.next === 'Ctrl+Alt+Right' && h.actions.length === 7, 'desk:get-hotkeys: supported, off, defaults', h);
  ok(['MediaPlayPause', 'MediaNextTrack'].every((k) => g.reg.has(k)) && !g.reg.has('Ctrl+Alt+Right'), 'only the hardware media keys are registered while off');
  h = await m.invoke('desk:set-hotkeys', { enabled: true });
  ok(h.ok && h.enabled && h.status.next === 'ok' && h.status['show-hide'] === 'taken', 'enable → registered, taken one reported', h.status);
  let sent0 = m.sentTo.length; g.fire('Ctrl+Alt+Right'); g.fire('Ctrl+Alt+Down');
  ok(eq(m.sentTo.slice(sent0), [['media:key', 'next'], ['media:key', 'vol-down']]), 'pressed → media:key next / vol-down to the renderer', m.sentTo.slice(sent0));
  w.focused = true; w.visible = true;
  h = await m.invoke('desk:set-hotkeys', { map: { 'show-hide': 'Ctrl+Alt+H' } });
  g.fire('Ctrl+Alt+H'); ok(!w.visible, 'show/hide while focused → hidden'); g.fire('Ctrl+Alt+H'); ok(w.visible && w.focused, '…and back, focused');
  h = await m.invoke('desk:set-hotkeys', { map: { next: 'ctrl+alt+right' } });
  ok(h.ok && h.map.next === 'Ctrl+Alt+Right', 'combos normalized by main');
  h = await m.invoke('desk:set-hotkeys', { map: { next: 'Ctrl+Alt+Space' } });
  ok(!h.ok && h.code === 'E_DUPLICATE' && h.action === 'next' && h.other === 'play-pause' && h.map.next === 'Ctrl+Alt+Right', 'duplicate → E_DUPLICATE, nothing changed', h);
  for (const bad of [{ map: { next: 'Shift+A' } }, { map: { next: 'Ctrl+Alt+Delete' } }, { map: { hack: 'Ctrl+Alt+K' } }, { enabled: 'yes' }, { map: null }, null, 'x']) {
    h = await m.invoke('desk:set-hotkeys', bad); if (h.ok || h.code !== 'E_INVALID') { ok(false, 'E_INVALID for ' + JSON.stringify(bad), h); break; }
  }
  ok(h.code === 'E_INVALID', 'bad patches (no modifier, reserved, unknown action, non-boolean, null, string) → E_INVALID');
  h = await m.invoke('desk:set-hotkeys', { map: { 'play-pause': '', next: 'Ctrl+Alt+Space' } });
  ok(h.ok && h.map['play-pause'] === '' && h.map.next === 'Ctrl+Alt+Space', 'move in one patch (clear one + reuse its combo) is allowed');
  sent0 = m.sentTo.length; g.fire('Ctrl+Alt+Space'); ok(eq(m.sentTo.slice(sent0), [['media:key', 'next']]), 'old combo now fires the new action');
  h = await m.invoke('desk:hotkeys-suspend', true);
  ok(h.status.next === 'off' && !g.reg.has('Ctrl+Alt+Space') && g.reg.has('MediaPlayPause'), 'suspend → ours released, media keys untouched');
  w.webContents.h['did-start-loading'].forEach((f) => f());
  ok(g.reg.has('Ctrl+Alt+Space'), 'renderer reload mid-recording → hotkeys back on');
  await m.invoke('desk:hotkeys-suspend', true);
  h = await m.invoke('desk:set-hotkeys', { map: { stop: 'Ctrl+Alt+S' } });
  ok(h.ok && g.reg.has('Ctrl+Alt+S') && h.status.stop === 'ok', 'saving ends a suspension');
  const saved = JSON.parse(fs.readFileSync(path.join(ud3, 'desktop.json'), 'utf8'));
  ok(saved.hotkeys && saved.hotkeys.enabled === true && saved.hotkeys.map.stop === 'Ctrl+Alt+S', 'stored in desktop.json', saved.hotkeys);
  g = fakeGS(); m = bootMain({ userData: ud3, displays: [PRIMARY], gs: g }); await m.ready();
  h = await m.invoke('desk:get-hotkeys');
  ok(h.enabled && h.map.stop === 'Ctrl+Alt+S' && g.reg.has('Ctrl+Alt+S') && g.reg.has('Ctrl+Alt+Space'), 'next launch: registered again from desktop.json');
  fs.writeFileSync(path.join(ud3, 'desktop.json'), JSON.stringify({ hotkeys: { enabled: true, map: { next: 'Alt+F4', prev: 'Ctrl+Alt+Left', stop: 'ctrl+alt+left' } } }));
  g = fakeGS(); m = bootMain({ userData: ud3, displays: [PRIMARY], gs: g }); await m.ready();
  h = await m.invoke('desk:get-hotkeys');
  ok(h.map.next === '' && h.map.prev === 'Ctrl+Alt+Left' && h.map.stop === '' && !g.reg.has('Alt+F4'), 'hand-edited desktop.json: reserved + repeated combos dropped', h.map);

  console.log('\n■ B7 · --nobody-quit (Setup / uninstaller ask the player to leave)');
  const ud4 = fs.mkdtempSync(path.join(os.tmpdir(), 'nobody-quit-'));
  m = bootMain({ argv: ['NOBODY.exe', '--nobody-quit'], userData: ud4, displays: [PRIMARY] }); await m.ready();
  ok(eq(m.exitCodes, [0]) && !m.win() && m.trays.length === 0, 'nothing running → this launch exits at once, no window, no tray', [m.exitCodes, !!m.win()]);
  m = bootMain({ userData: ud4, displays: [PRIMARY] }); await m.ready(); w = m.win(); w.emit('ready-to-show');
  await m.invoke('desk:set-pref', 'closeToTray', true);
  let q0 = m.quitCalls; const sent1 = m.sentTo.length;
  m.ev.emit('second-instance', {}, ['C:\\Portable\\NOBODY.exe', '--nobody-quit'], ud4);
  ok(m.quitCalls === q0 && !w.destroyed && m.sentTo.length === sent1, 'from ANOTHER install / a portable copy → ignored (no quit, no focus, no command)');
  w.focused = false;
  m.ev.emit('second-instance', {}, [process.execPath, '--nobody-quit'], ud4);
  ok(m.quitCalls > q0 && w.destroyed, 'from our own install dir → window closed + app.quit (even with close-to-tray on)', [m.quitCalls, w.destroyed]);
  ok(!m.sentTo.slice(sent1).some((x) => x[0] === 'app:close-requested'), 'no close veil (files are about to be replaced)');

  console.log(`\n${pass}/${pass + fail} passed`);
  if (fails.length) { console.log('FAILED:\n - ' + fails.join('\n - ')); process.exitCode = 1; }
})().catch((e) => { console.error(e); process.exitCode = 1; });
