// NOBODY Setup 1.8.0-dev.4 · UAC only for "All users", Chromium run on the real wizard UI (mocked window.nobodySetup)
import { chromium } from '/opt/sd-artifact/node_modules/playwright/index.mjs';
let pass = 0, fail = 0; const fails = [];
const ok = (c, m, x) => { if (c) { pass++; console.log('  ✔', m); } else { fail++; fails.push(m); console.log('  ✘', m, x !== undefined ? JSON.stringify(x) : ''); } };
const browser = await chromium.launch({ executablePath: '/ms-playwright/chromium-1208/chrome-linux64/chrome' });
const CTX = (o = {}) => ({ mode: 'setup', version: '1.8.0-dev.4', spec: 1, payloadBytes: 200e6, payloadFiles: 120, defaultUserDir: 'C:\\Users\\sara\\AppData\\Local\\Programs\\NOBODY', defaultAllDir: 'C:\\Program Files\\NOBODY', userDataDir: 'C:\\Users\\sara\\AppData\\Roaming\\NOBODY', freeBytes: 80e9, upgrade: false, installedVersion: null, devMode: false, elevated: false, resume: null, ...o });
const S = (page) => page.evaluate(() => ({ calls: window.__S.calls }));
async function open(ctxObj, lang = 'en') {
  const ctx = await browser.newContext({ viewport: { width: 980, height: 640 }, locale: lang === 'fa' ? 'fa-IR' : 'en-US', reducedMotion: 'reduce' }); const page = await ctx.newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(String(e).slice(0, 200)));
  await page.addInitScript((c) => sessionStorage.setItem('__ctx', JSON.stringify(c)), ctxObj);
  await page.goto('http://127.0.0.1:8790/');
  return { ctx, page, errs };
}
const toDestination = async (page) => {
  await page.getByRole('button', { name: /Continue|بریم جلو/ }).first().dispatchEvent('click');
  await page.getByRole('button', { name: /let me in|بذار برم تو/ }).first().dispatchEvent('click');
  await page.waitForSelector('#nb-dir', { timeout: 8000 });
};
const dir = (page) => page.$eval('#nb-dir', (e) => e.value);
const uac = (page) => page.$eval('[data-uac]', (e) => [e.getAttribute('data-uac'), e.innerText]).catch(() => null);
const installBtn = (page) => page.getByRole('button', { name: /^Install$|^نصب/ }).last();

console.log('\n■ 1 · default = "Just me", no UAC');
let { ctx, page, errs } = await open(CTX());
await toDestination(page);
ok(await dir(page) === 'C:\\Users\\sara\\AppData\\Local\\Programs\\NOBODY', 'default path = per-user (%LOCALAPPDATA%\\Programs)', await dir(page));
ok(await uac(page) === null, 'no admin note for "Just me"');
await installBtn(page).dispatchEvent('click');
await page.waitForTimeout(400);
let calls = (await S(page)).calls;
ok(calls.some((c) => c[0] === 'startInstall' && c[1].scope === 'me') && !calls.some((c) => c[0] === 'elevate'), 'Install → installs right away, no elevation asked', calls);
await ctx.close();

console.log('\n■ 2 · "All users" → note, UAC refused → stays, says so, nothing installed');
({ ctx, page, errs } = await open(CTX()));
await toDestination(page);
await page.getByText('All users', { exact: false }).first().dispatchEvent('click');
ok(await dir(page) === 'C:\\Program Files\\NOBODY', 'path follows the scope → Program Files', await dir(page));
let u = await uac(page);
ok(u && u[0] === 'hint' && /administrator permission/.test(u[1]), 'note: Windows will ask for admin', u);
await page.evaluate(() => { window.__S.elevateAnswer = 'denied'; });
await installBtn(page).dispatchEvent('click');
ok(await page.waitForFunction(() => document.querySelector('[data-uac]')?.getAttribute('data-uac') === 'asking', null, { timeout: 2000 }).then(() => true, () => false), 'while the UAC prompt is open: "waiting for Windows", Install disabled');
await page.waitForFunction(() => document.querySelector('[data-uac]')?.getAttribute('data-uac') === 'denied', null, { timeout: 3000 }).catch(() => {});
u = await uac(page);
ok(u && u[0] === 'denied' && /nothing was installed/.test(u[1]), 'refused → stays on this page, says nothing was installed', u);
calls = (await S(page)).calls;
const el = calls.find((c) => c[0] === 'elevate');
ok(el && el[1].scope === 'all' && el[1].destDir === 'C:\\Program Files\\NOBODY' && el[1].lang === 'en' && !calls.some((c) => c[0] === 'startInstall'), 'elevate got the choices; startInstall never called', calls);
await page.getByText('Just me', { exact: false }).first().dispatchEvent('click');
ok(await uac(page) === null, 'switching to "Just me" clears it');
await ctx.close();

console.log('\n■ 3 · UAC accepted → this window waits to be replaced');
({ ctx, page, errs } = await open(CTX()));
await toDestination(page); await page.getByText('All users', { exact: false }).first().dispatchEvent('click');
await page.evaluate(() => { window.__S.elevateAnswer = 'ok'; });
await installBtn(page).dispatchEvent('click'); await page.waitForTimeout(500);
u = await uac(page);
ok(u && u[0] === 'handed' && await installBtn(page).isDisabled(), 'handed over: Install stays disabled (the elevated copy takes it from here)', u);
ok(!(await S(page)).calls.some((c) => c[0] === 'startInstall'), 'this (unelevated) copy installs nothing');
await ctx.close();

console.log('\n■ 4 · the elevated copy resumes straight into installing');
({ ctx, page, errs } = await open(CTX({ elevated: true, resume: { destDir: 'D:\\Apps\\NOBODY', scope: 'all', desktop: false, launchAfter: true, openFolder: false, lang: 'fa' } })));
await page.waitForTimeout(1200);
calls = (await S(page)).calls;
const si = calls.find((c) => c[0] === 'startInstall');
ok(si && si[1].scope === 'all' && si[1].destDir === 'D:\\Apps\\NOBODY' && si[1].desktop === false && si[1].launchAfter === true, 'starts installing with the handed-over choices', calls);
ok(await page.evaluate(() => document.documentElement.innerText.match(/[\u0600-\u06FF]/) !== null), 'in the language chosen before the prompt (fa)');
ok(!calls.some((c) => c[0] === 'elevate'), 'never asks again');
await ctx.close();

console.log('\n■ 5 · already elevated ("Run as administrator") → no extra prompt');
({ ctx, page, errs } = await open(CTX({ elevated: true })));
await toDestination(page); await page.getByText('All users', { exact: false }).first().dispatchEvent('click');
ok(await uac(page) === null, 'no admin note');
await installBtn(page).dispatchEvent('click'); await page.waitForTimeout(400);
calls = (await S(page)).calls;
ok(calls.some((c) => c[0] === 'startInstall' && c[1].scope === 'all') && !calls.some((c) => c[0] === 'elevate'), 'installs directly');
await ctx.close();

console.log('\n■ 6 · Persian');
({ ctx, page, errs } = await open(CTX(), 'fa'));
await page.waitForTimeout(500);
const isFa = await page.evaluate(() => /[\u0600-\u06FF]/.test(document.body.innerText));
if (!isFa) await page.evaluate(() => {});
await toDestination(page);
await page.getByText('همه‌ی کاربرها', { exact: false }).first().dispatchEvent('click');
u = await uac(page);
ok(u && /اجازه/.test(u[1]), 'admin note in Persian', u);
ok(errs.length === 0, 'no page errors', errs);
await ctx.close();
await browser.close();
console.log(`\n${pass}/${pass + fail} passed`);
if (fails.length) console.log('FAILED:\n - ' + fails.join('\n - '));
