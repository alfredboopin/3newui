import { build } from '/opt/sd-artifact/node_modules/esbuild/lib/main.js';
import fs from 'fs';
const NM = '/opt/sd-artifact/node_modules'; const SRC = '/home/user/work/src/setup-app';
const plug = { name: 's', setup(b) {
  b.onResolve({ filter: /^@\// }, (a) => ({ path: SRC + '/src/' + a.path.slice(2) + (fs.existsSync(SRC + '/src/' + a.path.slice(2) + '.tsx') ? '.tsx' : fs.existsSync(SRC + '/src/' + a.path.slice(2) + '.ts') ? '.ts' : fs.existsSync(SRC + '/src/' + a.path.slice(2) + '/index.ts') ? '/index.ts' : '') }));
  b.onResolve({ filter: /^@shared\// }, (a) => ({ path: SRC + '/shared/' + a.path.slice(8) + '.ts' }));
  b.onLoad({ filter: /\.css$/ }, (a) => ({ contents: fs.readFileSync(a.path, 'utf8').replace(/@import\s+"tailwindcss";?/g, ''), loader: 'css' }));
} };
fs.mkdirSync('dist', { recursive: true });
await build({ entryPoints: ['entry.tsx'], bundle: true, outdir: 'dist', format: 'esm', plugins: [plug], alias: { react: NM + '/react', 'react-dom': NM + '/react-dom', clsx: NM + '/clsx', 'tailwind-merge': NM + '/tailwind-merge' }, loader: { '.woff2': 'dataurl', '.woff': 'dataurl', '.ttf': 'dataurl', '.jpg': 'dataurl', '.png': 'dataurl', '.svg': 'dataurl' }, jsx: 'automatic', define: { 'process.env.NODE_ENV': '"development"', 'import.meta.env.DEV': 'false', 'import.meta.env.PROD': 'true' }, logLevel: 'error' });
fs.writeFileSync('dist/index.html', '<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="entry.css"></head><body><div id="root"></div><script type="module" src="entry.js"></script></body></html>');
console.log('built', fs.statSync('dist/entry.js').size);
