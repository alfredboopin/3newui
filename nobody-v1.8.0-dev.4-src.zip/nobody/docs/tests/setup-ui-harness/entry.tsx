import "./mock";
import { createRoot } from "react-dom/client";
import App from "/home/user/work/src/setup-app/src/App";
createRoot(document.getElementById("root")!).render(<App />);
