// window.nobodySetup mock for the setup UI run (1.8.0-dev.4). State: window.__S
const S: any = (window as any).__S = { calls: [], elevateAnswer: 'denied', ctx: JSON.parse(sessionStorage.getItem('__ctx') || 'null'), events: [] };
let cb: any = null;
(window as any).nobodySetup = {
  isSetup: true,
  getContext: async () => S.ctx,
  statPath: async () => ({ exists: false, isDir: false, freeBytes: 50e9 }),
  chooseDir: async () => null,
  startInstall: async (o: any) => { S.calls.push(['startInstall', o]); if (o.scope === 'all' && !S.ctx.elevated) return { ok: false, code: 'E_NEEDS_ELEVATION' }; return { ok: true }; },
  elevate: async (o: any) => { S.calls.push(['elevate', o]); await new Promise((r) => setTimeout(r, 150)); return S.elevateAnswer === 'ok' ? { ok: true } : { ok: false, code: S.elevateAnswer === 'denied' ? 'E_UAC_DENIED' : 'E_ELEVATE' }; },
  cancelInstall: async () => true, startUninstall: async () => ({ ok: true }), launchApp: async () => true, openFolder: async () => true,
  minimize: async () => {}, close: async () => { S.calls.push(['close']); },
  onEvent: (f: any) => { cb = f; return () => { cb = null; }; },
};
