// Specs for src/cinema/lib/smartPlaylist.ts + trackSort "rating".
import {
  evaluateSmart, smartIdsFor, dropSmartCache, normalizeSmartDef, ruleIsActive, ruleError,
  templateDef, SMART_TEMPLATES, fold, defaultRule, retypeRule, emptyDef, opsFor, SMART_FIELDS, FIELD_KIND,
  type SmartPlaylistDef, type SmartRule, type SmartCtx, type SmartInputs,
} from "../../src/cinema/lib/smartPlaylist";
import { sortTracksBy } from "../../src/cinema/lib/trackSort";
import { bridgeTrackToTrack, type BridgeTrack } from "../../src/cinema/lib/desktopBridge";
import { addedAtFor, mtimeFromStamp, _resetAddedAt } from "../../src/cinema/lib/addedAt";
import type { Track } from "../../src/cinema/types";

const DAY = 86400000;
const NOW = Date.UTC(2026, 9, 1, 8, 0, 0);

let pass = 0, fail = 0;
function ok(cond: unknown, name: string, extra?: unknown) {
  if (cond) { pass++; console.log("  ✓ " + name); }
  else { fail++; console.log("  ✗ " + name + (extra !== undefined ? "  → " + JSON.stringify(extra) : "")); }
}
const eq = (a: unknown, b: unknown, name: string) => ok(JSON.stringify(a) === JSON.stringify(b), name, { got: a, want: b });

function T(id: string, p: Partial<Track> = {}): Track {
  return {
    id, title: id, artist: "Artist", album: "Album", duration: 200, format: "mp3", bitrate: 320,
    hasCover: false, isPlaceholderCover: true, hasEmbeddedLyrics: false, batchId: "b",
    importedAt: NOW - 100 * DAY, fileName: id + ".mp3", fileSize: 1, ...p,
  } as Track;
}
const lib: Track[] = [
  T("a", { title: "Café del Mar", artist: "Energy 52", genre: "Trance; Electronic", year: "1993", duration: 420, importedAt: NOW - 2 * DAY, filePath: "D:\\Music\\Trance\\a.flac", format: "flac", bitrate: 900 }),
  T("b", { title: "علي", artist: "محسن چاوشی", genre: "Pop", year: "2019", duration: 180, importedAt: NOW - 40 * DAY }),
  T("c", { title: "Kalbim", artist: "Tarkan", genre: "Pop", year: "2001", duration: 240, importedAt: NOW - 10 * DAY }),
  T("d", { title: "Silence", artist: "Delerium", genre: "", year: "", duration: 600, importedAt: NOW - 400 * DAY, bitrate: 128 }),
  T("e", { title: "Нежность", artist: "Ёлка", album: "Unknown Album", genre: "Electronic", year: "2010", duration: 90, importedAt: NOW - 1 * DAY }),
];
const ctx: SmartCtx = {
  playCounts: { a: 12, b: 3, c: 0, e: 1 },
  ratings: { a: 5, b: 4, c: 2 },
  liked: new Set(["b", "e"]),
  lastPlayed: { a: NOW - 1 * DAY, b: NOW - 120 * DAY, e: NOW - 5 * DAY },
  now: NOW,
};
let rid = 0;
const R = (field: SmartRule["field"], op: SmartRule["op"], value?: string | number, extra: Partial<SmartRule> = {}): SmartRule => ({ id: "t" + rid++, field, op, value, ...extra });
const D = (rules: SmartRule[], p: Partial<SmartPlaylistDef> = {}): SmartPlaylistDef => ({ v: 1, match: "all", rules, sort: { key: "imported", reverse: false }, limit: null, seed: 7, ...p });
const ids = (def: SmartPlaylistDef, c: SmartCtx = ctx, l: Track[] = lib) => evaluateSmart(def, l, c).map((t) => t.id).sort().join("");
const ord = (def: SmartPlaylistDef, c: SmartCtx = ctx) => evaluateSmart(def, lib, c).map((t) => t.id).join("");

export async function run() {
  console.log("text folding");
  eq(fold("  Café  DEL\u200CMar "), "cafe del mar", "case + accents + ZWNJ + spaces");
  eq(fold("علي"), fold("علی"), "Arabic ي = Persian ی");
  eq(fold("كتاب"), fold("کتاب"), "Arabic ك = Persian ک");
  eq(fold("مَحسن"), "محسن", "harakat stripped");
  eq(fold("Ёлка"), fold("ёлка"), "Cyrillic case");

  console.log("text rules");
  eq(ids(D([R("title", "contains", "cafe")])), "a", "contains, accent-insensitive");
  eq(ids(D([R("title", "is", "علی")])), "b", "is, Arabic/Persian fold");
  eq(ids(D([R("artist", "startsWith", "del")])), "d", "startsWith");
  eq(ids(D([R("artist", "endsWith", "52")])), "a", "endsWith");
  eq(ids(D([R("title", "notContains", "a")])), "bde", "notContains");
  eq(ids(D([R("genre", "is", "electronic")])), "ae", "genre is → each multi-genre value");
  eq(ids(D([R("genre", "isNot", "pop")])), "ade", "genre isNot");
  eq(ids(D([R("genre", "isEmpty")])), "d", "isEmpty");
  eq(ids(D([R("album", "isEmpty")])), "e", "'Unknown Album' counts as empty");
  eq(ids(D([R("path", "contains", "\\trance\\")])), "a", "path contains");
  eq(ids(D([R("format", "is", "FLAC")])), "a", "format is (case)");

  console.log("number rules");
  eq(ids(D([R("rating", "gte", 4)])), "ab", "rating ≥ 4");
  eq(ids(D([R("rating", "eq", 0)])), "de", "rating = 0 → unrated");
  eq(ids(D([R("plays", "lte", 1)])), "cde", "plays ≤ 1");
  eq(ids(D([R("year", "between", 2010, { value2: 1999 })])), "ce", "year between (reversed bounds)");
  eq(ids(D([R("year", "neq", 2001)])), "abde", "year ≠ → yearless songs included");
  eq(ids(D([R("duration", "gte", 7)])), "ad", "duration in minutes (≥ 7 min)");
  eq(ids(D([R("duration", "eq", 1.5)])), "e", "duration = 1.5 min");
  eq(ids(D([R("bitrate", "lte", 128)])), "d", "bitrate ≤ 128");

  console.log("date + bool rules");
  eq(ids(D([R("added", "inLast", 2, { unit: "weeks" })])), "ace", "added in last 2 weeks");
  eq(ids(D([R("added", "notInLast", 1, { unit: "months" })])), "bd", "added not in last month");
  eq(ids(D([R("lastPlayed", "never")])), "cd", "never played");
  eq(ids(D([R("lastPlayed", "notInLast", 3, { unit: "months" })])), "b", "notInLast skips never-played");
  eq(ids(D([R("liked", "isTrue")])), "be", "liked");
  eq(ids(D([R("liked", "isFalse")])), "acd", "not liked");

  console.log("match / half-typed rules");
  eq(ids(D([R("rating", "gte", 4), R("liked", "isTrue")])), "b", "all");
  eq(ids(D([R("rating", "gte", 4), R("liked", "isTrue")], { match: "any" })), "abe", "any");
  eq(ids(D([R("artist", "contains", "  "), R("rating", "gte", 5)])), "a", "blank text rule ignored");
  eq(ids(D([R("year", "between", 2000)])), "abcde", "between without 2nd value ignored");
  eq(ids(D([R("title", "gte" as never, 3)])), "abcde", "op not valid for field ignored");
  eq(ids(D([])), "abcde", "no rules → whole library");
  ok(!ruleIsActive(R("added", "inLast", 0)), "inLast 0 inactive");
  eq(ruleError(R("rating", "gte", 6)), "range", "rating 6 → range error");
  eq(ruleError(R("title", "contains", "")), "value", "empty text → value error");
  eq(ruleError(R("liked", "isTrue")), null, "bool never errors");

  console.log("sort + limit");
  eq(ord(D([], { sort: { key: "rating", reverse: false } })), "abcde", "rating: high → low, unrated last (by title)");
  eq(ord(D([], { sort: { key: "rating", reverse: true } })).slice(0, 3), "cba", "rating reversed, unrated STILL last");
  ok(ord(D([], { sort: { key: "rating", reverse: true } })).slice(3).split("").sort().join("") === "de", "unrated tail in reverse");
  eq(ord(D([], { sort: { key: "plays", reverse: false } })), "abecd", "plays desc");
  eq(ord(D([], { sort: { key: "recent", reverse: false } })).slice(0, 3), "aeb", "recent = last played history");
  eq(ord(D([], { sort: { key: "imported", reverse: false } })), "eacbd", "imported = newest first");
  eq(ord(D([], { limit: { n: 2, unit: "songs" } })), "ea", "limit songs");
  eq(ord(D([], { limit: { n: 9, unit: "minutes" } })), "ea", "limit minutes fills in order (90+420 ≤ 540)");
  eq(ord(D([], { limit: { n: 1, unit: "hours" } })), "eacbd", "limit hours (1530 s ≤ 1 h → all)");
  eq(ord(D([], { limit: { n: 15, unit: "minutes" } })), "eac", "limit stops at the first song that does not fit (750 + 180 > 900)");
  const r1 = ord(D([], { sort: { key: "random", reverse: false }, seed: 11 }));
  const r2 = ord(D([], { sort: { key: "random", reverse: false }, seed: 11 }));
  ok(r1 === r2, "random: same seed → same order");
  const seeds = new Set(Array.from({ length: 12 }, (_, i) => ord(D([], { sort: { key: "random", reverse: false }, seed: i + 1 }))));
  ok(seeds.size > 4, "random: different seeds → different orders", seeds.size);
  const big = Array.from({ length: 2000 }, (_, i) => T("x" + i));
  const firsts = evaluateSmart(D([], { sort: { key: "random", reverse: false }, seed: 3 }), big, ctx).slice(0, 100).map((t) => +t.id.slice(1));
  ok(firsts.reduce((a, b) => a + b, 0) / 100 > 600 && firsts.reduce((a, b) => a + b, 0) / 100 < 1400, "random spread over a 2k library");

  console.log("templates / defaults / normalise");
  for (const id of SMART_TEMPLATES) {
    const d = templateDef(id);
    ok(normalizeSmartDef(JSON.parse(JSON.stringify(d))) !== null && d.rules.every(ruleIsActive), `template ${id} valid + round-trips`);
  }
  eq(ids(templateDef("topRated")), "ab", "Top rated");
  eq(ids(templateDef("recentlyAdded")), "ace", "Recently added (30 days)");
  eq(ids(templateDef("neverPlayed")), "cd", "Never played");
  eq(ids(templateDef("forgotten")), "b", "Forgotten favourites");
  eq(ids(templateDef("heavyRotation")), "a", "Heavy rotation (30 d + ≥3 plays)");
  eq(evaluateSmart(templateDef("random50"), big, ctx).length, 50, "50 random");
  for (const f of SMART_FIELDS) {
    const r = defaultRule(f);
    ok(opsFor(f).includes(r.op), `defaultRule(${f}) op valid`);
  }
  const rt = retypeRule(R("title", "contains", "x"), "rating");
  ok(FIELD_KIND[rt.field] === "number" && rt.op === "gte", "retype text → rating resets op");
  ok(retypeRule(R("title", "contains", "x"), "artist").value === "x", "retype text → text keeps value");
  ok(emptyDef().rules.length === 1, "emptyDef has one starter rule");
  eq(normalizeSmartDef(null), null, "normalise(null)");
  eq(normalizeSmartDef("x"), null, "normalise(string)");
  const n = normalizeSmartDef({ match: "any", rules: [{ field: "nope", op: "is" }, { field: "rating", op: "gte", value: "4" }, { field: "title", op: "gte", value: 1 }, 5, null, { field: "added", op: "inLast", value: 2, unit: "years" }], sort: { key: "bogus" }, limit: { n: 1e9, unit: "days" }, seed: "x" })!;
  eq(n.rules.map((r) => `${r.field}:${r.op}:${r.value}:${r.unit ?? ""}`), ["rating:gte:4:", "added:inLast:2:days"], "normalise drops junk rules, coerces numbers, fixes unit");
  eq([n.match, n.sort.key, n.limit, n.seed], ["any", "imported", { n: 100000, unit: "songs" }, 1], "normalise sort/limit/seed");
  eq(normalizeSmartDef({ rules: Array.from({ length: 80 }, () => ({ field: "liked", op: "isTrue" })) })!.rules.length, 50, "normalise caps 50 rules");

  console.log("cache (smartIdsFor)");
  dropSmartCache();
  const inp: SmartInputs = { tracks: Object.fromEntries(lib.map((t) => [t.id, t])), order: lib.map((t) => t.id), playCounts: ctx.playCounts, ratings: ctx.ratings, lastPlayed: ctx.lastPlayed, likedIds: ["b", "e"] };
  const def = D([R("rating", "gte", 4)]);
  const first = smartIdsFor("p1", def, inp, NOW);
  ok(smartIdsFor("p1", def, { ...inp }, NOW) === first, "same inputs → cached array");
  const after = smartIdsFor("p1", def, { ...inp, ratings: { ...inp.ratings, c: 5 } }, NOW);
  eq(after.slice().sort().join(""), "abc", "new ratings object → re-evaluated");
  const tdef = D([R("added", "inLast", 2, { unit: "days" })]);
  const t0 = smartIdsFor("p2", tdef, inp, NOW);
  ok(smartIdsFor("p2", tdef, inp, NOW + 30000) === t0 || Math.floor((NOW + 30000) / 60000) !== Math.floor(NOW / 60000), "time rule: same minute → cached");
  eq(t0.slice().sort().join(""), "ae", "time rule baseline (a: 2 d, e: 1 d)");
  eq(smartIdsFor("p2", tdef, inp, NOW + 0.5 * DAY).join(""), "e", "time rule: re-evaluated as time passes");
  const cacheLike = smartIdsFor("p3", D([R("liked", "isTrue")]), inp, NOW);
  eq(smartIdsFor("p3", D([R("liked", "isTrue")]), { ...inp, likedIds: ["a"] }, NOW).join(""), "a", "liked change re-evaluates");
  eq(cacheLike.join(""), "eb", "liked baseline (newest first)");

  console.log("perf");
  const huge: Track[] = Array.from({ length: 20000 }, (_, i) => T("h" + i, { title: "Song " + i, artist: "Artist " + (i % 300), genre: i % 3 ? "Rock; Pop" : "Jazz", year: String(1970 + (i % 50)), importedAt: NOW - (i % 400) * DAY }));
  const hctx: SmartCtx = { ...ctx, ratings: Object.fromEntries(huge.filter((_, i) => i % 4 === 0).map((t, i) => [t.id, 1 + (i % 5)])) };
  const t1 = performance.now();
  const res = evaluateSmart(D([R("genre", "is", "pop"), R("year", "between", 1980, { value2: 2000 }), R("artist", "contains", "artist 1")], { match: "all", sort: { key: "rating", reverse: false } }), huge, hctx);
  const ms = performance.now() - t1;
  ok(ms < 400, `20k tracks, 3 rules + rating sort in ${ms.toFixed(0)} ms`, ms);
  ok(res.length > 0, "perf query returns rows", res.length);

  console.log("desktop (bridged) tracks");
  const bt = (p: Partial<BridgeTrack>): BridgeTrack => ({ id: "9", title: "x", artist: "y", album: "", duration: 100, hasCover: false, order: 4, coverUrl: null, sourceUrl: null, ...p });
  const br = bridgeTrackToTrack(bt({ bitrate: "320 kbps" as unknown as number }));
  eq(br.bitrate, 320, "classic '320 kbps' string → number");
  eq(ids(D([R("bitrate", "gte", 256)]), ctx, [br]), "9", "bitrate rule works on bridged rows");
  const fresh = bridgeTrackToTrack(bt({ addedAt: NOW - 3 * DAY } as Partial<BridgeTrack>));
  eq(ids(D([R("added", "inLast", 7)]), ctx, [fresh]), "9", "bridged row with addedAt → 'added in last 7 days'");
  eq(bridgeTrackToTrack(bt({ bitrate: "—" as unknown as number })).bitrate, undefined, "'—' bitrate → undefined");
  eq(ids(D([R("bitrate", "gte", 300)]), ctx, [T("s", { bitrate: "320 kbps" as unknown as number })]), "s", "engine reads string bitrates too");
  eq(mtimeFromStamp("123:1700000000000"), 1700000000000, "mtime from size:mtime stamp");
  eq(mtimeFromStamp(undefined), undefined, "no stamp → undefined");
  _resetAddedAt({ migrating: true });
  const old = NOW - 500 * DAY;
  eq(addedAtFor("m1", old, NOW), old, "upgrade session: first seen = file mtime");
  eq(addedAtFor("m1", NOW - 3 * DAY, NOW), old, "stamp is sticky");
  eq(addedAtFor("m2", NOW + DAY, NOW), NOW, "future mtime ignored → now");
  _resetAddedAt({ migrating: false, map: { k: old } });
  eq(addedAtFor("n1", old, NOW), NOW, "after upgrade: new id = now, even with an old mtime");
  eq(addedAtFor("k", undefined, NOW), old, "known id keeps its stamp");
  _resetAddedAt({ migrating: false });
  const legacy = bridgeTrackToTrack(bt({ id: "L", order: 3 }));
  ok(legacy.importedAt === 1e12 + 3 && (legacy.addedAt ?? 0) > NOW - DAY, "bridged row keeps sort key importedAt, gets a real addedAt");
  eq(ids(templateDef("recentlyAdded"), { ...ctx, now: Date.now() }, [legacy]), "L", "Recently added template now sees desktop rows");
  return { pass, fail };
}
