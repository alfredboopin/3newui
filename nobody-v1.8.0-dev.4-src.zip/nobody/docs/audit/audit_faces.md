# Three engine-face UI audit (static)

Scope: `src/cinema`, `src/eela`, and `src/alok` UI code and their three `index.css` files. The shared engine was read only to verify the state-mirror contract. No runtime/build test was possible because this is a read-only source tree without dependencies.

## Executive summary

The biggest concrete risks are (1) EELA's module-global dock `requestAnimationFrame` loop, which is never canceled and survives switching away from EELA, (2) EELA and ALOK's non-virtualized track lists, and (3) Cinema's whole-Zustand-store subscriptions. All three faces also have rAF loops that continue scheduling while the desktop window is minimized/backgrounded; ALOK's loop checks whether its DOM is visible, but not `document.hidden`, and EELA's visualizer/clock loops do neither. Queue sheets are read-only in Cinema/EELA even though Cinema draws a grip affordance; only ALOK exposes reorder controls. Dialogs have Escape paths but no focus trap.

The engine calls `pushState()` from `timeupdate` (`src/cinema/lib/engine.ts:63`, then `71-85`), so every selector-less `useUi()`/`useLibrary()` subscription below is a render-storm source while audio is playing.

## Findings

### High

#### F-01 — EELA dock rAF is a permanent module-level loop (high, performance/leak)
- **File:** `src/eela/components/PlayerBar.tsx:20-36,53`
- `startDockClock()` sets `clockStarted = true` and recursively calls `requestAnimationFrame(tick)`, but has no cancellation handle and no `stopDockClock`. `PlayerBar` calls it once in an effect at line 53. AppSwitch unmounts inactive engine faces (`src/AppSwitch.tsx:129-149`), but the loop keeps running forever after EELA is left; it only stops doing useful DOM writes when selectors return null.
- **Fix:** make the clock component-scoped with a cleanup, or expose a reference-counted start/stop service. Also pause on `document.hidden`.

#### F-02 — EELA main library mounts every track row (high, performance)
- **File:** `src/eela/components/LibraryView.tsx:474-533`
- `renderCard()` does `list.map(renderRow)` into one scroll container; All Songs/favorites/longest/queue and drilled groups can be the entire library. There is no `@tanstack/react-virtual` use in EELA. Each row contains CoverArt and multiple controls, so thousands of tracks create a large DOM and many subscriptions.
- **Fix:** share Cinema's virtualized `TrackList` (or create a face-neutral virtual list) and preserve row-specific actions via a render prop.

#### F-03 — ALOK panel lists are also fully mounted (high, performance)
- **Files:** `src/alok/components/Panel.tsx:203-210,364-370,390-403,526-535`
- Library, liked, recents, and playlist detail all use plain `.map()` over tracks. ALOK has no virtualizer, so the same large-library cost appears in each panel and playlist view.
- **Fix:** use one shared virtualized list for all track-bearing faces; keep the current `TrackRow` action surface as the row renderer.

### Medium

#### F-04 — Cinema PlayerBar subscribes to the entire UI store (medium, render storm)
- **File:** `src/cinema/components/PlayerBar.tsx:22-28`
- `const ui = useUi()` subscribes to every UI-store update, including every engine mirror update. It then rerenders the full dock (motion tree, CoverArt, controls) on each `timeupdate`, defeating the component's own “no React state per frame” comment.
- **Fix:** select only `currentId`, `isPlaying`, `repeat`, `shuffle`, `queueLength`, and `hasAudio` with individual selectors (or a shallow selector).

#### F-05 — Cinema NowPlaying has the same whole-store subscription
- **File:** `src/cinema/components/NowPlaying.tsx:30-37`
- `const ui = useUi()` causes the expanded stage to rerender on every mirror update even though its progress rAF writes directly to refs. This is especially expensive while the stage includes DreamField, visualizer and lyrics.
- **Fix:** split selectors; keep only the fields used by the render/effects.

#### F-06 — Cinema PlaylistsView subscribes to the complete library store
- **File:** `src/cinema/components/PlaylistsView.tsx:17-31`
- `const lib = useLibrary()` subscribes to every library update, including unrelated track patches/accent changes. The page also renders every playlist track directly at `199-228`.
- **Fix:** select only playlist mutation functions (`createPlaylist`, `renamePlaylist`, etc.) and virtualize the detail list.

#### F-07 — Cinema CommandPalette subscribes to two complete stores
- **File:** `src/cinema/components/CommandPalette.tsx:31-37,50-127`
- `const library = useLibrary()` and `const settings = useSettings()` subscribe the palette to every library/settings update. Its `useMemo` then rebuilds action/track rows and closures for each update, including engine mirror-induced UI activity indirectly through library changes.
- **Fix:** select `tracks`, `playlists`, and the settings fields actually used; use `getState()` for action-only mutation functions. Cap/virtualize results if the palette grows.

#### F-08 — EELA visualizer never tests `document.hidden` (medium, minimized/background CPU)
- **File:** `src/eela/components/EelaVisualizer.tsx:35-72`
- `draw()` schedules the next rAF before doing work and has no `document.hidden` guard. It remains active whenever the EELA ambient overlay is shown, including when the Electron window is minimized/backgrounded. The loop still samples the analyser, smooths every bar, clears and repaints the canvas.
- **Fix:** pause/cancel on `visibilitychange` (and restart on visible), or at minimum return before analyser/canvas work when hidden.

#### F-09 — EELA Now Playing clock and lyrics loops lack hidden-window pausing
- **Files:** `src/eela/components/NowPlaying.tsx:174-189` (`NpClock`), `src/eela/components/NowPlaying.tsx:211-225` (`LyricsSheet`)
- Both loops continuously reschedule rAF and mutate DOM/state without a `document.hidden` check. The lyrics loop can still call `setActive` after background frames. `EelaSlider` has the same unconditional loop at `src/eela/components/EelaSlider.tsx:24-35` (each mounted slider).
- **Fix:** centralize a visibility-aware frame scheduler and use it for clocks, lyrics, sliders and visualizers.

#### F-10 — ALOK Core and lyrics loops lack `document.hidden` pausing
- **Files:** `src/alok/components/Core.tsx:115-149,176-215,224-236`; `src/alok/components/LyricsSheet.tsx:34-46`
- Core's progress clock, bass/glow loop, and mini-lyrics loop, plus LyricsSheet's active-line loop, all continuously schedule rAF. Core's visibility check uses `root.getClientRects()` only (`185-186`), which detects an unmounted/display:none root but not a minimized/background window. ALOK's RadialViz does the same kind of root check at `src/alok/components/RadialViz.tsx:48-57` and also lacks `document.hidden`.
- **Fix:** add a shared visibility listener; stop scheduling while hidden and wake on visible. The root check is still useful for pane visibility.

#### F-11 — Classic→face handoff `loadedmetadata` listeners can leak forever
- **Files:** `src/cinema/App.tsx:128-145`, `src/eela/App.tsx:130-145`, `src/alok/App.tsx:143-158`
- Each handoff adds `onMeta` when the current duration is unavailable, but cleanup only happens inside `onMeta` after a successful seek. If the source errors, is replaced before metadata, or metadata never arrives, the listener remains attached to the singleton audio element. Repeated switches accumulate closures.
- **Fix:** return/capture a cleanup path for the pending listener, remove it on component effect cleanup and on source/track change, and/or use a one-shot guarded listener plus an abort token.

#### F-12 — Dialogs have Escape but no focus trap/initial-return focus
- **Files:** representative examples `src/cinema/components/QueueSheet.tsx:29-46`, `src/eela/components/QueueSheet.tsx:23-33`, `src/alok/components/QueueSheet.tsx:29-36`; same pattern in NowPlaying/FX/lyrics/palette/panels.
- These surfaces set `role="dialog"` (some omit `aria-modal`) and provide close buttons/global Escape, but do not move focus into the dialog, contain Tab/Shift+Tab, or restore focus to the trigger. Keyboard users can tab into the obscured page behind the scrim. This is a concrete interaction/accessibility failure, not merely styling.
- **Fix:** shared `Dialog`/`Sheet` primitive with `aria-modal="true"`, initial focus, focus cycling, Escape, and trigger-focus restoration.

#### F-13 — Cinema queue advertises drag/reorder but cannot reorder
- **File:** `src/cinema/components/QueueSheet.tsx:66-103`
- Every queue row renders `GripVertical` at line 87, but the row has no drag handlers, pointer capture, drop target, or move control. Users receive a reorder affordance that does nothing; only removal and jump work. EELA's queue is similarly read-only (`src/eela/components/QueueSheet.tsx:48-75`), despite the feature being expected by the shared engine.
- **Fix:** wire the grip to `engine.moveInQueue()` with a real drag/drop or up/down controls, or remove the grip and label reorder as unsupported. Reuse one queue component across faces.

#### F-14 — EELA playlist delete control is an inaccessible nested interactive
- **File:** `src/eela/components/PlaylistsView.tsx:49-87`
- A `span role="button" tabIndex={0}` is nested inside a `<button>` (lines 52 and 70). Its `onKeyDown` only calls `stopPropagation` (line 82); Enter/Space on that focused role-button never invokes delete, while native HTML interactive nesting is invalid and can produce inconsistent browser/Electron focus behavior.
- **Fix:** make the playlist row a non-button container with separate real buttons, or move delete outside the row button and implement Enter/Space activation if a custom role remains.

#### F-15 — Ctrl/⌘+K (and Cinema Ctrl/⌘+E) fires while typing
- **Files:** `src/cinema/App.tsx:224-244`, `src/alok/App.tsx:218-229`
- Both handlers intentionally process Ctrl/⌘+K before the `typing` guard. In a text/search input, Ctrl/⌘+K opens/toggles the palette (and Cinema Ctrl/⌘+E opens FX) and calls `preventDefault`, stealing an editing shortcut from the field. Other transport keys are guarded correctly.
- **Fix:** ignore global shortcuts when the target is an input/contenteditable unless the shortcut is explicitly documented and desired; if palette-from-input is intentional, do not suppress the field's default unless needed.

### Low

#### F-16 — Cinema dynamic accent extraction leaks its temporary blob URL on image failure
- **File:** `src/cinema/lib/covers.ts:95-112`
- `extractAccent()` creates a blob URL at line 100 and revokes it only after successful image load/draw at line 111. The `img.onerror` rejection takes the `catch` path at 142-145 without revoking the URL. Bad/corrupt covers can therefore accumulate unreleased blob URLs across repeated accent attempts.
- **Fix:** put `URL.revokeObjectURL(url)` in a `finally` around image decode/use.

#### F-17 — Large always-on decorative animation/blur budgets remain in Cinema/ALOK
- **Files:** `src/cinema/index.css:205-257,372-375`; `src/alok/index.css:1783-1821,1945-1980,2877-2878`
- Cinema's root DreamField has four 90px-blurred, `will-change: transform` vMax blobs plus two infinite dust animations; it is mounted behind the whole face, and its reduced-motion rule is the only pause mechanism. ALOK has an animated bass-scaled blurred aurora and an always-running ring/orbit animation; several large sheet surfaces use 14px backdrop blur (`2877-2878`). These are not correctness crashes, but on a desktop GPU under load they add continuous raster/compositor work even when audio is paused. EELA uses smaller, mostly static/pre-rendered cover backdrops, but its ambient veil still animates (`src/eela/index.css:711-765`).
- **Fix:** gate decorative animations on active playback/visibility, remove `will-change` from permanently animated blur blobs where possible, and use a reduced-cost static mode when minimized or idle.

## Feature inventory

Status meanings: **Present** = directly available in that face; **Partial** = related capability exists but scope is incomplete; **Absent** = no corresponding UI found in this slice. This is a source inventory, not a claim about engine/classic features outside the slice.

| User-facing feature | Cinema | EELA | ALOK | Evidence / notes |
|---|---|---|---|---|
| Library: songs | Present | Present | Present | Cinema `LibraryView.tsx:76,263-275`; EELA `LibraryView.tsx:267-289`; ALOK `Panel.tsx:119-210`. |
| Library: albums | Present | Present | Absent | Cinema/EELA group categories; ALOK has one flat library plus folders. |
| Library: artists | Present | Present | Absent | Cinema `LibraryView.tsx:208-216`; EELA `LibraryView.tsx:193-203`; no ALOK artist chapter. |
| Library: genres | Absent | Absent | Absent | No `genres` category/group or genre selector found in any face. |
| Library: folders | Present | Present | Present | Cinema/EELA folder chapters and ALOK `FoldersSection` (`Panel.tsx:224-344`). |
| Search | Present | Present | Present | Cinema Library search `LibraryView.tsx:487-496` and palette; EELA `LibraryView.tsx:259-289`; ALOK `Panel.tsx:165-175`. |
| Sort | Present | Present | Present | Cinema 4 sort keys `LibraryView.tsx:71,500-509`; EELA `LibraryView.tsx:325-347`; ALOK `Panel.tsx:117-138,177-187`. |
| Filters | Partial | Partial | Partial | Cinema category/search and Smart Fetch scopes; EELA Downloads status/scope filters but no general library filter; ALOK Downloads status/scope filters (`DownloadsView.tsx:513-616`) but no general library filter. |
| Playlists CRUD | Present | Partial | Partial | Cinema create/rename/delete/reorder/remove (`PlaylistsView.tsx:81-101,128-228`); EELA create/delete/remove but no rename/reorder (`PlaylistsView.tsx:49-105,129-155`); ALOK create/delete/add/remove but no rename/reorder (`Panel.tsx:409-535`). |
| Queue view | Present | Present | Present | Cinema `QueueSheet.tsx:29-105`; EELA `QueueSheet.tsx:23-75`; ALOK `QueueSheet.tsx:29-136`. |
| Queue reorder | Absent | Absent | Present | Cinema grip is inert; EELA has no reorder control; ALOK up/down calls `engine.moveInQueue` (`QueueSheet.tsx:95-112`). |
| Play next / add to queue | Present | Partial | Partial | Cinema TrackList/palette expose add and play-next (`TrackList.tsx:188-230`, palette Tab action); EELA rows add to queue but no play-next control; ALOK rows add to queue (`TrackRow.tsx:138-148`) but no explicit play-next control. |
| Lyrics view | Present | Present | Present | Cinema `LyricsView`; EELA `NowPlaying.tsx:160-165`/`LyricsSheet`; ALOK `LyricsSheet.tsx`. |
| Visualizer | Present | Present | Present | Cinema `Visualizer.tsx`; EELA `EelaVisualizer.tsx`; ALOK `RadialViz.tsx`/Core. |
| Mini-player | Present | Present | Absent | Cinema PlayerBar and EELA PlayerBar are persistent docks; ALOK has the central Core, no separate mini-player/dock. |
| EQ UI | Present | Absent | Present | Cinema `FxSheet.tsx`; ALOK `FxSheet.tsx`; EELA only exposes lyric/effect style settings, no EQ gain/control sheet. |
| Sleep timer | Present | Absent | Present | Cinema/ALOK FX sheets include timer options; no EELA timer surface found. |
| Playback speed | Present | Absent | Present | Cinema/ALOK FX sheets call `engine.setRate`; no EELA speed control. |
| Tag editor | Absent | Absent | Absent | No metadata/tag editing form or mutation UI found in these faces; download pickers edit query fields, not track tags. |
| Stats/history | Partial | Partial | Partial | Cinema most-played and play counts; EELA most-played; ALOK Recents and shared counts, but no full stats/history dashboard. |
| Favorites / ratings | Partial | Partial | Partial | All faces expose likes/favorites; no star/numeric rating control found. |
| Context menus | Present | Absent | Absent | Cinema TrackList “more” popover has playlist/remove actions (`TrackList.tsx:203-233`); EELA/ALOK use inline buttons/popovers, not a context-menu surface. |
| Drag-and-drop import | Present | Present | Present | Window-level guarded handlers in Cinema `App.tsx:181-222`, EELA `App.tsx:161-202`, ALOK `App.tsx:173-213`. |
| Keyboard shortcuts | Present | Present | Present | Cinema broad transport/palette/FX/ambient/overlay handling `App.tsx:224-268`; EELA transport/Escape `App.tsx:204-225`; ALOK transport/volume/queue/FX/palette `App.tsx:215-265`. |
| Settings | Present | Present | Present | Cinema `SettingsView`, EELA `SettingsView`, ALOK `Panel.tsx:540-750`. |

## Duplication / architecture opportunities

- All three faces duplicate classic handoff consumption, including the vulnerable pending-`loadedmetadata` listener (`App.tsx` in each face). Move this to one shared hook/service with abortable cleanup.
- Cinema/EELA/ALOK duplicate queue-sheet rendering and queue semantics. A shared queue model/view should expose shuffle-aware listen order, jump/remove/reorder consistently; currently only ALOK has controls.
- Cinema's virtualized `TrackList` should become a face-neutral list primitive; EELA and ALOK currently duplicate row maps and pay the full DOM cost.
- The visualizer scheduling logic is duplicated across Cinema, EELA, and ALOK with inconsistent hidden-window behavior. One shared `useVisibilityRaf` helper would prevent regressions.
- Dialog/sheet focus management is duplicated as ad hoc scrims and Escape listeners. A shared accessible sheet/dialog primitive would address F-12 across all faces.

## Limitations / unverified areas

- This was static analysis only; no dependency install, TypeScript compile, Electron run, profiler, or interaction test was available. Runtime effects (actual frame rate, GPU cost, browser interpretation of nested interactive markup) should be confirmed in a build.
- The shared engine was used only to verify that `timeupdate` mirrors state and that queue operations are listen-position based. Engine correctness itself was outside this slice.
- Inventory statuses are limited to the three requested faces. Classic UI, engine APIs, and download/metadata code outside these face components may expose additional capabilities not reachable from the listed face UIs.
