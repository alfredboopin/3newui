# Shared audio engine and data-layer audit

Static audit of the requested shared slice (`cinema/lib`, `cinema/store`, the shared parser/lyrics/desktop helpers). No build or runtime tests were possible because dependencies are absent. Line numbers refer to the checked-in source.

## Executive findings

### 1. HIGH — track-load race can play the wrong track and revoke the current URL
**`src/cinema/lib/engine.ts:271-325`**

`loadCurrent()` has no request/generation token. It awaits `db.getFile()` in `applySource()`, so two rapid `setQueue`/`next`/`jumpTo` calls can resolve out of order. A stale request then assigns its source, calls `play()`, and can revoke the object URL installed by the newer request (`applySource` lines 275-285). This is reproducible for IDB-backed tracks; bridge URLs make the window smaller but do not make the API cancellation-safe. The resulting `currentId`, audio source, emitted `track`, and autoplay state can disagree.

**Fix:** increment a `loadGeneration` on every load/clear; capture it before every `await`, and after each await return if stale. Revoke/install URLs only in the winning generation. Also pause before changing source and make `loadCurrent` return a promise that callers can await.

### 2. HIGH — missing-file fallback can loop forever
**`src/cinema/lib/engine.ts:310-315`, `359-382`**

When `applySource(id)` fails, `loadCurrent` calls `next()` with the default `auto=false`. At the final queue item, `next(false)` wraps `pos` to zero and calls `loadCurrent(true)` again (lines 366-374). A queue containing only a deleted/missing file therefore cycles indefinitely; a queue of all missing files does the same, repeatedly issuing IDB reads and `play()` calls.

**Fix:** distinguish an invalid source from user “next”: remove/skip invalid IDs, or call a guarded `next(true)` that stops at end. If no playable item remains, call `stopAndClear()` and surface an error once.

### 3. HIGH — Smart Fetch cancellation/start has a global run race
**`src/cinema/lib/smartFetch.ts:162-173`, `357-427`, `429-433`**

`cancelled` is one module-global boolean. `cancelSmartFetch()` sets `running:false` immediately while old workers remain in flight; a new `startSmartFetch()` resets `cancelled=false`. Old workers can then continue, write statuses into the new run (same `trackId`), and increment the new run's `done` counter. Cancellation is therefore not a barrier.

**Fix:** use a monotonically increasing `runId` captured by every worker and reject all state updates whose id is no longer current. Keep `running` true until the old pool settles, or explicitly separate active and cancelling runs.

### 4. HIGH — Cinema standalone import does not use the broad parser
**`src/cinema/lib/importer.ts:7,242-280`; `src/cinema/lib/metadata.ts:94-151`; contrast `src/audioParser.ts:47-105`**

The shared Cinema importer calls `parseFileMeta`, which parses only ID3v2/ID3v1. The much broader parser (`audioParser.ts`) is used by the legacy `src/App.tsx`, not by this importer. Thus a standalone Cinema/EELA/ALOK import of FLAC Vorbis comments/Picture, Ogg comments, MP4 `ilst`/cover, WAV `LIST/INFO`, or AIFF `COMM` metadata falls back to filename/default values and placeholder art. The picker advertises all of those formats (`importer.ts:157-160`) but the metadata path does not support them.

**Fix:** make `parseFileMeta` call the bounded `parseAudioFileMetadata` (passing desktop head/tail/real size where available), or share one parser result type and one import pipeline. Add explicit tests for each advertised container.

### 5. HIGH — ID3 unsynchronisation is ignored in both parsers
**`src/audioParser.ts:180-318`; `src/cinema/lib/metadata.ts:94-135`**

Neither implementation checks the ID3 header unsynchronisation flag (`flags & 0x80`) or removes inserted `00` bytes before decoding frame payloads. Valid tags using unsynchronisation can produce corrupted UTF-16/text, malformed APIC boundaries, and unusable USLT/SYLT data; frame boundaries can also become wrong if parsing the transformed payload as raw bytes.

**Fix:** after reading the tag body, de-unsynchronise `FF 00` → `FF` (with the ID3 rules) before frame walking, while retaining the tag-size bounds; or parse frame boundaries in the unsynchronised byte stream and de-unsync each payload according to the tag/frame flags.

### 6. HIGH — ID3v2.3 extended headers are not skipped
**`src/cinema/lib/metadata.ts:107-110`; `src/audioParser.ts:191-203`**

`metadata.ts` only recognizes an extended header for v2.4 (`ver === 4`), despite parsing v2.3 frames. `audioParser.ts` ignores extended-header flags entirely. A valid v2.3 tag with an extended header is consequently walked from the wrong byte and its text/APIC fields are commonly missed.

**Fix:** implement version-specific extended-header lengths (v2.3 big-endian size/structure, v2.4 syncsafe structure) and start frame walking after the complete header; handle padding/footer flags separately.

### 7. HIGH — MP4 version-1 `mvhd` duration has high/low 32-bit words reversed
**`src/audioParser.ts:620-632`**

For a version-1 `mvhd`, duration is a 64-bit big-endian integer with the high word at `bodyStart + 24` and low word at `+28`. The code computes `getUint32(+28) * 2^32 + getUint32(+24)`, reversing them. Long or ordinary MP4/M4A durations can become wildly incorrect and are then trusted by the classic importer (`src/App.tsx:1467-1471`).

**Fix:** `duration = view.getUint32(bodyStart + 24) * 4294967296 + view.getUint32(bodyStart + 28)` (or use `getBigUint64` with a safe-number check).

### 8. MEDIUM — embedded ID3 SYLT lyrics are silently dropped for MPEG-frame time format
**`src/audioParser.ts:261-289`**

SYLT supports time format 1 (MPEG frames) and 2 (milliseconds), but the implementation emits lines only when `timeFormat === 2` (line 281). Valid SYLT tags using MPEG-frame timestamps produce no lyrics at all.

**Fix:** support format 1 using the stream's MPEG sample/frame timing, or retain the synchronized entries as a best-effort sequence and mark the timing approximation.

### 9. MEDIUM — MP4 `data` box type is read from the wrong offset
**`src/audioParser.ts:581-610`**

Inside an MP4 `data` box, the first 4 bytes are version/flags and the next 4 are the data type. The code masks `getUint32(childBody)` (the flags) and uses that as `kind`, so `covr` PNG/JPEG detection is wrong (normally it always falls back to JPEG). This does not usually prevent image bytes from being extracted, but reports the wrong MIME and can make downstream image handling fail for PNG art.

**Fix:** read `const kind = view.getUint32(childBody + 4)` and start text/image payload at `childBody + 8` as already done.

### 10. MEDIUM — `looksLikeLrc` rejects valid timestamp-only LRC syntax
**`src/cinema/lib/lyrics.ts:33-35`; top-level duplicate `src/lrc.ts:9-21`**

The parser accepts `[mm:ss]` (fraction optional), but `looksLikeLrc()` requires `[mm:ss.xxx]`. A sidecar or embedded lyric file containing only whole-second timestamps is classified as plain text by `importer.ts:270-272`, so it never becomes synced lyrics. The top-level legacy parser has no offset support at all (`src/lrc.ts:9-21`), while the Cinema parser does implement `[offset:]` (`cinema/lib/lyrics.ts:11-14`), creating inconsistent behavior across faces.

**Fix:** make detection use the same timestamp regex as parsing, e.g. `/\\[\\d{1,3}:\\d{2}(?:[.:]\\d{1,3})?\\]/`; share one parser/detector and offset implementation.

### 11. MEDIUM — cover caches are unbounded and cover URL calls can leak duplicate URLs
**`src/cinema/lib/covers.ts:11-12,147,155,244-285,288-291`**

`urlCache`, `blurCache`, `paletteCache`, and `accentCache` grow for every distinct track key. `invalidateCover()` removes one entry, but normal library rescans/replacements do not necessarily invalidate all derived entries; `revokeAllCovers()` only revokes/clears `urlCache`, leaving the data-URL blur and palette/accent maps populated. In addition, two concurrent `coverUrl(trackId)` calls can both miss, each create a URL, and the first URL is overwritten at line 273 without revocation.

**Fix:** use an LRU/size-bounded cache with explicit eviction, clear all four caches in the global cleanup, and deduplicate in-flight `coverUrl` promises (`Map<string, Promise<string|null>>`).

### 12. MEDIUM — broken-image path leaks an object URL in `extractAccent`
**`src/cinema/lib/covers.ts:96-145`**

The temporary URL is revoked only after `await` resolves successfully (line 111). If image decoding rejects at line 104, control goes to the outer catch and returns a fallback without revoking the URL. Repeated corrupt/unsupported cover blobs leak one object URL per attempt.

**Fix:** wrap image loading in `try/finally { URL.revokeObjectURL(url) }`, and close/cleanup any bitmap/canvas resources in the analogous palette path.

### 13. MEDIUM — bridge cover blob cache is unbounded
**`src/cinema/lib/desktopBridge.ts:116-136`**

`coverBlobCache` retains a Promise and URL for every bridged track. It is invalidated only when a cover is written. Track deletion, folder removal, and bridge URL churn leave stale blobs/promises in the module map for the entire session.

**Fix:** invalidate on bridge library notifications/removals, bound the cache, and use an abortable/TTL cache. Do not cache failed/null results indefinitely unless a short TTL is intentional.

### 14. MEDIUM — subfolder grouping is O(n²) on directory-heavy libraries
**`src/cinema/lib/libraryIndex.ts:114-132`**

`subfoldersUnder()` builds all directories, then for every child directory filters/scans the entire `tracks` array. With many folders (e.g. one or more tracks per folder across 10k+ tracks), this is O(number-of-directories × number-of-tracks), potentially quadratic. The other groupers are largely linear plus sorting.

**Fix:** build a normalized directory-to-tracks index once, or accumulate each track into all needed ancestor/direct-child buckets in one pass; cache indexes by library revision.

### 15. MEDIUM — folder deletion performs redundant IDB writes and thousands of store updates
**`src/cinema/lib/folderManager.ts:90-110`; `src/cinema/store/library.ts:152-174`**

`removeFolder()` explicitly deletes track/file/cover records, then calls `lib.removeTrack()`, which deletes the same records again and updates the Zustand store/playlists once per track. Ten-thousand-track removal causes repeated full-map/filter allocations, repeated playlist writes, and many React notifications.

**Fix:** add one bulk `removeTracks(ids)` transaction/store action; delete all object-store keys in one transaction, update the in-memory state once, and persist affected playlists once.

### 16. MEDIUM — Smart Fetch status updates are O(items²)
**`src/cinema/lib/smartFetch.ts:164-173`, `422-426`**

Every item completion maps the full `items` array (`setStatus`), so a 10k-item run does roughly 100 million item visits before React rendering costs. `done` is also updated per completion. This is avoidable for the stated large-library target.

**Fix:** store item status in a `Record<id,status>`/Map and update one key; batch completion updates or use a mutable job model with one throttled Zustand publish.

### 17. MEDIUM — desktop folder import serializes every metadata read
**`src/desktopLibrary.ts:275-301`**

`loadDesktopFolders()` loops folders, then audio paths, awaiting `readDesktopFile()` one at a time. Each file can require stat, head read, tail read, source URL conversion, and IPC. A 10k-track folder therefore has fully serialized metadata I/O, despite the importer’s later parse/probe pools being bounded.

**Fix:** use a bounded pool (e.g. 4–8 files) for `readDesktopFile`; keep the pool small enough to avoid disk/IPC contention and preserve result association.

### 18. MEDIUM — media-session support is absent when booting directly into EELA/ALOK
**`src/cinema/App.tsx:270-271`; `src/AppSwitch.tsx:129-149`; `src/cinema/lib/mediaSession.ts:56-83`**

Only `CinemaApp` calls `initMediaSession`. `AppSwitch` explicitly unmounts hidden engine faces, so a session started directly in EELA or ALOK never installs Media Session handlers/metadata. If Cinema was previously mounted, its subscription is removed on unmount (handlers remain due `bound`, but metadata/playback mirroring stops). The shared engine itself supports the actions, but initialization is not shared.

**Fix:** initialize media session once at the root/shared engine module, or call it from a root that remains mounted; separately maintain one subscription and cleanly replace/clear action handlers.

### 19. LOW/MEDIUM — `mediaKeys` teardown does not unregister the native callback
**`src/mediaKeys.ts:20-33`**

`installMediaKeyBridge()` returns cleanup that only resets a boolean. It cannot remove the callback previously passed to `api.onMediaKey`. If the root is torn down/reinitialized and the bridge permits repeated registration, callbacks accumulate and each key dispatches multiple events.

**Fix:** have preload expose an unsubscribe function, or install exactly once for process lifetime and make cleanup a no-op by contract.

### 20. LOW — recent entries can accumulate duplicates in IndexedDB
**`src/cinema/store/library.ts:237-245`; `src/cinema/lib/db.ts:142-145`**

The in-memory recents list de-duplicates by track id, but IDB uses `at` as the key and `pushRecent` only inserts a new timestamp. Older entries for the same track remain forever. Repeated plays eventually make `getRecents()` return many copies of the same track, crowding the 60-entry slice and growing the store.

**Fix:** maintain one record per track (track id key), or delete older entries for that track in one transaction before inserting; periodically compact old records.

### 21. LOW — `autoApply:false` plus `saveToDisk:false` discards a successful Smart Fetch result
**`src/cinema/lib/smartFetch.ts:213-239`, `241-273`**

When both options are false, lyric/cover bytes are fetched but neither written to the library nor saved to disk, while the item is reported `saved` (lines 309-310 / 320-321). The option comments say data is only persisted to sidecars when `autoApply` is false, but `saveToDisk` can also be false.

**Fix:** reject that option combination, or retain the result in a session cache and report `preview`/`discarded` rather than `saved`.

## Additional parser and data-layer observations

* `audioParser.ts:215-221` correctly distinguishes v2.3 big-endian frame sizes from v2.4 syncsafe sizes; that specific issue is not a bug. The missing unsynchronisation/extended-header handling above is the surrounding correctness gap.
* `audioParser.ts:702-739` only finds an EOF `moov` when the complete box starts inside the supplied tail slice and uses a 32-bit size. A `moov` larger than the 1 MiB tail, or whose header begins before the tail boundary, is not recovered; duration/metadata then falls back to probing/empty values. This is a bounded limitation, not a universal failure.
* `audioParser.ts:748-830` limits initial Ogg comment collection to 32 pages and scans backward for the last `OggS` magic without validating the page checksum/structure. Huge comment headers can be truncated; accidental magic bytes near EOF can produce a bad duration. Consider parsing page lacing/serial/checksum and using a reliable tail-page boundary.
* `audioParser.ts:846-920` and `937-975` are functional for bounded WAV/AIFF heads, but desktop head-only files cannot expose metadata chunks beyond the 3 MiB head. `parseAiff` also labels every AIFF/AIFC stream `PCM` without examining the AIFC compression type.
* `src/cinema/lib/metadata.ts:164-190` revokes probe object URLs, which is correct, but timed-out `Audio` objects are not explicitly cleared (`src`/handlers); explicit teardown would reduce pressure during very large failed imports.
* `src/cinema/lib/db.ts:19-37` permanently memoizes a rejected `indexedDB.open()` promise. A transient open/version/quota failure poisons all future calls until page reload; clear `dbp` on open error/blocked/version-change and expose an actionable error.
* `src/cinema/lib/db.ts:41-50` resolves per-request success rather than transaction completion. This is acceptable for simple reads, but writes can report success before a later transaction abort; write helpers should resolve on `oncomplete` and reject on `onabort`.
* `src/cinema/store/library.ts:87-112` catches every hydration failure and marks the store hydrated with empty data. This makes quota/schema/IDB failures look like an empty library. Preserve an error state and allow retry.
* `src/cinema/lib/mediaSession.ts:21-25` always labels bridged artwork as `image/jpeg`; PNG/WebP URLs/blobs are mislabeled in the Media Session metadata. Standalone IDB covers are never used there, only the bridge URL/fallback.
* `src/cinema/lib/engine.ts:451-460` persists the complete queue in `localStorage` on every volume change/tick timer. A 10k-track queue can hit localStorage limits and JSON serialization costs; failures are swallowed. Use IndexedDB for large resume state and debounce writes.
* `src/cinema/lib/engine.ts:55-68` intentionally installs singleton listeners once and `Emitter.on()` returns an unsubscribe; those specific listener patterns are not leaks in the module-singleton design. `folderManager` and UI event effects do remove their listeners.

## Feature inventory (shared engine/data layer)

| Feature | Status | Evidence / scope |
|---|---|---|
| HTML audio playback | **Present** | Singleton `HTMLAudioElement`, source resolution and play/pause in `engine.ts:27-68,268-350`. |
| WebAudio analyser/visualizer feed | **Present** | `ensureGraph()` creates analyser and `freqData()` exposes bytes (`engine.ts:108-140`, `97-105`). |
| Queue create/start | **Present** | `setQueue(ids,startId,autoplay)` (`engine.ts:172-184`). |
| Queue add / play-next | **Present** | `addToQueue` (`engine.ts:186-194`). Subject to the load race above. |
| Queue remove / clear / reorder / jump | **Present** | `removeFromQueue`, `clearQueue`, `moveInQueue`, `jumpTo` (`engine.ts:196-237`). |
| Shuffle | **Present** | Fisher–Yates order and shuffle toggle (`engine.ts:239-260`). |
| Repeat off/all/one | **Present** | `RepeatMode` and end handling (`types.ts:3`, `engine.ts:262-382`). Missing-source recursion is a correctness risk. |
| End-of-queue behavior | **Present, partial** | Auto end pauses with repeat off; manual next wraps to first (`engine.ts:366-377`). Missing-file queue can loop. |
| Seeking | **Present** | Clamped seek rejects unknown/Infinity duration (`engine.ts:390-394`); resume/handoff use metadata listeners. |
| Volume | **Present, basic** | Native linear `audio.volume` (`engine.ts:396-402`). No perceptual/loudness curve. |
| Playback speed / pitch preservation | **Present** | 0.5–2.0 rate, `preservesPitch=true` (`engine.ts:463-475`). |
| Six-band EQ | **Present** | Six peaking filters, -12..+12 dB, persisted settings (`engine.ts:44-161`). No ReplayGain/preamp user control. |
| Crossfade | **Absent** | No secondary audio element, gain ramp, or crossfade setting in the engine. |
| Gapless playback | **Absent/unsupported** | One media element and source swap at `ended`; no pre-buffered next source or gapless scheduling. |
| ReplayGain / loudness normalization | **Absent** | No ReplayGain metadata or gain application found. |
| Sleep timer | **Present** | Timed timer and “at track end” mode (`engine.ts:477-523`). Timed mode is wall-clock based, including while paused. |
| Resume last session | **Present, partial** | localStorage queue/position/repeat/shuffle/volume and deferred restore (`engine.ts:450-581`). No validation/versioning and load race applies. |
| Media Session metadata/actions | **Partial** | `mediaSession.ts:56-83`; only Cinema initializes it, so direct EELA/ALOK boot misses it; standalone artwork fallback. |
| Hardware media keys | **Present, desktop-dependent** | Electron main bridge → `mediaKeys.ts`, engine subscription (`engine.ts:617-633`). Teardown is not fully unregistering. |
| Playlists | **Present** | IDB playlists, liked system list, create/rename/delete/add/remove/reorder (`store/library.ts:176-235`). |
| Smart playlists | **Partial** | Static selectors/categories, including Most Played/Longest/Favorites (`libraryIndex.ts:13-25,230-249`); no user-defined rule engine or persisted smart-playlist definitions. |
| Recents / play counts | **Present, leaky persistence** | 5-second genuine-play logger (`engine.ts:429-448`), IDB recents and localStorage counts (`store/library.ts:80-85,237-245`). |
| Scrobbling (Last.fm/ListenBrainz/etc.) | **Absent** | No external scrobble client or credentials/state. |
| Embedded lyrics | **Present, format-dependent** | ID3 USLT/SYLT, Vorbis/MP4 parser paths in `audioParser.ts`; Cinema standalone importer currently only calls ID3-only `metadata.ts`. |
| LRC sync | **Present, partial** | Multiple timestamps, offsets, sorting in `cinema/lib/lyrics.ts`; detector rejects `[mm:ss]` without fraction; top-level legacy parser lacks offsets. |
| Remote lyric fetch | **Present** | LRCLIB exact/fuzzy/retry/timeout (`src/lrclib.ts`) and Smart Fetch. |
| Embedded/fetched covers | **Present, partial** | APIC/FLAC/MP4 parsing in broad parser; placeholders and cover caches (`covers.ts`); standalone importer parser gap. |
| Cover accent / palette / backdrop | **Present** | `extractAccent`, `extractPaletteFromBlob`, `blurredBackdrop` (`covers.ts:95-263`). Caches need bounds/cleanup. |
| Cover fetch | **Present** | iTunes/Deezer in `src/coverart.ts`, artist cover helper in `covers.ts`, Smart Fetch persistence. |
| Import/persistence | **Present, desktop and web** | IDB tracks/files/covers/playlists/recents/batches (`db.ts`), bounded web import, Electron/Tauri path import (`importer.ts`, `desktopLibrary.ts`). |
| Supported file-picker formats | **Present as advertised** | MP3, FLAC, OGG/OGA/Opus, M4A/AAC/WAV/WebM/WMA, AIF/AIFF/ALAC/APE/CAF/DSF/MPC/3GP/AMR/MP4/MKA (`utils.ts:5-12`, `importer.ts:157-160`). Actual browser playback/parser support remains runtime-dependent. |
| Metadata technicals | **Partial** | Broad parser handles MP3/FLAC/MP4/Ogg/WAV/AIFF, but parser bugs above and Cinema standalone path does not call it. |
| Legacy Tauri branch | **Present, partial** | `desktopLibrary.ts` uses Tauri fs/dialog/asset source; `desktopHttp.ts` uses plugin-http with web fallback. |

## Review limits

This is a static read-only review. I inspected every file in the requested `cinema/lib` and `cinema/store` directories (including `lyrics.ts`/`useT.ts` present there), plus the named shared parser, lyric, cover, blob, desktop, media-key, UI-mode, and type files. Runtime timing, browser-specific media behavior, IndexedDB quota behavior, Electron main-process protocol correctness, and Tauri plugin behavior remain unexecuted here. The findings above are code-path failures or complexity defects visible from the source; claims about actual codec support should be validated in target Chromium/WebView2/Tauri runtimes.
