# NOBODY desktop / packaging audit

**Scope.** Static review of the checked-in Electron 41 entry points, legacy Tauri 2 configuration, setup-app installer, build metadata, and shipped `dist/`. No dependencies were installed and no runtime/Windows installer execution was possible. Line references point to the supplied source tree.

## Findings

### 1. **HIGH — Electron IPC is an unrestricted arbitrary-file read/write API**

- **Source:** [`electron/main.cjs:637-736`](file:///home/user/src/electron/main.cjs#L637-L736), [`electron/preload.cjs:89-95`](file:///home/user/src/electron/preload.cjs#L89-L95).
- **What is concrete:** `assertAbsolutePath()` only checks “string + absolute + no NUL.” `fs:stat`, `fs:read-slice`, `fs:read-file`, `fs:write-text-file`, `fs:write-binary-file`, and `fs:walk` then operate on that path. There is no allowed-root check, no ownership/capability token, and no sender/origin check. The preload exposes every one of these methods to the renderer.
- **Impact:** Any renderer compromise (an XSS, future remote navigation mistake, or compromised local bundle) can read arbitrary absolute files and overwrite arbitrary user-writable files, not merely selected music folders. `writeTextFile` and `writeBinaryFile` can also overwrite existing files.
- **Fix:** Keep the bridge capability-based: issue opaque file handles from native dialogs and resolve only those handles, or enforce canonical roots (selected folders plus app data/downloads) with `realpath`/reparse-point checks. Add sender/origin validation to every privileged handler. Bound text/binary writes as well as reads.

### 2. **HIGH — `app://` is an arbitrary absolute-path file server**

- **Source:** [`electron/main.cjs:148-168`](file:///home/user/src/electron/main.cjs#L148-L168), [`electron/main.cjs:196-264`](file:///home/user/src/electron/main.cjs#L196-L264), renderer URL construction [`src/desktopLibrary.ts:54-69`](file:///home/user/src/src/desktopLibrary.ts#L54-L69).
- **What is concrete:** The protocol decodes any absolute path, normalizes it, and streams it. Normalization rejects relative traversal but does **not** restrict the result to an approved library root; `/etc/passwd`, a browser profile file, or any other readable absolute path is a valid target. `Access-Control-Allow-Origin: *` makes the response readable by any renderer origin that can reach the scheme.
- **Impact:** This duplicates the IPC read vulnerability and makes arbitrary file disclosure possible through a URL/fetch path, including range reads. Path normalization is not an authorization boundary.
- **Fix:** Use opaque per-file capabilities or a signed path token, and enforce canonical approved roots before `stat`/stream creation. Do not use wildcard CORS; return the requesting trusted origin (or avoid `fetch` by using a narrowly scoped protocol implementation).

### 3. **HIGH — HTTP allow-list is bypassed by redirects**

- **Source:** [`electron/main.cjs:739-770`](file:///home/user/src/electron/main.cjs#L739-L770).
- **What is concrete:** Only the initial URL is checked by `isAllowedRemoteUrl()`. `net.fetch(rawUrl, init)` does not set manual redirect handling, and the response URL/final host is never checked. Electron/Fetch follows redirects by default.
- **Impact:** An allowed LRCLIB/iTunes/Deezer/CDN endpoint can redirect the main process to an arbitrary HTTP(S) host (potentially an intranet service), and the proxy returns that response to the renderer. This defeats the stated host allow-list and creates SSRF/data-exfiltration potential.
- **Fix:** Set `redirect: "manual"`; validate every `Location` hop with the same exact-host/suffix policy, cap hop count, and reject non-allow-listed final URLs. Prefer an explicit method/header policy rather than forwarding arbitrary renderer headers.

### 4. **MEDIUM — External-link validation is scheme-only, not destination validation**

- **Source:** [`electron/main.cjs:323-328`](file:///home/user/src/electron/main.cjs#L323-L328), [`electron/main.cjs:805-811`](file:///home/user/src/electron/main.cjs#L805-L811).
- **What is concrete:** A renderer-supplied URL is opened whenever it begins with `http:` or `https:`. Any HTTPS domain is accepted; neither handler parses/normalizes the URL nor restricts hosts. `setWindowOpenHandler` and `shell:open-external` therefore allow arbitrary web destinations.
- **Impact:** A compromised or merely mistaken renderer can launch arbitrary phishing/untrusted URLs in the system browser. The comment says “allow-listed shell,” but the implementation is only scheme-listed.
- **Fix:** Parse with `new URL`, require `https:`, and allow only the documented support/update domains (or make external navigation an explicit user-confirmed action). Validate the final URL before `openExternal`.

### 5. **MEDIUM — No CSP is shipped for any renderer**

- **Source:** [`index.html:1-18`](file:///home/user/src/index.html#L1-L18), [`setup-app/index.html:1-16`](file:///home/user/src/setup-app/index.html#L1-L16), and Tauri [`src-tauri/tauri.conf.json:32-38`](file:///home/user/src/src-tauri/tauri.conf.json#L32-L38).
- **What is concrete:** Neither HTML document contains a CSP meta tag, and the Tauri config explicitly sets `"csp": null`.
- **Impact:** There is no defense-in-depth against script injection. This is particularly consequential here because the Electron renderer is connected to high-impact arbitrary-path IPC and an arbitrary-path protocol, while the Tauri webview has broad filesystem permissions.
- **Fix:** Ship a restrictive CSP appropriate to the build (no `unsafe-eval`; restrict `script-src`, `style-src`, `img-src`, `media-src`, and `connect-src` to required local schemes/hosts). Use a separate, equally restrictive policy for the setup wizard and keep dev-only exceptions out of production.

### 6. **MEDIUM — Legacy Tauri policy grants global and filesystem-wide access**

- **Source:** [`src-tauri/tauri.conf.json:12-38`](file:///home/user/src/src-tauri/tauri.conf.json#L12-L38), [`src-tauri/capabilities/default.json:28-72`](file:///home/user/src/src-tauri/capabilities/default.json#L28-L72).
- **What is concrete:** `withGlobalTauri: true`, `assetProtocol.scope: ["**"]`, and `fs:scope` includes `{ "path": "**" }` in addition to broad home/data/temp roots. The capability also enables read/write/open/seek/stat permissions.
- **Impact:** The legacy Tauri build exposes a much broader filesystem surface than the UI needs. With `csp: null`, a renderer injection has direct access to the global Tauri API and broad file permissions.
- **Fix:** Remove `withGlobalTauri` unless required, expose only narrow invoke/bridge functions, and scope FS to user-selected roots plus app data. Remove the `**` catch-all and set a production CSP.

### 7. **MEDIUM — Large IPC/network payloads still create avoidable memory spikes**

- **Source:** [`electron/main.cjs:705-725`](file:///home/user/src/electron/main.cjs#L705-L725), [`electron/main.cjs:751-769`](file:///home/user/src/electron/main.cjs#L751-L769), [`src/desktopHttp.ts:35-73`](file:///home/user/src/src/desktopHttp.ts#L35-L73).
- **What is concrete:** `fs:read-file` reads up to 32 MiB into a Buffer and clones it over IPC. `http:fetch` reads the complete response into an ArrayBuffer (up to 30 MiB), base64-encodes it (about 40 MiB), sends it over IPC, then the renderer decodes another byte array and constructs a `Response`. `writeBinaryFile` and `writeTextFile` have no payload size cap at all.
- **Impact:** Concurrent cover/download requests or a malicious/large renderer payload can produce multi-copy memory pressure and UI stalls. Audio playback itself is correctly streamed through `createReadStream`; this finding is about sidecars and HTTP proxy transfers.
- **Fix:** Stream HTTP responses through a dedicated protocol/IPC stream or keep a much smaller response cap; use bounded sidecar reads; cap and validate write payloads before IPC and in main.

### 8. **HIGH — Elevated installer follows destination junctions/reparse points**

- **Source:** [`setup-app/electron-builder.yml:47-64`](file:///home/user/src/setup-app/electron-builder.yml#L47-L64), [`setup-app/electron/installerCore.ts:480-513`](file:///home/user/src/setup-app/electron/installerCore.ts#L480-L513), [`setup-app/electron/installerCore.ts:650-680`](file:///home/user/src/setup-app/electron/installerCore.ts#L650-L680), [`setup-app/electron/installerCore.ts:745-764`](file:///home/user/src/setup-app/electron/installerCore.ts#L745-L764).
- **What is concrete:** The portable setup requests `admin` execution. The installer explicitly supports installing in-place into an existing non-NOBODY directory, then writes `path.join(destDir, rel)` with `mkdirSync`/`copyFileSync`; it never rejects symlinks, NTFS junctions, or reparse points in destination components.
- **Impact:** A local user/process that can prepare the chosen directory can place a junction such as `dest\resources` pointing elsewhere. The elevated setup then follows it and overwrites files outside the selected install root. This is an arbitrary-file overwrite/possible local privilege escalation boundary.
- **Fix:** For elevated installs, require a new/owned destination or validate every component with no-follow/reparse-point checks immediately before each write. Use safe directory handles/atomic writes where available; do not permit arbitrary in-place installs under elevation.

### 9. **MEDIUM — Setup renderer is not sandboxed**

- **Source:** [`setup-app/electron/main.ts:649-686`](file:///home/user/src/setup-app/electron/main.ts#L649-L686).
- **What is concrete:** The setup window sets `contextIsolation: true` and `nodeIntegration: false`, but omits `sandbox: true` (the player window explicitly sets it at [`electron/main.cjs:310-316`](file:///home/user/src/electron/main.cjs#L310-L316)).
- **Impact:** A setup-renderer compromise gets a less isolated Electron preload/runtime boundary at the most privileged point in the product—the installer, which is configured to run elevated. The setup preload is intentionally an Electron preload with privileged IPC.
- **Fix:** Set `sandbox: true`, add CSP, deny navigation, and validate all IPC senders/arguments. Keep the setup preload to the smallest possible bridge.

### 10. **MEDIUM — Installer copy/verification performs synchronous I/O on Electron’s main thread**

- **Source:** [`setup-app/electron/installerCore.ts:207-210`](file:///home/user/src/setup-app/electron/installerCore.ts#L207-L210), [`setup-app/electron/installerCore.ts:311-353`](file:///home/user/src/setup-app/electron/installerCore.ts#L311-L353), [`setup-app/electron/installerCore.ts:466-547`](file:///home/user/src/setup-app/electron/installerCore.ts#L466-L547); invoked by [`setup-app/electron/main.ts:752-798`](file:///home/user/src/setup-app/electron/main.ts#L752-L798).
- **What is concrete:** Manifest hashing, recursive enumeration, `copyFileSync`, `statSync`, and verification hashing all run synchronously inside the main-process install call. The outer function is `async`, but those synchronous operations still block the Electron event loop.
- **Impact:** Installing a large runtime/payload can freeze the setup window and delay IPC/progress events; cancellation is only observed between synchronous files. This does not affect the player’s bounded asynchronous `fsp` handlers, but it does affect the shipped custom installer.
- **Fix:** Move copy/hash work to a worker thread or child process; use async filesystem APIs and stream hashes/copies; make cancellation interruptible.

### 11. **MEDIUM — Setup always requests UAC elevation, including per-user installs**

- **Source:** [`setup-app/electron-builder.yml:47-64`](file:///home/user/src/setup-app/electron-builder.yml#L47-L64), [`setup-app/electron/main.ts:776-783`](file:///home/user/src/setup-app/electron/main.ts#L776-L783), [`setup-app/electron/installerCore.ts:562-585`](file:///home/user/src/setup-app/electron/installerCore.ts#L562-L585).
- **What is concrete:** The only setup target is a portable executable with `requestExecutionLevel: admin`, while the UI accepts `scope: "me"` and installs to a per-user location/HKCU.
- **Impact:** A user choosing “just me” still receives an administrator prompt and runs the whole custom installer with elevated rights. This violates least privilege and makes the advertised per-user scope misleading.
- **Fix:** Build separate per-user and all-user flows (or select an execution level at install time): per-user setup should run unelevated and use HKCU/LocalAppData; only all-user should elevate, with a carefully bounded elevated helper.

### 12. **MEDIUM — Upgrade/uninstall kills every same-named process, not the selected install**

- **Source:** [`setup-app/electron/main.ts:579-594`](file:///home/user/src/setup-app/electron/main.ts#L579-L594), [`electron/uninstall.cjs:226-241`](file:///home/user/src/electron/uninstall.cjs#L226-L241).
- **What is concrete:** The setup uses `taskkill /F /IM NOBODY.exe /T`; the standalone uninstaller enumerates processes by executable name and force-kills every matching PID except itself. No executable path or install identity is checked.
- **Impact:** A portable copy, second installation, or unrelated same-named process can be terminated during upgrade/uninstall. Forced termination can lose playback state or in-flight writes, and multiple installations cannot be independently serviced.
- **Fix:** Use the app’s single-instance/lock identity or a per-install PID/IPC shutdown handshake; verify process image paths before termination; use graceful close with a bounded force-kill fallback.

### 13. **MEDIUM — Main player has no persisted window geometry**

- **Source:** [`electron/main.cjs:285-317`](file:///home/user/src/electron/main.cjs#L285-L317), [`electron/main.cjs:400-405`](file:///home/user/src/electron/main.cjs#L400-L405), [`electron/main.cjs:534-575`](file:///home/user/src/electron/main.cjs#L534-L575).
- **What is concrete:** Every new window starts at the fixed 1360×860 centered defaults. `savedWindowState` only holds an in-memory pre-compact bounds snapshot; the transient `win:state` message contains only maximized/fullscreen flags.
- **Impact:** User-resized position/size is lost on restart; the requested “remember window size” desktop integration is absent. Compact mode restoration works only within the current process.
- **Fix:** Persist normal bounds, maximized/fullscreen state, and monitor validity under app userData; clamp restored bounds to an available display and avoid restoring off-screen geometry.

### 14. **MEDIUM — Declared package/lock state is not reproducible, and Electron is range-pinned**

- **Source:** [`package.json:1-16`](file:///home/user/src/package.json#L1-L16), [`package.json:72-90`](file:///home/user/src/package.json#L72-L90), [`package-lock.json:1-32`](file:///home/user/src/package-lock.json#L1-L32), [`setup-app/package.json:16-31`](file:///home/user/src/setup-app/package.json#L16-L31).
- **What is concrete:** `package.json` is version 1.5.2 but the npm lock root is `react-vite-tailwind` version 0.0.0 and lists a different dependency set (e.g. missing `@fontsource-variable/fraunces`, `@tanstack/react-virtual`, `@tauri-apps/plugin-http`, and `zustand`; extra old `music-metadata`/`jsmediatags`; different Framer Motion/Lucide ranges). The root app declares `electron: "^41.7.1"`, while setup pins exactly `41.7.1`.
- **Impact:** `npm ci` can reject the stale lock, while Bun and npm can resolve different dependency graphs. The app runtime can drift to a later 41.x than the runtime-reuse setup, undermining the stated “exact Electron runtime” contract.
- **Fix:** Choose one package manager per package, regenerate and commit the matching lockfile (or make the build fail on drift), pin Electron exactly in both app and setup, and run a clean reproducible packaging build in CI.

### 15. **LOW — Electron product/package identity remains generic**

- **Source:** [`package.json:1-7`](file:///home/user/src/package.json#L1-L7), migration context [`ELECTRON-MIGRATION-REPORT.md:195-198`](file:///home/user/src/ELECTRON-MIGRATION-REPORT.md#L195-L198).
- **What is concrete:** The npm package name is `react-vite-tailwind`; the migration report itself notes that electron-builder’s bare unpacked executable name follows that package name even though `productName` is NOBODY.
- **Impact:** Portable/unpacked artifacts, crash reports, process matching, and file-association commands can use the generic executable identity. This also contributes to the name-based process-kill problem above.
- **Fix:** Rename the package to a stable product identifier (for example `nobody-player`) and verify executable names, shortcuts, ARP strings, and process matching after a clean build.

### 16. **LOW — Unsigned custom installer increases tampering/SmartScreen exposure**

- **Source:** [`setup-app/electron-builder.yml:59-64`](file:///home/user/src/setup-app/electron-builder.yml#L59-L64).
- **What is concrete:** The config explicitly has `signExecutable: false`; the same portable setup can request admin and write the installed runtime.
- **Impact:** Users receive no Authenticode publisher/integrity signal, and tampering or repackaging is harder to detect. SmartScreen warnings and support friction are likely.
- **Fix:** Sign the setup and installed executables with a managed Authenticode certificate, publish hashes/signatures, and verify artifacts in release automation.

## Checked items with no finding

- The player BrowserWindow does set `contextIsolation: true`, `nodeIntegration: false`, and `sandbox: true` ([`electron/main.cjs:310-316`](file:///home/user/src/electron/main.cjs#L310-L316)). Permission requests are denied ([`electron/main.cjs:819-825`](file:///home/user/src/electron/main.cjs#L819-L825)), and new windows are denied. `webSecurity` is not explicitly set, but there is no code evidence that it is disabled; Electron’s default remains enabled.
- Player local audio uses a streamed `fs.createReadStream` and range responses ([`electron/main.cjs:252-264`](file:///home/user/src/electron/main.cjs#L252-L264)); it does not buffer whole FLAC files for playback. Metadata head/tail reads are capped at 8 MiB and sidecars at 32 MiB.
- The root Vite single-file plugin is opt-in (`SINGLEFILE=1`) ([`vite.config.ts:11-22`](file:///home/user/src/vite.config.ts#L11-L22)), so the checked-in normal `dist/index.html` is not a giant inlined application. The setup wizard does always use it ([`setup-app/vite.config.ts:7-10`](file:///home/user/src/setup-app/vite.config.ts#L7-L10)); its generated font CSS is ~479 KiB, and the shipped player font directory is ~3.3 MiB in this zip—not 15 MiB. This remains a startup/cache tradeoff, not a confirmed defect at those measured sizes.
- `globalShortcut` media registration is best-effort and is unregistered on `will-quit` ([`electron/main.cjs:782-803`](file:///home/user/src/electron/main.cjs#L782-L803), [`electron/main.cjs:850-854`](file:///home/user/src/electron/main.cjs#L850-L854)).
- A single-instance lock is present for both player and setup ([`electron/main.cjs:94-105`](file:///home/user/src/electron/main.cjs#L94-L105); [`setup-app/electron/main.ts:886-901`](file:///home/user/src/setup-app/electron/main.ts#L886-L901)). The player’s second-instance handler focuses the existing window but does not forward command-line paths.

## Desktop integration matrix

| Feature | Status | Evidence / notes |
|---|---|---|
| Tray icon | **Absent** | No `Tray`, tray menu, or tray lifecycle code in `electron/` or renderer. |
| Hardware media keys | **Present** | Main registers Play/Pause, Next, Previous, Stop via `globalShortcut` ([`electron/main.cjs:774-803`](file:///home/user/src/electron/main.cjs#L774-L803)); preload forwards events. Registration is hard-coded and best-effort. |
| SMTC/MPRIS / Media Session | **Partial / present via Web Media Session** | Cinema initializes `navigator.mediaSession`, metadata, and action handlers ([`src/cinema/lib/mediaSession.ts:30-83`](file:///home/user/src/src/cinema/lib/mediaSession.ts#L30-L83)). No native Windows SMTC or Linux MPRIS implementation is present; behavior depends on Chromium/WebView support. |
| Taskbar thumbnail buttons | **Absent** | No `BrowserWindow.setThumbarButtons`/thumbnail code. |
| Jump list | **Absent** | No `app.setJumpList` or task category code. |
| File associations | **Absent** | Electron Builder config has no `fileAssociations`/protocol registration. Tauri config likewise has no association declaration. |
| Drag files onto window | **Present** | Cinema/EELA/ALOK install window-level drag/drop handlers; classic import paths also support dropped files. |
| Open-with argv | **Absent / incomplete** | No player parsing of initial `process.argv`; `second-instance` ignores `commandLine`, so even a future association would not route paths to the existing window. |
| Single instance | **Present** | `requestSingleInstanceLock()` in player and setup. |
| Remember window size | **Absent** | No userData geometry persistence; compact snapshot is in-memory only. |
| Auto-update | **Absent** | No `autoUpdater`, `electron-updater`, update URL/provider, or update IPC. Releases require a new installer. |
| Discord RPC | **Absent** | No Discord RPC dependency or integration. |
| Configurable global hotkeys | **Absent** | Only fixed media accelerators are registered; no settings-backed registration API. |
| External link handling | **Present but weakly validated** | HTTPS/HTTP scheme check only; see Finding 4. |
| Custom installer / ARP | **Present** | Setup writes shortcuts and registry entries, with rollback/verification logic, but see Findings 8–12 and 16. |

## Scope limitations

- I did not execute Electron, the setup executable, NSIS/MSI, Windows registry operations, or a real Tauri build. Windows UAC, junction behavior, WebView2 Media Session behavior, and installer rollback outcomes should be confirmed on Windows 10/11.
- No internet or dependency installation was available, so redirect behavior and package-manager validation were established from the checked-in API usage/configuration rather than live requests. The source does not provide a redirect policy, final-host check, or update service.
