# Classic UI audit (React 19 + Vite + TypeScript + Electron 41)

Scope reviewed: `src/App.tsx` (all 5,927 lines, in chunks), `DownloadCenter.tsx`, `AppSwitch.tsx`, `appClose.ts`, `nudge.ts`, cursor modules, `i18n.ts`, `stylesData.ts`, `quotes.ts`, `desktopWindow.ts`, `main.tsx`, `index.css`, plus the shared engine where needed to compare behavior. Static read-only audit; no runtime profiling or network testing was possible.

Primary source links: [App.tsx](file:///home/user/src/src/App.tsx), [DownloadCenter.tsx](file:///home/user/src/src/DownloadCenter.tsx), [AppSwitch.tsx](file:///home/user/src/src/AppSwitch.tsx), [index.css](file:///home/user/src/src/index.css), and [shared engine](file:///home/user/src/src/cinema/lib/engine.ts).

## Ranked findings

### 1. Repeat is ignored by the real `<audio>` path — **High**

- **Evidence:** `src/App.tsx:1053-1067` defines `goNext()` and `src/App.tsx:2228-2250` wires `<audio onEnded={goNext}>`. The `repeat` state is not consulted by `onEnded`; it always advances (including from the last track back to index 0).
- **Failure:** Enabling the visible Repeat button does nothing for imported files with `sourceUrl`. The fallback/no-source ticker at `src/App.tsx:1141-1170` does check `repeat`, so behavior differs depending on how the track is sourced.
- **Fix:** Use a single end handler for both paths: if repeat-one is enabled, set `currentTime = 0` and `play()`; otherwise advance according to the queue/repeat-all policy. Keep repeat semantics in one playback function rather than split ticker/DOM handlers. The shared engine already demonstrates explicit repeat-one/repeat-all handling at `src/cinema/lib/engine.ts:359-382`.

### 2. A rejected `play()` from the previous track can pause the newly selected track — **High**

- **Evidence:** `src/App.tsx:1199-1210` calls `audio.play().catch(() => setIsPlaying(false))` whenever `isPlaying`, source, or volume changes. `selectTrack()` changes the source and leaves `isPlaying` true at `src/App.tsx:1004-1013`.
- **Failure:** If a play promise for track A is pending and the user presses Next, changing `src` aborts A's promise. Its rejection handler unconditionally sets `isPlaying(false)`, which can pause track B after B's effect has already called `play()`. This is a common rapid-next/source-load race; `AbortError` is expected during source changes, not a playback failure.
- **Fix:** Capture a generation/source token in the effect and only update state if the rejected promise still belongs to the current source/play request. Ignore expected `AbortError`; explicitly pause before changing source if that is the desired transition.

### 3. Removed current-track blob URLs are intentionally skipped but never reclaimed — **Medium**

- **Evidence:** `removeMusicFolder()` and `rescanFolder()` skip revoking the source URL of the currently indexed track at `src/App.tsx:1645-1659` and `src/App.tsx:1686-1703`. The track is then removed from state, while the persistent audio element remains mounted (`src/App.tsx:2226-2252`).
- **Failure:** When the current track is removed or disappears during a rescan, its blob URL is no longer held by any track, but `revokeManagedBlobUrl()` is deliberately not called. Repeated remove/rescan cycles can pin audio bytes for the session. The comment's “keep it so playback is never cut off” does not provide a later release point.
- **Fix:** Pause/detach the audio source, wait for the source transition if necessary, then revoke the old URL; or keep a one-entry “currently detached” URL and revoke it on `loadedmetadata`, `pause`, track change, or removal completion. Also clear `isPlaying` when no playable replacement exists.

### 4. Removing/rescanning tracks leaves stale queue, playlist, and recents IDs — **Medium**

- **Evidence:** Folder removal filters only `folderPaths` and `tracks` at `src/App.tsx:1645-1655`; rescan drops tracks at `src/App.tsx:1686-1698`. The persisted `queueIds`, playlists, and `recentlyPlayedIds` are maintained separately (`src/App.tsx:738-745`, `845-847`) and saved at `src/App.tsx:934-961`.
- **Failure:** Removing a folder leaves its IDs in Ur Queue/custom playlists/liked/recent history. The queue badge can count tracks no longer in the library, and re-importing a file with a stable path can make it unexpectedly reappear in an old playlist/queue.
- **Fix:** Compute removed IDs and filter them from `queueIds`, every playlist's `trackIds`, and `recentlyPlayedIds` in the same removal/rescan transaction; persist the cleaned state.

### 5. Classic's rAF visualizer continues while the classic pane is hidden — **Medium performance**

- **Evidence:** `AppSwitch` intentionally keeps Classic mounted with `display:none` at `src/AppSwitch.tsx:129-150`. `useBeatVisualizer()` starts a self-scheduling rAF loop whenever `isPlaying` is true and only checks `document.hidden`/`container.isConnected` at `src/App.tsx:178-219`.
- **Failure:** If Classic is in idle mode while playing and the user switches to Cinema/EELA/ALOK, the classic DOM stays connected even though it is hidden, so the 60fps bar loop continues to write styles. This is avoidable GPU/CPU work in the active alternative UI.
- **Fix:** Gate the loop on `getUiMode() === "classic"`, or stop it on `UI_SWITCH_EVENT`; also cancel any active frame when the pane becomes hidden. Do not use `isConnected` as a proxy for visibility.

### 6. Media-key subscription is recreated after every App render — **Medium performance / maintainability**

- **Evidence:** `src/App.tsx:1083-1095` has `useEffect(...)` with no dependency array. Its own comment says re-subscribing “per render is intentional.” `onMediaKey()` creates a new window listener each time (`src/mediaKeys.ts:36-44`).
- **Failure:** Every state render tears down and re-adds the global media-key listener, including renders caused by lyric-index changes, settings, imports, and overlays. Cleanup prevents a permanent listener leak, but it adds needless global churn and makes event timing harder to reason about.
- **Fix:** Use stable callbacks plus refs (`tracksRef`, `trackIndexRef`, playback refs), or memoize `goNext`/`goPrevious`; subscribe once on mount and clean up once.

### 7. Library, queue, lyrics/download rows all create full lists — **Medium performance**

- **Evidence:** Library maps every filtered track at `src/App.tsx:3491-3553`; queue maps every displayed track at `src/App.tsx:4921-4946`; lyrics maps every lyric line at `src/App.tsx:4088-4101`; Download Center maps every filtered track at `src/DownloadCenter.tsx:1301-1318`.
- **Failure:** `content-visibility:auto` in `src/index.css:6452-6458` reduces off-screen paint, but it does not remove the DOM, React elements, event closures, image nodes, or memory cost. Large local libraries can still make filtering, reconciliation, and scrolling expensive.
- **Fix:** Virtualize the track table, queue, and Download Center list (and consider a bounded lyric window for unusually large LRCs). Keep stable row components and only render the viewport plus overscan.

### 8. Classic-to-engine handoff discards the classic Ur Queue — **Medium**

- **Evidence:** Classic exposes `queueIds` state at `src/App.tsx:845-847`, but its bridge `captureHandoff()` sends `cur.tracks.map(...)` (the entire library) at `src/App.tsx:1957-1967`. On return, the handoff is mapped into Classic's Ur Queue and activates that tab at `src/App.tsx:2063-2078`.
- **Failure:** Switch Classic → Cinema/EELA/ALOK → Classic and the user's curated Ur Queue is replaced by the full library. The return path then displays the full library as the Ur Queue.
- **Fix:** Include classic `queueIds` and active queue mode in the bridge API/ref, and send the actual listen order. If Up Next is selected, explicitly define whether it should hand off as the full library or a queue snapshot.

### 9. Browser file imports cannot deduplicate the same physical file — **Medium**

- **Evidence:** `runBatchImport()` derives a stable ID only from `desktopRecord.path` at `src/App.tsx:1432-1435`; raw browser `File` records are given empty paths at `src/App.tsx:1351-1357`. Without a path, IDs are random at `src/App.tsx:1505-1507`.
- **Failure:** Selecting the same file again in the browser/web build creates another row with a new ID. Desktop path-based deduplication does not apply to the fallback file picker.
- **Fix:** Use a session/import fingerprint (name + size + lastModified + optional content hash) for pathless Files, and deduplicate before parsing. Mark the fingerprint as a fallback rather than using `Date.now()+random`.

### 10. Async batch work is not abortable after stop, close, or page switch — **Medium**

- **Evidence:** Download Center workers only check `stopRef` before taking the next item (`src/DownloadCenter.tsx:959-966`); an in-flight request continues and processors update state after awaits (`src/DownloadCenter.tsx:846-928`). The folder sync modals have the same pattern (`src/App.tsx:5193-5246`, `5626-5673`). Cleanup merely sets a boolean (`src/DownloadCenter.tsx:724-729`; `src/App.tsx:5182-5187`, `5615-5620`).
- **Failure:** Leaving the page/unmounting a modal does not cancel current network/download operations. A response can still call parent handlers, update state after unmount, and in cover paths create a managed blob URL. Stop only prevents workers from picking the next item; it does not stop work already in flight.
- **Fix:** Pass an `AbortSignal` through fetch/download helpers, abort on stop/unmount, and check the signal/alive flag after every await before state updates or blob creation. Revoke any URL created by a result that is no longer accepted.

### 11. Metadata handoff `loadedmetadata` listeners can accumulate — **Medium**

- **Evidence:** Handoff seeking installs an anonymous lifecycle tied to `applySeek` at `src/App.tsx:2096-2111`; the listener is removed only if the event fires. The retry can run repeatedly at `src/App.tsx:2124-2138`.
- **Failure:** If the target source never loads metadata (unsupported/missing file), the listener remains on the persistent audio element. Repeated failed handoffs can retain closures and add listeners that never fire.
- **Fix:** Attach one named listener with an abort/timeout cleanup, remove it when a newer handoff supersedes it, and clear it on source error/abort.

### 12. Seeking fights user drag because playback writes directly to the range input — **Low/Medium UX**

- **Evidence:** `applyElapsedUI()` writes `mainSeekRef.current.value` and `compactSeekRef.current.value` on every time update at `src/App.tsx:701-710`; the same inputs are actively dragged through `onChange` at `src/App.tsx:2400-2408` and `4812-4822`.
- **Failure:** While the user is dragging, the playback tick can overwrite the thumb with the old/current playback position, making precise seeking jumpy and sometimes ending the drag at a value different from the pointer.
- **Fix:** Track pointer/keyboard seeking with a `seekingRef`; suppress playback writes until `pointerup`/`change` commits, then apply the chosen time. Alternatively use a properly controlled/throttled range state.

### 13. Donate clipboard calls can produce unhandled rejected promises — **Low**

- **Evidence:** `DonateView.copyAddress()` calls `navigator.clipboard?.writeText(address)` without awaiting or catching at `src/App.tsx:4398-4402`.
- **Failure:** Clipboard permission/security failures reject the promise and create an unhandled rejection, while the UI still shows the address as copied. The support-nudge implementation correctly awaits/catches its clipboard helper at `src/App.tsx:4144-4152`, so this is inconsistent.
- **Fix:** `await` the write in `try/catch`, set `copiedKey` only on success, and show a failure state or leave the button unchanged.

### 14. Close veil's singleton flag is never reset — **Low**

- **Evidence:** `playCloseVeil()` sets module variable `playing = true` at `src/appClose.ts:39-43`, but no code resets it after the promise resolves (`src/appClose.ts:44-65`).
- **Failure:** In web/preview builds where `window.close()` is blocked, a later close attempt takes the “already playing” branch and only waits one second; it cannot start a fresh veil. It also complicates hot-reload/retry behavior.
- **Fix:** Reset `playing` in a `finally` around the veil completion; retain a shared in-flight promise for true idempotence instead of a permanent boolean.

### 15. Classic is a 5,927-line stateful god component with duplicated playback policy — **Low (high change-risk)**

- **Evidence:** `src/App.tsx:643-2961` owns state, imports, persistence, handoff, bridge registration, audio, keyboard/media keys, and all shell rendering; child views continue in the same file through line 5927. The shared engine independently owns an audio element/event handlers at `src/cinema/lib/engine.ts:27-68`, queue/repeat/shuffle at `src/cinema/lib/engine.ts:171-263`, speed at `src/cinema/lib/engine.ts:463-475`, and sleep timer at `src/cinema/lib/engine.ts:477-520`.
- **Failure/risk:** Two playback implementations already disagree (notably repeat behavior), and changes must be synchronized manually across effects, bridge, and hidden-pane lifecycle. This is the structural source of several findings above; it is not merely a style concern.
- **Fix:** Extract a shared transport contract/service for play/pause/seek/end/repeat/queue/handoff. Keep Classic's own audio element if required, but centralize policy and expose tested adapters instead of duplicating it in a monolith.

## Additional performance observations (not counted as separate correctness bugs)

- `src/index.css:312`, `901`, `1900`, `1954`, `2000`, `2801`, `3408`, `6544-6569`, `7754`, `7932-7938`, and many later blocks use backdrop blur; several are large cards/chrome. The performance pack reduces some values, but visible stacked glass surfaces still cause expensive WebView2 compositing, especially on large ambient backgrounds.
- `src/index.css:6387-6390`, `6442-6450`, and `6523-6524` apply `will-change` broadly, including elements that are static or only transition occasionally. `will-change` can retain GPU layers and increase memory; apply it only during an active animation/transition.
- Classic ambient orbs animate continuously whenever `ambientMotion` is enabled (`src/index.css:178-183`), even when playback is paused except for the explicit paused override. Consider disabling ambient motion when the window is hidden/backgrounded and when the user opts into a battery/performance mode.
- The classic page still performs O(n) filtering on every search keystroke (`src/App.tsx:854-864`, `3267-3271`) and renders a full filtered list; virtualization and an indexed search model would address both costs.

## Feature inventory (classic face)

| Feature | Status | Evidence / notes |
|---|---|---|
| Play/pause | Present | Own persistent `<audio>` at `App.tsx:2228-2250`; buttons in FocusView/PlayerBar. |
| Previous/next | Present | `goPrevious`/`goNext` at `App.tsx:1053-1073`; hardware media keys also route here. |
| Seek/scrub | Present / partial | Main and compact range controls at `App.tsx:2400-2408`, `4812-4822`; drag race noted above. |
| Volume + mute/restore | Present | PlayerBar `App.tsx:4766-4772`, `4840-4851`; persisted in state. |
| Shuffle | Present / partial | Boolean toggle + random index (`App.tsx:1061-1066`, `4791-4795`); no shuffle history/order persistence and no queue-aware shuffle order. |
| Repeat | Partial / buggy | Toggle exists (`App.tsx:4807-4809`), fallback ticker honors it, real audio `onEnded` ignores it (Finding 1). No repeat-one/all modes; only one boolean. |
| Queue view | Present | `QueuePanel` at `App.tsx:4861-4954`, with Up Next and Ur Queue tabs. |
| Queue add/remove | Present | Ur Queue add/remove buttons (`App.tsx:3537-3548`, `4933-4941`). |
| Queue reorder | Absent | No reorder/move handler or UI in Classic; shared engine has one, but it is not exposed by Classic. |
| Playlists | Present / partial | Create, add/remove tracks, delete custom playlists (`App.tsx:1113-1139`, `4957-5129`). No rename or reorder. |
| Liked/favorites | Present | System liked playlist and heart actions (`App.tsx:841-843`, `1100-1111`). |
| Library import files | Present | Desktop picker and browser file input (`App.tsx:1606-1641`, `2946-2957`). |
| Library import folders | Present | Native folder selection, persisted folder paths, browser directory input (`App.tsx:1587-1621`, `2949-2957`). |
| Drag-and-drop import | Present | Shell drag handlers (`App.tsx:2437-2445`, `2196-2204`). |
| Rescan/remove managed folders | Present | Folder tab actions and implementations (`App.tsx:1662-1725`, `3608-3718`). Removal leaves stale IDs (Finding 4). |
| Search | Present / partial | Quick palette searches title/artist/album/year/format and caps results at 7 (`App.tsx:854-864`, `2529-2677`); library filter searches title/artist/album. No indexed/fuzzy search. |
| Sort | Absent | No sort state/control; library remains import order. |
| Recents/history | Present | Recently played IDs after six seconds and Recents tab (`App.tsx:1041-1051`, `3276-3279`, `3573-3606`). |
| Lyrics display | Present | Synced line list, active scrolling, click-to-seek (`App.tsx:4088-4103`, `3724-3765`). |
| LRC import | Present | `.lrc`/text file input and parser (`App.tsx:1391-1407`, `2946`). |
| Automatic lyric lookup | Present | LRCLIB auto-find (`App.tsx:3843-3865`) plus Download Center. |
| Batch lyric sync/download | Present | Download Center and folder modal (`DownloadCenter.tsx:933-994`; `App.tsx:5135-5569`). |
| Plain/embedded lyrics | Present | Embedded LRC/plain parsing (`App.tsx:1473-1497`); plain lines are spread evenly. |
| Lyrics translation | Absent | Settings explicitly says translation removed (`App.tsx:4591-4594`); no translation state/rendering. |
| Lyric styles/size | Present | Settings controls and CSS styles (`App.tsx:4595-4629`). |
| Lyric fullscreen | Present / partial | DOM/native window fullscreen handlers (`App.tsx:3804-3910`); platform-dependent behavior is best-effort. |
| Cover art extraction | Present | Embedded cover parsing and blob registry (`App.tsx:1450-1465`). |
| Cover art search/apply/save | Present | Download Center/manual and folder sync (`DownloadCenter.tsx:451-604`, `App.tsx:5572-5927`). |
| Metadata display | Present | Technical metadata parsed/displayed in library/download rows. |
| Tag editing / write-back metadata | Absent | No tag mutation UI/API; only reads metadata in `parseAudioFileMetadata`. |
| Equalizer (audio DSP) | Absent in Classic | Classic only renders visual bars/orbit (`App.tsx:3064-3107`, `4393-4431`); DSP EQ exists only in shared engine (`cinema/lib/engine.ts:44-160`). |
| Playback speed / pitch | Absent in Classic | No `playbackRate` or speed control in App; shared engine has it at `engine.ts:463-475`. |
| Sleep timer | Absent in Classic | No sleep timer state/UI/timer; shared engine has one at `engine.ts:477-520`. |
| Crossfade / gapless | Absent | No crossfade, fade, or gapless scheduling in Classic audio path. |
| Waveform / spectrum from audio | Absent / partial | Visual equalizer is synthetic BPM/rAF animation (`App.tsx:178-219`), not audio analysis. |
| Mini-player / compact mode | Present | OS compact window and compact shell (`App.tsx:750-762`, `2254-2418`; `desktopWindow.ts:151-221`). |
| Full app fullscreen | Present | Native/DOM fullscreen controls (`App.tsx:866-917`, `desktopWindow.ts:125-149`). |
| Keyboard shortcuts | Present / partial | Global transport/navigation shortcuts at `App.tsx:1212-1340`; excludes input/textarea but not generic contenteditable/select controls. |
| Hardware media keys | Present | Electron bridge + Classic subscription (`main.tsx:42-49`, `App.tsx:1075-1095`). |
| Persistence | Present / partial | Settings/playlists/queue/folders/recent IDs in localStorage (`App.tsx:934-975`); audio bytes/tracks are re-imported from folders, not persisted. |
| Multi-language UI | Present | FA/EN/TR/RU dictionaries (`i18n.ts:186-933`), shared language bus (`App.tsx:651-676`). |
| RTL | Present / partial | `dir` switches for Farsi at `App.tsx:2224-2236`; many track/title surfaces force `dir="ltr"`, appropriate for Latin metadata but mixed-script edge cases remain. |
| UI face switching | Present | Settings calls `switchUiMode` for Cinema/EELA/ALOK (`App.tsx:4550-4566`); Classic remains mounted by design. |
| Download Center | Present | Dedicated page with selection, filters, worker batches, manual pickers (`DownloadCenter.tsx:672-1354`). |
| Sleep/idle visual mode | Present (visual only) | 30-second idle overlay (`App.tsx:977-1002`, `2820-2828`); does not stop audio. |

## Limitations

This is static analysis only. I did not run Electron/WebView2, load a real library, simulate rapid `play()`/source races, inspect GPU traces, or exercise network APIs. Therefore timing/race findings are derived from the concrete promise/effect/event lifecycles, while exact jank magnitude and platform-specific media behavior remain unmeasured.
