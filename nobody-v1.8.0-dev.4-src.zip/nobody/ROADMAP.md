# NOBODY — Roadmap to a pro player

## Phase 2 · Performance (V1.5.4–1.5.5) ✅ done, pending Windows QA
- Shared virtualized TrackList for EELA, ALOK, Classic library/queue, Download Center (@tanstack/react-virtual is already a dep)
- Visibility-aware shared rAF scheduler (EELA visualizer/slider/lyrics, ALOK Core/RadialViz)
- Bulk `removeTracks(ids)` IDB transaction; O(n) subfolder index; bounded pool for desktop folder import
- Resume state → IndexedDB + debounce (10k queues overflow localStorage)
- Trim always-on blur/animations; perf mode toggle; drop `dist/` + one lockfile from the source zip
## Phase 3 · Core playback (V1.6.0 → 1.6.5) ✅ done, pending Windows QA
- ✅ Gapless (dual element / pre-buffer) + crossfade 0–12 s (V1.6.0, engine faces; pending Windows QA)
- ✅ ReplayGain / loudness normalisation, EQ presets + preamp, 10-band option (1.6.1 backend, 1.6.2 UI)
- ✅ Classic: repeat off/all/one, EQ, speed, sleep timer (reuse engine) (1.6.3)
- ✅ Queue drag-reorder in Cinema/EELA, "play next", save queue as playlist (1.6.4)
- ✅ Sort (title/artist/album/date added/duration/plays) + reverse + genre view (1.6.5)
## Phase 4 · Library (V1.7.0)
- Tag editor with write-back (ID3/Vorbis/MP4) — in main process
- Smart playlists (rule engine), ratings, M3U/M3U8 import-export
- Listening stats, Last.fm / ListenBrainz scrobbling, duplicate finder
## Phase 5 · Desktop (V1.8.0)
- Tray + mini controls, Windows taskbar thumbnail buttons, jump list
- File associations + open-with argv + second-instance file forwarding
- Remember window size/position, configurable global hotkeys, Discord RPC
- Auto-update (electron-updater) + code signing
- Installer: no UAC for per-user, reject junctions, async copy in worker, kill only own PID
## Phase 6 · Architecture (V2.0.0)
- Move Classic onto the shared engine (one playback policy), split App.tsx (5.9k lines)
- Shared Dialog primitive (focus trap), CSP, tighten/remove legacy Tauri config
- Unit tests for parsers/LRC/engine queue, CI build
