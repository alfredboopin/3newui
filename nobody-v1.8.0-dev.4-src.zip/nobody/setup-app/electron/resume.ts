/**
 * NOBODY Setup 1.8.0-dev.4 · the unelevated → elevated hand-over argument.
 * Pure (no Electron) so docs/tests/installer-run.cjs can test it.
 */
import type { InstallOptions } from "../shared/contract";

export const ELEVATED_FLAG = "--nobody-elevated";
export const RESUME_PREFIX = "--nobody-resume=";
export type Resume = InstallOptions & { lang?: string };

export function encodeResume(r: Resume): string {
  return Buffer.from(JSON.stringify(r), "utf8").toString("base64url");
}
export function decodeResume(argv: string[]): Resume | null {
  const raw = argv.find((a) => a.startsWith(RESUME_PREFIX));
  if (!raw) return null;
  try {
    const o = JSON.parse(Buffer.from(raw.slice(RESUME_PREFIX.length), "base64url").toString("utf8"));
    if (!o || typeof o !== "object" || typeof o.destDir !== "string" || o.destDir.length > 260) return null;
    return {
      destDir: o.destDir,
      scope: o.scope === "all" ? "all" : "me",
      desktop: !!o.desktop,
      launchAfter: !!o.launchAfter,
      openFolder: !!o.openFolder,
      lang: typeof o.lang === "string" && /^[a-z]{2}$/.test(o.lang) ? o.lang : undefined,
    };
  } catch {
    return null;
  }
}
