/**
 * NOBODY Setup 1.8.0-dev.4 · Windows process + elevation helpers.
 *
 * TypeScript twin of the player's electron/winproc.cjs (the uninstaller
 * uses that one). docs/tests/installer-run.cjs checks both give the same
 * answers.
 *
 *   - kill only OUR install: processes are matched by full image path
 *     (inside the install dir), never by image name.
 *   - graceful first: `<install>\NOBODY.exe --nobody-quit`, then a bounded
 *     force-kill of the verified PIDs.
 *   - elevation: PowerShell Start-Process -Verb RunAs via -EncodedCommand
 *     (UTF-16LE base64): no path or argument can break the quoting.
 */
import path from "path";
import { execFile, execFileSync, spawn } from "child_process";

export const QUIT_FLAG = "--nobody-quit";

export interface ProcInfo {
  pid: number;
  path: string | null;
}

export function psEncode(script: string): string {
  return Buffer.from(String(script), "utf16le").toString("base64");
}
export function psQuote(s: string): string {
  return "'" + String(s).replace(/'/g, "''") + "'";
}

export function listScript(exeName: string): string {
  const name = String(exeName).replace(/'/g, "''");
  return (
    "$ErrorActionPreference='SilentlyContinue';" +
    `@(Get-CimInstance Win32_Process -Filter "Name='${name}'" | Select-Object ProcessId,ExecutablePath) | ConvertTo-Json -Compress`
  );
}

export function parseProcessJson(out: string): ProcInfo[] {
  let v: unknown;
  try {
    v = JSON.parse(String(out || "").trim() || "[]");
  } catch {
    return [];
  }
  const arr: any[] = Array.isArray(v) ? v : v && typeof v === "object" ? [v] : [];
  const res: ProcInfo[] = [];
  for (const o of arr) {
    const pid = Number(o && o.ProcessId);
    if (!Number.isInteger(pid) || pid <= 0) continue;
    res.push({ pid, path: typeof o.ExecutablePath === "string" && o.ExecutablePath ? o.ExecutablePath : null });
  }
  return res;
}

export function ownInstallPids(a: { list: ProcInfo[]; installDir: string; ownPid: number; isWin?: boolean }): number[] {
  const isWin = a.isWin ?? process.platform === "win32";
  const P = isWin ? path.win32 : path.posix;
  const norm = (p: string) => (isWin ? P.resolve(p).toLowerCase() : P.resolve(p));
  const root = norm(a.installDir);
  const out: number[] = [];
  for (const p of a.list || []) {
    if (!p || p.pid === a.ownPid || !p.path) continue;
    const rel = P.relative(root, norm(p.path));
    if (!rel || rel.startsWith("..") || P.isAbsolute(rel)) continue;
    out.push(p.pid);
  }
  return out;
}

export function elevateScript(exe: string, args: string[]): string {
  const list = (args || []).map(psQuote).join(",");
  return (
    "$ErrorActionPreference='Stop';" +
    `try { Start-Process -FilePath ${psQuote(exe)}${list ? ` -ArgumentList ${list}` : ""} -Verb RunAs | Out-Null; exit 0 } catch { exit 1223 }`
  );
}

const IS_ADMIN_SCRIPT =
  "if (([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 0 } else { exit 1 }";

const psArgs = (script: string) => ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", psEncode(script)];

export function listProcesses(exeName: string): ProcInfo[] {
  if (process.platform !== "win32") return [];
  try {
    const out = execFileSync("powershell.exe", psArgs(listScript(exeName)), {
      encoding: "utf8",
      timeout: 15_000,
      windowsHide: true,
      stdio: ["ignore", "pipe", "ignore"],
    });
    return parseProcessJson(out);
  } catch {
    return [];
  }
}

let elevatedCache: boolean | null = null;
export function isElevated(): boolean {
  if (process.platform !== "win32") return typeof process.getuid === "function" && process.getuid() === 0;
  if (elevatedCache !== null) return elevatedCache;
  try {
    execFileSync("powershell.exe", psArgs(IS_ADMIN_SCRIPT), { timeout: 15_000, windowsHide: true, stdio: "ignore" });
    elevatedCache = true;
  } catch {
    elevatedCache = false;
  }
  return elevatedCache;
}

export function relaunchElevated(exe: string, args: string[]): Promise<"started" | "denied" | "error"> {
  return new Promise((resolve) => {
    if (process.platform !== "win32") {
      resolve("error");
      return;
    }
    execFile("powershell.exe", psArgs(elevateScript(exe, args)), { windowsHide: true, timeout: 120_000 }, (err: any) => {
      if (!err) resolve("started");
      else resolve(err.code === 1223 ? "denied" : "error");
    });
  });
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export interface CloseDeps {
  list?: () => ProcInfo[];
  quit?: (exe: string) => void;
  kill?: (pid: number) => void;
  sleep?: (ms: number) => Promise<void>;
}

/** Close every NOBODY running from installDir (except us). */
export async function closeInstall(
  o: { installDir: string; exeName: string; ownPid?: number; graceful?: boolean; waitMs?: number; isWin?: boolean },
  deps: CloseDeps = {}
): Promise<{ found: number; graceful: number; killed: number }> {
  const isWin = o.isWin ?? process.platform === "win32";
  const ownPid = o.ownPid ?? process.pid;
  const waitMs = o.waitMs ?? 6000;
  const P = isWin ? path.win32 : path.posix;
  const list = deps.list ?? (() => listProcesses(o.exeName));
  const quit =
    deps.quit ??
    ((exe: string) => {
      try {
        const c = spawn(exe, [QUIT_FLAG], { detached: true, stdio: "ignore", windowsHide: true });
        c.unref();
      } catch {
        /* best-effort */
      }
    });
  const kill =
    deps.kill ??
    ((pid: number) => {
      try {
        execFileSync("taskkill", ["/F", "/T", "/PID", String(pid)], { timeout: 15_000, windowsHide: true, stdio: "ignore" });
      } catch {
        /* gone */
      }
    });
  const nap = deps.sleep ?? sleep;
  const mine = () => ownInstallPids({ list: list(), installDir: o.installDir, ownPid, isWin });
  let pids = mine();
  const found = pids.length;
  if (!found) return { found: 0, graceful: 0, killed: 0 };
  if (o.graceful !== false) {
    quit(P.join(o.installDir, o.exeName));
    for (let t = 0; t < waitMs && pids.length; t += 250) {
      await nap(250);
      pids = mine();
    }
  }
  const left = pids.length;
  for (const pid of pids) kill(pid);
  return { found, graceful: found - left, killed: left };
}

/** 1.8.0+ players understand --nobody-quit; older ones would just focus their window */
export function supportsQuitFlag(version: unknown): boolean {
  const m = /^(\d+)\.(\d+)\.(\d+)(?:-dev\.(\d+))?/.exec(String(version || ""));
  if (!m) return false;
  const [maj, min, pat] = [Number(m[1]), Number(m[2]), Number(m[3])];
  if (maj !== 1) return maj > 1;
  if (min !== 8) return min > 8;
  if (pat > 0) return true;
  return m[4] === undefined || Number(m[4]) >= 4; // 1.8.0-dev.4 introduced it
}
