/**
 * The shell — V4 (full-bleed, V1.5.2 user request «فقط پنجره ستاپ بمونه»).
 * The wizard IS the OS window now: the simulated desktop is gone entirely —
 * no fake wallpaper, no taskbar, no desktop icons, no stage hairline, no
 * floating card with drop shadow and dead margins. The 980×640 design
 * surface fills the frameless Electron window edge-to-edge; it scales itself
 * down only when a screen genuinely cannot hold 980×640 (DPI squeeze), and
 * stays centred on the same seamless background if the OS window is resized
 * larger.
 *
 * The custom title bar now drags the REAL window through
 * -webkit-app-region: drag (min/close controls stay no-drag) — what the
 * NSIS build does with SetWindowLong / WM_NCLBUTTONDOWN, the Electron
 * wizard does natively. The visual contract is identical.
 */
import { useLayoutEffect, useState, type ReactNode } from "react";
import { LANGS, t } from "@/installer/i18n";
import { TOKENS } from "@/installer/tokens";
import { useSetup } from "@/installer/useSetup";
import { cn } from "@/utils/cn";
import { Aurora, Motes, useSpotlight } from "@/ui/motion";
import { AppTile, Hairline, LangPills, WinGlyph } from "@/ui/kit";

const W = TOKENS.window.w;
const H = TOKENS.window.h;

const SETUP_STEPS = ["welcome", "license", "destination", "installing", "finish"];
const UN_STEPS = ["confirm", "progress", "done"];

/* ----------------------------------------------------------- the window */

export function SetupWindow({ children }: { children: ReactNode }) {
  const s = useSetup();
  const [vp, setVp] = useState<{ w: number; h: number }>({ w: W, h: H });
  const spotlight = useSpotlight<HTMLDivElement>();

  useLayoutEffect(() => {
    const onResize = () => setVp({ w: window.innerWidth, h: window.innerHeight });
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  /* full-bleed: the design fills the window at 1:1 (the Electron window
     opens at exactly 980×640 content size); scale down only when the
     viewport cannot hold the design. `s.scale` stays the QA override. */
  const fitScale = Math.min(s.scale, vp.w / W, vp.h / H);

  const setupIdx = SETUP_STEPS.indexOf(s.page);
  const unIdx = UN_STEPS.indexOf(s.unPage);
  const showSpine = s.mode === "uninstall" ? unIdx >= 0 : setupIdx > 0;

  const minimized = s.win === "minimized";
  const closed = s.win === "closed";
  const calm = !s.motionOn;
  const energy = calm ? 0.15 : s.energy;

  return (
    <div
      className={cn("fixed inset-0 overflow-hidden", calm && "nb-reduce")}
      style={{ background: TOKENS.bg }}
    >
      {/* window — the same three layers as before, minus the drag offsets:
          L1 the centre anchor · L2 the entry/exit animation · L3 the DPI
          scale. CSS animations override inline `transform`, so the entry
          animation and the scale must never live on the same element or
          fitScale silently stops working at 125% and 150%. */}
      <div
        className="absolute left-1/2 top-1/2"
        style={{ transform: "translate(-50%, -50%)" }}
      >
        {/* L2 · entry / exit */}
        <div className={cn(minimized ? "nb-genie" : closed ? "nb-fade-out" : "nb-pop")}>
          {/* L3 · the window — the OS window's entire content area */}
          <div
            ref={spotlight.ref}
            dir={s.dir}
            className="nb-grain relative flex flex-col overflow-hidden"
            style={
              {
                width: W,
                height: H,
                background: TOKENS.bg,
                fontFamily: s.dir === "rtl" ? "var(--font-fa)" : "var(--font-ui)",
                transform: `scale(${fitScale})`,
                opacity: closed ? 0 : 1,
                transition: "transform .34s var(--ease-nb), opacity .3s ease, filter .3s ease",
                filter: closed ? "blur(8px)" : "none",
                pointerEvents: closed ? "none" : "auto",
                "--nb-dir": s.dir === "rtl" ? "-1" : "1",
                "--nb-energy": energy,
              } as React.CSSProperties
            }
          >
            {/* layered ambience */}
            <div
              className="pointer-events-none absolute inset-0"
              style={{
                background:
                  "radial-gradient(85% 55% at 50% 22%, rgba(255,45,120,0.06) 0%, rgba(255,122,77,0.02) 45%, rgba(8,7,11,0) 78%)",
              }}
            />
            {/* the breathing vignette — faster and brighter as energy rises */}
            <div
              className="nb-energy pointer-events-none absolute inset-0"
              style={{
                background:
                  "radial-gradient(70% 50% at 50% 62%, rgba(255,45,120,0.5) 0%, rgba(255,122,77,0.18) 45%, transparent 75%)",
                filter: "blur(40px)",
              }}
              aria-hidden
            />
            {!calm && <Aurora energy={energy} />}
            {!calm && s.ambient && <Motes count={20} seed={s.mode === "uninstall" ? 5 : 2} />}
            {!calm && spotlight.p.on && (
              <div
                className="pointer-events-none absolute"
                style={{
                  left: `${spotlight.p.x * 100}%`,
                  top: `${spotlight.p.y * 100}%`,
                  width: 440,
                  height: 440,
                  marginLeft: -220,
                  marginTop: -220,
                  background:
                    "radial-gradient(circle, rgba(255,158,196,0.06) 0%, rgba(255,45,120,0.02) 42%, transparent 70%)",
                  transition: "opacity 600ms ease",
                }}
              />
            )}

            {/* title bar — drags the real frameless window (app-region);
                the control cluster opts out so buttons stay clickable */}
            <div
              className="nb-drag relative z-20 flex shrink-0 items-center justify-between"
              style={{ height: TOKENS.window.titlebar, WebkitAppRegion: "drag" } as React.CSSProperties}
            >
              <div className="nb-slide-in flex items-center gap-3 ps-6">
                <AppTile size={26} />
                <span className="nb-font-mono text-[10px] font-medium tracking-[0.14em] text-nb-dim">
                  {t(s.lang, "chrome.winTitle")}
                </span>
              </div>
              <div
                className="nb-slide-in flex items-center gap-2.5 pe-3"
                style={{ animationDelay: "90ms", WebkitAppRegion: "no-drag" } as React.CSSProperties}
              >
                <LangPills
                  langs={LANGS}
                  active={s.lang}
                  onPick={(c) => s.setLang(c as typeof s.lang)}
                />
                <span className="mx-0.5 h-4 w-px bg-white/8" aria-hidden />
                <WinGlyph kind="min" label={t(s.lang, "chrome.min")} onClick={s.minimize} />
                <WinGlyph
                  kind="close"
                  label={t(s.lang, "chrome.close")}
                  onClick={() =>
                    s.openDialog(
                      s.page === "installing" && s.progress.running ? "cancel" : "quit",
                    )
                  }
                />
              </div>
            </div>

            <Hairline className="relative z-20 mx-6" travel={!calm} />

            {/* page */}
            <div className="relative z-10 min-h-0 flex-1 overflow-hidden">
              {showSpine && (
                <Spine
                  steps={s.mode === "uninstall" ? UN_STEPS : SETUP_STEPS}
                  index={s.mode === "uninstall" ? unIdx : setupIdx}
                  energy={energy}
                />
              )}
              {children}
              {/* the opening curtain */}
              {!calm && s.curtain > 0 && s.mode === "setup" && s.page === "welcome" && (
                <span
                  key={s.curtain}
                  className="pointer-events-none absolute inset-0 z-30 overflow-hidden"
                  aria-hidden
                >
                  <span
                    className="absolute inset-x-0 top-0 h-1/2 origin-top"
                    style={{
                      background: "#050407",
                      animation: "nb-curtain-top 1000ms var(--ease-nb) both",
                    }}
                  />
                  <span
                    className="absolute inset-x-0 bottom-0 h-1/2 origin-bottom"
                    style={{
                      background: "#050407",
                      animation: "nb-curtain-bottom 1000ms var(--ease-nb) both",
                    }}
                  />
                  <span
                    className="absolute inset-x-0 top-1/2 h-[2px] rounded-full"
                    style={{
                      background:
                        "linear-gradient(90deg, transparent, #FF2D78 24%, #FFD9E6 50%, #FF7A4D 76%, transparent)",
                      boxShadow: "0 0 26px 4px rgba(255,45,120,0.5)",
                      animation: "nb-curtain-seam 1000ms var(--ease-nb) both",
                    }}
                  />
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {closed && (
        <div className="absolute inset-0 z-40 grid place-items-center">
          <div className="nb-fade text-center">
            <div className="nb-font-mono nb-blink mb-3 text-[10px] tracking-[0.3em] text-white/35">
              {s.mode === "uninstall" ? "UNINSTALLER EXITED" : "SETUP EXITED"}
            </div>
            <button
              type="button"
              onClick={s.restart}
              className="nb-focus rounded-full border border-white/12 px-6 py-2 text-[11px] text-white/70 transition-all duration-300 hover:border-white/30 hover:text-white"
            >
              {s.mode === "uninstall" ? "run the installer again" : "run setup again"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------- the spine */

function Spine({ steps, index, energy }: { steps: string[]; index: number; energy: number }) {
  const frac = steps.length > 1 ? index / (steps.length - 1) : 0;
  return (
    <div
      className="nb-slide-in pointer-events-none absolute inset-y-8 z-10 flex flex-col items-center"
      style={{ insetInlineStart: 30, animationDuration: "620ms" }}
      aria-hidden
    >
      <div className="absolute inset-y-1 w-[2px] rounded-full bg-white/[0.07]" />
      <div
        className="absolute top-1 w-[2px] origin-top rounded-full"
        style={{
          height: `calc(100% - 8px)`,
          transform: `scaleY(${Math.max(0.001, frac)})`,
          transition: "transform 700ms var(--ease-nb-out)",
          background: "linear-gradient(180deg, #FF2D78, #FF7A4D)",
          boxShadow: `0 0 ${8 + energy * 14}px rgba(255,45,120,${0.45 + energy * 0.5})`,
        }}
      />
      <div className="relative flex h-full flex-col justify-between py-1">
        {steps.map((st, i) => {
          const done = i < index;
          const now = i === index;
          return (
            <span key={st} className="relative grid place-items-center">
              {now && (
                <span
                  className="absolute h-4 w-4 rounded-full"
                  style={{
                    border: "1px solid rgba(255,45,120,0.55)",
                    animation: `nb-pulse-ring ${1900 - energy * 600}ms var(--ease-nb) infinite`,
                  }}
                />
              )}
              <span
                className="block h-[6px] w-[6px] rounded-full transition-all duration-500"
                style={{
                  background: done ? "#FF9EC4" : now ? "#FF2D78" : "rgba(255,255,255,0.14)",
                  transform: now ? "scale(1.5)" : "scale(1)",
                  boxShadow: now
                    ? `0 0 ${8 + energy * 12}px 2px rgba(255,45,120,${0.7 + energy * 0.3})`
                    : done
                      ? "0 0 6px rgba(255,158,196,0.4)"
                      : "none",
                }}
              />
            </span>
          );
        })}
      </div>
    </div>
  );
}
