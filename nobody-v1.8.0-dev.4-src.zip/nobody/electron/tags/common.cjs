'use strict';
/* ─────────────────────────────────────────────────────────────────────────
 * NOBODY — tag editor core · shared helpers (V1.7.0, Phase 4)
 *
 * Pure Node (no deps). Everything works on a "source": { size, read(pos, len) }
 * so the same readers run on the real file, on a virtual view of a write
 * plan (verify BEFORE touching the original) and in tests.
 * ───────────────────────────────────────────────────────────────────────── */

const FIELD_KEYS = ['title', 'artist', 'album', 'albumArtist', 'year', 'genre', 'track', 'disc', 'composer', 'comment'];
const MAX_META_BYTES = 64 * 1024 * 1024; // any single tag / moov / header region we load
const MAX_COVER_BYTES = 12 * 1024 * 1024; // fits a FLAC block (16 MB) with room to spare
const FIELD_MAX = { comment: 8000, default: 1000 };

class TagError extends Error {
  constructor(code, detail) {
    super(detail ? `${code}: ${detail}` : code);
    this.code = code;
  }
}

/* ── sources ─────────────────────────────────────────────────────────── */

function fileSource(handle, size) {
  return {
    size,
    async read(pos, len) {
      const n = Math.max(0, Math.min(len, size - pos));
      const buf = Buffer.alloc(n);
      let got = 0;
      while (got < n) {
        const { bytesRead } = await handle.read(buf, got, n - got, pos + got);
        if (bytesRead === 0) break;
        got += bytesRead;
      }
      return got === n ? buf : buf.subarray(0, got);
    },
  };
}

function bufferSource(buf) {
  return {
    size: buf.length,
    async read(pos, len) {
      return Buffer.from(buf.subarray(pos, Math.min(buf.length, pos + len)));
    },
  };
}

/** A read-only view of what the file WILL look like after a plan runs.
 *  pieces: Buffer | { from, to } (| { ogg: { from, to } } — copied raw here;
 *  the page renumbering does not change any byte a tag reader looks at). */
function virtualSource(base, pieces) {
  const map = [];
  let size = 0;
  for (const p of pieces) {
    if (Buffer.isBuffer(p)) {
      map.push({ at: size, len: p.length, buf: p });
      size += p.length;
    } else {
      const r = p.ogg || p;
      const len = r.to - r.from;
      map.push({ at: size, len, from: r.from });
      size += len;
    }
  }
  return {
    size,
    async read(pos, len) {
      const end = Math.min(size, pos + len);
      const out = [];
      for (const m of map) {
        if (m.at + m.len <= pos || m.at >= end) continue;
        const a = Math.max(pos, m.at);
        const b = Math.min(end, m.at + m.len);
        if (m.buf) out.push(m.buf.subarray(a - m.at, b - m.at));
        else out.push(await base.read(m.from + (a - m.at), b - a));
      }
      return Buffer.concat(out);
    },
  };
}

/** In-place writes as a virtual view (writes never change the size). */
function overlaySource(base, writes) {
  const sorted = [...writes].sort((a, b) => a.offset - b.offset);
  const pieces = [];
  let cur = 0;
  for (const w of sorted) {
    if (w.offset > cur) pieces.push({ from: cur, to: w.offset });
    pieces.push(w.buf);
    cur = w.offset + w.buf.length;
  }
  if (cur < base.size) pieces.push({ from: cur, to: base.size });
  return virtualSource(base, pieces);
}

async function readExact(src, pos, len) {
  if (len > MAX_META_BYTES) throw new TagError('E_TOO_LARGE', 'metadata region too large');
  if (pos < 0 || pos + len > src.size) throw new TagError('E_CORRUPT', 'unexpected end of file');
  const b = await src.read(pos, len);
  if (b.length !== len) throw new TagError('E_CORRUPT', 'short read');
  return b;
}

/* ── text helpers ────────────────────────────────────────────────────── */

function isLatin1(s) {
  for (let i = 0; i < s.length; i++) if (s.charCodeAt(i) > 0xff) return false;
  return true;
}

function decodeUtf16(buf, bigEndianDefault) {
  let be = bigEndianDefault;
  let b = buf;
  if (b.length >= 2 && b[0] === 0xff && b[1] === 0xfe) { be = false; b = b.subarray(2); }
  else if (b.length >= 2 && b[0] === 0xfe && b[1] === 0xff) { be = true; b = b.subarray(2); }
  const even = b.subarray(0, b.length - (b.length % 2));
  if (!be) return even.toString('utf16le');
  const sw = Buffer.from(even);
  sw.swap16();
  return sw.toString('utf16le');
}

function cleanValue(s) {
  return String(s ?? '').replace(/\0+$/g, '').trim();
}

const ID3_GENRES = [
  "Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal",
  "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial",
  "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk",
  "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise",
  "Alternative Rock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic",
  "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta",
  "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychedelic", "Rave", "Showtunes",
  "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock",
  "Folk", "Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebop", "Latin", "Revival", "Celtic", "Bluegrass",
  "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic",
  "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove",
  "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle",
  "Duet", "Punk Rock", "Drum Solo", "A Cappella", "Euro-House", "Dance Hall", "Goa", "Drum & Bass", "Club-House", "Hardcore",
  "Terror", "Indie", "BritPop", "Afro-Punk", "Polsk Punk", "Beat", "Christian Gangsta Rap", "Heavy Metal", "Black Metal", "Crossover",
  "Contemporary Christian", "Christian Rock", "Merengue", "Salsa", "Thrash Metal", "Anime", "JPop", "Synthpop",
];

/** "(17)Rock", "(17)", "17", "Rock\0Pop" → ["Rock"] / ["Rock","Pop"] */
function normalizeGenreList(raw) {
  const out = [];
  for (let piece of String(raw || '').split(/\0|;|\|/)) {
    piece = piece.trim();
    if (!piece) continue;
    const refs = /^((?:\(\d+\)|\(RX\)|\(CR\))+)(.*)$/i.exec(piece);
    if (refs) {
      const rest = refs[2].trim();
      if (rest) { out.push(rest); continue; }
      for (const m of refs[1].matchAll(/\((\d+|RX|CR)\)/gi)) {
        const id = m[1].toUpperCase();
        if (id === 'RX') out.push('Remix');
        else if (id === 'CR') out.push('Cover');
        else if (ID3_GENRES[Number(id)]) out.push(ID3_GENRES[Number(id)]);
      }
      continue;
    }
    if (/^\d{1,3}$/.test(piece) && ID3_GENRES[Number(piece)]) { out.push(ID3_GENRES[Number(piece)]); continue; }
    out.push(piece);
  }
  const seen = new Set();
  return out.filter((g) => { const k = g.toLowerCase(); if (seen.has(k)) return false; seen.add(k); return true; });
}

function splitGenreInput(s) {
  return String(s || '').split(';').map((g) => g.trim()).filter(Boolean);
}

/** "3", "3/12", "03 / 12" → { n: 3, total: 12 } ; "" → null */
function parseNumPair(s) {
  const m = /^\s*(\d{1,5})?\s*(?:\/\s*(\d{1,5}))?\s*$/.exec(String(s ?? ''));
  if (!m || (!m[1] && !m[2])) return null;
  return { n: m[1] ? Number(m[1]) : 0, total: m[2] ? Number(m[2]) : 0 };
}

function formatNumPair(n, total) {
  if (!n && !total) return '';
  return total ? `${n || 0}/${total}` : String(n);
}

/* ── patch validation (never trust the renderer) ─────────────────────── */

function normalizePatch(raw) {
  if (!raw || typeof raw !== 'object') throw new TagError('E_INVALID', 'patch');
  const fields = {};
  const src = raw.fields && typeof raw.fields === 'object' ? raw.fields : {};
  for (const key of FIELD_KEYS) {
    if (!Object.prototype.hasOwnProperty.call(src, key)) continue;
    const v = src[key];
    if (v !== null && typeof v !== 'string') throw new TagError('E_INVALID', key);
    let s = String(v ?? '');
    s = key === 'comment'
      ? s.replace(/\r\n?/g, '\n').replace(/[\x00-\x08\x0b-\x1f\x7f]/g, '')
      : s.replace(/[\x00-\x1f\x7f]/g, ' ');
    s = s.trim();
    const max = FIELD_MAX[key] || FIELD_MAX.default;
    if (s.length > max) throw new TagError('E_INVALID', `${key} too long`);
    if (key === 'year' && s && !/^\d{4}(-\d{2}(-\d{2})?)?$/.test(s)) throw new TagError('E_INVALID', 'year');
    if ((key === 'track' || key === 'disc') && s) {
      const p = parseNumPair(s);
      if (!p || p.n > 65535 || p.total > 65535) throw new TagError('E_INVALID', key);
      s = formatNumPair(p.n, p.total);
    }
    if (key === 'genre') s = splitGenreInput(s).join('; ');
    fields[key] = s;
  }
  let cover = { action: 'keep' };
  if (raw.cover && typeof raw.cover === 'object') {
    const a = raw.cover.action;
    if (a === 'remove') cover = { action: 'remove' };
    else if (a === 'set') {
      const d = raw.cover.data;
      if (!(d instanceof Uint8Array)) throw new TagError('E_INVALID', 'cover data');
      if (d.byteLength === 0 || d.byteLength > MAX_COVER_BYTES) throw new TagError('E_INVALID', 'cover size');
      const data = Buffer.from(d.buffer, d.byteOffset, d.byteLength);
      const info = imageInfo(data);
      if (!info) throw new TagError('E_INVALID', 'cover must be JPEG or PNG');
      cover = { action: 'set', data: Buffer.from(data), ...info };
    } else if (a !== undefined && a !== 'keep') throw new TagError('E_INVALID', 'cover action');
  }
  return { fields, cover };
}

/** JPEG / PNG only (what every tag format and player understands). */
function imageInfo(b) {
  if (b.length > 24 && b[0] === 0x89 && b.toString('latin1', 1, 4) === 'PNG') {
    return { mime: 'image/png', width: b.readUInt32BE(16), height: b.readUInt32BE(20), depth: (b[24] || 8) * 4 };
  }
  if (b.length > 4 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) {
    let width = 0, height = 0, depth = 24;
    let o = 2;
    while (o + 9 < b.length) {
      if (b[o] !== 0xff) { o++; continue; }
      const m = b[o + 1];
      if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7)) { o += 2; continue; }
      const len = b.readUInt16BE(o + 2);
      if ((m >= 0xc0 && m <= 0xcf) && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) {
        height = b.readUInt16BE(o + 5);
        width = b.readUInt16BE(o + 7);
        depth = b[o + 4] * (b[o + 9] || 3);
        break;
      }
      o += 2 + len;
    }
    return { mime: 'image/jpeg', width, height, depth };
  }
  return null;
}

/* ── FLAC-style picture structure (FLAC PICTURE block + Ogg METADATA_BLOCK_PICTURE) */

function buildPictureStruct(cover) {
  const mime = Buffer.from(cover.mime, 'latin1');
  const out = Buffer.alloc(32 + mime.length + cover.data.length);
  let o = 0;
  out.writeUInt32BE(3, o); o += 4; // front cover
  out.writeUInt32BE(mime.length, o); o += 4;
  mime.copy(out, o); o += mime.length;
  out.writeUInt32BE(0, o); o += 4; // empty description
  out.writeUInt32BE(cover.width >>> 0, o); o += 4;
  out.writeUInt32BE(cover.height >>> 0, o); o += 4;
  out.writeUInt32BE(cover.depth >>> 0, o); o += 4;
  out.writeUInt32BE(0, o); o += 4; // colors
  out.writeUInt32BE(cover.data.length, o); o += 4;
  cover.data.copy(out, o);
  return out;
}

/* ── comparison used by verify-before-commit ─────────────────────────── */

function comparable(key, value, ctx) {
  let s = cleanValue(value);
  if (key === 'genre') return normalizeGenreList(s).map((g) => g.toLowerCase()).join(';');
  if (key === 'track' || key === 'disc') {
    const p = parseNumPair(s);
    return p ? `${p.n}/${p.total}` : '';
  }
  if (key === 'year' && ctx && ctx.yearOnly) return s.slice(0, 4);
  if (key === 'comment') s = s.replace(/\r\n?/g, '\n');
  return s;
}

function verifyAgainst(expected, got, ctx) {
  const bad = [];
  for (const [k, v] of Object.entries(expected.fields)) {
    if (comparable(k, v, ctx) !== comparable(k, got.fields[k], ctx)) bad.push(k);
  }
  if (expected.cover.action === 'set' && !got.hasCover) bad.push('cover');
  if (expected.cover.action === 'remove' && got.hasCover) bad.push('cover');
  return bad;
}

function emptyFields() {
  const f = {};
  for (const k of FIELD_KEYS) f[k] = '';
  return f;
}

module.exports = {
  FIELD_KEYS, MAX_META_BYTES, MAX_COVER_BYTES, TagError,
  fileSource, bufferSource, virtualSource, overlaySource, readExact,
  isLatin1, decodeUtf16, cleanValue, ID3_GENRES, normalizeGenreList, splitGenreInput,
  parseNumPair, formatNumPair, normalizePatch, imageInfo, buildPictureStruct,
  verifyAgainst, emptyFields,
};
