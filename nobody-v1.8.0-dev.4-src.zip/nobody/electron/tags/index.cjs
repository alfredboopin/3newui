'use strict';
/* ─────────────────────────────────────────────────────────────────────────
 * NOBODY — tag editor core (V1.7.0, Phase 4 · part 1)
 *
 * readTags(path)          → { format, tagType, fields, hasCover }
 * writeTags(path, patch)  → { mode: 'inplace'|'rewrite', size, mtimeMs, fields, hasCover }
 *
 * Safety model
 *  - the container is detected from the bytes (extension only gates access)
 *  - every write is planned first; the planned result is parsed again from a
 *    virtual view and compared with the request BEFORE the file is touched
 *  - in place: only the tag region is overwritten (audio bytes never move)
 *  - rewrite: a hidden temp file next to the original, fsync, parse + verify
 *    the temp file, then an atomic rename (retried while Windows holds a lock)
 *  - one write per file at a time
 * ───────────────────────────────────────────────────────────────────────── */

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const C = require('./common.cjs');
const id3 = require('./id3.cjs');
const flac = require('./flac.cjs');
const ogg = require('./ogg.cjs');
const mp4 = require('./mp4.cjs');

const TAG_EXTS = new Set(['mp3', 'flac', 'ogg', 'oga', 'opus', 'm4a', 'm4b', 'mp4', 'alac']);
const COPY_CHUNK = 1 << 20;

async function detect(src, ext) {
  if (src.size < 12) throw new C.TagError('E_CORRUPT', 'file too small');
  const head = await src.read(0, 12);
  if (head.toString('latin1', 0, 3) === 'ID3') {
    const h = await id3.readId3Header(src, 0);
    if (h && h.total + 4 <= src.size) {
      const after = await src.read(h.total, 4);
      if (after.toString('latin1') === 'fLaC') return { kind: 'flac', flacOff: h.total };
    }
    if (ext === 'flac') throw new C.TagError('E_CORRUPT', 'FLAC stream not found');
    return { kind: 'mp3' };
  }
  if (head.toString('latin1', 0, 4) === 'fLaC') return { kind: 'flac', flacOff: 0 };
  if (head.toString('latin1', 0, 4) === 'OggS') return { kind: 'ogg' };
  if (head.toString('latin1', 4, 8) === 'ftyp') return { kind: 'mp4' };
  if (ext === 'mp3' && head[0] === 0xff && (head[1] & 0xe0) === 0xe0) return { kind: 'mp3' };
  throw new C.TagError('E_UNSUPPORTED', 'unknown container');
}

async function readFrom(src, ext) {
  const d = await detect(src, ext);
  let r;
  if (d.kind === 'mp3') r = await id3.readMp3(src);
  else if (d.kind === 'flac') r = await flac.readFlac(src, d.flacOff);
  else if (d.kind === 'ogg') r = await ogg.readOgg(src);
  else r = await mp4.readMp4(src);
  const format = d.kind === 'ogg' ? (r.codec === 'opus' ? 'opus' : 'ogg') : d.kind === 'mp4' ? 'm4a' : d.kind;
  return { format, tagType: r.tagType, fields: r.fields, hasCover: r.hasCover };
}

async function planFor(src, ext, patch) {
  const d = await detect(src, ext);
  if (d.kind === 'mp3') return id3.planMp3(src, patch);
  if (d.kind === 'flac') return flac.planFlac(src, patch, d.flacOff);
  if (d.kind === 'ogg') return ogg.planOgg(src, patch);
  return mp4.planMp4(src, patch);
}

/* ── path gate ───────────────────────────────────────────────────────── */

function extOf(p) {
  return path.extname(p).slice(1).toLowerCase();
}

async function gate(target, forWrite) {
  if (typeof target !== 'string' || !path.isAbsolute(target) || target.includes('\0')) throw new C.TagError('E_INVALID', 'path');
  const p = path.normalize(target);
  const ext = extOf(p);
  if (!TAG_EXTS.has(ext)) throw new C.TagError('E_UNSUPPORTED', `.${ext} files can't be tagged`);
  let st;
  try { st = await fsp.lstat(p); } catch { throw new C.TagError('E_NOT_FOUND'); }
  if (st.isSymbolicLink() || !st.isFile()) throw new C.TagError('E_INVALID', 'not a regular file');
  if (forWrite) {
    try { await fsp.access(p, fs.constants.R_OK | fs.constants.W_OK); } catch { throw new C.TagError('E_READONLY'); }
  }
  return { p, ext, st };
}

async function withFile(p, flags, fn) {
  const h = await fsp.open(p, flags);
  try {
    const st = await h.stat();
    return await fn(C.fileSource(h, Number(st.size)), h);
  } finally {
    await h.close().catch(() => undefined);
  }
}

/* ── public: read ────────────────────────────────────────────────────── */

async function readTags(target) {
  const { p, ext } = await gate(target, false);
  return withFile(p, 'r', (src) => readFrom(src, ext));
}

/* ── public: write ───────────────────────────────────────────────────── */

const locks = new Map();
function serialized(key, fn) {
  const prev = locks.get(key) || Promise.resolve();
  const run = prev.catch(() => undefined).then(fn);
  const tail = run.catch(() => undefined);
  locks.set(key, tail);
  tail.then(() => { if (locks.get(key) === tail) locks.delete(key); });
  return run;
}

async function writePieces(src, pieces, fh) {
  let at = 0;
  const write = async (buf) => {
    let off = 0;
    while (off < buf.length) {
      const { bytesWritten } = await fh.write(buf, off, buf.length - off, at);
      off += bytesWritten;
      at += bytesWritten;
    }
  };
  for (const piece of pieces) {
    if (Buffer.isBuffer(piece)) await write(piece);
    else if (piece.ogg) await ogg.copyRenumbered(src, piece.ogg, write);
    else {
      for (let pos = piece.from; pos < piece.to; ) {
        const b = await src.read(pos, Math.min(COPY_CHUNK, piece.to - pos));
        if (!b.length) throw new C.TagError('E_CORRUPT', 'short read while copying');
        await write(b);
        pos += b.length;
      }
    }
  }
  return at;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function renameWithRetry(from, to) {
  let last;
  for (let i = 0; i < 8; i++) {
    try { await fsp.rename(from, to); return; } catch (e) {
      last = e;
      if (!['EBUSY', 'EPERM', 'EACCES'].includes(e && e.code)) break;
      await sleep(120 * (i + 1));
    }
  }
  throw new C.TagError('E_BUSY', last && last.code);
}

async function writeTags(target, rawPatch) {
  const patch = C.normalizePatch(rawPatch);
  const { p, ext, st } = await gate(target, true);
  return serialized(p.toLowerCase(), async () => {
    let mode;
    let yearOnly = false;
    let pendingTmp = null;
    await withFile(p, 'r+', async (src, fh) => {
      const plan = await planFor(src, ext, patch);
      mode = plan.mode;
      yearOnly = !!plan.yearOnly;
      const view = plan.mode === 'inplace' ? C.overlaySource(src, plan.writes) : C.virtualSource(src, plan.pieces);
      const planned = await readFrom(view, ext);
      const bad = C.verifyAgainst(patch, planned, { yearOnly });
      if (bad.length) throw new C.TagError('E_VERIFY', bad.join(','));

      if (plan.mode === 'inplace') {
        for (const w of plan.writes) {
          let off = 0;
          while (off < w.buf.length) {
            const { bytesWritten } = await fh.write(w.buf, off, w.buf.length - off, w.offset + off);
            off += bytesWritten;
          }
        }
        await fh.sync().catch(() => undefined);
        return;
      }

      const dir = path.dirname(p);
      const tmp = path.join(dir, `.${path.basename(p)}.nobody-${crypto.randomBytes(4).toString('hex')}.tmp`);
      let out;
      try {
        out = await fsp.open(tmp, 'wx', st.mode & 0o777);
        const written = await writePieces(src, plan.pieces, out);
        await out.sync().catch(() => undefined);
        await out.close();
        out = null;
        if (written !== view.size) throw new C.TagError('E_VERIFY', 'size');
        const check = await withFile(tmp, 'r', (s) => readFrom(s, ext));
        const bad2 = C.verifyAgainst(patch, check, { yearOnly });
        if (bad2.length) throw new C.TagError('E_VERIFY', bad2.join(','));
      } catch (e) {
        if (out) await out.close().catch(() => undefined);
        await fsp.unlink(tmp).catch(() => undefined);
        if (e && e.code === 'ENOSPC') throw new C.TagError('E_NO_SPACE');
        if (e && (e.code === 'EACCES' || e.code === 'EPERM')) throw new C.TagError('E_READONLY');
        throw e;
      }
      // the original handle must be closed before the rename (Windows)
      pendingTmp = tmp;
    });
    if (pendingTmp) {
      try {
        await renameWithRetry(pendingTmp, p);
      } catch (e) {
        await fsp.unlink(pendingTmp).catch(() => undefined);
        throw e;
      }
    }
    const after = await withFile(p, 'r', (s) => readFrom(s, ext));
    const info = await fsp.stat(p);
    return { mode, size: Number(info.size), mtimeMs: Number(info.mtimeMs), ...after };
  });
}

/** Error → stable code for the renderer ("E_BUSY", …). */
function errorCode(e) {
  if (e && typeof e.code === 'string' && e.code.startsWith('E_')) return e.code;
  if (e && e.code === 'ENOENT') return 'E_NOT_FOUND';
  if (e && (e.code === 'EACCES' || e.code === 'EPERM')) return 'E_READONLY';
  if (e && e.code === 'EBUSY') return 'E_BUSY';
  return 'E_FAILED';
}

module.exports = { readTags, writeTags, errorCode, TAG_EXTS, _internal: { readFrom, planFor, C } };
