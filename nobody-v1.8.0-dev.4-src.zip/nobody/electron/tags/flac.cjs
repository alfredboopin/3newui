'use strict';
/* NOBODY — tag editor · FLAC. Metadata blocks are rebuilt (STREAMINFO first,
 * SEEKTABLE / APPLICATION / CUESHEET kept verbatim, new VORBIS_COMMENT,
 * pictures) and written in place whenever they fit the old metadata area
 * (padding absorbs the difference). Otherwise the file is rewritten with 8 KB
 * of fresh padding. An ID3v2 prefix (some rippers add one) is kept as is. */

const { TagError, readExact, buildPictureStruct } = require('./common.cjs');
const { parseComments, serializeComments, fieldsFromComments, applyPatch } = require('./vorbis.cjs');

const PAD_NEW = 8192;
const MAX_INPLACE_PAD = 4 * 1024 * 1024;
const BLOCK_MAX = 0xffffff;

async function loadBlocks(src, flacOff) {
  const magic = await readExact(src, flacOff, 4);
  if (magic.toString('latin1') !== 'fLaC') throw new TagError('E_CORRUPT', 'not a FLAC stream');
  let pos = flacOff + 4;
  const blocks = [];
  for (;;) {
    const h = await readExact(src, pos, 4);
    const last = !!(h[0] & 0x80);
    const type = h[0] & 0x7f;
    const len = (h[1] << 16) | (h[2] << 8) | h[3];
    if (type === 127) throw new TagError('E_CORRUPT', 'invalid FLAC block');
    if (pos + 4 + len > src.size) throw new TagError('E_CORRUPT', 'FLAC block past end of file');
    // padding content is never needed
    const data = type === 1 ? null : await readExact(src, pos + 4, len);
    blocks.push({ type, len, data });
    pos += 4 + len;
    if (last) break;
    if (blocks.length > 4096) throw new TagError('E_CORRUPT', 'too many FLAC blocks');
  }
  if (!blocks.length || blocks[0].type !== 0) throw new TagError('E_CORRUPT', 'missing STREAMINFO');
  return { blocks, metaStart: flacOff + 4, metaEnd: pos };
}

async function readFlac(src, flacOff) {
  const { blocks } = await loadBlocks(src, flacOff);
  const vcb = blocks.find((b) => b.type === 4);
  const vc = vcb ? parseComments(vcb.data) : { vendor: '', comments: [] };
  return { fields: fieldsFromComments(vc), hasCover: blocks.some((b) => b.type === 6), tagType: 'Vorbis comment (FLAC)' };
}

function blockBytes(type, data, last) {
  if (data.length > BLOCK_MAX) throw new TagError('E_TOO_LARGE', 'FLAC metadata block over 16 MB');
  const h = Buffer.from([(last ? 0x80 : 0) | type, (data.length >>> 16) & 0xff, (data.length >>> 8) & 0xff, data.length & 0xff]);
  return Buffer.concat([h, data]);
}

async function planFlac(src, patch, flacOff) {
  const { blocks, metaStart, metaEnd } = await loadBlocks(src, flacOff);
  const vcb = blocks.find((b) => b.type === 4);
  const vc = vcb ? parseComments(vcb.data) : { vendor: 'NOBODY', comments: [] };
  const newVc = serializeComments(applyPatch(vc, patch, false));

  const out = [{ type: 0, data: blocks[0].data }];
  for (const b of blocks.slice(1)) if (b.type !== 1 && b.type !== 4 && b.type !== 6) out.push(b);
  out.push({ type: 4, data: newVc });
  if (patch.cover.action === 'keep') for (const b of blocks) if (b.type === 6) out.push(b);
  if (patch.cover.action === 'set') out.push({ type: 6, data: buildPictureStruct(patch.cover) });

  const body = out.map((b) => b.data);
  const used = body.reduce((n, d) => n + 4 + d.length, 0);
  const region = metaEnd - metaStart;
  const serialize = (pad) => {
    const parts = out.map((b, i) => blockBytes(b.type, b.data, pad === null && i === out.length - 1));
    if (pad !== null) parts.push(blockBytes(1, Buffer.alloc(pad), true));
    return Buffer.concat(parts);
  };
  if (used === region) return { mode: 'inplace', writes: [{ offset: metaStart, buf: serialize(null) }] };
  if (region - used >= 4 && region - used - 4 <= Math.min(BLOCK_MAX, MAX_INPLACE_PAD)) {
    return { mode: 'inplace', writes: [{ offset: metaStart, buf: serialize(region - used - 4) }] };
  }
  return { mode: 'rewrite', pieces: [{ from: 0, to: metaStart }, serialize(PAD_NEW), { from: metaEnd, to: src.size }] };
}

module.exports = { readFlac, planFlac };
