'use strict';
/* NOBODY — tag editor · Ogg Vorbis / Ogg Opus.
 * Page 0 (identification header) is kept byte-for-byte. The comment packet
 * (and, for Vorbis, the setup packet that shares its pages) is re-paginated.
 * If the number of header pages changes, every later page of the stream gets
 * its sequence number shifted and its CRC recomputed while the file is
 * streamed to the temp copy. Multiplexed / FLAC-in-Ogg streams are refused. */

const { TagError, readExact } = require('./common.cjs');
const { parseComments, serializeComments, fieldsFromComments, applyPatch, hasOggPicture } = require('./vorbis.cjs');

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let r = i << 24;
    for (let j = 0; j < 8; j++) r = r & 0x80000000 ? ((r << 1) ^ 0x04c11db7) >>> 0 : (r << 1) >>> 0;
    t[i] = r >>> 0;
  }
  return t;
})();

function oggCrc(buf) {
  let crc = 0;
  for (let i = 0; i < buf.length; i++) crc = ((crc << 8) ^ CRC_TABLE[((crc >>> 24) ^ buf[i]) & 0xff]) >>> 0;
  return crc >>> 0;
}

async function readPageAt(src, pos) {
  const h = await readExact(src, pos, 27);
  if (h.toString('latin1', 0, 4) !== 'OggS' || h[4] !== 0) throw new TagError('E_CORRUPT', 'bad Ogg page');
  const nseg = h[26];
  const segs = await readExact(src, pos + 27, nseg);
  let dataLen = 0;
  for (const s of segs) dataLen += s;
  const data = await readExact(src, pos + 27 + nseg, dataLen);
  return {
    pos, type: h[5], serial: h.readUInt32LE(14), seq: h.readUInt32LE(18),
    segs, data, length: 27 + nseg + dataLen,
  };
}

/** Reads the header packets. Returns their bytes and where the header pages end. */
async function loadHeaders(src) {
  const first = await readPageAt(src, 0);
  if (!(first.type & 0x02)) throw new TagError('E_CORRUPT', 'first Ogg page is not BOS');
  const serial = first.serial;
  let codec;
  if (first.data.length >= 7 && first.data[0] === 1 && first.data.toString('latin1', 1, 7) === 'vorbis') codec = 'vorbis';
  else if (first.data.toString('latin1', 0, 8) === 'OpusHead') codec = 'opus';
  else throw new TagError('E_UNSUPPORTED', 'only Ogg Vorbis and Ogg Opus can be tagged');
  if (first.segs.length === 0 || first.segs[first.segs.length - 1] === 255) throw new TagError('E_UNSUPPORTED', 'unusual Ogg layout');
  for (let i = 0; i < first.segs.length - 1; i++) if (first.segs[i] < 255) throw new TagError('E_UNSUPPORTED', 'unusual Ogg layout');

  const want = codec === 'vorbis' ? 2 : 1; // packets after the ident header
  const packets = [];
  let cur = [];
  let pos = first.length;
  let pages = 0;
  while (packets.length < want) {
    if (pos >= src.size) throw new TagError('E_CORRUPT', 'Ogg headers truncated');
    const p = await readPageAt(src, pos);
    if (p.serial !== serial) throw new TagError('E_UNSUPPORTED', 'multiplexed Ogg streams');
    pages++;
    let off = 0;
    for (let i = 0; i < p.segs.length; i++) {
      const s = p.segs[i];
      if (packets.length >= want) throw new TagError('E_UNSUPPORTED', 'audio data shares a header page');
      cur.push(p.data.subarray(off, off + s));
      off += s;
      if (s < 255) { packets.push(Buffer.concat(cur)); cur = []; }
    }
    pos += p.length;
    if (pages > 4096) throw new TagError('E_TOO_LARGE', 'Ogg header too large');
  }
  if (cur.length) throw new TagError('E_UNSUPPORTED', 'unusual Ogg layout');
  const comment = packets[0];
  let vc;
  let tail = Buffer.alloc(0);
  if (codec === 'vorbis') {
    if (comment[0] !== 3 || comment.toString('latin1', 1, 7) !== 'vorbis') throw new TagError('E_CORRUPT', 'missing Vorbis comment header');
    vc = parseComments(comment, 7);
  } else {
    if (comment.toString('latin1', 0, 8) !== 'OpusTags') throw new TagError('E_CORRUPT', 'missing OpusTags');
    vc = parseComments(comment, 8);
    // RFC 7845: extra binary data after the comments is kept if its first bit says so
    const extra = comment.subarray(vc.end);
    if (extra.length && extra[0] & 1) tail = Buffer.from(extra);
  }
  return { codec, serial, firstPageLen: first.length, headerEnd: pos, headerPages: pages, vc, setup: packets[1] || null, tail };
}

async function readOgg(src) {
  const h = await loadHeaders(src);
  return {
    fields: fieldsFromComments(h.vc),
    hasCover: hasOggPicture(h.vc),
    tagType: h.codec === 'opus' ? 'Vorbis comment (Opus)' : 'Vorbis comment (Ogg)',
    codec: h.codec,
  };
}

function pageBytes(type, granuleMinusOne, serial, seq, segs, datas) {
  const head = Buffer.alloc(27 + segs.length);
  head.write('OggS', 0, 'latin1');
  head[4] = 0;
  head[5] = type;
  if (granuleMinusOne) head.fill(0xff, 6, 14);
  head.writeUInt32LE(serial, 14);
  head.writeUInt32LE(seq >>> 0, 18);
  head[26] = segs.length;
  for (let i = 0; i < segs.length; i++) head[27 + i] = segs[i];
  const page = Buffer.concat([head, ...datas]);
  page.writeUInt32LE(oggCrc(page), 22);
  return page;
}

function paginate(packets, serial, startSeq) {
  const pages = [];
  let segs = [], datas = [], ended = false, continued = false;
  const flush = (midPacket) => {
    pages.push(pageBytes(continued ? 1 : 0, !ended, serial, startSeq + pages.length, segs, datas));
    continued = midPacket;
    segs = []; datas = []; ended = false;
  };
  for (const p of packets) {
    const full = Math.floor(p.length / 255);
    let off = 0;
    for (let i = 0; i <= full; i++) {
      const s = i < full ? 255 : p.length % 255;
      if (segs.length === 255) flush(true);
      segs.push(s);
      datas.push(p.subarray(off, off + s));
      off += s;
      if (i === full) ended = true;
    }
    if (segs.length === 255) flush(false);
  }
  if (segs.length) flush(false);
  return pages;
}

async function planOgg(src, patch) {
  const h = await loadHeaders(src);
  const vc = serializeComments(applyPatch(h.vc, patch, true));
  const comment = h.codec === 'vorbis'
    ? Buffer.concat([Buffer.from([3]), Buffer.from('vorbis', 'latin1'), vc, Buffer.from([1])])
    : Buffer.concat([Buffer.from('OpusTags', 'latin1'), vc, h.tail]);
  const packets = h.setup ? [comment, h.setup] : [comment];
  const pages = paginate(packets, h.serial, 1);
  const newHeader = Buffer.concat(pages);
  const seqDelta = pages.length - h.headerPages;
  const oldLen = h.headerEnd - h.firstPageLen;
  if (seqDelta === 0 && newHeader.length === oldLen) {
    return { mode: 'inplace', writes: [{ offset: h.firstPageLen, buf: newHeader }] };
  }
  const rest = seqDelta === 0
    ? { from: h.headerEnd, to: src.size }
    : { ogg: { from: h.headerEnd, to: src.size, serial: h.serial, seqDelta } };
  return { mode: 'rewrite', pieces: [{ from: 0, to: h.firstPageLen }, newHeader, rest] };
}

/** Streams [from, to) to `write`, shifting page sequence numbers of `serial`
 *  by seqDelta and fixing their CRC. Anything that isn't a valid page (junk,
 *  a truncated tail) is copied verbatim. */
async function copyRenumbered(src, piece, write) {
  const { from, to, serial, seqDelta } = piece;
  const CHUNK = 1 << 20;
  let buf = Buffer.alloc(0);
  let pos = from;
  let bufStart = from;
  const fill = async (need) => {
    while (buf.length < need && pos < to) {
      const b = await src.read(pos, Math.min(CHUNK, to - pos));
      if (!b.length) break;
      pos += b.length;
      buf = buf.length ? Buffer.concat([buf, b]) : b;
    }
  };
  for (;;) {
    await fill(27);
    if (buf.length === 0) break;
    const okHead = buf.length >= 27 && buf.toString('latin1', 0, 4) === 'OggS' && buf[4] === 0;
    if (!okHead) {
      // not a page: flush everything that's left verbatim
      await write(buf);
      buf = Buffer.alloc(0);
      while (pos < to) {
        const b = await src.read(pos, Math.min(CHUNK, to - pos));
        if (!b.length) break;
        pos += b.length;
        await write(b);
      }
      break;
    }
    const nseg = buf[26];
    await fill(27 + nseg);
    if (buf.length < 27 + nseg) { await write(buf); buf = Buffer.alloc(0); continue; }
    let dataLen = 0;
    for (let i = 0; i < nseg; i++) dataLen += buf[27 + i];
    const len = 27 + nseg + dataLen;
    await fill(len);
    if (buf.length < len) { await write(buf); buf = Buffer.alloc(0); continue; }
    const page = Buffer.from(buf.subarray(0, len));
    if (page.readUInt32LE(14) === serial) {
      page.writeUInt32LE((page.readUInt32LE(18) + seqDelta) >>> 0, 18);
      page.writeUInt32LE(0, 22);
      page.writeUInt32LE(oggCrc(page), 22);
    }
    await write(page);
    buf = buf.subarray(len);
    bufStart += len;
  }
  void bufStart;
}

module.exports = { readOgg, planOgg, copyRenumbered, oggCrc };
