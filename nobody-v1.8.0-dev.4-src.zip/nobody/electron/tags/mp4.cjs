'use strict';
/* NOBODY — tag editor · MP4 / M4A / M4B (iTunes-style moov/udta/meta/ilst).
 * The moov atom is loaded, its ilst rebuilt (unknown items kept verbatim) and
 * the size difference absorbed by a `free` atom inside meta (or a top-level
 * `free` right after moov) so the edit is in place. Otherwise the moov is
 * rewritten with 2 KB of padding and — when moov sits before mdat — every
 * stco / co64 chunk offset is shifted. Fragmented files are refused then. */

const { TagError, readExact, cleanValue, emptyFields, ID3_GENRES, normalizeGenreList, parseNumPair } = require('./common.cjs');

const PAD_NEW = 2048;
const CONTAINERS = new Set(['moov', 'trak', 'mdia', 'minf', 'stbl', 'udta', 'meta', 'ilst', 'edts', 'dinf', 'mvex']);

async function topLevel(src) {
  const atoms = [];
  let pos = 0;
  while (pos + 8 <= src.size) {
    const h = await src.read(pos, 16);
    let size = h.readUInt32BE(0);
    const type = h.toString('latin1', 4, 8);
    let hs = 8;
    if (size === 1) {
      if (h.length < 16) break;
      const big = h.readBigUInt64BE(8);
      if (big > BigInt(Number.MAX_SAFE_INTEGER)) throw new TagError('E_CORRUPT', 'atom too large');
      size = Number(big);
      hs = 16;
    } else if (size === 0) size = src.size - pos;
    if (size < hs || pos + size > src.size) {
      // trailing garbage / truncated last atom: stop walking, keep bytes as they are
      if (!atoms.length) throw new TagError('E_CORRUPT', 'invalid MP4');
      break;
    }
    atoms.push({ type, pos, size, hs });
    pos += size;
    if (atoms.length > 100000) break;
  }
  return atoms;
}

/** meta is a full box in ISO/iTunes files but a plain container in some QuickTime files. */
function metaPrefix(b, start) {
  if (b.length >= start + 8 && b.toString('latin1', start + 4, start + 8) === 'hdlr') return 0;
  return 4;
}

function parseTree(b, start, end, parentType) {
  const kids = [];
  let pos = start;
  while (pos + 8 <= end) {
    let size = b.readUInt32BE(pos);
    const type = b.toString('latin1', pos + 4, pos + 8);
    let hs = 8;
    if (size === 1) { size = Number(b.readBigUInt64BE(pos + 8)); hs = 16; } else if (size === 0) size = end - pos;
    if (size < hs || pos + size > end) { kids.push({ type: null, raw: b.subarray(pos, end) }); break; }
    if (CONTAINERS.has(type) && parentType !== 'ilst') {
      let prefix = Buffer.alloc(0);
      let cs = pos + hs;
      if (type === 'meta') { const p = metaPrefix(b, cs); prefix = b.subarray(cs, cs + p); cs += p; }
      kids.push({ type, prefix, children: parseTree(b, cs, pos + size, type) });
    } else kids.push({ type, raw: b.subarray(pos, pos + size) });
    pos += size;
  }
  if (pos < end && (!kids.length || kids[kids.length - 1].type !== null)) kids.push({ type: null, raw: b.subarray(pos, end) });
  return kids;
}

function nodeSize(n) {
  if (n.raw) return n.raw.length;
  return 8 + n.prefix.length + n.children.reduce((s, c) => s + nodeSize(c), 0);
}

function serialize(n) {
  if (n.raw) return n.raw;
  const body = Buffer.concat([n.prefix, ...n.children.map(serialize)]);
  if (body.length + 8 > 0xffffffff) throw new TagError('E_TOO_LARGE', 'atom');
  const h = Buffer.alloc(8);
  h.writeUInt32BE(body.length + 8, 0);
  h.write(n.type, 4, 'latin1');
  return Buffer.concat([h, body]);
}

const child = (n, type) => n && n.children && n.children.find((c) => c.type === type);

function atom(type, body) {
  const h = Buffer.alloc(8);
  h.writeUInt32BE(body.length + 8, 0);
  h.write(type, 4, 'latin1');
  return Buffer.concat([h, body]);
}

/* ── ilst items ──────────────────────────────────────────────────────── */

function itemData(raw) {
  // item atom → [{ type, payload }] of its 'data' children
  const out = [];
  let pos = 8;
  while (pos + 8 <= raw.length) {
    const size = raw.readUInt32BE(pos);
    const t = raw.toString('latin1', pos + 4, pos + 8);
    if (size < 8 || pos + size > raw.length) break;
    if (t === 'data' && size >= 16) out.push({ type: raw.readUInt32BE(pos + 8) & 0xffffff, payload: raw.subarray(pos + 16, pos + size) });
    pos += size;
  }
  return out;
}

function dataAtom(type, payload) {
  const b = Buffer.alloc(8);
  b.writeUInt32BE(type, 0); // version 0 + 3-byte type
  return atom('data', Buffer.concat([b, payload]));
}

const TEXT_ITEMS = { title: '\xa9nam', artist: '\xa9ART', album: '\xa9alb', albumArtist: 'aART', year: '\xa9day', genre: '\xa9gen', composer: '\xa9wrt', comment: '\xa9cmt' };

function readIlst(ilst) {
  const f = emptyFields();
  let hasCover = false;
  if (!ilst) return { fields: f, hasCover };
  for (const it of ilst.children) {
    if (!it.raw || !it.type) continue;
    const t = it.type;
    const data = itemData(it.raw);
    if (t === 'covr') { if (data.length) hasCover = true; continue; }
    if (t === 'trkn' || t === 'disk') {
      const p = data[0] && data[0].payload;
      if (p && p.length >= 6) {
        const n = p.readUInt16BE(2), tot = p.readUInt16BE(4);
        const s = n || tot ? (tot ? `${n}/${tot}` : String(n)) : '';
        if (t === 'trkn') f.track = s; else f.disc = s;
      }
      continue;
    }
    if (t === 'gnre') {
      const p = data[0] && data[0].payload;
      if (p && p.length >= 2 && !f.genre) { const g = ID3_GENRES[p.readUInt16BE(0) - 1]; if (g) f.genre = g; }
      continue;
    }
    const key = Object.keys(TEXT_ITEMS).find((k) => TEXT_ITEMS[k] === t);
    if (!key) continue;
    const vals = data.filter((d) => d.type === 1 || d.type === 0).map((d) => cleanValue(d.payload.toString('utf8'))).filter(Boolean);
    if (!vals.length) continue;
    if (key === 'genre') f.genre = normalizeGenreList(vals.join(';')).join('; ');
    else if (key === 'year') f.year = vals[0].slice(0, 10);
    else f[key] = vals.join(key === 'comment' ? '\n' : '; ');
  }
  return { fields: f, hasCover };
}

function buildIlstChildren(ilst, patch) {
  const F = patch.fields;
  const drop = new Set();
  for (const k of Object.keys(F)) {
    if (TEXT_ITEMS[k]) drop.add(TEXT_ITEMS[k]);
    if (k === 'genre') drop.add('gnre');
    if (k === 'track') drop.add('trkn');
    if (k === 'disc') drop.add('disk');
  }
  if (patch.cover.action !== 'keep') drop.add('covr');
  const kept = (ilst ? ilst.children : []).filter((c) => !(c.type && drop.has(c.type)));
  const fresh = [];
  for (const [k, t] of Object.entries(TEXT_ITEMS)) {
    if (F[k]) fresh.push({ type: t, raw: atom(t, dataAtom(1, Buffer.from(F[k], 'utf8'))) });
  }
  const pair = (t, s, len) => {
    const p = parseNumPair(s);
    if (!p) return;
    const b = Buffer.alloc(len);
    b.writeUInt16BE(Math.min(p.n, 65535), 2);
    b.writeUInt16BE(Math.min(p.total, 65535), 4);
    fresh.push({ type: t, raw: atom(t, dataAtom(0, b)) });
  };
  if (F.track) pair('trkn', F.track, 8);
  if (F.disc) pair('disk', F.disc, 6);
  const covers = kept.filter((c) => c.type === 'covr');
  const rest = kept.filter((c) => c.type !== 'covr');
  if (patch.cover.action === 'set') {
    const t = patch.cover.mime === 'image/png' ? 14 : 13;
    covers.push({ type: 'covr', raw: atom('covr', dataAtom(t, patch.cover.data)) });
  }
  return [...fresh, ...rest, ...covers];
}

function hdlrMdir() {
  const b = Buffer.alloc(25);
  b.write('mdir', 8, 'latin1');
  b.write('appl', 12, 'latin1');
  return { type: 'hdlr', raw: atom('hdlr', b) };
}

/** Finds (or creates) moov/udta/meta/ilst. Returns the nodes. */
function locate(moov, create) {
  let udta = child(moov, 'udta');
  if (!udta) {
    if (!create) return {};
    udta = { type: 'udta', prefix: Buffer.alloc(0), children: [] };
    moov.children.push(udta);
  }
  let meta = udta.children.find((c) => c.type === 'meta' && c.children);
  if (!meta) {
    if (!create) return { udta };
    meta = { type: 'meta', prefix: Buffer.alloc(4), children: [hdlrMdir()] };
    udta.children.push(meta);
  }
  let ilst = child(meta, 'ilst');
  if (!ilst && create) {
    ilst = { type: 'ilst', prefix: Buffer.alloc(0), children: [] };
    meta.children.push(ilst);
  }
  return { udta, meta, ilst };
}

async function loadMoov(src) {
  const atoms = await topLevel(src);
  if (!atoms.length || atoms[0].type !== 'ftyp') throw new TagError('E_CORRUPT', 'missing ftyp');
  const moovs = atoms.filter((a) => a.type === 'moov');
  if (moovs.length !== 1) throw new TagError(moovs.length ? 'E_UNSUPPORTED' : 'E_CORRUPT', 'moov');
  const m = moovs[0];
  const raw = await readExact(src, m.pos, m.size);
  const moov = { type: 'moov', prefix: Buffer.alloc(0), children: parseTree(raw, m.hs, m.size, 'moov') };
  return { atoms, m, moov };
}

async function readMp4(src) {
  const { moov } = await loadMoov(src);
  const { ilst } = locate(moov, false);
  return { ...readIlst(ilst), tagType: 'iTunes (MP4)' };
}

function freeAtom(size) {
  const b = Buffer.alloc(size);
  b.writeUInt32BE(size, 0);
  b.write('free', 4, 'latin1');
  return { type: 'free', raw: b };
}

function* stcoNodes(n) {
  if (!n.children) return;
  for (const c of n.children) {
    if (c.raw && (c.type === 'stco' || c.type === 'co64')) yield { parent: n, node: c };
    else if (c.children) yield* stcoNodes(c);
  }
}

function shiftOffsets(moov, after, delta) {
  for (const { node } of stcoNodes(moov)) {
    const r = Buffer.from(node.raw);
    const count = r.readUInt32BE(12);
    const wide = node.type === 'co64';
    const step = wide ? 8 : 4;
    if (16 + count * step > r.length) throw new TagError('E_CORRUPT', 'chunk offset table');
    for (let i = 0; i < count; i++) {
      const o = 16 + i * step;
      if (wide) {
        const v = r.readBigUInt64BE(o);
        if (v >= BigInt(after)) r.writeBigUInt64BE(v + BigInt(delta), o);
      } else {
        const v = r.readUInt32BE(o);
        if (v >= after) {
          const nv = v + delta;
          if (nv > 0xffffffff || nv < 0) throw new TagError('E_UNSUPPORTED', 'chunk offsets overflow');
          r.writeUInt32BE(nv, o);
        }
      }
    }
    node.raw = r;
  }
}

async function planMp4(src, patch) {
  const { atoms, m, moov } = await loadMoov(src);
  const { meta } = locate(moov, true);
  const ilst = child(meta, 'ilst');
  ilst.children = buildIlstChildren(ilst, patch);
  // drop the padding right after ilst (we re-create it to fit)
  const i = meta.children.indexOf(ilst);
  if (meta.children[i + 1] && meta.children[i + 1].type === 'free') meta.children.splice(i + 1, 1);
  const core = nodeSize(moov);
  const slack = m.size - core;
  const withPad = (pad) => {
    const idx = meta.children.indexOf(ilst);
    if (pad > 0) meta.children.splice(idx + 1, 0, freeAtom(pad));
    const buf = serialize(moov);
    if (pad > 0) meta.children.splice(idx + 1, 1);
    return buf;
  };
  if (slack === 0 || slack >= 8) {
    return { mode: 'inplace', writes: [{ offset: m.pos, buf: withPad(slack) }] };
  }
  const idx = atoms.indexOf(m);
  const next = atoms[idx + 1];
  if (next && (next.type === 'free' || next.type === 'skip') && next.hs === 8) {
    const room = slack + next.size; // bytes left for a trailing free atom
    if (room === 0 || room >= 8) {
      const bufs = [withPad(0)];
      if (room > 0) bufs.push(freeAtom(room).raw);
      return { mode: 'inplace', writes: [{ offset: m.pos, buf: Buffer.concat(bufs) }] };
    }
  }
  // full rewrite of moov
  const mdatAfter = atoms.some((a) => a.type === 'mdat' && a.pos > m.pos);
  const fragmented = atoms.some((a) => a.type === 'moof') || !!child(moov, 'mvex');
  const newSize = core + PAD_NEW;
  const delta = newSize - m.size;
  if (mdatAfter) {
    if (fragmented) throw new TagError('E_UNSUPPORTED', 'fragmented MP4');
    shiftOffsets(moov, m.pos + m.size, delta);
  }
  const buf = withPad(PAD_NEW);
  return { mode: 'rewrite', pieces: [{ from: 0, to: m.pos }, buf, { from: m.pos + m.size, to: src.size }] };
}

module.exports = { readMp4, planMp4 };
