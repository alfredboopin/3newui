'use strict';
/* NOBODY — tag editor · Vorbis comments (FLAC VORBIS_COMMENT block, Ogg
 * Vorbis / Opus comment packets). Keys are case-insensitive; every key we
 * don't edit (REPLAYGAIN_*, LYRICS, MUSICBRAINZ_*, …) is kept verbatim. */

const { TagError, cleanValue, emptyFields, normalizeGenreList, splitGenreInput, parseNumPair, buildPictureStruct } = require('./common.cjs');

function parseComments(b, off = 0) {
  if (off + 8 > b.length) throw new TagError('E_CORRUPT', 'vorbis comment');
  const vlen = b.readUInt32LE(off);
  off += 4;
  if (off + vlen + 4 > b.length) throw new TagError('E_CORRUPT', 'vorbis vendor');
  const vendor = b.toString('utf8', off, off + vlen);
  off += vlen;
  const count = b.readUInt32LE(off);
  off += 4;
  const comments = [];
  for (let i = 0; i < count; i++) {
    if (off + 4 > b.length) throw new TagError('E_CORRUPT', 'vorbis comment list');
    const len = b.readUInt32LE(off);
    off += 4;
    if (off + len > b.length) throw new TagError('E_CORRUPT', 'vorbis comment entry');
    const s = b.toString('utf8', off, off + len);
    off += len;
    const eq = s.indexOf('=');
    if (eq <= 0) { comments.push({ raw: s }); continue; }
    comments.push({ key: s.slice(0, eq), value: s.slice(eq + 1) });
  }
  return { vendor, comments, end: off };
}

function serializeComments(vc) {
  const parts = [];
  const vendor = Buffer.from(vc.vendor || 'NOBODY', 'utf8');
  const head = Buffer.alloc(4);
  head.writeUInt32LE(vendor.length);
  parts.push(head, vendor);
  const cnt = Buffer.alloc(4);
  cnt.writeUInt32LE(vc.comments.length);
  parts.push(cnt);
  for (const c of vc.comments) {
    const s = Buffer.from(c.raw !== undefined ? c.raw : `${c.key}=${c.value}`, 'utf8');
    const l = Buffer.alloc(4);
    l.writeUInt32LE(s.length);
    parts.push(l, s);
  }
  return Buffer.concat(parts);
}

const K = (c) => (c.key || '').toUpperCase();

function fieldsFromComments(vc) {
  const f = emptyFields();
  const all = (key) => vc.comments.filter((c) => K(c) === key).map((c) => cleanValue(c.value)).filter(Boolean);
  const first = (...keys) => { for (const k of keys) { const v = all(k)[0]; if (v) return v; } return ''; };
  f.title = all('TITLE').join(' / ');
  f.artist = all('ARTIST').join('; ');
  f.album = first('ALBUM');
  f.albumArtist = first('ALBUMARTIST', 'ALBUM ARTIST', 'ALBUM_ARTIST');
  f.year = first('DATE', 'YEAR').slice(0, 10);
  f.genre = normalizeGenreList(all('GENRE').join(';')).join('; ');
  const tn = parseNumPair(first('TRACKNUMBER'));
  const tt = Number(first('TRACKTOTAL', 'TOTALTRACKS')) || 0;
  if (tn) f.track = tn.total || tt ? `${tn.n}/${tn.total || tt}` : String(tn.n);
  const dn = parseNumPair(first('DISCNUMBER'));
  const dt = Number(first('DISCTOTAL', 'TOTALDISCS')) || 0;
  if (dn) f.disc = dn.total || dt ? `${dn.n}/${dn.total || dt}` : String(dn.n);
  f.composer = all('COMPOSER').join('; ');
  f.comment = first('COMMENT', 'DESCRIPTION');
  return f;
}

const DROP = {
  title: ['TITLE'], artist: ['ARTIST'], album: ['ALBUM'],
  albumArtist: ['ALBUMARTIST', 'ALBUM ARTIST', 'ALBUM_ARTIST'],
  year: ['DATE', 'YEAR'], genre: ['GENRE'],
  track: ['TRACKNUMBER', 'TRACKTOTAL', 'TOTALTRACKS'],
  disc: ['DISCNUMBER', 'DISCTOTAL', 'TOTALDISCS'],
  composer: ['COMPOSER'], comment: ['COMMENT', 'DESCRIPTION'],
};
const PICTURE_KEYS = ['METADATA_BLOCK_PICTURE', 'COVERART', 'COVERARTMIME'];

/** Returns a new comment list. `oggCover` = write the cover as
 *  METADATA_BLOCK_PICTURE (Ogg); FLAC stores it in a PICTURE block instead. */
function applyPatch(vc, patch, oggCover) {
  const drop = new Set();
  for (const k of Object.keys(patch.fields)) for (const key of DROP[k]) drop.add(key);
  if (oggCover && patch.cover.action !== 'keep') for (const key of PICTURE_KEYS) drop.add(key);
  const kept = vc.comments.filter((c) => c.raw !== undefined || !drop.has(K(c)));
  const fresh = [];
  const F = patch.fields;
  const add = (key, v) => { if (v) fresh.push({ key, value: v }); };
  add('TITLE', F.title);
  add('ARTIST', F.artist);
  add('ALBUM', F.album);
  add('ALBUMARTIST', F.albumArtist);
  add('DATE', F.year);
  if (F.genre) for (const g of splitGenreInput(F.genre)) add('GENRE', g);
  if (F.track) {
    const p = parseNumPair(F.track);
    if (p && p.n) add('TRACKNUMBER', String(p.n));
    if (p && p.total) add('TRACKTOTAL', String(p.total));
  }
  if (F.disc) {
    const p = parseNumPair(F.disc);
    if (p && p.n) add('DISCNUMBER', String(p.n));
    if (p && p.total) add('DISCTOTAL', String(p.total));
  }
  add('COMPOSER', F.composer);
  add('COMMENT', F.comment);
  const out = [...fresh, ...kept];
  if (oggCover && patch.cover.action === 'set') {
    out.push({ key: 'METADATA_BLOCK_PICTURE', value: buildPictureStruct(patch.cover).toString('base64') });
  }
  return { vendor: vc.vendor, comments: out };
}

function hasOggPicture(vc) {
  return vc.comments.some((c) => K(c) === 'METADATA_BLOCK_PICTURE' || K(c) === 'COVERART');
}

module.exports = { parseComments, serializeComments, fieldsFromComments, applyPatch, hasOggPicture };
