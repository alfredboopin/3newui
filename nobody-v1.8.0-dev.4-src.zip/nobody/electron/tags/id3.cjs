'use strict';
/* NOBODY — tag editor · ID3v2 (MP3, and the ID3 prefix some FLACs carry).
 * Reads v2.2 / v2.3 / v2.4, writes v2.3 (new tags, v2.2 upgrades) or keeps v2.4.
 * Frames we don't edit are kept byte-for-byte (flags included), except frames
 * marked "discard on tag alteration". In-place when the new frames fit in the
 * old tag + padding, otherwise the tag is rebuilt with 2 KB padding. */

const {
  TagError, readExact, isLatin1, decodeUtf16, cleanValue, ID3_GENRES,
  normalizeGenreList, splitGenreInput, parseNumPair, emptyFields,
} = require('./common.cjs');

const PAD_NEW = 2048;

function syncsafe(b, o) {
  return ((b[o] & 0x7f) << 21) | ((b[o + 1] & 0x7f) << 14) | ((b[o + 2] & 0x7f) << 7) | (b[o + 3] & 0x7f);
}
function isSyncsafe(b, o) {
  return !(b[o] & 0x80 || b[o + 1] & 0x80 || b[o + 2] & 0x80 || b[o + 3] & 0x80);
}
function toSyncsafe(n) {
  if (n > 0x0fffffff) throw new TagError('E_TOO_LARGE', 'ID3 tag over 256 MB');
  return Buffer.from([(n >>> 21) & 0x7f, (n >>> 14) & 0x7f, (n >>> 7) & 0x7f, n & 0x7f]);
}
function deUnsync(b) {
  const out = Buffer.alloc(b.length);
  let j = 0;
  for (let i = 0; i < b.length; i++) {
    out[j++] = b[i];
    if (b[i] === 0xff && b[i + 1] === 0x00) i++;
  }
  return out.subarray(0, j);
}

async function readId3Header(src, pos = 0) {
  if (src.size < pos + 10) return null;
  const h = await src.read(pos, 10);
  if (h.length < 10 || h.toString('latin1', 0, 3) !== 'ID3') return null;
  const major = h[3];
  if (major < 2 || major > 4 || h[4] === 0xff || !isSyncsafe(h, 6)) return null;
  const flags = h[5];
  const size = syncsafe(h, 6);
  const footer = major === 4 && flags & 0x10 ? 10 : 0;
  return { pos, major, flags, size, total: 10 + size + footer };
}

const ID_RE = { 2: /^[A-Z0-9]{3}$/, 3: /^[A-Z0-9]{4}$/, 4: /^[A-Z0-9]{4}$/ };

function frameEndsCleanly(body, at, major) {
  if (at === body.length) return true;
  if (at > body.length) return false;
  if (body[at] === 0) return true; // padding
  const idLen = major === 2 ? 3 : 4;
  if (at + idLen > body.length) return false;
  return ID_RE[major].test(body.toString('latin1', at, at + idLen));
}

async function loadId3(src, hdr) {
  if (hdr.major === 2 && hdr.flags & 0x40) throw new TagError('E_UNSUPPORTED', 'compressed ID3v2.2');
  const raw = await readExact(src, hdr.pos + 10, Math.min(hdr.size, src.size - hdr.pos - 10));
  let body = raw;
  if (hdr.major < 4 && hdr.flags & 0x80) body = deUnsync(body);
  let off = 0;
  if (hdr.major >= 3 && hdr.flags & 0x40 && body.length >= 4) {
    off = hdr.major === 3 ? 4 + body.readUInt32BE(0) : syncsafe(body, 0);
  }
  const frames = [];
  const hl = hdr.major === 2 ? 6 : 10;
  while (off + hl <= body.length) {
    if (body[off] === 0) break; // padding
    const idLen = hdr.major === 2 ? 3 : 4;
    const id = body.toString('latin1', off, off + idLen);
    if (!ID_RE[hdr.major].test(id)) break;
    let size;
    if (hdr.major === 2) size = (body[off + 3] << 16) | (body[off + 4] << 8) | body[off + 5];
    else if (hdr.major === 3) size = body.readUInt32BE(off + 4);
    else {
      // v2.4 sizes are syncsafe; iTunes-era writers used plain 32-bit. Pick the one that lands on a frame.
      const s1 = isSyncsafe(body, off + 4) ? syncsafe(body, off + 4) : -1;
      const s2 = body.readUInt32BE(off + 4);
      if (s1 >= 0 && frameEndsCleanly(body, off + 10 + s1, 4)) size = s1;
      else if (frameEndsCleanly(body, off + 10 + s2, 4)) size = s2;
      else size = s1 >= 0 ? s1 : s2;
    }
    if (off + hl + size > body.length) break; // truncated frame: stop, keep what we have
    const flags = hdr.major === 2 ? null : Buffer.from(body.subarray(off + 8, off + 10));
    frames.push({ id, flags, body: Buffer.from(body.subarray(off + hl, off + hl + size)) });
    off += hl + size;
  }
  return { ...hdr, frames };
}

/** Frame payload with v2.3/v2.4 frame-level encodings undone (null = can't read). */
function frameContent(fr, tag) {
  let b = fr.body;
  if (tag.major === 4 && fr.flags) {
    const f = fr.flags[1];
    if (f & 0x0c) return null; // compressed / encrypted
    if (f & 0x40) b = b.subarray(1); // grouping id
    if (f & 0x01) b = b.subarray(4); // data length indicator
    if (f & 0x02 || tag.flags & 0x80) b = deUnsync(b);
  } else if (tag.major === 3 && fr.flags) {
    const f = fr.flags[1];
    if (f & 0xc0) return null;
    if (f & 0x20) b = b.subarray(1);
  }
  return b;
}

function decodeStrings(enc, b) {
  const out = [];
  if (enc === 1 || enc === 2) {
    let start = 0;
    for (let i = 0; i + 1 < b.length; i += 2) {
      if (b[i] === 0 && b[i + 1] === 0) { out.push(decodeUtf16(b.subarray(start, i), enc === 2)); start = i + 2; }
    }
    if (start < b.length) out.push(decodeUtf16(b.subarray(start), enc === 2));
  } else {
    const codec = enc === 3 ? 'utf8' : 'latin1';
    let start = 0;
    for (let i = 0; i < b.length; i++) if (b[i] === 0) { out.push(b.toString(codec, start, i)); start = i + 1; }
    if (start < b.length) out.push(b.toString(codec, start));
  }
  return out;
}

function textOf(fr, tag) {
  const b = frameContent(fr, tag);
  if (!b || b.length < 1) return '';
  return decodeStrings(b[0], b.subarray(1)).map(cleanValue).filter(Boolean).join('\0');
}

/** COMM / COM → { desc, text } */
function commentOf(fr, tag) {
  const b = frameContent(fr, tag);
  if (!b || b.length < 5) return null;
  const enc = b[0];
  const rest = b.subarray(4);
  let cut = -1, skip = 1;
  if (enc === 1 || enc === 2) {
    for (let i = 0; i + 1 < rest.length; i += 2) if (rest[i] === 0 && rest[i + 1] === 0) { cut = i; skip = 2; break; }
  } else cut = rest.indexOf(0);
  if (cut < 0) return { desc: '', text: cleanValue(decodeStrings(enc, rest).join('\n')) };
  const desc = cleanValue(decodeStrings(enc, rest.subarray(0, cut))[0] || '');
  const text = decodeStrings(enc, rest.subarray(cut + skip)).join('\n').replace(/\0+$/, '').trim();
  return { desc, text };
}

const V22 = { TT2: 'TIT2', TP1: 'TPE1', TAL: 'TALB', TP2: 'TPE2', TYE: 'TYER', TCO: 'TCON', TRK: 'TRCK', TPA: 'TPOS', TCM: 'TCOM', COM: 'COMM', PIC: 'APIC' };
const canon = (id, major) => (major === 2 ? V22[id] || `~${id}` : id);

function fieldsFromId3(tag) {
  const f = emptyFields();
  let hasCover = false;
  let yearV3 = '', yearV4 = '';
  let comment = null;
  for (const fr of tag.frames) {
    const id = canon(fr.id, tag.major);
    switch (id) {
      case 'TIT2': f.title ||= textOf(fr, tag).replace(/\0/g, ' / '); break;
      case 'TPE1': f.artist ||= textOf(fr, tag).replace(/\0/g, '; '); break;
      case 'TALB': f.album ||= textOf(fr, tag).replace(/\0/g, ' '); break;
      case 'TPE2': f.albumArtist ||= textOf(fr, tag).replace(/\0/g, '; '); break;
      case 'TCON': f.genre ||= normalizeGenreList(textOf(fr, tag)).join('; '); break;
      case 'TRCK': f.track ||= textOf(fr, tag).split('\0')[0]; break;
      case 'TPOS': f.disc ||= textOf(fr, tag).split('\0')[0]; break;
      case 'TCOM': f.composer ||= textOf(fr, tag).replace(/\0/g, '; '); break;
      case 'TDRC': yearV4 ||= textOf(fr, tag).split('\0')[0]; break;
      case 'TYER': yearV3 ||= textOf(fr, tag).split('\0')[0]; break;
      case 'COMM': {
        const c = commentOf(fr, tag);
        if (c && c.text && (c.desc === '' ? comment === null || comment.desc !== '' : comment === null && !/^itun/i.test(c.desc))) comment = c;
        break;
      }
      case 'APIC': hasCover = true; break;
      default: break;
    }
  }
  f.year = (yearV4 || yearV3).trim();
  if (f.year && !/^\d{4}(-\d{2}(-\d{2})?)?/.test(f.year)) f.year = (/\d{4}/.exec(f.year) || [''])[0];
  else f.year = f.year.slice(0, 10);
  f.comment = comment ? comment.text : '';
  return { fields: f, hasCover };
}

/* ── ID3v1 ───────────────────────────────────────────────────────────── */

async function readId3v1(src) {
  if (src.size < 128) return null;
  const b = await src.read(src.size - 128, 128);
  if (b.toString('latin1', 0, 3) !== 'TAG') return null;
  return b;
}

function fieldsFromV1(b) {
  const s = (a, z) => cleanValue(b.toString('latin1', a, z).replace(/\0.*$/s, ''));
  const f = emptyFields();
  f.title = s(3, 33); f.artist = s(33, 63); f.album = s(63, 93); f.year = s(93, 97).replace(/\D/g, '');
  if (b[125] === 0 && b[126] !== 0) { f.comment = s(97, 125); f.track = String(b[126]); }
  else f.comment = s(97, 127);
  if (ID3_GENRES[b[127]]) f.genre = ID3_GENRES[b[127]];
  return f;
}

function patchV1(b, fields) {
  const out = Buffer.from(b);
  const put = (a, len, v) => {
    out.fill(0, a, a + len);
    const s = isLatin1(v) ? v : '';
    Buffer.from(s, 'latin1').copy(out, a, 0, len);
  };
  if ('title' in fields) put(3, 30, fields.title);
  if ('artist' in fields) put(33, 30, fields.artist);
  if ('album' in fields) put(63, 30, fields.album);
  if ('year' in fields) put(93, 4, fields.year.slice(0, 4));
  const v11 = out[125] === 0 && out[126] !== 0;
  if ('comment' in fields) put(97, v11 || 'track' in fields ? 28 : 30, fields.comment);
  if ('track' in fields) {
    const p = parseNumPair(fields.track);
    out[125] = 0;
    out[126] = p && p.n > 0 && p.n < 256 ? p.n : 0;
  }
  if ('genre' in fields) {
    const first = (splitGenreInput(fields.genre)[0] || '').toLowerCase();
    const idx = ID3_GENRES.findIndex((g) => g.toLowerCase() === first);
    out[127] = idx >= 0 ? idx : 255;
  }
  return out;
}

/* ── writing ─────────────────────────────────────────────────────────── */

function encText(major, s) {
  if (major === 4) return Buffer.concat([Buffer.from([3]), Buffer.from(s, 'utf8')]);
  if (isLatin1(s)) return Buffer.concat([Buffer.from([0]), Buffer.from(s, 'latin1')]);
  return Buffer.concat([Buffer.from([1, 0xff, 0xfe]), Buffer.from(s, 'utf16le')]);
}

function encComment(major, s) {
  if (major === 4) return Buffer.concat([Buffer.from([3]), Buffer.from('eng', 'latin1'), Buffer.from([0]), Buffer.from(s, 'utf8')]);
  if (isLatin1(s)) return Buffer.concat([Buffer.from([0]), Buffer.from('eng', 'latin1'), Buffer.from([0]), Buffer.from(s, 'latin1')]);
  return Buffer.concat([Buffer.from([1]), Buffer.from('eng', 'latin1'), Buffer.from([0xff, 0xfe, 0, 0, 0xff, 0xfe]), Buffer.from(s, 'utf16le')]);
}

function encPicture(cover) {
  return Buffer.concat([Buffer.from([0]), Buffer.from(cover.mime, 'latin1'), Buffer.from([0, 3, 0]), cover.data]);
}

function frameBytes(major, id, flags, body) {
  const h = Buffer.alloc(10);
  h.write(id, 0, 'latin1');
  if (major === 4) toSyncsafe(body.length).copy(h, 4);
  else h.writeUInt32BE(body.length, 4);
  if (flags) flags.copy(h, 8);
  return Buffer.concat([h, body]);
}

/** v2.2 → v2.3: keep only what maps; PIC's 3-char image format becomes a MIME type. */
function upgradeV22(tag) {
  const out = [];
  for (const fr of tag.frames) {
    const id = V22[fr.id];
    if (!id) continue;
    if (id === 'APIC') {
      if (fr.body.length < 6) continue;
      const fmt = fr.body.toString('latin1', 1, 4).toUpperCase();
      const mime = fmt === 'PNG' ? 'image/png' : 'image/jpeg';
      out.push({ id, flags: Buffer.alloc(2), body: Buffer.concat([fr.body.subarray(0, 1), Buffer.from(mime + '\0', 'latin1'), fr.body.subarray(4)]) });
    } else out.push({ id, flags: Buffer.alloc(2), body: fr.body });
  }
  return out;
}

const DROP_FOR = {
  title: ['TIT2'], artist: ['TPE1'], album: ['TALB'], albumArtist: ['TPE2'], genre: ['TCON'],
  track: ['TRCK'], disc: ['TPOS'], composer: ['TCOM'],
  year: ['TYER', 'TDAT', 'TIME', 'TRDA', 'TDRC', 'TORY'],
};

function buildFrames(tag, patch) {
  const major = tag && tag.major === 4 ? 4 : 3;
  let kept = [];
  if (tag) {
    if (tag.major === 2) kept = upgradeV22(tag);
    else {
      for (const fr of tag.frames) {
        // "discard frame if the tag is altered" (v2.3: 0x80 of byte 0, v2.4: 0x40)
        if (fr.flags && fr.flags[0] & (tag.major === 3 ? 0x80 : 0x40)) continue;
        let { flags, body } = fr;
        if (tag.major === 4 && tag.flags & 0x80 && !(flags[1] & 0x02)) {
          // tag-level unsync implied it for every frame; we drop the tag flag
          body = deUnsync(body);
        }
        kept.push({ id: fr.id, flags, body });
      }
    }
  }
  const tagForRead = { major, flags: 0 };
  const drop = new Set();
  for (const k of Object.keys(patch.fields)) for (const id of DROP_FOR[k] || []) drop.add(id);
  kept = kept.filter((fr) => {
    if (drop.has(fr.id)) return false;
    if ('comment' in patch.fields && fr.id === 'COMM') {
      const c = commentOf(fr, tag && tag.major !== 2 ? tag : tagForRead);
      if (!c || c.desc === '') return false;
    }
    if (patch.cover.action !== 'keep' && fr.id === 'APIC') return false;
    return true;
  });

  const fresh = [];
  const F = patch.fields;
  const add = (id, s) => { if (s) fresh.push({ id, flags: Buffer.alloc(2), body: encText(major, s) }); };
  if ('title' in F) add('TIT2', F.title);
  if ('artist' in F) add('TPE1', F.artist);
  if ('album' in F) add('TALB', F.album);
  if ('albumArtist' in F) add('TPE2', F.albumArtist);
  if ('year' in F) add(major === 4 ? 'TDRC' : 'TYER', major === 4 ? F.year : F.year.slice(0, 4));
  if ('genre' in F) add('TCON', splitGenreInput(F.genre).join(major === 4 ? '\0' : '; '));
  if ('track' in F) add('TRCK', F.track);
  if ('disc' in F) add('TPOS', F.disc);
  if ('composer' in F) add('TCOM', F.composer);
  if ('comment' in F && F.comment) fresh.push({ id: 'COMM', flags: Buffer.alloc(2), body: encComment(major, F.comment) });

  const pics = kept.filter((fr) => fr.id === 'APIC');
  const rest = kept.filter((fr) => fr.id !== 'APIC');
  if (patch.cover.action === 'set') pics.push({ id: 'APIC', flags: Buffer.alloc(2), body: encPicture(patch.cover) });
  const all = [...fresh, ...rest, ...pics];
  return { major, bytes: Buffer.concat(all.map((fr) => frameBytes(major, fr.id, fr.flags, fr.body))) };
}

function tagHeader(major, size) {
  const h = Buffer.alloc(10);
  h.write('ID3', 0, 'latin1');
  h[3] = major; h[4] = 0; h[5] = 0;
  toSyncsafe(size).copy(h, 6);
  return h;
}

async function readMp3(src) {
  const hdr = await readId3Header(src, 0);
  const tag = hdr ? await loadId3(src, hdr) : null;
  const v1 = await readId3v1(src);
  if (tag && tag.frames.length) {
    const r = fieldsFromId3(tag);
    return { ...r, tagType: `ID3v2.${tag.major}` };
  }
  if (v1) return { fields: fieldsFromV1(v1), hasCover: false, tagType: 'ID3v1' };
  return { fields: emptyFields(), hasCover: false, tagType: 'none' };
}

async function planMp3(src, patch) {
  const hdr = await readId3Header(src, 0);
  const tag = hdr ? await loadId3(src, hdr) : null;
  const v1 = await readId3v1(src);
  const { major, bytes } = buildFrames(tag, patch);
  const newV1 = v1 ? patchV1(v1, patch.fields) : null;
  const oldTotal = hdr ? Math.min(hdr.total, src.size) : 0;
  const audioEnd = v1 ? src.size - 128 : src.size;
  if (hdr && 10 + bytes.length <= oldTotal) {
    const size = oldTotal - 10;
    const buf = Buffer.concat([tagHeader(major, size), bytes, Buffer.alloc(size - bytes.length)]);
    const writes = [{ offset: 0, buf }];
    if (newV1) writes.push({ offset: src.size - 128, buf: newV1 });
    return { mode: 'inplace', writes, yearOnly: major === 3 };
  }
  const tagBuf = Buffer.concat([tagHeader(major, bytes.length + PAD_NEW), bytes, Buffer.alloc(PAD_NEW)]);
  const pieces = [tagBuf, { from: oldTotal, to: audioEnd }];
  if (newV1) pieces.push(newV1);
  return { mode: 'rewrite', pieces, yearOnly: major === 3 };
}

module.exports = { readId3Header, loadId3, readMp3, planMp3 };
