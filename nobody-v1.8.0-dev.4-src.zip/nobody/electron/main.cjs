/* ─────────────────────────────────────────────────────────────────────────
 * NOBODY — Electron main process (Tauri 2 → Electron migration)
 *
 * Mirrors every capability the Tauri build exposed through
 * src-tauri/capabilities/default.json, scoped the same way:
 *
 *   1. Frameless, transparent window (rounded corners + CSS-drawn shadow —
 *      the native OS shadow is NOT relied on, see Issue 3 of the brief).
 *   2. Window controls: minimize / toggle-maximize / close / fullscreen.
 *   3. Compact mini-player: resize + reposition + always-on-top + restore
 *      (parity with desktopWindow.ts's Tauri compact functions).
 *   4. Native folder/file dialogs (plugin-dialog parity).
 *   5. Bounded file I/O: stat / readSlice (metadata head + tail reads — the
 *      PHASE-3 memory fix depends on these staying bounded) / readFile /
 *      writeTextFile / writeBinaryFile / recursive folder walk (plugin-fs).
 *   6. app:// custom protocol — STREAMS local audio/covers off disk
 *      (convertFileSrc parity). Range requests are honored so <audio>
 *      seeking never buffers a whole FLAC into memory (Issue 4).
 *   7. Allow-listed HTTP proxy (plugin-http parity, Issue 1): only the
 *      domains the Tauri capability file scoped — LRCLIB, iTunes Search +
 *      its artwork CDN, Deezer API + its image CDN.
 *
 * Security baseline (§3 of the brief):
 *   contextIsolation: true · nodeIntegration: false · sandbox: true
 *   one narrow contextBridge surface in preload.cjs · permission requests
 *   denied · window.open denied (openExternal allow-listed instead).
 * ───────────────────────────────────────────────────────────────────────── */

const {
  app,
  BrowserWindow,
  Menu,
  ipcMain,
  protocol,
  net,
  screen,
  shell,
  nativeImage,
  globalShortcut,
  Tray,
} = require('electron');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

/* ── Uninstaller boot (--nobody-uninstall) — MEMENTO lineage ─────────────
 * The installed app's own exe IS the uninstaller; Add/Remove Programs
 * registers: "…\NOBODY.exe" --nobody-uninstall. The check runs BEFORE
 * requestSingleInstanceLock so the headless uninstaller never fights a
 * running player for the lock, and the CommonJS module wrapper's
 * top-level return skips the whole player lifecycle below. */
const { isUninstallInvocation } = require('./uninstall.cjs');
const desktop = require('./desktop.cjs');
if (isUninstallInvocation(process.argv)) {
  require('./uninstall.cjs').startUninstallMode();
  return;
}

/* ── Constants shared with the renderer implementation (desktopWindow.ts) ── */
const DEFAULT_W = 1360;
const DEFAULT_H = 860;
const MIN_W = 720;
const MIN_H = 520;
const COMPACT_W = 440;
const COMPACT_H = 260;
const COMPACT_MARGIN = 30;

/* HTTP proxy limits (keeps the IPC surface from becoming a memory hole) */
const HTTP_TIMEOUT_MS = 20000;
const HTTP_MAX_BYTES = 30 * 1024 * 1024; // cover art is ~1MB; be generous but bounded
const READ_SLICE_MAX = 8 * 1024 * 1024; // metadata head is 3MB, tails ≤ 1MB
const READ_FILE_MAX = 32 * 1024 * 1024; // lrc/txt/jpg sidecars are small
const WALK_MAX_ENTRIES = 100000;
const WALK_MAX_DEPTH = 16;
/* Task 30 — dialog:save-copy bound (a full album FLAC is ~60MB; an
 * hour-long mix can reach ~600MB — reject anything past 1GB). */
const COPY_MAX_BYTES = 1024 * 1024 * 1024;

/* §3 — the ONLY remote hosts the app may reach through the proxy.
 * Mirrors src-tauri/capabilities/default.json's http:scope exactly. */
const HTTP_ALLOWED_HOSTS = new Set([
  'lrclib.net', 'itunes.apple.com', 'api.deezer.com',
  /* 1.7.0 scrobbling: Last.fm API 2.0 + ListenBrainz API 1 (https only, below) */
  'ws.audioscrobbler.com', 'api.listenbrainz.org',
]);
/* hosts that must never be reached over plain http (they carry credentials) */
const HTTPS_ONLY_HOSTS = new Set(['ws.audioscrobbler.com', 'api.listenbrainz.org']);
const HTTP_ALLOWED_SUFFIXES = ['.mzstatic.com', '.dzcdn.net'];

function isAllowedRemoteUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return false;
    const host = url.hostname.toLowerCase();
    if (HTTPS_ONLY_HOSTS.has(host)) return url.protocol === 'https:';
    if (HTTP_ALLOWED_HOSTS.has(host)) return true;
    return HTTP_ALLOWED_SUFFIXES.some((suffix) => host.endsWith(suffix) && host.length > suffix.length);
  } catch {
    return false;
  }
}

/* V1.5.3 (P1 security): external links are limited to the product's own
 * support/contact destinations + the metadata providers' sites. */
const EXTERNAL_ALLOWED = ['t.me', 'telegram.me', 'github.com', 'reymit.ir', 'instagram.com', 'lrclib.net', 'musicbrainz.org',
  /* 1.7.0 scrobbling: Last.fm authorisation page + API account, ListenBrainz token page */
  'last.fm', 'listenbrainz.org'];
function isAllowedExternalUrl(rawUrl) {
  try {
    const url = new URL(rawUrl);
    if (url.protocol !== 'https:') return false;
    const host = url.hostname.toLowerCase();
    return EXTERNAL_ALLOWED.some((d) => host === d || host.endsWith('.' + d));
  } catch {
    return false;
  }
}

/* ── Single instance (a second launch focuses the existing window) ──────── */
const gotLock = app.requestSingleInstanceLock();
/* 1.8.0-dev.4: `NOBODY.exe --nobody-quit` is how Setup / the uninstaller ask
 * a running player to close before they touch its files. Nothing running →
 * this launch just leaves (it must never open a player window). */
const QUIT_FLAG = '--nobody-quit';
if (gotLock && process.argv.slice(1).includes(QUIT_FLAG)) {
  app.exit(0);
  return;
}
/** same install dir (case-insensitive on Windows): only our own Setup/uninstaller may quit us */
function sameInstall(exeA, exeB) {
  try {
    const P = process.platform === 'win32' ? path.win32 : path;
    const a = P.dirname(P.resolve(String(exeA))); const b = P.dirname(P.resolve(String(exeB)));
    return process.platform === 'win32' ? a.toLowerCase() === b.toLowerCase() : a === b;
  } catch { return false; }
}
if (!gotLock) {
  app.quit();
} else {
  /* 1.8.0 (P5): a second launch forwards its files ("Open with", double
   * click, drag onto the exe) and jump-list commands to this instance. A
   * command alone never steals the focus. */
  app.on('second-instance', (_event, argv, workingDirectory) => {
    if (Array.isArray(argv) && argv.slice(1).includes(QUIT_FLAG)) {
      // quit at once (no veil, no tray): files are about to be replaced
      if (sameInstall(argv[0], process.execPath)) quitForInstaller();
      return;
    }
    const parsed = desktop.parseOpenArgs(argv, workingDirectory);
    if (parsed.cmd && !parsed.files.length && !parsed.playlists.length) {
      sendPlayerCommand(parsed.cmd);
      return;
    }
    if (parsed.files.length || parsed.playlists.length) queueOpen(parsed);
    showMainWindow();
  });
}

/* ── 1.8.0 (P5): desktop integration state ──────────────────────────────── */
/* files from the command line / a second launch / macOS open-file wait here
 * until the renderer has a library to put them in (desk:ready) */
let rendererReady = false;
let pendingOpen = { files: [], playlists: [] };
/* only playlists that really came in through "open with" may be read */
const openedPlaylists = new Set();
let isQuitting = false;
let desktopShell = null;
/* 1.8.0-dev.2: user-defined global hotkeys (desktop.cjs createHotkeys) */
let hotkeys = null;
let hotkeySuspendTimer = null;
let desktopPrefs = { ...desktop.DEFAULT_PREFS };
const prefsFile = () => path.join(app.getPath('userData'), 'desktop.json');
const windowStateFile = () => path.join(app.getPath('userData'), 'window-state.json');
const playlistKey = (p) => (process.platform === 'win32' ? path.normalize(p).toLowerCase() : path.normalize(p));
{
  const first = desktop.parseOpenArgs(process.argv, process.cwd());
  pendingOpen = { files: first.files, playlists: first.playlists };
  for (const p of first.playlists) openedPlaylists.add(playlistKey(p));
}
function queueOpen(parsed) {
  for (const p of parsed.playlists) openedPlaylists.add(playlistKey(p));
  if (rendererReady && mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('desk:open', { files: parsed.files, playlists: parsed.playlists });
  } else {
    pendingOpen = { files: [...pendingOpen.files, ...parsed.files].slice(0, 500), playlists: [...pendingOpen.playlists, ...parsed.playlists].slice(0, 50) };
  }
}
// macOS: Finder "Open with" / dock drops (may fire before ready)
app.on('open-file', (event, filePath) => {
  event.preventDefault();
  const parsed = desktop.parseOpenArgs(['', filePath], '/');
  if (parsed.files.length || parsed.playlists.length) queueOpen(parsed);
  if (app.isReady()) showMainWindow();
});
function sendPlayerCommand(cmd) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('media:key', cmd);
}
function showMainWindow() {
  let win = mainWindow;
  if (!win || win.isDestroyed()) {
    if (!app.isReady()) return;
    win = createWindow();
  }
  if (win.isMinimized()) win.restore();
  if (!win.isVisible()) win.show();
  win.focus();
  desktopShell?.refresh();
}
function toggleMainWindow() {
  const win = mainWindow;
  if (win && !win.isDestroyed() && win.isVisible() && !win.isMinimized() && win.isFocused()) {
    win.hide();
    desktopShell?.refresh();
  } else {
    showMainWindow();
  }
}
/** Quit from the tray: the close veil plays if the window is on screen */
function quitApp() {
  isQuitting = true;
  const win = mainWindow;
  if (!win || win.isDestroyed()) { app.quit(); return; }
  if (win.isVisible() && !win.isMinimized()) {
    try { win.webContents.send('app:close-requested'); } catch { closeConfirmed = true; win.close(); return; }
    if (closeFailsafe) clearTimeout(closeFailsafe);
    closeFailsafe = setTimeout(() => { if (!win.isDestroyed()) { closeConfirmed = true; win.close(); } }, 3500);
  } else {
    closeConfirmed = true;
    win.close();
  }
}
/** 1.8.0-dev.4: Setup / uninstaller asked us to leave (--nobody-quit) */
function quitForInstaller() {
  isQuitting = true;
  closeConfirmed = true;
  const win = mainWindow;
  if (win && !win.isDestroyed()) win.close();
  app.quit();
}
/** ✕ / Alt+F4 / taskbar close with "keep playing in the tray" on */
function hideToTray(win) {
  if (isQuitting || !desktopPrefs.closeToTray || !desktopShell?.hasTray) return false;
  win.hide();
  desktopShell.refresh();
  if (!desktopPrefs.trayNoteShown) {
    desktopShell.balloon();
    desktopPrefs = { ...desktopPrefs, trayNoteShown: true };
    desktop.writePrefs(prefsFile(), desktopPrefs);
  }
  return true;
}
/* the packaged app ships dist/** + electron/** only: public/icon.png does
 * not exist there (vite copies it into dist) */
function resolveIcon() {
  for (const p of [path.join(__dirname, '../dist/icon.png'), path.join(__dirname, '../public/icon.png'), path.join(__dirname, '../build/icon.png')]) {
    try { if (fs.existsSync(p)) return p; } catch { /* next */ }
  }
  return path.join(__dirname, '../dist/icon.png');
}
/* window geometry worth remembering: never the compact mini-player or the
 * fullscreen size */
function rememberedBounds(win) {
  if (savedWindowState) return savedWindowState;
  if (win.isFullScreen()) return preFullscreenBounds;
  try { return win.getNormalBounds(); } catch { return null; }
}
let stateTimer = null;
function saveWindowStateNow(win) {
  if (stateTimer) { clearTimeout(stateTimer); stateTimer = null; }
  if (!win || win.isDestroyed() || win.isMinimized()) return;
  const b = rememberedBounds(win);
  if (!b || !(b.width > 0 && b.height > 0)) return;
  const maximized = savedWindowState ? false : win.isFullScreen() ? preFullscreenMaximized : win.isMaximized();
  desktop.writeWindowState(windowStateFile(), { ...b, maximized });
}
function saveWindowStateSoon(win) {
  if (stateTimer) clearTimeout(stateTimer);
  stateTimer = setTimeout(() => saveWindowStateNow(win), 600);
}


/* Desktop music players must be allowed to resume playback on boot without
 * a user gesture (the Tauri build had no autoplay restrictions either). */
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

/* ── Issue 4: privileged app:// scheme for STREAMING local files ──────────
 * standard:false keeps the URL opaque (no host lowercasing / path mangling
 * of Windows drive letters), stream:true lets <audio>/<video> range-read,
 * supportFetchAPI lets fetch()/decode work against it. Registered BEFORE
 * app ready, as Electron requires. */
protocol.registerSchemesAsPrivileged([
  {
    scheme: 'app',
    privileges: {
      standard: false,
      secure: true,
      stream: true,
      supportFetchAPI: true,
      // Lets fetch() from the file:// renderer origin read app:// responses
      // (media elements never needed CORS; fetch() does). The handler also
      // answers with Access-Control-Allow-Origin below.
      corsEnabled: true,
      bypassCSP: false,
    },
  },
]);

/* ── Content types for the protocol handler ─────────────────────────────── */
const MIME = new Map([
  ['mp3', 'audio/mpeg'], ['wav', 'audio/wav'], ['flac', 'audio/flac'],
  ['ogg', 'audio/ogg'], ['oga', 'audio/ogg'], ['opus', 'audio/ogg'],
  ['m4a', 'audio/mp4'], ['m4b', 'audio/mp4'], ['aac', 'audio/aac'],
  ['alac', 'audio/mp4'], ['aif', 'audio/aiff'], ['aiff', 'audio/aiff'],
  ['caf', 'audio/x-caf'], ['webm', 'audio/webm'], ['mp4', 'video/mp4'],
  ['wma', 'audio/x-ms-wma'], ['ape', 'audio/x-ape'], ['amr', 'audio/amr'],
  ['3gp', 'audio/3gpp'], ['dsf', 'audio/dsf'], ['mpc', 'audio/musepack'],
  ['jpg', 'image/jpeg'], ['jpeg', 'image/jpeg'], ['png', 'image/png'],
  ['webp', 'image/webp'], ['lrc', 'text/plain; charset=utf-8'],
  ['txt', 'text/plain; charset=utf-8'],
]);

/** Resolves the real absolute path from an app:// URL.
 *  The renderer builds URLs as `app://` + encodeURIComponent(absolutePath),
 *  which survives Chromium URL normalization for non-special schemes. */
function pathFromAppUrl(requestUrl) {
  if (!requestUrl.startsWith('app://')) return null;
  let raw = requestUrl.slice('app://'.length);
  const hash = raw.indexOf('#');
  if (hash >= 0) raw = raw.slice(0, hash);
  const query = raw.indexOf('?');
  if (query >= 0) raw = raw.slice(0, query);
  try {
    const decoded = decodeURIComponent(raw);
    // Reject relative paths / traversal games — only real absolute paths.
    const normalized = path.normalize(decoded);
    if (!path.isAbsolute(normalized)) return null;
    if (normalized.includes('\0')) return null;
    return normalized;
  } catch {
    return null;
  }
}

/** Parses a Range header ("bytes=start-end" | "bytes=start-" | "bytes=-N"). */
function parseRange(header, size) {
  if (!header) return null;
  const match = /^bytes=(\d*)-(\d*)$/.exec(header.trim());
  if (!match) return null;
  const [, startRaw, endRaw] = match;
  if (startRaw === '' && endRaw === '') return null;
  let start;
  let end;
  if (startRaw === '') {
    // suffix range: last N bytes
    const n = Number(endRaw);
    if (!Number.isFinite(n) || n <= 0) return null;
    start = Math.max(0, size - n);
    end = size - 1;
  } else {
    start = Number(startRaw);
    end = endRaw === '' ? size - 1 : Number(endRaw);
    if (!Number.isFinite(start) || !Number.isFinite(end)) return null;
    if (start >= size) return { start: 0, end: 0, invalid: true };
    end = Math.min(end, size - 1);
  }
  if (end < start) return null;
  return { start, end };
}

function registerAppProtocol() {
  protocol.handle('app', async (request) => {
    const filePath = pathFromAppUrl(request.url);
    if (!filePath) return new Response(null, { status: 400 });

    let stat;
    try {
      stat = await fsp.stat(filePath);
    } catch {
      return new Response(null, { status: 404 });
    }
    if (!stat.isFile()) return new Response(null, { status: 404 });

    const size = stat.size;
    const ext = path.extname(filePath).slice(1).toLowerCase();
    // V1.5.3 (P1 security): app:// serves media/sidecar types only
    if (!MIME.has(ext)) return new Response(null, { status: 403 });
    const contentType = MIME.get(ext);
    const baseHeaders = {
      'Content-Type': contentType,
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'no-store',
      // corsEnabled scheme: the file:// renderer origin may fetch() these
      // responses (probe helpers, cover decoding, etc.).
      'Access-Control-Allow-Origin': '*',
    };

    // HEAD — metadata probe without a body.
    if (request.method === 'HEAD') {
      return new Response(null, { status: 200, headers: { ...baseHeaders, 'Content-Length': String(size) } });
    }
    /* CORS preflight — the engine's media element now requests app:// sources
     * with crossOrigin="anonymous" (QA fix for the WebAudio "outputs zeroes"
     * silence taint). CORS-mode requests carrying a Range header can be
     * preflighted; answer before the GET-only gate or the load would fail. */
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
          'Access-Control-Allow-Headers': 'Range, Content-Type, If-Range',
          'Access-Control-Max-Age': '86400',
        },
      });
    }
    if (request.method !== 'GET') return new Response(null, { status: 405 });

    const range = parseRange(request.headers.get('range'), size);

    // 416 — the renderer asked for bytes past EOF (stale seek position).
    if (range && range.invalid) {
      return new Response(null, {
        status: 416,
        headers: { 'Content-Range': `bytes */${size}` },
      });
    }

    /* STREAMED READ — fs.createReadStream + Readable.toWeb keeps memory
     * flat no matter how large the FLAC is (Issue 4's whole point: the
     * file is never buffered into a JS Blob). */
    const start = range ? range.start : 0;
    const end = range ? range.end : size - 1;
    const headers = { ...baseHeaders, 'Content-Length': String(end - start + 1) };
    if (range) headers['Content-Range'] = `bytes ${start}-${end}/${size}`;

    const nodeStream = fs.createReadStream(filePath, { start, end });
    nodeStream.on('error', () => { /* the web stream surfaces the abort */ });
    const webStream = require('stream').Readable.toWeb(nodeStream);

    return new Response(webStream, { status: range ? 206 : 200, headers });
  });
}

/* ── Window creation ────────────────────────────────────────────────────── */
let mainWindow = null;

/* V1.4.0 (#6) — close-veil flow state. `closeConfirmed` flips true only
 * when the renderer has played its per-face close animation and asked for
 * the REAL close (win:close-confirmed) or the failsafe fired; until then
 * the `close` event below is intercepted and the veil is requested.
 * `closeFailsafe` guarantees the app can never get stuck un-closable if
 * the renderer crashes or is suspended mid-veil. */
let closeConfirmed = false;
let closeFailsafe = null;

/* V1.4.0 (#5) — manual window drag state. While the renderer runs a
 * pointer-capture drag over IPC, this holds the window bounds at drag
 * start so win:drag-by can reposition absolutely from accumulated deltas. */
let drag = null;

function createWindow() {
  // A (re)created window starts with a clean close-flow slate (macOS
  // activate-after-close recreates; a previous window's confirmation must
  // not leak into the new one).
  closeConfirmed = false;
  if (closeFailsafe) {
    clearTimeout(closeFailsafe);
    closeFailsafe = null;
  }

  /* 1.8.0 (P5): last size / position / maximized, fitted to the monitors
   * that exist now (an unplugged screen never swallows the window) */
  let fit;
  try {
    const primary = screen.getPrimaryDisplay();
    const displays = [primary, ...screen.getAllDisplays().filter((d) => d.id !== primary.id)];
    fit = desktop.fitWindowState(desktop.readWindowState(windowStateFile()), displays, { defW: DEFAULT_W, defH: DEFAULT_H, minW: MIN_W, minH: MIN_H });
  } catch {
    fit = { width: DEFAULT_W, height: DEFAULT_H, maximized: false, center: true };
  }
  const win = new BrowserWindow({
    width: fit.width,
    height: fit.height,
    ...(fit.center ? {} : { x: fit.x, y: fit.y }),
    minWidth: MIN_W,
    minHeight: MIN_H,
    title: 'NOBODY',
    center: fit.center,

    /* Issue 3 — transparent + frameless; the soft shadow and the rounded
     * corners are DRAWN BY THE APP's CSS (html.electron .app-shell /
     * .compact-shell box-shadow), never delegated to the OS. */
    transparent: true,
    frame: false,
    backgroundColor: '#00000000',
    icon: nativeImage.createFromPath(resolveIcon()),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  });

  mainWindow = win;
  rendererReady = false;
  win.once('ready-to-show', () => {
    if (fit.maximized) win.maximize();
    win.show();
  });
  // 1.8.0 (P5): geometry survives restarts; thumbar buttons need a shown window
  for (const ev of ['resize', 'move']) win.on(ev, () => saveWindowStateSoon(win));
  for (const ev of ['maximize', 'unmaximize']) win.on(ev, () => saveWindowStateNow(win));
  win.on('show', () => { desktopShell?.attachWindow(); desktopShell?.refresh(); });
  win.on('hide', () => desktopShell?.refresh());
  win.webContents.on('did-start-loading', () => {
    rendererReady = false;
    // a reload mid-recording must not leave the global hotkeys off
    if (hotkeySuspendTimer) { clearTimeout(hotkeySuspendTimer); hotkeySuspendTimer = null; }
    hotkeys?.suspend(false);
  });


  // Opening new windows is not part of the product; external links go
  // through the allow-listed shell:openExternal IPC instead.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (isAllowedExternalUrl(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  // never let the player window itself navigate away from the bundle
  win.webContents.on('will-navigate', (event, url) => {
    const dev = process.env.VITE_DEV_SERVER_URL;
    if (url.startsWith('file://') || (dev && url.startsWith(dev))) return;
    event.preventDefault();
  });

  win.webContents.on('did-finish-load', () => pushWindowState());

  for (const event of ['maximize', 'unmaximize', 'enter-full-screen', 'leave-full-screen']) {
    win.on(event, pushWindowState);
  }

  // A user escaping fullscreen via the OS (F11/Win+Down) must also flush the
  // saved pre-fullscreen bounds so a later toggle starts from a clean slate.
  win.on('leave-full-screen', () => {
    preFullscreenBounds = null;
    preFullscreenMaximized = false;
  });

  // BUG FIX (user report: stuck in fullscreen) — F11 now ALWAYS toggles the
  // window fullscreen, handled in the MAIN process so it works in every UI
  // (classic / cinema / EELA / ALOK) even when no renderer button or keyboard
  // handler is reachable. The same verified round-trip as the win:toggle-
  // fullscreen IPC is used, so exiting always restores the saved geometry.
  win.webContents.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown' || input.key !== 'F11' || input.control || input.meta) return;
    event.preventDefault();
    if (!mainWindow || mainWindow.isDestroyed()) return;
    if (!mainWindow.isFullScreen()) {
      try {
        preFullscreenBounds = mainWindow.getNormalBounds();
        preFullscreenMaximized = mainWindow.isMaximized();
      } catch {
        preFullscreenBounds = null;
        preFullscreenMaximized = false;
      }
      mainWindow.setFullScreen(true);
    } else {
      mainWindow.setFullScreen(false);
      restoreAfterFullscreen();
    }
    pushWindowState();
  });

  /* V1.4.0 (#6) — EVERY close path lands here: the ✕ buttons route through
   * win:close → app:close-requested, and Alt+F4 / taskbar close hit this
   * event directly. Until the renderer confirms, the close is held while
   * the per-face veil animation plays; a 3.5s failsafe force-closes if the
   * renderer never answers (crashed / suspended). */
  win.on('close', (e) => {
    saveWindowStateNow(win);
    if (closeConfirmed) return;
    e.preventDefault();
    if (hideToTray(win)) return;
    try {
      win.webContents.send('app:close-requested');
    } catch {
      closeConfirmed = true;
      win.close();
      return;
    }
    if (closeFailsafe) clearTimeout(closeFailsafe);
    closeFailsafe = setTimeout(() => {
      if (!win.isDestroyed()) {
        closeConfirmed = true;
        win.close();
      }
    }, 3500);
  });

  if (process.env.VITE_DEV_SERVER_URL) {
    win.loadURL(process.env.VITE_DEV_SERVER_URL);
  } else {
    win.loadFile(path.join(__dirname, '../dist/index.html'));
  }
  return win;
}

function pushWindowState() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  mainWindow.webContents.send('win:state', {
    maximized: mainWindow.isMaximized(),
    fullscreen: mainWindow.isFullScreen(),
  });
}

/* ── Window control IPC ─────────────────────────────────────────────────── */
/* BUG FIX (user report: clicking the fullscreen button again never returned
 * to the small window): on Windows, a frameless TRANSPARENT window can fail
 * to restore its pre-fullscreen geometry — the OS reports fullscreen=false
 * while the window stays screen-sized. We now snapshot getNormalBounds()
 * before entering fullscreen and, after the exit transition settles, verify
 * the state and force-restore the saved bounds (re-maximizing when the
 * window was maximized before). */
let preFullscreenBounds = null; // { x?, y?, width, height } in DIPs
let preFullscreenMaximized = false;

function registerWindowIpc() {
  ipcMain.on('win:minimize', () => mainWindow?.minimize());

  ipcMain.on('win:maximize', () => {
    if (!mainWindow) return;
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
  });

  /* V1.4.0 (#6) — 'win:close' now REQUESTS the close flow instead of
   * closing directly: the renderer plays its per-face veil, then confirms
   * through win:close-confirmed. The real close always funnels through the
   * createWindow 'close' guard (or its 3.5s failsafe). Renderer-side
   * idempotency in src/appClose.ts keeps the veil to exactly one play. */
  ipcMain.on('win:close', () => {
    if (mainWindow && !mainWindow.isDestroyed() && hideToTray(mainWindow)) return;
    mainWindow?.webContents.send('app:close-requested');
  });

  ipcMain.on('win:close-confirmed', () => {
    closeConfirmed = true;
    if (closeFailsafe) {
      clearTimeout(closeFailsafe);
      closeFailsafe = null;
    }
    mainWindow?.close();
  });

  /* V1.4.0 (#5) — manual window drag over IPC (replaces the OS drag
   * regions, which are resolved at the OS hit-test level where CSS cursors
   * are ignored). The renderer pointer-captures the gesture on its
   * [data-tauri-drag-region] surfaces and streams accumulated deltas; main
   * turns them into absolute setPosition() calls from the drag-start
   * bounds. Disabled while maximized/fullscreen — native snapping wins. */
  ipcMain.on('win:drag-start', () => {
    const win = mainWindow;
    if (!win || win.isDestroyed() || win.isMaximized() || win.isFullScreen()) {
      drag = null;
      return;
    }
    const b = win.getBounds();
    const c = screen.getCursorScreenPoint();
    drag = { x: b.x, y: b.y, cx: c.x, cy: c.y };
  });

  ipcMain.on('win:drag-by', (_event, ax, ay) => {
    if (!drag || !mainWindow || mainWindow.isDestroyed()) return;
    const dx = Number(ax);
    const dy = Number(ay);
    const nx = Math.round(drag.x + (Number.isFinite(dx) ? dx : 0));
    const ny = Math.round(drag.y + (Number.isFinite(dy) ? dy : 0));
    if (!Number.isFinite(nx) || !Number.isFinite(ny)) return;
    try {
      mainWindow.setPosition(nx, ny);
    } catch {
      drag = null; // the OS refused the move — abandon the drag
    }
  });

  ipcMain.on('win:drag-end', () => {
    drag = null;
  });

  // invoke (not send) so the renderer gets the REAL resulting fullscreen
  // state back, exactly like Tauri's setFullscreen(next) round-trip.
  ipcMain.handle('win:toggle-fullscreen', () => {
    if (!mainWindow) return false;
    if (!mainWindow.isFullScreen()) {
      try {
        preFullscreenBounds = mainWindow.getNormalBounds();
        preFullscreenMaximized = mainWindow.isMaximized();
      } catch {
        preFullscreenBounds = null;
        preFullscreenMaximized = false;
      }
      mainWindow.setFullScreen(true);
      return true;
    }
    mainWindow.setFullScreen(false);
    restoreAfterFullscreen();
    return false;
  });

  ipcMain.handle('win:get-state', () => ({
    maximized: !!mainWindow?.isMaximized(),
    fullscreen: !!mainWindow?.isFullScreen(),
  }));
}

/** Verifies the exit-fullscreen transition actually restored the geometry
 *  and force-restores it when the transparent-window quirk swallows it. */
function restoreAfterFullscreen() {
  const win = mainWindow;
  if (!win) return;
  const saved = preFullscreenBounds;
  const wasMax = preFullscreenMaximized;
  preFullscreenBounds = null;
  preFullscreenMaximized = false;
  setTimeout(() => {
    if (win.isDestroyed()) return;
    if (win.isFullScreen()) {
      try { win.setFullScreen(false); } catch { /* best effort */ }
    }
    if (saved) {
      try {
        const b = win.getBounds();
        const stillHuge = b.width >= saved.width * 1.6 && b.height >= saved.height * 1.6;
        if (stillHuge || win.isFullScreen()) win.setBounds(saved);
      } catch { /* best effort */ }
      if (wasMax) {
        try { win.maximize(); } catch { /* best effort */ }
      }
    }
    pushWindowState();
  }, 220);
}

/* ── Compact mini-player IPC (Issue 2 of desktopWindow parity) ──────────── */
let savedWindowState = null; // { x, y, width, height } in DIPs (logical px)

function registerCompactIpc() {
  ipcMain.handle('win:enter-compact', () => {
    if (!mainWindow) return false;
    try {
      // getNormalBounds() returns pre-maximize geometry and works while
      // maximized, so a compact round-trip from a maximized window restores.
      savedWindowState = mainWindow.getNormalBounds();
      if (mainWindow.isFullScreen()) mainWindow.setFullScreen(false);
      if (mainWindow.isMaximized()) mainWindow.unmaximize();
      mainWindow.setAlwaysOnTop(true);
      mainWindow.setResizable(false);

      const { workArea } = screen.getPrimaryDisplay();
      const x = workArea.x + workArea.width - COMPACT_W - COMPACT_MARGIN;
      const y = workArea.y + workArea.height - COMPACT_H - COMPACT_MARGIN;
      mainWindow.setBounds({
        x: Math.max(workArea.x, x),
        y: Math.max(workArea.y, y),
        width: COMPACT_W,
        height: COMPACT_H,
      });
      return true;
    } catch {
      // CSS mini-player still works even if the OS resize failed.
      return false;
    }
  });

  ipcMain.handle('win:exit-compact', () => {
    if (!mainWindow) return false;
    try {
      mainWindow.setAlwaysOnTop(false);
      mainWindow.setResizable(true);
      if (savedWindowState) {
        mainWindow.setBounds(savedWindowState);
      } else {
        mainWindow.setBounds({ width: DEFAULT_W, height: DEFAULT_H });
        mainWindow.center();
      }
      savedWindowState = null;
      return true;
    } catch {
      return false;
    }
  });
}

/* ── Dialog IPC (plugin-dialog parity) ──────────────────────────────────── */
const AUDIO_LYRIC_FILTER = {
  name: 'Audio & Lyrics',
  extensions: ['mp3', 'wav', 'flac', 'ogg', 'oga', 'opus', 'm4a', 'aac', 'alac', 'aif', 'aiff', 'caf', 'webm', 'mp4', 'wma', 'ape', 'amr', '3gp', 'dsf', 'mpc', 'lrc', 'txt'],
};

function registerDialogIpc() {
  ipcMain.handle('dialog:pick-folders', async () => {
    const { dialog } = require('electron');
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'Add music folders to Nobody',
      properties: ['openDirectory', 'multiSelections'],
    });
    if (result.canceled) return [];
    return result.filePaths;
  });

  ipcMain.handle('dialog:pick-files', async () => {
    const { dialog } = require('electron');
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'Add music to Nobody',
      properties: ['openFile', 'multiSelections'],
      filters: [AUDIO_LYRIC_FILTER],
    });
    if (result.canceled) return [];
    return result.filePaths;
  });

  /* Task 30 — "Save audio file" (Download Center / new-UI exports):
   * native Save-As dialog defaulting to the user's Downloads folder, then a
   * plain, progress-free fs.copyFile in the MAIN process (the renderer never
   * touches the bytes). Resolves with the saved absolute path, or null when
   * the user cancelled the dialog. */
  ipcMain.handle('dialog:save-copy', async (_event, srcPath, defaultName) => {
    const src = assertAbsolutePath(srcPath);
    const info = await fsp.stat(src);
    if (!info.isFile()) throw new Error('Not a file');
    if (Number(info.size) > COPY_MAX_BYTES) throw new Error('File too large to copy');

    const { dialog } = require('electron');
    const safe = sanitizeFilename(defaultName);
    const result = await dialog.showSaveDialog(mainWindow, {
      title: 'Save audio file',
      defaultPath: path.join(app.getPath('downloads'), safe),
    });
    if (result.canceled || !result.filePath) return null;

    const dest = assertAbsolutePath(result.filePath);
    await fsp.copyFile(src, dest);
    return dest;
  });
}

/* ── File-system IPC (plugin-fs parity, bounded) ────────────────────────── */
function assertAbsolutePath(p) {
  if (typeof p !== 'string' || !path.isAbsolute(p) || p.includes('\0')) {
    throw new Error('Invalid path');
  }
  return path.normalize(p);
}

/* V1.5.3 (P1 security): the renderer may only READ media/sidecar types
 * (audio, cover images, .lrc/.txt) and only WRITE lyric/cover sidecars.
 * Before, any absolute path was readable/writable through IPC — an XSS
 * could have read SSH keys or overwritten arbitrary user files. */
const READABLE_EXTS = new Set([...MIME.keys()]);
const WRITABLE_EXTS = new Set(['lrc', 'txt', 'jpg', 'jpeg', 'png', 'webp']);
const WRITE_MAX = 32 * 1024 * 1024;

function extOf(p) {
  return path.extname(p).slice(1).toLowerCase();
}

function assertReadablePath(p) {
  const abs = assertAbsolutePath(p);
  if (!READABLE_EXTS.has(extOf(abs))) throw new Error('Blocked file type');
  return abs;
}

function assertWritablePath(p) {
  const abs = assertAbsolutePath(p);
  if (!WRITABLE_EXTS.has(extOf(abs))) throw new Error('Blocked file type');
  return abs;
}

/** Task 30 — strips path separators / control characters from a dialog
 *  default filename (the renderer only ever supplies a display name). */
function sanitizeFilename(name) {
  const clean = String(name ?? 'nobody')
    .replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 160);
  return clean || 'nobody';
}

async function walkFolder(root, extSet) {
  const out = [];
  const stack = [{ dir: root, depth: 0 }];
  while (stack.length > 0 && out.length < WALK_MAX_ENTRIES) {
    const { dir, depth } = stack.pop();
    if (depth > WALK_MAX_DEPTH) continue;
    let entries;
    try {
      entries = await fsp.readdir(dir, { withFileTypes: true });
    } catch {
      continue; // unreadable folder → skip, like the Tauri walk did
    }
    for (const entry of entries) {
      if (out.length >= WALK_MAX_ENTRIES) break;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        stack.push({ dir: full, depth: depth + 1 });
      } else if (entry.isFile()) {
        const ext = path.extname(entry.name).toLowerCase();
        if (extSet.size === 0 || extSet.has(ext)) out.push(full);
      }
    }
  }
  return out;
}

function registerFsIpc() {
  ipcMain.handle('fs:stat', async (_event, target) => {
    const p = assertAbsolutePath(target);
    const info = await fsp.stat(p);
    return { size: Number(info.size), isFile: info.isFile(), mtimeMs: Number(info.mtimeMs) };
  });

  /** Bounded slice read — the metadata head (first N bytes) and the
   *  MP4/Ogg tail reads depend on this; NEVER expose an unbounded read. */
  ipcMain.handle('fs:read-slice', async (_event, target, start, length) => {
    const p = assertReadablePath(target);
    const from = Math.max(0, Number(start) || 0);
    const len = Math.min(READ_SLICE_MAX, Math.max(0, Number(length) || 0));
    if (len === 0) return new Uint8Array(0);
    const handle = await fsp.open(p, 'r');
    try {
      const buffer = new Uint8Array(len);
      const { bytesRead } = await handle.read(buffer, 0, len, from);
      return buffer.subarray(0, bytesRead);
    } finally {
      await handle.close().catch(() => undefined);
    }
  });

  ipcMain.handle('fs:read-file', async (_event, target) => {
    const p = assertReadablePath(target);
    const info = await fsp.stat(p);
    if (!info.isFile()) throw new Error('Not a file');
    if (Number(info.size) > READ_FILE_MAX) throw new Error('File too large');
    const buffer = await fsp.readFile(p);
    return new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
  });

  ipcMain.handle('fs:write-text-file', async (_event, target, content) => {
    const p = assertWritablePath(target);
    const text = String(content ?? '');
    if (text.length > WRITE_MAX) throw new Error('Payload too large');
    await fsp.writeFile(p, text, 'utf-8');
    return true;
  });

  // Uint8Array survives IPC structured clone — no base64 round-trip needed.
  ipcMain.handle('fs:write-binary-file', async (_event, target, bytes) => {
    const p = assertWritablePath(target);
    if (!(bytes instanceof Uint8Array)) throw new Error('Expected binary payload');
    if (bytes.byteLength > WRITE_MAX) throw new Error('Payload too large');
    await fsp.writeFile(p, Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength));
    return true;
  });

  ipcMain.handle('fs:walk', async (_event, root, extensions) => {
    const base = assertAbsolutePath(root);
    const extSet = new Set(
      (Array.isArray(extensions) ? extensions : [])
        .filter((e) => typeof e === 'string')
        .map((e) => (e.startsWith('.') ? e.toLowerCase() : `.${e.toLowerCase()}`)),
    );
    return walkFolder(base, extSet);
  });
}

/* ── 1.7.0-dev.9 (P4 · 6): M3U / M3U8 import + export ─────────────────────
 * Import: the main process opens the picker and hands back the BYTES (≤ 8 MB
 * each), so .m3u never has to join READABLE_EXTS. Export: the save dialog
 * remembers the chosen path; playlist:write accepts ONLY a path returned by
 * that dialog (once), and only .m3u / .m3u8. WRITABLE_EXTS stays as it is. */
const PLAYLIST_READ_MAX = 8 * 1024 * 1024;
const PLAYLIST_WRITE_MAX = 16 * 1024 * 1024;
const PLAYLIST_EXT_RE = /\.m3u8?$/i;
const exportGrants = new Map(); // normalised path → expiry (ms)

function registerPlaylistIpc() {
  ipcMain.handle('playlist:pick-import', async () => {
    const { dialog } = require('electron');
    const result = await dialog.showOpenDialog(mainWindow, {
      title: 'Import playlists',
      properties: ['openFile', 'multiSelections'],
      filters: [{ name: 'Playlists', extensions: ['m3u', 'm3u8'] }],
    });
    if (result.canceled) return [];
    const out = [];
    for (const raw of result.filePaths.slice(0, 50)) {
      try {
        const p = assertAbsolutePath(raw);
        if (!PLAYLIST_EXT_RE.test(p)) continue;
        const info = await fsp.stat(p);
        if (!info.isFile()) continue;
        if (Number(info.size) > PLAYLIST_READ_MAX) { out.push({ path: p, error: 'E_TOO_LARGE' }); continue; }
        const buf = await fsp.readFile(p);
        out.push({ path: p, bytes: new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength) });
      } catch {
        out.push({ path: String(raw), error: 'E_READ' });
      }
    }
    return out;
  });

  ipcMain.handle('playlist:pick-export', async (_event, defaultName) => {
    const { dialog } = require('electron');
    const safe = sanitizeFilename(defaultName).replace(/\.m3u8?$/i, '');
    const result = await dialog.showSaveDialog(mainWindow, {
      title: 'Export playlist',
      defaultPath: path.join(app.getPath('music'), `${safe}.m3u8`),
      filters: [
        { name: 'M3U8 playlist (UTF-8)', extensions: ['m3u8'] },
        { name: 'M3U playlist', extensions: ['m3u'] },
      ],
    });
    if (result.canceled || !result.filePath) return null;
    let dest = assertAbsolutePath(result.filePath);
    if (!PLAYLIST_EXT_RE.test(dest)) dest += '.m3u8';
    exportGrants.set(dest, Date.now() + 10 * 60 * 1000);
    return dest;
  });

  ipcMain.handle('playlist:write', async (_event, target, text) => {
    const dest = assertAbsolutePath(target);
    const until = exportGrants.get(dest);
    exportGrants.delete(dest);
    if (!until || until < Date.now()) throw new Error('Path not granted');
    if (!PLAYLIST_EXT_RE.test(dest)) throw new Error('Blocked file type');
    const body = String(text ?? '');
    if (body.length > PLAYLIST_WRITE_MAX) throw new Error('Payload too large');
    const bytes = Buffer.from(body, 'utf-8');
    const data = /\.m3u$/i.test(dest) ? Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), bytes]) : bytes;
    const tmp = `${dest}.nobody-tmp`;
    await fsp.writeFile(tmp, data);
    try {
      await fsp.rename(tmp, dest);
    } catch (e) {
      await fsp.copyFile(tmp, dest).finally(() => fsp.unlink(tmp).catch(() => undefined));
    }
    return true;
  });
}

/* ── V1.7.0 (P4): tag editor — read / write-back (electron/tags) ───────── */
function registerTagsIpc() {
  const tags = require('./tags/index.cjs');
  const wrap = (fn) => async (_event, ...args) => {
    try { return { ok: true, ...(await fn(...args)) }; } catch (e) { return { ok: false, code: tags.errorCode(e) }; }
  };
  ipcMain.handle('tags:read', wrap((p) => tags.readTags(p)));
  ipcMain.handle('tags:write', wrap((p, patch) => tags.writeTags(p, patch)));
}

/* ── Issue 1: allow-listed HTTP proxy (plugin-http parity) ──────────────── */
function registerHttpIpc() {
  ipcMain.handle('http:fetch', async (_event, rawUrl, options = {}) => {
    if (typeof rawUrl !== 'string' || !isAllowedRemoteUrl(rawUrl)) {
      throw new Error('Blocked by NOBODY allow-list: ' + String(rawUrl).slice(0, 120));
    }
    const init = {
      method: typeof options.method === 'string' ? options.method : 'GET',
      headers: options.headers && typeof options.headers === 'object' ? options.headers : undefined,
      signal: AbortSignal.timeout(HTTP_TIMEOUT_MS),
      // net.fetch runs in the main process — no browser CORS applies.
    };
    if (typeof options.body === 'string' && options.body.length > 0 && init.method !== 'GET' && init.method !== 'HEAD') {
      init.body = options.body;
    }

    // V1.5.3 (P1 security): follow redirects MANUALLY and re-check every hop
    // against the allow-list (an allowed host could 30x the main process to
    // any intranet/arbitrary host before).
    init.redirect = 'manual';
    let currentUrl = rawUrl;
    let response;
    for (let hop = 0; ; hop++) {
      response = await net.fetch(currentUrl, init);
      const loc = response.status >= 300 && response.status < 400 ? response.headers.get('location') : null;
      if (!loc) break;
      if (hop >= 5) throw new Error('Too many redirects');
      const nextUrl = new URL(loc, currentUrl).toString();
      if (!isAllowedRemoteUrl(nextUrl)) throw new Error('Redirect blocked by NOBODY allow-list');
      currentUrl = nextUrl;
    }

    const headers = {};
    for (const [key, value] of response.headers.entries()) headers[key.toLowerCase()] = value;
    const contentLength = Number(headers['content-length'] || 0);
    if (contentLength > HTTP_MAX_BYTES) throw new Error('Response too large');

    const buffer = await response.arrayBuffer();
    if (buffer.byteLength > HTTP_MAX_BYTES) throw new Error('Response too large');

    return {
      ok: response.ok,
      status: response.status,
      headers,
      bodyBase64: Buffer.from(buffer).toString('base64'),
    };
  });
}

/* ── V1.4.0 (#9): hardware media keys (globalShortcut) ────────────────────
 * Like every Windows player, the keyboard's Fn-media keys must control
 * playback even when the window is minimized or unfocused — globalShortcut
 * is the only Electron channel that fires in those states (input events
 * die without focus). Each press is forwarded to the renderer on
 * 'media:key' (src/mediaKeys.ts re-broadcasts it to the active face).
 * Registration is best-effort: another application may already own a key,
 * in which case that one shortcut is skipped silently. */
const MEDIA_KEY_SHORTCUTS = [
  ['MediaPlayPause', 'play-pause'],
  ['MediaNextTrack', 'next'],
  ['MediaPreviousTrack', 'prev'],
  ['MediaStop', 'stop'],
];
const registeredMediaShortcuts = [];

function registerMediaKeyShortcuts() {
  for (const [accelerator, action] of MEDIA_KEY_SHORTCUTS) {
    try {
      const ok = globalShortcut.register(accelerator, () => {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('media:key', action);
        }
      });
      if (ok) registeredMediaShortcuts.push(accelerator);
    } catch {
      /* another app may own the key — skip silently */
    }
  }
}

/* ── 1.7.0 scrobbling: secrets at rest (Electron safeStorage) ───────────────
 * The Last.fm session key / ListenBrainz token / a user's own Last.fm shared
 * secret are encrypted with the OS keychain (DPAPI on Windows) into
 * userData/secrets.json. Only `scrobble.*` names, ≤ 4 KB values. Where
 * encryption is unavailable (some Linux setups) the value is stored as-is
 * and flagged `plain`. */
const SECRET_NAME_RE = /^scrobble\.[a-z]+\.[a-z]+$/;
const SECRET_MAX = 4096;
function secretsFile() { return path.join(app.getPath('userData'), 'secrets.json'); }
function readSecrets() {
  try {
    const o = JSON.parse(fs.readFileSync(secretsFile(), 'utf8'));
    return o && typeof o === 'object' && !Array.isArray(o) ? o : {};
  } catch {
    return {};
  }
}
function writeSecrets(o) {
  const f = secretsFile();
  const tmp = f + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(o), { mode: 0o600 });
  fs.renameSync(tmp, f);
}
function registerSecretIpc() {
  const { safeStorage } = require('electron');
  const canEncrypt = () => { try { return safeStorage.isEncryptionAvailable(); } catch { return false; } };
  ipcMain.handle('secret:get', (_event, name) => {
    if (typeof name !== 'string' || !SECRET_NAME_RE.test(name)) return null;
    const v = readSecrets()[name];
    if (!v || typeof v.data !== 'string') return null;
    try {
      return v.plain ? Buffer.from(v.data, 'base64').toString('utf8') : safeStorage.decryptString(Buffer.from(v.data, 'base64'));
    } catch {
      return null;
    }
  });
  ipcMain.handle('secret:set', (_event, name, value) => {
    if (typeof name !== 'string' || !SECRET_NAME_RE.test(name)) throw new Error('Blocked secret name');
    if (typeof value !== 'string' || !value || value.length > SECRET_MAX) throw new Error('Invalid secret');
    const o = readSecrets();
    o[name] = canEncrypt()
      ? { data: safeStorage.encryptString(value).toString('base64') }
      : { data: Buffer.from(value, 'utf8').toString('base64'), plain: true };
    writeSecrets(o);
    return true;
  });
  ipcMain.handle('secret:delete', (_event, name) => {
    if (typeof name !== 'string' || !SECRET_NAME_RE.test(name)) return false;
    const o = readSecrets();
    if (!(name in o)) return true;
    delete o[name];
    writeSecrets(o);
    return true;
  });
}

/* ── 1.7.0 duplicate finder: Recycle Bin (never a hard delete) ──────────────
 * Audio files only (same list the reader accepts, minus sidecars), absolute
 * paths of existing regular files, ≤ 500 per call. shell.trashItem moves them
 * to the OS Recycle Bin, so every removal can be undone from Explorer. */
const TRASH_AUDIO_EXTS = new Set(['mp3', 'wav', 'flac', 'ogg', 'oga', 'opus', 'm4a', 'm4b', 'aac', 'alac', 'aif', 'aiff', 'caf', 'webm', 'mp4', 'wma', 'ape', 'amr', '3gp', 'dsf', 'mpc']);
function registerTrashIpc() {
  ipcMain.handle('fs:trash', async (_event, paths) => {
    if (!Array.isArray(paths) || paths.length > 500) throw new Error('Invalid trash request');
    const out = [];
    for (const p of paths) {
      if (typeof p !== 'string' || !path.isAbsolute(p) || p.includes('\0')) { out.push({ path: String(p), ok: false, code: 'E_INVALID' }); continue; }
      if (!TRASH_AUDIO_EXTS.has(extOf(p))) { out.push({ path: p, ok: false, code: 'E_TYPE' }); continue; }
      try {
        const st = await fs.promises.lstat(p);
        if (!st.isFile()) { out.push({ path: p, ok: false, code: 'E_TYPE' }); continue; }
        await shell.trashItem(path.resolve(p));
        out.push({ path: p, ok: true });
      } catch (e) {
        out.push({ path: p, ok: false, code: e && e.code === 'ENOENT' ? 'E_NOT_FOUND' : 'E_BUSY' });
      }
    }
    return out;
  });
}

/* ── shell.openExternal with a scheme allow-list ────────────────────────── */
function registerShellIpc() {
  ipcMain.handle('shell:open-external', async (_event, url) => {
    if (typeof url !== 'string' || !isAllowedExternalUrl(url)) throw new Error('Blocked URL');
    await shell.openExternal(url);
    return true;
  });
}

/* ── 1.8.0 (P5): desktop integration IPC ────────────────────────────────── */
const OPEN_WITH_SUPPORTED = () => process.platform === 'win32' && app.isPackaged;
/** runs reg.exe commands in order; resolves false if an `add` failed */
function runReg(commands) {
  const { execFile } = require('child_process');
  return commands.reduce((prev, args) => prev.then((okSoFar) => new Promise((resolve) => {
    execFile('reg', args, { windowsHide: true, timeout: 15000 }, (err) => resolve(okSoFar && (!err || args[0] === 'delete')));
  })), Promise.resolve(true));
}
async function applyOpenWith(on) {
  if (!OPEN_WITH_SUPPORTED()) return false;
  return runReg(desktop.openWithRegCommands(process.execPath, on));
}
function registerDesktopIpc() {
  /* the renderer has a library: hand over what was opened before that */
  ipcMain.handle('desk:ready', () => {
    rendererReady = true;
    const out = pendingOpen;
    pendingOpen = { files: [], playlists: [] };
    return out;
  });
  ipcMain.handle('desk:read-playlist', async (_event, target) => {
    try {
      const p = assertAbsolutePath(target);
      if (!/\.m3u8?$/i.test(p) || !openedPlaylists.has(playlistKey(p))) return { path: String(target), error: 'E_DENIED' };
      const info = await fsp.stat(p);
      if (!info.isFile()) return { path: p, error: 'E_READ' };
      if (Number(info.size) > 8 * 1024 * 1024) return { path: p, error: 'E_TOO_LARGE' };
      const buf = await fsp.readFile(p);
      return { path: p, bytes: new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength) };
    } catch {
      return { path: String(target), error: 'E_READ' };
    }
  });
  ipcMain.handle('desk:get-prefs', () => ({
    closeToTray: !!desktopPrefs.closeToTray,
    openWith: !!desktopPrefs.openWith,
    platform: process.platform,
    trayAvailable: !!desktopShell?.hasTray,
    openWithSupported: OPEN_WITH_SUPPORTED(),
  }));
  ipcMain.handle('desk:set-pref', async (_event, key, value) => {
    if (typeof value !== 'boolean') return { ok: false };
    if (key === 'closeToTray') {
      desktopPrefs = { ...desktopPrefs, closeToTray: value };
      return { ok: desktop.writePrefs(prefsFile(), desktopPrefs), value };
    }
    if (key === 'openWith') {
      if (!OPEN_WITH_SUPPORTED()) return { ok: false, code: 'E_UNSUPPORTED', value: false };
      const ok = await applyOpenWith(value);
      if (ok) { desktopPrefs = { ...desktopPrefs, openWith: value }; desktop.writePrefs(prefsFile(), desktopPrefs); }
      return { ok, value: !!desktopPrefs.openWith };
    }
    return { ok: false };
  });
  /* 1.8.0-dev.2: global hotkeys */
  const hotkeyPayload = () => {
    const c = hotkeys ? hotkeys.config : desktop.cleanHotkeys(desktopPrefs.hotkeys);
    return { enabled: c.enabled, map: c.map, status: hotkeys ? hotkeys.status : {}, defaults: { ...desktop.DEFAULT_HOTKEYS }, actions: [...desktop.HOTKEY_ACTIONS], supported: !!hotkeys };
  };
  ipcMain.handle('desk:get-hotkeys', () => hotkeyPayload());
  ipcMain.handle('desk:set-hotkeys', (_event, patch) => {
    if (!hotkeys) return { ok: false, code: 'E_UNSUPPORTED', ...hotkeyPayload() };
    if (!patch || typeof patch !== 'object') return { ok: false, code: 'E_INVALID', ...hotkeyPayload() };
    const cur = hotkeys.config;
    const next = { enabled: cur.enabled, map: { ...cur.map } };
    if (patch.enabled !== undefined) {
      if (typeof patch.enabled !== 'boolean') return { ok: false, code: 'E_INVALID', ...hotkeyPayload() };
      next.enabled = patch.enabled;
    }
    if (patch.map !== undefined) {
      if (!patch.map || typeof patch.map !== 'object') return { ok: false, code: 'E_INVALID', ...hotkeyPayload() };
      for (const [a, v] of Object.entries(patch.map)) {
        if (!desktop.HOTKEY_ACTIONS.includes(a)) return { ok: false, code: 'E_INVALID', action: a, ...hotkeyPayload() };
        const n = desktop.normalizeAccelerator(v);
        if (n === null) return { ok: false, code: 'E_INVALID', action: a, ...hotkeyPayload() };
        next.map[a] = n;
      }
      const seen = new Map();
      for (const a of desktop.HOTKEY_ACTIONS) {
        const v = next.map[a];
        if (!v) continue;
        if (seen.has(v)) return { ok: false, code: 'E_DUPLICATE', action: a, other: seen.get(v), ...hotkeyPayload() };
        seen.set(v, a);
      }
    }
    if (hotkeySuspendTimer) { clearTimeout(hotkeySuspendTimer); hotkeySuspendTimer = null; }
    hotkeys.suspend(false);
    hotkeys.set(next);
    desktopPrefs = { ...desktopPrefs, hotkeys: hotkeys.config };
    const saved = desktop.writePrefs(prefsFile(), desktopPrefs);
    return { ok: saved, ...hotkeyPayload() };
  });
  /* while the renderer records a combo our own shortcuts must stay quiet;
   * a crashed / reloaded renderer can't leave them off: 20 s cap */
  ipcMain.handle('desk:hotkeys-suspend', (_event, on) => {
    if (!hotkeys) return hotkeyPayload();
    if (hotkeySuspendTimer) { clearTimeout(hotkeySuspendTimer); hotkeySuspendTimer = null; }
    hotkeys.suspend(on === true);
    if (on === true) hotkeySuspendTimer = setTimeout(() => { hotkeySuspendTimer = null; hotkeys?.suspend(false); }, 20000);
    return hotkeyPayload();
  });
  ipcMain.on('desk:labels', (_event, labels) => desktopShell?.setLabels(labels));
  ipcMain.on('desk:now-playing', (_event, np) => desktopShell?.setNowPlaying(np));
}

/* ── App lifecycle ──────────────────────────────────────────────────────── */

app.whenReady().then(() => {
  // No application menu — the app draws its own titlebar chrome.
  Menu.setApplicationMenu(null);

  // Deny every web permission request (mic/cam/notifications… not needed).
  app.on('web-contents-created', (_event, contents) => {
    contents.session.setPermissionRequestHandler((_wc, permission, callback) => {
      callback(false);
      void permission;
    });
  });

  registerAppProtocol();
  registerWindowIpc();
  registerCompactIpc();
  registerDialogIpc();
  registerFsIpc();
  registerTagsIpc();
  registerPlaylistIpc();
  registerHttpIpc();
  registerSecretIpc();
  registerTrashIpc();
  registerShellIpc();
  desktopPrefs = desktop.readPrefs(prefsFile());
  registerDesktopIpc();

  // 1.8.0 (P5): tray, thumbnail toolbar, jump list (before the window, so
  // its first 'show' already finds the shell)
  desktopShell = desktop.createDesktopShell({
    electron: { Tray, Menu, nativeImage, app },
    getWindow: () => mainWindow,
    send: sendPlayerCommand,
    iconPath: resolveIcon(),
    assetsDir: path.join(__dirname, 'assets'),
    isWin: process.platform === 'win32',
    toggleWindow: toggleMainWindow,
    onQuit: quitApp,
  });
  desktopShell.start();
  // re-point "Open with" at this exe (an update may have moved it)
  if (desktopPrefs.openWith && OPEN_WITH_SUPPORTED()) void applyOpenWith(true);

  createWindow();


  // #9 — registered AFTER window creation so the webContents target for
  // 'media:key' already exists.
  registerMediaKeyShortcuts();
  // 1.8.0-dev.2: the user's own global hotkeys (off by default)
  hotkeys = desktop.createHotkeys({
    globalShortcut,
    onAction: (action) => { if (action === 'show-hide') toggleMainWindow(); else sendPlayerCommand(action); },
  });
  hotkeys.set(desktopPrefs.hotkeys);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', () => { isQuitting = true; });

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

/* #9 — never leak OS-global media keys past our lifetime (registered once,
 * outside whenReady, exactly like window-all-closed). */
app.on('will-quit', () => {
  globalShortcut.unregisterAll();
  desktopShell?.destroy();
});
