/**
 * NOBODY 1.8.0-dev.4 · Windows process + elevation helpers (Phase 5 · installer hardening).
 *
 * Shared by the uninstaller (uninstall.cjs). setup-app/electron/winproc.ts is
 * the TypeScript twin used by NOBODY Setup; docs/tests/installer-run.cjs keeps
 * the two in lock-step.
 *
 *   - "kill only our own install": processes are matched by their FULL image
 *     path (inside the install dir), never by the image name. A portable copy,
 *     a second install or an unrelated NOBODY.exe is left alone.
 *   - graceful first: `<install>\NOBODY.exe --nobody-quit` asks the running
 *     player to quit (main.cjs honours it only from its own install dir);
 *     a bounded force-kill of the verified PIDs is the fallback.
 *   - elevation: PowerShell Start-Process -Verb RunAs, passed as
 *     -EncodedCommand (UTF-16LE base64) so no path or argument can break out
 *     of the quoting.
 */
'use strict';

const path = require('path');
const { execFile, execFileSync, spawn } = require('child_process');

const QUIT_FLAG = '--nobody-quit';

/** PowerShell -EncodedCommand payload */
function psEncode(script) {
  return Buffer.from(String(script), 'utf16le').toString('base64');
}
/** single-quoted PowerShell literal */
function psQuote(s) {
  return "'" + String(s).replace(/'/g, "''") + "'";
}

/** script: every process with this image name → [{ ProcessId, ExecutablePath }] as JSON */
function listScript(exeName) {
  const name = String(exeName).replace(/'/g, "''");
  return (
    "$ErrorActionPreference='SilentlyContinue';" +
    `@(Get-CimInstance Win32_Process -Filter "Name='${name}'" | Select-Object ProcessId,ExecutablePath) | ConvertTo-Json -Compress`
  );
}

/** ConvertTo-Json output → [{ pid, path }] (one object or an array; junk → []) */
function parseProcessJson(out) {
  let v;
  try {
    v = JSON.parse(String(out || '').trim() || '[]');
  } catch {
    return [];
  }
  const arr = Array.isArray(v) ? v : v && typeof v === 'object' ? [v] : [];
  const res = [];
  for (const o of arr) {
    const pid = Number(o && o.ProcessId);
    if (!Number.isInteger(pid) || pid <= 0) continue;
    res.push({ pid, path: typeof o.ExecutablePath === 'string' && o.ExecutablePath ? o.ExecutablePath : null });
  }
  return res;
}

const norm = (p, win) => {
  const r = (win ? path.win32 : path.posix).resolve(String(p));
  return win ? r.toLowerCase() : r;
};

/**
 * PIDs that belong to THIS install: image path inside installDir, never our
 * own pid. A null path (another user's / elevated process we can't inspect)
 * is not provably ours → never killed.
 */
function ownInstallPids({ list, installDir, ownPid, isWin = process.platform === 'win32' }) {
  const P = isWin ? path.win32 : path.posix;
  const root = norm(installDir, isWin);
  const out = [];
  for (const p of list || []) {
    if (!p || p.pid === ownPid || !p.path) continue;
    const img = norm(p.path, isWin);
    const rel = P.relative(root, img);
    if (!rel || rel.startsWith('..') || P.isAbsolute(rel)) continue;
    out.push(p.pid);
  }
  return out;
}

/** script: start `exe args…` elevated; exit 0 = started, 1223 = UAC refused */
function elevateScript(exe, args) {
  const list = (args || []).map(psQuote).join(',');
  return (
    "$ErrorActionPreference='Stop';" +
    `try { Start-Process -FilePath ${psQuote(exe)}${list ? ` -ArgumentList ${list}` : ''} -Verb RunAs | Out-Null; exit 0 } catch { exit 1223 }`
  );
}

const IS_ADMIN_SCRIPT =
  "if (([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 0 } else { exit 1 }";

const psArgs = (script) => ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', psEncode(script)];

/* ── Windows glue (not unit-testable here; thin on purpose) ──────────── */

function listProcesses(exeName) {
  if (process.platform !== 'win32') return [];
  try {
    const out = execFileSync('powershell.exe', psArgs(listScript(exeName)), { encoding: 'utf8', timeout: 15000, windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] });
    return parseProcessJson(out);
  } catch {
    return [];
  }
}

let elevatedCache = null;
function isElevated() {
  if (process.platform !== 'win32') return typeof process.getuid === 'function' && process.getuid() === 0;
  if (elevatedCache !== null) return elevatedCache;
  try {
    execFileSync('powershell.exe', psArgs(IS_ADMIN_SCRIPT), { timeout: 15000, windowsHide: true, stdio: 'ignore' });
    elevatedCache = true;
  } catch {
    elevatedCache = false;
  }
  return elevatedCache;
}

/** → Promise<'started' | 'denied' | 'error'> */
function relaunchElevated(exe, args) {
  return new Promise((resolve) => {
    if (process.platform !== 'win32') { resolve('error'); return; }
    execFile('powershell.exe', psArgs(elevateScript(exe, args)), { windowsHide: true, timeout: 120000 }, (err) => {
      if (!err) resolve('started');
      else resolve(err.code === 1223 ? 'denied' : 'error');
    });
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Close every NOBODY running from installDir (except us).
 * deps (for tests): { list(), quit(exe), kill(pid), now(), sleep(ms) }
 * → { found, graceful, killed }
 */
async function closeInstall({ installDir, exeName, ownPid = process.pid, graceful = true, waitMs = 6000, isWin = process.platform === 'win32' }, deps = {}) {
  const list = deps.list || (() => listProcesses(exeName));
  const P = isWin ? path.win32 : path.posix;
  const quit = deps.quit || ((exe) => {
    try { const c = spawn(exe, [QUIT_FLAG], { detached: true, stdio: 'ignore', windowsHide: true }); c.unref(); } catch { /* best-effort */ }
  });
  const kill = deps.kill || ((pid) => {
    try { execFileSync('taskkill', ['/F', '/T', '/PID', String(pid)], { timeout: 15000, windowsHide: true, stdio: 'ignore' }); } catch { /* gone */ }
  });
  const nap = deps.sleep || sleep;
  const mine = () => ownInstallPids({ list: list(), installDir, ownPid, isWin });
  let pids = mine();
  const found = pids.length;
  if (!found) return { found: 0, graceful: 0, killed: 0 };
  if (graceful) {
    quit(P.join(installDir, exeName));
    for (let t = 0; t < waitMs && pids.length; t += 250) {
      await nap(250);
      pids = mine();
    }
  }
  const left = pids.length;
  for (const pid of pids) kill(pid);
  return { found, graceful: found - left, killed: left };
}

module.exports = {
  QUIT_FLAG,
  psEncode,
  psQuote,
  listScript,
  parseProcessJson,
  ownInstallPids,
  elevateScript,
  listProcesses,
  isElevated,
  relaunchElevated,
  closeInstall,
};
