/* ─────────────────────────────────────────────────────────────────────────
 * NOBODY — desktop integration (1.8.0, Phase 5 · part 1)
 *
 *   • window state   remember size / position / maximized across launches,
 *                    never restore onto a monitor that is gone
 *   • open with      audio / .m3u files from the command line, a second
 *                    launch, macOS open-file; queued until the UI is ready
 *   • "Open with"    per-user (HKCU, no UAC) registration on Windows
 *   • tray           now playing + Play/Pause, Next, Previous, Show, Quit;
 *                    optional "keep playing in the tray" on close
 *   • taskbar        thumbnail toolbar ⏮ ⏯ ⏭ + jump list tasks
 *
 * Pure helpers are exported for docs/tests/desktop-run.cjs; the stateful
 * part (createDesktopShell) gets Electron injected, so it runs against a
 * fake in tests. Every player command is forwarded to the renderer as the
 * existing `media:key` IPC: Classic and the shared engine already answer it.
 * ───────────────────────────────────────────────────────────────────────── */
'use strict';
const path = require('path');
const fs = require('fs');

const AUDIO_EXTS = ['mp3', 'flac', 'wav', 'ogg', 'oga', 'opus', 'm4a', 'm4b', 'aac', 'alac', 'aif', 'aiff', 'wma', 'ape', 'webm', 'dsf', 'mpc'];
const PLAYLIST_EXTS = ['m3u', 'm3u8'];
const AUDIO_RE = new RegExp(`\\.(${AUDIO_EXTS.join('|')})$`, 'i');
const PLAYLIST_RE = /\.m3u8?$/i;
const COMMANDS = new Set(['play-pause', 'next', 'prev', 'stop']);
const MAX_OPEN = 500;

/* ── command line ─────────────────────────────────────────────────────── */
/** argv → { files, playlists, cmd }. argv[0] is the exe; switches are skipped
 *  (Chromium may append its own), relative paths resolve against `cwd`, only
 *  audio / playlist extensions count (dev runs pass "." / the app path). */
function parseOpenArgs(argv, cwd) {
  const out = { files: [], playlists: [], cmd: null };
  const seen = new Set();
  const list = Array.isArray(argv) ? argv.slice(1) : [];
  for (const raw of list) {
    if (typeof raw !== 'string' || !raw) continue;
    const m = /^--nobody-cmd=([a-z-]+)$/.exec(raw);
    if (m) { if (COMMANDS.has(m[1])) out.cmd = m[1]; continue; }
    if (raw.startsWith('-')) continue;
    let p = raw.replace(/^"(.*)"$/, '$1');
    if (/^file:\/\//i.test(p)) { try { p = require('url').fileURLToPath(p); } catch { continue; } }
    if (!path.isAbsolute(p)) p = path.resolve(cwd || process.cwd(), p);
    p = path.normalize(p);
    if (p.includes('\0')) continue;
    const key = process.platform === 'win32' ? p.toLowerCase() : p;
    if (seen.has(key)) continue;
    if (AUDIO_RE.test(p)) { seen.add(key); out.files.push(p); }
    else if (PLAYLIST_RE.test(p)) { seen.add(key); out.playlists.push(p); }
    if (out.files.length + out.playlists.length >= MAX_OPEN) break;
  }
  return out;
}

/* ── window state ─────────────────────────────────────────────────────── */
function readWindowState(file) {
  try {
    const o = JSON.parse(fs.readFileSync(file, 'utf8'));
    const n = (v) => (typeof v === 'number' && Number.isFinite(v) ? Math.round(v) : null);
    const s = { x: n(o.x), y: n(o.y), width: n(o.width), height: n(o.height), maximized: o.maximized === true };
    if (!(s.width > 0 && s.height > 0)) return null;
    return s;
  } catch {
    return null;
  }
}
function writeWindowState(file, s) {
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify({ x: s.x, y: s.y, width: s.width, height: s.height, maximized: !!s.maximized }));
    fs.renameSync(tmp, file);
    return true;
  } catch {
    return false;
  }
}
const overlap = (a, b) => Math.max(0, Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y));
/** Saved state → BrowserWindow bounds that are usable on the CURRENT
 *  monitors. Size is clamped to [min, the work area it lands on]. The
 *  window keeps its position only if ≥ 120 × 32 px of it is on some work
 *  area (then its title strip is pulled onto that area); otherwise it is
 *  centred (no x/y).
 *  `displays`: [{ workArea: {x,y,width,height} }], first = primary. */
function fitWindowState(saved, displays, opt) {
  const { defW, defH, minW, minH } = opt;
  const areas = (displays || []).map((d) => d && d.workArea).filter((a) => a && a.width > 0 && a.height > 0);
  const primary = areas[0] || { x: 0, y: 0, width: defW, height: defH };
  if (!saved) return { width: Math.min(defW, primary.width), height: Math.min(defH, primary.height), maximized: false, center: true };
  let width = Math.max(minW, saved.width);
  let height = Math.max(minH, saved.height);
  if (saved.x !== null && saved.y !== null) {
    const rect = { x: saved.x, y: saved.y, width, height };
    let best = null; let bestArea = 0;
    for (const a of areas) { const o = overlap(rect, a); if (o > bestArea) { bestArea = o; best = a; } }
    const visW = best ? Math.min(saved.x + width, best.x + best.width) - Math.max(saved.x, best.x) : 0;
    const visH = best ? Math.min(saved.y + height, best.y + best.height) - Math.max(saved.y, best.y) : 0;
    if (best && visW >= 120 && visH >= 32) {
      width = Math.min(width, Math.max(minW, best.width));
      height = Math.min(height, Math.max(minH, best.height));
      // pull the title strip fully onto that work area
      const x = Math.min(Math.max(saved.x, best.x - width + 120), best.x + best.width - 120);
      const y = Math.min(Math.max(saved.y, best.y), best.y + best.height - 32);
      return { x, y, width, height, maximized: saved.maximized, center: false };
    }
  }
  return { width: Math.min(width, Math.max(minW, primary.width)), height: Math.min(height, Math.max(minH, primary.height)), maximized: saved.maximized, center: true };
}

/* ── "Open with" (Windows, per user) ──────────────────────────────────── */
const PROG_AUDIO = 'NOBODY.AudioFile';
const PROG_LIST = 'NOBODY.Playlist';
const CLASSES = 'HKCU\\Software\\Classes';
/** reg.exe argument lists. register=true writes, false removes (each delete
 *  may fail harmlessly when the key is already gone). */
function openWithRegCommands(exePath, register, exeName = path.win32.basename(exePath || 'NOBODY.exe')) {
  const cmd = `"${exePath}" "%1"`;
  const icon = `"${exePath}",0`;
  const app = `${CLASSES}\\Applications\\${exeName}`;
  const exts = [...AUDIO_EXTS.map((e) => [e, PROG_AUDIO]), ...PLAYLIST_EXTS.map((e) => [e, PROG_LIST])];
  if (!register) {
    return [
      ...exts.map(([e, prog]) => ['delete', `${CLASSES}\\.${e}\\OpenWithProgids`, '/v', prog, '/f']),
      ['delete', `${CLASSES}\\${PROG_AUDIO}`, '/f'],
      ['delete', `${CLASSES}\\${PROG_LIST}`, '/f'],
      ['delete', app, '/f'],
    ];
  }
  const out = [];
  for (const [prog, label] of [[PROG_AUDIO, 'NOBODY audio file'], [PROG_LIST, 'NOBODY playlist']]) {
    out.push(['add', `${CLASSES}\\${prog}`, '/ve', '/d', label, '/f']);
    out.push(['add', `${CLASSES}\\${prog}\\DefaultIcon`, '/ve', '/d', icon, '/f']);
    out.push(['add', `${CLASSES}\\${prog}\\shell\\open\\command`, '/ve', '/d', cmd, '/f']);
  }
  out.push(['add', app, '/v', 'FriendlyAppName', '/d', 'NOBODY', '/f']);
  out.push(['add', `${app}\\DefaultIcon`, '/ve', '/d', icon, '/f']);
  out.push(['add', `${app}\\shell\\open\\command`, '/ve', '/d', cmd, '/f']);
  for (const [e, prog] of exts) {
    out.push(['add', `${app}\\SupportedTypes`, '/v', `.${e}`, '/d', '', '/f']);
    out.push(['add', `${CLASSES}\\.${e}\\OpenWithProgids`, '/v', prog, '/t', 'REG_NONE', '/f']);
  }
  return out;
}

/* ── tray / taskbar text ──────────────────────────────────────────────── */
const DEFAULT_LABELS = { play: 'Play', pause: 'Pause', next: 'Next', prev: 'Previous', show: 'Show NOBODY', hide: 'Hide NOBODY', quit: 'Quit NOBODY', nothing: 'Nothing playing', trayNote: 'NOBODY keeps playing here. Right-click for controls.' };
function cleanLabels(o) {
  const out = { ...DEFAULT_LABELS };
  if (o && typeof o === 'object') for (const k of Object.keys(DEFAULT_LABELS)) if (typeof o[k] === 'string' && o[k].trim()) out[k] = o[k].trim().slice(0, 120);
  return out;
}
function cleanNowPlaying(o) {
  const s = (v) => (typeof v === 'string' ? v.replace(/[\r\n\t]+/g, ' ').trim().slice(0, 200) : '');
  return { title: s(o && o.title), artist: s(o && o.artist), playing: !!(o && o.playing) };
}
/** "Title — Artist" (bounded for the 127-char Windows tray tooltip) */
function nowPlayingText(np, max = 127) {
  if (!np || !np.title) return '';
  const t = np.artist ? `${np.title} — ${np.artist}` : np.title;
  return t.length > max ? t.slice(0, max - 1) + '…' : t;
}
function windowTitle(np) {
  const t = nowPlayingText(np, 200);
  return t ? `${t} · NOBODY` : 'NOBODY';
}


/* ── 1.8.0-dev.2 (P5 · part 2): configurable global hotkeys ──────────────
 * Stored in desktop.json as { enabled, map: { action: accelerator } }.
 * Accelerators are kept in ONE canonical form ("Ctrl+Alt+Shift+Super+Key")
 * so duplicates are easy to spot. Keys are physical (the renderer records
 * KeyboardEvent.code), so a combo set on a Persian / Russian layout still
 * fires on an English one. Off by default: a player must never grab keys
 * the user didn't ask for. */
const HOTKEY_ACTIONS = ['play-pause', 'next', 'prev', 'stop', 'vol-up', 'vol-down', 'show-hide'];
const DEFAULT_HOTKEYS = Object.freeze({
  'play-pause': 'Ctrl+Alt+Space',
  next: 'Ctrl+Alt+Right',
  prev: 'Ctrl+Alt+Left',
  stop: '',
  'vol-up': 'Ctrl+Alt+Up',
  'vol-down': 'Ctrl+Alt+Down',
  'show-hide': 'Ctrl+Alt+N',
});
const MOD_ORDER = ['Ctrl', 'Alt', 'Shift', 'Super'];
const MOD_ALIAS = { ctrl: 'Ctrl', control: 'Ctrl', commandorcontrol: 'Ctrl', cmdorctrl: 'Ctrl', alt: 'Alt', option: 'Alt', altgr: null, shift: 'Shift', super: 'Super', meta: 'Super', win: 'Super', cmd: 'Super', command: 'Super' };
const NAMED_KEYS = ['Space', 'Up', 'Down', 'Left', 'Right', 'Home', 'End', 'PageUp', 'PageDown', 'Insert', 'Delete', 'Backspace', 'Tab', 'Enter',
  'Plus', '-', '=', ',', '.', '/', ';', "'", '[', ']', '\\', '`',
  'num0', 'num1', 'num2', 'num3', 'num4', 'num5', 'num6', 'num7', 'num8', 'num9', 'numadd', 'numsub', 'nummult', 'numdiv', 'numdec'];
const KEY_ALIAS = { arrowup: 'Up', arrowdown: 'Down', arrowleft: 'Left', arrowright: 'Right', pgup: 'PageUp', pgdn: 'PageDown', del: 'Delete', ins: 'Insert', return: 'Enter', ' ': 'Space', minus: '-', equal: '=', comma: ',', period: '.', slash: '/', semicolon: ';', quote: "'", backquote: '`', backslash: '\\', bracketleft: '[', bracketright: ']' };
/** combos the OS keeps for itself (or that would trap the user) */
const RESERVED = new Set(['Ctrl+Alt+Delete', 'Alt+Tab', 'Alt+F4', 'Ctrl+Shift+Escape', 'Super+L', 'Super+D', 'Super+Tab', 'Alt+Space', 'Ctrl+Escape', 'Alt+Escape', 'Super+Space']);

function canonKey(raw) {
  const k = String(raw);
  if (/^[a-z]$/i.test(k)) return k.toUpperCase();
  if (/^[0-9]$/.test(k)) return k;
  const f = /^f([1-9]|1[0-9]|2[0-4])$/i.exec(k); if (f) return 'F' + f[1];
  const low = k.toLowerCase();
  if (KEY_ALIAS[low] !== undefined) return KEY_ALIAS[low];
  if (KEY_ALIAS[k] !== undefined) return KEY_ALIAS[k];
  const named = NAMED_KEYS.find((n) => n.toLowerCase() === low);
  return named || null;
}
/**
 * "ctrl + alt + right" → "Ctrl+Alt+Right"; '' for empty; null when invalid.
 * Rules: exactly one non-modifier key; Ctrl, Alt or Super is required
 * (Shift+letter would eat typing) except for F13–F24; no OS-reserved combo.
 */
function normalizeAccelerator(input) {
  if (input === '' || input === null || input === undefined) return '';
  if (typeof input !== 'string' || input.length > 64) return null;
  const parts = input.split('+').map((x) => x.trim());
  // "Ctrl+Plus" may arrive as "Ctrl++"
  const tokens = [];
  for (let i = 0; i < parts.length; i++) {
    if (parts[i] === '' && i === parts.length - 1 && parts[i - 1] === '') { tokens.push('Plus'); continue; }
    if (parts[i] === '') continue;
    tokens.push(parts[i]);
  }
  const mods = new Set(); let key = null;
  for (const t of tokens) {
    const low = t.toLowerCase();
    if (Object.prototype.hasOwnProperty.call(MOD_ALIAS, low)) {
      const m = MOD_ALIAS[low];
      if (!m || mods.has(m)) return null;
      mods.add(m); continue;
    }
    if (key) return null;
    key = canonKey(t);
    if (!key) return null;
  }
  if (!key) return null;
  const fHigh = /^F(1[3-9]|2[0-4])$/.test(key);
  if (!fHigh && !mods.has('Ctrl') && !mods.has('Alt') && !mods.has('Super')) return null;
  const out = [...MOD_ORDER.filter((m) => mods.has(m)), key].join('+');
  return RESERVED.has(out) ? null : out;
}
/** stored value → { enabled, map } (unknown actions dropped, bad / repeated combos cleared) */
function cleanHotkeys(o) {
  const src = o && typeof o === 'object' ? o : {};
  const inMap = src.map && typeof src.map === 'object' ? src.map : null;
  const map = {}; const seen = new Set();
  for (const a of HOTKEY_ACTIONS) {
    let v = inMap && Object.prototype.hasOwnProperty.call(inMap, a) ? normalizeAccelerator(inMap[a]) : DEFAULT_HOTKEYS[a];
    if (v === null) v = '';
    if (v && seen.has(v)) v = '';
    if (v) seen.add(v);
    map[a] = v;
  }
  return { enabled: src.enabled === true, map };
}
/**
 * Registers the enabled hotkeys. deps: { globalShortcut, onAction(action) }.
 * Returns a controller; status per action: 'ok' | 'taken' (another app owns
 * it) | 'unset' | 'off' (feature off / suspended).
 */
function createHotkeys(deps) {
  const { globalShortcut } = deps;
  let cfg = cleanHotkeys(null);
  let mine = [];
  let suspended = false;
  let status = {};
  const offAll = () => { for (const a of HOTKEY_ACTIONS) status[a] = cfg.map[a] ? 'off' : 'unset'; };
  function release() {
    for (const acc of mine) { try { globalShortcut.unregister(acc); } catch { /* ignore */ } }
    mine = [];
  }
  function apply() {
    release(); status = {};
    if (!cfg.enabled || suspended) { offAll(); return status; }
    for (const a of HOTKEY_ACTIONS) {
      const acc = cfg.map[a];
      if (!acc) { status[a] = 'unset'; continue; }
      let ok = false;
      try { ok = !!globalShortcut.register(acc, () => deps.onAction(a)); } catch { ok = false; }
      if (ok) mine.push(acc);
      status[a] = ok ? 'ok' : 'taken';
    }
    return status;
  }
  return {
    set(next) { cfg = cleanHotkeys(next); return apply(); },
    /** while the renderer records a combo, ours must not fire */
    suspend(on) { const want = !!on; if (want === suspended) return status; suspended = want; return apply(); },
    get config() { return { enabled: cfg.enabled, map: { ...cfg.map } }; },
    get status() { return { ...status }; },
    get suspended() { return suspended; },
    release,
  };
}

/* ── prefs (userData/desktop.json, read before the UI exists) ─────────── */
const DEFAULT_PREFS = { closeToTray: false, openWith: false, trayNoteShown: false };
function readPrefs(file) {
  try { const o = JSON.parse(fs.readFileSync(file, 'utf8')); return { ...DEFAULT_PREFS, ...pick(o) }; } catch { return { ...DEFAULT_PREFS }; }
}
function pick(o) {
  const out = {};
  if (o && typeof o === 'object') {
    for (const k of Object.keys(DEFAULT_PREFS)) if (typeof o[k] === 'boolean') out[k] = o[k];
    if (o.hotkeys && typeof o.hotkeys === 'object') out.hotkeys = cleanHotkeys(o.hotkeys);
  }
  return out;
}
function writePrefs(file, p) {
  try { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify({ ...DEFAULT_PREFS, ...pick(p) })); return true; } catch { return false; }
}

/* ── the stateful shell: tray + thumbar + jump list ───────────────────── */
/**
 * deps: { electron: { Tray, Menu, nativeImage, app }, getWindow(), send(cmd),
 *         iconPath, assetsDir, isWin, onQuit(), toggleWindow() }
 */
function createDesktopShell(deps) {
  const { electron, getWindow, send, iconPath, assetsDir, isWin } = deps;
  const { Tray, Menu, nativeImage, app } = electron;
  let tray = null;
  let labels = cleanLabels(null);
  let np = cleanNowPlaying(null);
  const img = (name) => { try { const i = nativeImage.createFromPath(path.join(assetsDir, name)); return i && !i.isEmpty() ? i : null; } catch { return null; } };
  const icons = { prev: img('thumb-prev.png'), play: img('thumb-play.png'), pause: img('thumb-pause.png'), next: img('thumb-next.png') };

  function trayImage() {
    try {
      const i = nativeImage.createFromPath(iconPath);
      if (!i || i.isEmpty()) return nativeImage.createEmpty();
      return i.resize({ width: 16, height: 16, quality: 'best' });
    } catch { return nativeImage.createEmpty(); }
  }
  function visible() { const w = getWindow(); return !!(w && !w.isDestroyed() && w.isVisible() && !w.isMinimized()); }
  function menu() {
    const text = nowPlayingText(np, 60);
    return Menu.buildFromTemplate([
      { label: text || labels.nothing, enabled: false },
      { type: 'separator' },
      { label: np.playing ? labels.pause : labels.play, click: () => send('play-pause') },
      { label: labels.next, click: () => send('next') },
      { label: labels.prev, click: () => send('prev') },
      { type: 'separator' },
      { label: visible() ? labels.hide : labels.show, click: () => deps.toggleWindow() },
      { type: 'separator' },
      { label: labels.quit, click: () => deps.onQuit() },
    ]);
  }
  function refreshTray() {
    if (!tray) return;
    const t = nowPlayingText(np);
    try { tray.setToolTip(t ? (t.length + 10 <= 127 ? `${t} · NOBODY` : t) : 'NOBODY'); } catch { /* ignore */ }
    try { tray.setContextMenu(menu()); } catch { /* ignore */ }
  }
  function refreshThumbar() {
    if (!isWin) return;
    const w = getWindow();
    if (!w || w.isDestroyed() || !icons.prev || !icons.next || !icons.play || !icons.pause) return;
    try {
      w.setThumbarButtons([
        { tooltip: labels.prev, icon: icons.prev, click: () => send('prev') },
        { tooltip: np.playing ? labels.pause : labels.play, icon: np.playing ? icons.pause : icons.play, click: () => send('play-pause') },
        { tooltip: labels.next, icon: icons.next, click: () => send('next') },
      ]);
    } catch { /* window not shown yet: retried on show */ }
  }
  function refreshJumpList() {
    if (!isWin || !app.setUserTasks) return;
    const program = process.execPath;
    const pre = app.isPackaged ? '' : `"${app.getAppPath()}" `;
    try {
      app.setUserTasks([
        { program, arguments: `${pre}--nobody-cmd=play-pause`, iconPath: program, iconIndex: 0, title: `${labels.play} / ${labels.pause}`, description: `${labels.play} / ${labels.pause}` },
        { program, arguments: `${pre}--nobody-cmd=next`, iconPath: program, iconIndex: 0, title: labels.next, description: labels.next },
        { program, arguments: `${pre}--nobody-cmd=prev`, iconPath: program, iconIndex: 0, title: labels.prev, description: labels.prev },
      ]);
    } catch { /* ignore */ }
  }
  function refreshTitle() {
    const w = getWindow();
    if (w && !w.isDestroyed()) { try { w.setTitle(windowTitle(np)); } catch { /* ignore */ } }
  }

  return {
    start() {
      try {
        tray = new Tray(trayImage());
        tray.on('click', () => deps.toggleWindow());
        refreshTray();
      } catch { tray = null; /* no tray on this desktop (some Linux) */ }
      refreshJumpList();
    },
    /** window shown / recreated: Windows drops thumbar buttons with it */
    attachWindow() { refreshThumbar(); refreshTitle(); },
    setLabels(o) { labels = cleanLabels(o); refreshTray(); refreshThumbar(); refreshJumpList(); },
    setNowPlaying(o) {
      const next = cleanNowPlaying(o);
      const changed = next.title !== np.title || next.artist !== np.artist || next.playing !== np.playing;
      np = next;
      if (!changed) return false;
      refreshTray(); refreshThumbar(); refreshTitle();
      return true;
    },
    /** window visibility changed: the Show/Hide item follows */
    refresh() { refreshTray(); },
    balloon(text) {
      if (!tray || !isWin || !tray.displayBalloon) return;
      try { tray.displayBalloon({ title: 'NOBODY', content: text || labels.trayNote, iconType: 'none', noSound: true }); } catch { /* ignore */ }
    },
    get hasTray() { return !!tray; },
    get state() { return { labels, np, tray: !!tray }; },
    destroy() { try { tray && tray.destroy(); } catch { /* ignore */ } tray = null; },
  };
}

module.exports = {
  AUDIO_EXTS, PLAYLIST_EXTS, COMMANDS,
  parseOpenArgs, readWindowState, writeWindowState, fitWindowState,
  openWithRegCommands, PROG_AUDIO, PROG_LIST,
  cleanLabels, cleanNowPlaying, nowPlayingText, windowTitle,
  readPrefs, writePrefs, DEFAULT_PREFS,
  HOTKEY_ACTIONS, DEFAULT_HOTKEYS, normalizeAccelerator, cleanHotkeys, createHotkeys,
  createDesktopShell,
};
